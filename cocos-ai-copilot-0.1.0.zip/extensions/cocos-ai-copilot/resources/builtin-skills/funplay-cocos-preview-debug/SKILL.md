---
name: funplay-cocos-preview-debug
description: "Operate and debug a running Cocos Creator Game View through the Cocos AI Copilot built-in Cocos Runtime. Use for Preview click, pointer, touch, drag, restart-safe runtime validation, and Preview runtime-error diagnosis."
---

# Cocos Preview Operation and Debugging

Use the existing Cocos Runtime tools. Do not automate the Windows cursor, use desktop coordinates, dispatch into the edit Scene, or create another Preview bridge.

## Run and bind the Preview

1. Start the intended scene with `run_project_preview` using `mode: "gameView"` when runtime interaction is authorized.
2. Call `simulate_preview_input` for the first intended action without inventing a session ID. Retain the returned `previewSessionId` and pass it to every later action in that Preview run.
3. If Preview was intentionally restarted, obtain the replacement session ID from a fresh action. If a session mismatch occurs unexpectedly, stop the sequence and inspect the current Preview instead of retrying into it blindly.

The Local Tool already waits for the Preview guest and GameCanvas readiness for a bounded period. A readiness error is not a successful input.

## Choose input precisely

- Prefer `target.path` or `target.uuid`. Use `target.name` only when it is unique; resolve an ambiguity with an exact path or UUID.
- Use `click` for a mouse-style activation, `drag` for a mouse drag, `tap` for a real Cocos touch tap, and `touchDrag` for a real touch move sequence.
- For coordinate-only input, prefer `coordinateSpace: "normalized"` for resolution-independent positions. Use canvas, client, or Cocos view coordinates only when the task supplies or requires that coordinate system.
- Give drag a finite `steps` and `durationMs`; do not replace a drag with a start/end teleport.
- Use manual down/move/up only when the task genuinely needs an open pointer lifecycle. Cancel or release it before ending or restarting Preview.

Do not treat `sent: true` as gameplay success. It proves dispatch, not game behavior.

## Verify runtime behavior

After each meaningful interaction, read a semantic runtime invariant such as game state, node position, component value, or visible text. Capture the Game View only when appearance is part of the evidence. A normal interaction proof combines:

- the input result and its `previewSessionId`;
- a changed runtime value from the same session; and
- a screenshot when visual placement matters.

For a standard interaction loop, verify Start, the requested action, drag destination, and Restart/reset independently. When touch support is relevant, verify that the game listener received touch start, move, and end rather than assuming a renamed click is touch.

In Creator desktop Preview, a mouse sequence is intentionally converted into a touch sequence before its matching mouse event is dispatched. UI hit testing can consume a mouse-up before a global `input.on(MOUSE_UP)` listener sees it, while the claimed touch still returns `TOUCH_END` or `TOUCH_CANCEL` to its start node. For drag completion, accept the semantic dropped/end state plus a complete touch start/move/end-or-cancel lifecycle; do not require a global mouse-up counter when the release is over a different UI node.

## Diagnose Preview runtime errors

Use `get_preview_runtime_diagnostics` when available to read the current Preview session's structured `console.error`, uncaught exception, and unhandled rejection entries. Preserve and reason from the returned message, stack, source, line, column, count, sequence, and `previewSessionId`.

- Do not substitute Editor Console lines for Preview runtime evidence.
- Repeated entries with one fingerprint and an increased count are one recurring bug, not unrelated failures.
- Never attribute an earlier Preview session's diagnostics to the current run.
- Locate the project script from the runtime evidence; do not guess a file or line supplied outside the evidence.
- After fixing code, wait for Creator compilation, restart Preview, repeat the original trigger path, verify the expected behavior, and then verify the error does not recur in the new session. An empty new session before retriggering is not proof of a fix.

Runtime diagnostics belong in Activity/evidence. Only actual project edits belong in Review and Undo.

## Bounded verification, not a requirement to beat the game

Cocos AI Copilot is a game-development assistant. For an ordinary development task, verify the requested functionality rather than treating a full or unassisted playthrough as a completion gate. Keep Preview startup checks, input validation, semantic readback after meaningful actions, screenshots when visual evidence matters, and the final runtime-error review. This boundary does not waive operation auditing, checking the effects of edits, or confirming that an action actually worked.

Use focused checks of relevant movement, collision, collectibles, damage, checkpoints, reset, and finish-condition logic. Stop once the requested checks have evidence; do not keep planning routes, retrying jumps, or adjusting strategies solely because the automated player has not won. A failed automated route alone is not proof of a game defect. An observed broken interaction or critical Runtime error still needs diagnosis and, when a fix is authorized, a targeted fix and retest. Do not hide such defects behind "manual playtest required" or mark an unverified check as passed.

Attempt an automatic full-game playthrough only when the user explicitly requests it. Unless the user sets a different budget, limit automatic playtesting to three minutes total and an explicitly requested full playthrough to at most three route attempts, whichever limit is reached first. These are ceilings, not targets to fill; restarting Preview does not reset the budget. Do not change movement speed, jump height, collision rules, or level design just to make automation pass. Assisted placement may verify a local invariant, but it is not evidence of an unassisted playthrough.

At completion or the budget boundary, release owned input and distinguish checks that passed, defects that remain, and checks not performed. Core gameplay acceptance belongs to human playtesting; report that handoff without adding "complete the whole game" as a mandatory outstanding task. Do not claim human acceptance or successful actions without evidence. The absence of an automatic win does not justify extending the test loop.

Read session-bound runtime diagnostics after the **last** test action, not before additional attempts. Include any remaining issue in the final result. During a long verification sequence, give a brief progress update at the next safe tool boundary, about once per minute; summarize the current check and remaining gap, not full scripts or logs.

## Finish cleanly

Before reporting success, ensure no pointer remains owned, the intended Preview session is still current, semantic runtime checks pass, and any screenshot supports rather than replaces those checks. Report a concrete limitation instead of claiming success from a tool response alone.
