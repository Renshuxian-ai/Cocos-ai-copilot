---
name: funplay-cocos-2d-image-toolkit
description: "Process, slice, import, configure, place, preview, review, and undo 2D image assets in Cocos Creator through the Cocos AI Copilot image_editor Local Tools. Use for image editing, Sprite Sheet, Nine-Slice, pixel-art filtering, and image-to-scene workflows."
---

# Cocos 2D Image Toolkit

Use the built-in `image_editor_*` Local Tools. They share the same Image Core as the visible Image Workbench, so do not reproduce image processing with shell scripts or automate the panel DOM.

## Choose the shortest valid workflow

- For headless crop, trim, resize, canvas padding, flip, rotate, alpha/color changes, tint, composite, or mask: `image_editor_sources` → `image_editor_process`.
- To create a project asset: process first, then `image_editor_import`; never overwrite the source.
- To change Cocos texture metadata: `image_editor_configure_asset` after import, then use its readback result.
- To place a static image: `image_editor_place_image`; use `sliced: true` only after legal borders are configured.
- To slice or animate: `image_editor_open` → `image_editor_inspect` → `image_editor_edit` → playback if useful → `image_editor_save_frames` → `image_editor_create_animation` → `image_editor_place_in_scene`.
- To prove runtime behavior: place first, then `image_editor_preview_scene` or `image_editor_start_preview`, followed by `image_editor_runtime_state` and a screenshot when visual evidence matters.

Only start Preview or simulate UI input when the user authorized runtime or UI validation. Project writes must appear in Review and remain Undoable.

## Source and revision rules

Use only IDs returned by `image_editor_sources`, a conversation-owned Artifact/attachment ID, or a `db://assets/...` project image. Arbitrary filesystem paths are not valid image sources.

The interactive editor is revision-bound. After `image_editor_open` or any edit, inspect again when needed and pass the latest `editorId` and `revision`. If the image was replaced or the revision is stale, stop and re-inspect instead of guessing.

Processing always replays an ordered recipe from the fixed source. When a geometry-changing version must be sliced, save that version as an Artifact and open the Artifact for slicing; old Sprite Sheet coordinates belong to the old source.

## Processing recipe

Pass operations in the intended order to `image_editor_process`, with `output.format` set to `png` or `jpeg` and a new output name.

Supported operation types:

- Geometry: `crop`, `trimTransparent`, `resize`, `padding`, `flip`, `rotate` (90/180/270).
- Alpha and color: `colorKey`, `opacity`, `brightness`, `contrast`, `hue`, `saturation`, `tint` (`multiply` or `mix`).
- Lightweight composition: `composite` and `mask` (`alpha` or `grayscale`) using a same-conversation image Artifact as `source`.

Use `nearest` for pixel art and `bilinear` or `bicubic` for smooth artwork. PNG preserves alpha. JPEG requires an intentional matte color because it cannot preserve transparency. `trimTransparent` with `empty: "noop"` is the safe default for a fully transparent image unless the task requires an error.

After processing, verify returned width, height, format, transparency, operation summary, and hashes. A successful tool call alone is not visual proof; capture or inspect the result when appearance is part of the request.

## Cocos asset settings

`image_editor_configure_asset` supports:

- `filter`: `nearest` or `linear`.
- wrap: `clamp` or `repeat`.
- SpriteFrame pivot and legal Nine-Slice borders.
- mip filter on/off with save, reimport, and readback verification.

SpriteFrame pivot and scene-node UITransform anchor are different settings. Per-image compression presets are intentionally unsupported in Creator 3.8.8 because there is no stable public write API; do not claim or fake compression changes.

## Completion evidence

For every requested result:

1. Check the tool's structured result and exact asset/node identifiers.
2. Verify dimensions and relevant pixel/alpha or metadata invariants.
3. For runtime claims, read the actual Game View state rather than inferring it from the edit scene.
4. Open or summarize Review with clear image version, dimensions, format, operations, assets, and scene changes.
5. If Undo is requested, verify restored/deleted counts, zero conflicts, source hash unchanged, and generated assets/nodes absent.

Do not describe a deferred, unsupported, or merely UI-visible result as verified.

## Asset readiness and retry boundary

The import/configure tools create missing project folders, refresh AssetDB, and perform bounded type/sub-asset readback. A file on disk alone does not prove ImageAsset or SpriteFrame readiness. Continue only with the returned confirmed asset/child UUIDs. Do not configure, place, or animate a resource after an unconfirmed import.

Do not repeat a write to the same output path merely because a readiness query timed out. Preserve the existing file and report "资源状态需要人工确认". For a correctable validation/input error, allow at most one corrected retry of that operation, only after identifying the cause and keeping the correction within the task. Stop after two attempts total; never use repeated refresh, overwrite, or shell import as a normal readiness loop. Existing successful steps need not be repeated.
