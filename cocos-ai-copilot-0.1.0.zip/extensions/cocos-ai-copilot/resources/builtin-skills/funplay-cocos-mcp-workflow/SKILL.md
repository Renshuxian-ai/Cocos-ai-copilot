---
name: funplay-cocos-mcp-workflow
description: "Inspect, edit, validate, preview, and debug Cocos Creator projects through the Cocos AI Copilot built-in Cocos Runtime, with explicit boundaries between read-only queries, editor modifications, runtime validation, and UI interaction."
---

# Cocos Runtime Workflow

## Task Classification and Boundaries

Classify every task before calling any stateful tool. Use one or more of these task types:

1. **Read-only Query** — Read only the project, scene, node, component, asset, log, file, or editor information needed for the answer, without changing state.
2. **Editor Modification** — Create or modify scripts, scenes, nodes, components, prefabs, assets, files, or serialized properties.
3. **Runtime Validation** — Start or observe Preview and verify actual runtime behavior with runtime state, logs, or screenshots.
4. **UI Interaction** — Simulate mouse, keyboard, button, or other editor/preview UI input.

Composite tasks are allowed, but authorize and execute each phase separately. Editor Modification does not automatically authorize Runtime Validation, and Runtime Validation does not automatically authorize UI Interaction.

### Hard User Boundaries

Within this workflow, explicit user restrictions take precedence over its default steps. Treat requests such as read-only, do not modify, do not save, do not start/stop/restart Preview, do not simulate input, or do not change runtime state as hard boundaries.

Do not expand the authorized task type to obtain stronger evidence, complete a standard workflow, improve validation quality, or make a tool succeed. If a required action exceeds the boundary, report the limitation or request authorization instead.

### Principle of Least Capability

Choose the lowest-capability tool sufficient for the authorized goal:

`Read < Editor Mutation < Runtime State Change < UI Input Simulation`

- If read or inspect tools can complete the task, do not write.
- If runtime state, logs, or screenshots can verify behavior, do not simulate mouse or keyboard input.
- Do not expose or invoke a more powerful tool merely because it is available.

### Creator API First

When an implementation depends on Creator editor behavior, engine input/events, Scene or Asset DB semantics, Preview, import, build, or version compatibility, check the matching Cocos Creator version's official manual/API and, when needed, the same-version official Cocos engine/editor source before designing a workaround. Prefer a documented public API. If Creator only exposes an Editor-specific internal bridge, use it only with capability detection, a clear unsupported-version error, and targeted version tests. Build a custom compatibility layer only when the official product provides no suitable path. Do not turn ordinary game scripting or layout work into a routine documentation search when the relevant API is already established.

## Tool Boundaries

| Task type | Allowed | Denied by default |
| --- | --- | --- |
| Read-only Query | Read, inspect, list, query, and explicitly requested log/file reads | Write, create, delete, set, save, refresh, Preview lifecycle, runtime operations, and simulated input |
| Editor Modification | Read plus necessary create/set/write/save/refresh and diagnostics tools | Preview, runtime tools, and simulated input |
| Runtime Validation | Preview state/lifecycle within authorization, runtime state, logs, and screenshots | Scene, prefab, script, asset, and file writes |
| UI Interaction | Explicitly authorized input or UI actions against the named target | Unrelated input, state changes, or editor/project modifications |

Tool availability is not authorization. The `core`, `full`, or custom exposure profile may reveal a tool that remains forbidden for the current task type.

### Read-only Query Allowlist and Denylist

Read-only Query may use:

- `get_editor_state`, `get_scene_info`, `get_hierarchy`, and `get_selection`.
- Component and asset queries.
- `list_*`, `inspect_*`, `read_*`, and equivalent non-mutating tools.
- Repository file reads.
- Log reads only when the user requests logs or they are part of the requested read-only evidence.

Read-only Query must not use:

- `create_node`, `delete_node`, `add_component`, `remove_component`, or `set_component_property`.
- `save_scene`, `save_current_scene`, `create_prefab`, asset/file writes, or refresh operations.
- `run_project_preview`, `start_preview`, `stop_preview`, or `restart_preview`.
- `get_runtime_state`, runtime mutation, or other runtime operations.
- `simulate_mouse_click`, `simulate_preview_input`, or any keyboard/mouse simulation.

`execute_javascript` has arbitrary read/write capability and is denied by default for Read-only Query. Use it only when the user has explicitly authorized it, no narrower read-only tool can complete the request, and the reviewed code is demonstrably non-mutating. Otherwise do not call it.

## Editor and Preview State Rules

1. **Read-only Query:** Preserve the initial Editor/Preview state. Never transition Editor to Preview or Preview to Editor.
2. **Editor Modification:** Perform editor writes only in a valid Editor state. If the current state is incompatible, do not stop or switch Preview automatically; report the limitation or request authorization.
3. **Runtime Validation:** Use runtime tools only in a valid Preview state and only within the authorized Preview lifecycle.
4. **UI Interaction:** Confirm that the exact target window or control is present, visible, and currently interactive before sending input.
5. If a tool requires an unauthorized state transition, do not make the transition merely to let the tool run.

Record relevant temporary runtime state before changing it. Restore authorized temporary changes such as pause, time scale, or input state before finishing unless the user explicitly requests otherwise.

## Operating Loop

### 1. Establish Context

- Use the Host-provided fresh Cocos Live Context as the current project, editor mode, active Scene, and selection baseline. Do not call `get_editor_state` or `get_scene_info` merely to confirm fields already present there.
- Inspect hierarchy, selection, assets, scenes, or prefabs only when the requested operation needs an identity or detail absent from the Live Context. Do not enumerate the project as a routine preflight.
- Treat user-provided node and asset names as hints. Resolve the real hierarchy path, node UUID, asset UUID, or `db://assets/...` URL before any authorized edit.
- Call `get_tool_catalog` only when the authorized task requires a tool that may be hidden by the current exposure profile. A catalog entry does not grant permission to use it.

### 2. Follow the Classified Workflow

#### Read-only Query

1. Read only the information the user requested.
2. Resolve necessary ambiguity using additional read-only inspection.
3. Return a concise answer and stop. Do not continue into editor modification, Preview, runtime state, or UI interaction for extra validation.

A Read-only Query is complete when:

- The requested information has been read and summarized.
- Necessary ambiguity was resolved without mutation.
- Nothing was created, modified, deleted, saved, or refreshed.
- Preview was not started, stopped, or restarted.
- No runtime operation or simulated input was used.
- Editor/Preview state matches the state at task start.

Read-only Query never needs Preview to revalidate information already obtained from editor or project reads.

#### Editor Modification

Use the edit workflow only for an authorized Editor Modification:

`Inspect -> Identify exact target -> Apply the smallest requested change -> Read back -> Save only when required -> Run relevant diagnostics`

- Edit TypeScript and ordinary project files with repository or MCP file tools, then refresh only the affected asset when required and run relevant diagnostics.
- Edit live scene nodes with focused scene/component tools or an explicitly authorized `execute_javascript` call using `context="scene"`.
- Use `execute_javascript` with `context="editor"` only for authorized asset-db, Editor message, project orchestration, or editor-process filesystem work.
- For editor-visible serialized property mutations, prefer a stable public Creator Editor Message mutation API when one is available instead of assigning directly to live engine objects. This keeps editor panels on the normal mutation and notification path; use focused tools or Scene Script for operations that do not have an appropriate public message.
- Inspect prefab ownership and references before mutation. Prefer focused prefab tools, or edit a verified linked instance and deliberately apply it through the editor workflow.
- Preserve existing UI and gameplay prefab hierarchies; change only the necessary nodes, components, and serialized fields.
- Save or refresh only assets and scenes intentionally changed.
- Keep JavaScript safety checks enabled unless the code and its paths were explicitly reviewed. Null-check every scene, node, component, asset, and filesystem lookup, and return concise before/after values with stable UUIDs or asset URLs where useful.
- Do not guess alternate paths, create replacement objects silently, or run self-healing mutation loops after a missing reference or unsupported editor message.

Editor Modification does not authorize Preview, Runtime Validation, or Input Simulation by default. Add Runtime Validation only when the user explicitly requests running/testing or when the user's stated acceptance criteria explicitly require runtime behavior.

An Editor Modification is complete when:

- The smallest requested change is applied.
- The exact changed node, component, prefab, asset, script, or value is read back.
- Required persistence is saved correctly.
- TypeScript changes have relevant diagnostics.
- Scene or prefab changes have targeted structural validation.
- The response distinguishes verified results from items not validated.

Preview is not a default Editor Modification completion condition.

#### Runtime Validation

Enter Runtime Validation only when the user explicitly requests Preview, running the project, testing gameplay behavior, checking a runtime result, or otherwise authorizes runtime acceptance testing.

- Define the behavior and success criteria before starting.
- Use a focused Preview tool that reports current state/readiness when available. Query `get_preview_mode` separately only when the focused tool cannot safely decide whether Preview is already running.
- Use `run_project_preview`, start/stop Preview, `get_runtime_state`, logs, and screenshots only as needed for the stated criteria.
- Distinguish a browser `localUrl` from a LAN `networkUrl`.
- Use `capture_scene_screenshot` for scene-side composition, `capture_preview_screenshot` for game output, and `capture_editor_screenshot` for editor UI or extension panels.
- Runtime Validation alone does not authorize Scene, prefab, script, asset, or file changes.
- Input events require separate UI Interaction authorization; Runtime Validation alone is insufficient.
- Do not continue with unrelated input attempts merely to produce an automated result. Mark the remaining check as manual when reliable automation is unavailable.

Runtime Validation is complete when:

- The target behavior and success criteria are explicit.
- The minimum necessary runtime state, logs, screenshots, and separately authorized input were used.
- Actual observations and limitations are reported.
- Temporary pause, time scale, or input-state changes are restored.
- Any unautomated requirement is reported as `Manual Check`.

#### UI Interaction

Treat `simulate_mouse_click`, `simulate_preview_input`, keyboard simulation, mouse simulation, and equivalent actions as a separately authorized UI Interaction phase.

Use UI Interaction only when:

- The user explicitly requests an interaction test; or
- The named behavior cannot be verified by a more stable semantic method and the user has authorized input simulation.

Prefer semantic tools and state inspection over coordinate clicks or low-level input. Target only the named preview, simulator, editor window, or control. A successful runtime-state query is not permission to add mouse or keyboard simulation for completeness.

## Preview Is Not Universal Validation

Do not automatically Preview work merely because it is visual. Visual inspection and runtime behavior are different task types.

The following do not authorize Preview by themselves:

- Scene hierarchy queries.
- Component or node inspection.
- Asset or static UI hierarchy inspection.
- Read-only Scene analysis.
- Editor modifications without runtime acceptance criteria.

Only an authorized Runtime Validation phase permits entering or changing Preview.

## Tool Exposure and Execution Contexts

- The default `core` profile exposes the main inspection, diagnostics, logs, screenshots, scene, asset, and unified JavaScript workflow.
- The `full` profile adds focused mutation tools for nodes, components, prefabs, UI, runtime control, input simulation, files, and project Preview. Exposure does not override the classified task boundary.
- If an authorized tool is unavailable under a custom profile, adapt to the exposed catalog and report the missing capability instead of pretending it ran.
- In scene context, use Cocos runtime and scene APIs for authorized live hierarchy and component work. In editor context, use `Editor` APIs and messages for authorized asset-db and extension orchestration.
- Use `execute_scene_script` and `execute_editor_script` only as compatibility entrypoints; prefer `execute_javascript` with an explicit context for authorized new workflows. The stricter Read-only Query rule for `execute_javascript` still applies.

## Scene, Prefab, and Asset Safety

- Do not treat Cocos `.scene`, `.prefab`, or `.meta` files as ordinary text. Prefer scene-process, prefab, and asset-db operations that preserve UUID references and editor import state.
- Resolve SpriteFrame and other asset sub-resources through Asset DB inspection; do not guess sub-asset UUIDs or repair them by raw `.meta` editing.
- Load a UUID or sub-asset ID with `cc.assetManager.loadAny(id, callback)`. Do not pass `cc.SpriteFrame` as a second argument; that typed overload belongs to the resources API, not `loadAny`.
- Load a Resources path with `cc.resources.load(path, cc.SpriteFrame, callback)`. In either callback, reject the reported error immediately and verify that the returned asset is a `cc.SpriteFrame` before binding it, so a bad ID or wrong asset type does not degrade into an outer tool timeout.
- If `edit_prefab_json` is authorized, target a verified prefab path and the smallest exact JSON path or literal replacement, then run `validate_prefab_references` and inspect the result.
- Before structural prefab work, call `inspect_prefab`; for scene instances, call `inspect_prefab_instance` and choose deliberately between apply and revert.
- Replacing a prefab at the same path can keep the asset UUID while changing internal object IDs and breaking serialized references, animation tracks, nested prefab links, and scene overrides.
- Inspect dependencies with `inspect_asset_dependencies` and validate them with `validate_asset_dependencies` before and after sensitive authorized asset changes.
- Never copy a `.meta` file when duplicating an asset. Use `duplicate_prefab` or asset-db operations so the new asset receives its own UUID.

## Readback and Diagnostics

- A successful mutation response is Product Evidence when that focused tool already returns verified after-state/readback. Re-inspect only when its result omits the acceptance value or reports uncertainty.
- After external script changes, refresh only the affected asset or `db://assets` when required, then run TypeScript no-emit diagnostics or `get_script_diagnostic_context`.
- Cocos import and compilation are asynchronous. Re-query relevant diagnostics, logs, or asset information instead of assuming the first response observed final state.
- Use `validate_scene` as a compact final pass for authorized modifications, not as a substitute for targeted readback.
- Read `get_recent_logs` or `search_project_logs` when logs are requested or relevant to an authorized validation. Do not clear persistent logs without explicit confirmation.
- Fix diagnostics or new error logs caused by an authorized change before claiming that modification succeeded.

## Product Success by Task Type

Product Success depends on the classified task type:

- **Read-only Query:** The requested facts were correctly read and answered without state change.
- **Editor Modification:** The requested change was applied, read back, persisted when required, and checked with relevant diagnostics.
- **Runtime Validation:** Real runtime evidence addressed the stated behavior and success criteria.
- **UI Interaction:** The explicitly authorized target interaction succeeded and its observable result was reported.

For composite tasks, report each phase separately. For example:

```text
Editor Change: PASS
Runtime Validation: Not requested
```

Never upgrade `Not requested` into an action to perform.

## Examples

### Read-only Scene Query

User: "Read the current Scene, hierarchy, and main components. Read only; do not modify."

- Classification: Read-only Query.
- Allow: `get_editor_state`, `get_scene_info`, `get_hierarchy`, and component inspection.
- Deny: Preview, runtime state, simulated input, save, and create/set/delete operations.
- Complete by returning the requested information and stopping.

### Add a Component

User: "Add WeaponController to PlayerCar."

- Classification: Editor Modification.
- Flow: inspect -> `add_component` -> readback -> save if required -> diagnostics.
- Do not enter Preview automatically.

### Validate Gameplay

User: "Run the game and verify that PlayerCar can shoot."

- Classification: Runtime Validation.
- Allow Preview, runtime state, logs, and screenshots.
- Do not edit Scene or scripts automatically. If input is required, obtain or confirm UI Interaction authorization.

### Click a Preview Control

User: "Click the Restart button in Preview and test it."

- Classification: Runtime Validation + UI Interaction.
- Confirm the Preview target is interactive, then perform only the authorized interaction.

## Failure Handling

Use bounded recovery: at most two attempts per failing operation, with a second attempt only after identifying and correcting the cause. Never blindly repeat a mutation. A resource tool already waits for AssetDB readiness; if it reports pending/manual confirmation, preserve the generated resource, stop that dependent branch, and report "资源状态需要人工确认". A completed write followed by uncertain readback is not permission to recreate or overwrite the asset.

Internal music verification outputs (for example a round-trip WAV) are not user deliverables. `audio_sources` returns validated deliverables even when another source is rejected; use those results instead of searching temporary folders or weakening provenance checks. Separate generated, present in Assets, AssetDB-confirmed, and runtime-verified evidence.

Treat a failed attempt followed by verified recovery as recovered, not a final task failure. A diagnostic tool can execute successfully while finding user-code, engine-declaration, dependency-declaration, or configuration issues; report these categories separately. Only report the whole task as failed when its required outcome remains unmet.

Keep context focused: use the provided tool catalog without printing or re-requesting it. For errors, retain the tool/target, category, file/line, concise message, and required next action. Read a preserved diagnostic report or a small source snippet only when the summary is insufficient; do not repeatedly dump full logs or unchanged scripts. During long work, provide a short progress update at a safe boundary about once per minute. For authorized automatic gameplay verification, use the existing Preview skill's bounded test budget and disclose unverified routes.

For Cocos AI Copilot game-audio workflows, the Copilot-provided `audio_*` Local Tools are the authoritative path. After an external music or sound-effect MCP creates audio, use `audio_sources`, `audio_process` when editing is needed, `audio_import`, `audio_configure_source`, `audio_start_preview`, and one final `audio_runtime_state` readback. Do not substitute raw `execute_javascript`, `refresh_assets`, `add_component`, `save_current_scene`, or `run_project_preview` calls when the matching `audio_*` tool is available; those substitutions bypass the shared Audio Core and Review/Undo evidence.

- If MCP is unreachable, limit claims to authorized filesystem inspection or edits; do not claim scene, prefab, editor, Preview, or runtime verification.
- If a node lookup is ambiguous, return matching paths and UUIDs and identify the intended target before any mutation.
- If editor readback and serialized text disagree, trust editor and asset-db readback first and investigate the selected asset, scene instance, or import state without exceeding the task boundary.
- If the current state or exposed tool profile cannot satisfy the authorized task, report the limitation. Do not expand permissions, switch state, simulate input, or perform unrelated edits as a fallback.
