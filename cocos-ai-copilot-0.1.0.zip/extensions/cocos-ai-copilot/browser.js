'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { fileURLToPath } = require('url');
const { createCodexRuntimeResolver } = require('./lib/codex-runner');
const { CodexAppServerClient } = require('./lib/codex-app-server-client');
const { CodexBackendSession } = require('./lib/codex-backend-session');
const { selectablePermissionModes } = require('./lib/codex-permission-mode');
const { version: EXTENSION_VERSION } = require('./package.json');
const { resolveCreatorProjectRoot } = require('./lib/project-root');
const {
  ProjectSkillLoader,
  buildPromptWithProjectSkillState,
  buildPromptWithProjectSkills,
  partitionProjectSkillInjections,
  selectProjectSkillNames,
} = require('./lib/skill-loader');
const { ToolGuard } = require('./lib/tool-guard/tool-guard');
const { GuardProxy } = require('./lib/tool-guard/guard-proxy');
const { DetailRegistry } = require('./lib/detail-registry');
const { SessionStore } = require('./lib/session-store');
const { catalogEvidence } = require('./lib/semantic-activity');
const { continuationSnapshot, summaryPrompt, continuedSession } = require('./lib/continuation');
const { SettingsStore } = require('./lib/settings-store');
const { CodexRuntimeConnection } = require('./lib/codex-runtime-connection');
const { SecretStore } = require('./lib/secret-store');
const {
  PROVIDER_DEFINITIONS,
  normalizeCodexModels,
  normalizeProviderError,
  runtimeProvider,
  verifyProviderKey,
} = require('./lib/model-services');
const {
  inferMimeType,
  listOutboxFiles,
  materializeTurnAttachments,
  persistOutboxArtifacts,
  prepareTurnOutbox,
  removeMaterializedMessageAttachments,
  removeOutbox,
  removeTurnAttachments,
  resolveStoredArtifact,
  safeFileName,
  sanitizeManagedPaths,
  snapshotIncomingBytes,
  snapshotIncomingPath,
  storageRoots,
  sessionRoot,
  assertContained,
  validateStoredAttachment,
} = require('./lib/attachment-utils');
const { EnvironmentDiscovery } = require('./lib/environment-discovery');
const { RuntimeResolver } = require('./lib/runtime-resolver');
const { CodexMcpConfigAdapter } = require('./lib/codex-mcp-config-adapter');
const { McpSettingsState } = require('./lib/mcp-settings-state');
const { normalizeEditorMetadata } = require('./lib/mcp-local-form');
const { resolveMcpEntry, browseMcpFile } = require('./lib/mcp-launch-files');
const { CreatorExtensionMcpDiscovery } = require('./lib/creator-extension-mcp-discovery');
const { BuiltInSkillManager } = require('./lib/builtin-skill-manager');
const { CocosRuntimeService } = require('./lib/cocos-runtime/runtime-service');
const { setCocosRuntimeService } = require('./lib/cocos-runtime/runtime-host');
const previewRuntime = require('./lib/cocos-runtime/preview-runtime');
const { createTurnChangeStore } = require('./lib/turn-change-store');
const { ChatThumbnailCache } = require('./lib/chat-thumbnail-cache');
const { preparePreviewForUndo, restorePreviewModeAfterUndo } = require('./lib/preview-undo-lifecycle');
const { changeSetSummary, revalidateSceneItems } = require('./lib/turn-change-set');
const { TurnPerformanceTrace, rememberTrace } = require('./lib/turn-performance-trace');
const {
  buildTurnChangeSet,
  captureBeforePaths,
  captureObservedEvidence,
  captureTurnStartFileExistence,
  fileExistenceChanges,
  mergeCaptures,
  reconcileEvidenceFileEvents,
  revalidateFileItems,
  undoAssetItems,
  undoFileItems,
} = require('./lib/turn-review');
const {
  buildCocosDeveloperInstructions,
  buildCocosExecutionPrompt,
  buildCocosFollowUpInput,
  buildUserMessageContent,
  createCocosContextSnapshot,
  createModelFacingContextSnapshot,
  readProjectDescriptor,
} = require('./lib/cocos-context-snapshot');
const {
  FUNPLAY_GUARD_ADAPTER,
  FUNPLAY_PROJECT_SKILLS,
  createFunplayGuardAdapter,
} = require('./lib/funplay-runtime');

const EXTENSION_NAME = 'cocos-ai-copilot';
const CODEX_EVENT_CHANNEL = `${EXTENSION_NAME}:codex-event`;
const DETAIL_EVENT_CHANNEL = `${EXTENSION_NAME}:detail-changed`;
const NEW_SESSION_EVENT_CHANNEL = `${EXTENSION_NAME}:new-session-requested`;
const MODEL_SERVICES_EVENT_CHANNEL = `${EXTENSION_NAME}:model-services-changed`;
const SETTINGS_NAVIGATION_EVENT_CHANNEL = `${EXTENSION_NAME}:settings-navigation`;
const SESSION_LIFECYCLE_EVENT_CHANNEL = `${EXTENSION_NAME}:session-lifecycle-changed`;
const MCP_SERVICES_EVENT_CHANNEL = `${EXTENSION_NAME}:mcp-services-changed`;
const CHANGES_EVENT_CHANNEL = `${EXTENSION_NAME}:changes-changed`;
const DETAIL_PANEL_NAME = `${EXTENSION_NAME}.detail`;
const SETTINGS_PANEL_NAME = `${EXTENSION_NAME}.settings`;
const CHANGES_PANEL_NAME = `${EXTENSION_NAME}.changes`;
const PROJECT_ROOT = resolveCreatorProjectRoot(global.Editor, path.resolve(__dirname, '..', '..'));
const SPECIAL_CONTEXT_SUPPRESSION_MS = 500;
const sessions = new Map();
const activeTurnPerformanceTraces = new Map();
const completedTurnPerformanceTraces = new Map();
let continuationPending = false;
const sessionStore = new SessionStore({
  projectRoot: PROJECT_ROOT,
  onError: () => broadcastCodexEvent({ type: 'session-store-error', message: '聊天历史暂时无法保存，请检查本地存储。' }),
});
const turnChangeStore = createTurnChangeStore({
  root: sessionStore.applicationRoot,
  projectKey: sessionStore.projectKey,
});
const settingsStore = new SettingsStore({
  directory: path.join(sessionStore.applicationRoot, 'settings'),
});
const secretStore = new SecretStore({
  directory: path.join(sessionStore.applicationRoot, 'secrets'),
});
const builtInSkillManager = new BuiltInSkillManager({
  projectRoot: PROJECT_ROOT,
  extensionRoot: __dirname,
});
const cocosRuntimeService = new CocosRuntimeService({
  projectRoot: PROJECT_ROOT,
  extensionRoot: __dirname,
  editor: global.Editor,
  skillManager: builtInSkillManager,
  isEnabled: () => settingsStore.load().cocosRuntimeEnabled !== false,
});
setCocosRuntimeService(cocosRuntimeService);
const fileStorageRoots = storageRoots({
  applicationRoot: sessionStore.applicationRoot,
  projectKey: sessionStore.projectKey,
  projectRoot: PROJECT_ROOT,
});
const chatThumbnailCache = new ChatThumbnailCache({
  root: fileStorageRoots.thumbnails,
  nativeImageProvider: () => loadElectronMain().nativeImage,
});
const managedInternalPathRoots = [
  fileStorageRoots.attachments,
  fileStorageRoots.artifacts,
  fileStorageRoots.thumbnails,
  path.join(fileStorageRoots.runtime, 'attachments'),
  path.join(fileStorageRoots.runtime, 'artifacts'),
];
const projectSkillLoader = new ProjectSkillLoader({
  projectRoot: PROJECT_ROOT,
  allowedSkills: Object.values(FUNPLAY_PROJECT_SKILLS),
});
const detailRegistry = new DetailRegistry();
const configuredAppServerExecutable = process.env.COCOS_AI_APP_SERVER_EXECUTABLE
  || process.env.COCOS_AI_CODEX_EXECUTABLE || '';
const runtimeConnection = new CodexRuntimeConnection({
  readPath: () => settingsStore.load().codexExecutablePath,
  writePath: (codexExecutablePath) => settingsStore.update({ codexExecutablePath }),
  createResolver: (manualPath) => createCodexRuntimeResolver(manualPath || configuredAppServerExecutable,
    process.env, { applicationRoot: sessionStore.applicationRoot }),
  getClient: () => appServerClient,
  runtimeSnapshot: () => runtimeSnapshotWithProviders(),
  isBusy: () => Boolean(modelServicesRefreshPromise || pendingChatGptLogin || assetPreviewCommitPending || continuationPending
    || appServerClient.isRunning || guardProxy?.activeTask
    || [...sessions.values()].some((item) => item.runner.isRunning || item.preparingTaskId || item.resumePromise)),
});
const resolveAppServerExecutable = runtimeConnection.resolveExecutable;
const appServerClient = new CodexAppServerClient({
  projectRoot: PROJECT_ROOT,
  executablePath: configuredAppServerExecutable,
  resolveExecutable: resolveAppServerExecutable,
  clientInfo: {
    name: 'cocos_ai_copilot',
    title: 'Cocos AI Copilot',
    version: EXTENSION_VERSION,
  },
});
const environmentDiscovery = new EnvironmentDiscovery({
  projectRoot: PROJECT_ROOT,
  getRuntimeConnections: async () => [await cocosRuntimeService.connection()],
  resolveCodexExecutable: resolveAppServerExecutable,
});
const externalCocosDiscovery = new CreatorExtensionMcpDiscovery({
  projectRoot: PROJECT_ROOT,
  listPackages: () => global.Editor?.Package?.getPackages?.({ enable: true }) || [],
  request: (name, message) => Editor.Message.request(name, message),
  getBuiltin: () => cocosRuntimeService.getStatus(),
});
const runtimeResolver = new RuntimeResolver({
  guardAdapters: {
    [FUNPLAY_GUARD_ADAPTER]: createFunplayGuardAdapter(ensureGuardProxy),
  },
});
const mcpConfigAdapter = new CodexMcpConfigAdapter({
  client: appServerClient,
  projectRoot: PROJECT_ROOT,
  getRuntimeSnapshot: async () => runtimeSnapshotWithProviders(
    (await runtimeResolver.resolve(environmentDiscovery.registry)).snapshot()
  ),
});
let mcpSettingsAppServerRevision = appServerClient.lifecycleRevision;
const mcpSettingsState = new McpSettingsState({
  load: () => readManagedMcpSnapshot(),
  onUpdated: () => broadcastMcpServicesChanged('shared-snapshot-updated'),
});
let toolGuard = null;
let guardProxy = null;
let guardProxyStartPromise = null;
let mainPanelContext = null;
let nativeMenuThemeLeaseCount = 0;
let nativeMenuPreviousThemeSource = null;
let projectDescriptorPromise = null;
let permissionStatePromise = null;
let modelServicesRefreshPromise = null;
let pendingChatGptLogin = null;
let disposeAppServerNotification = null;
const undoInProgress = new Set();
let selectedChangesRef = null;
let assetPreviewCommitPending = false;
let audioCommitPending = false;
const { persistGeneratedImage, persistMcpImages, readImage, mergeImageArtifacts } = require('./lib/image-artifacts');
const { readAudio, enrichAudioArtifacts, persistMcpAudio } = require('./lib/audio-artifacts');
const { inspectAudioProjectStatus } = require('./lib/audio/project-status');
const { audioStatusPatch, audioStatusView, runtimeEvidencePatch } = require('./lib/audio/status-model');
const { audioImportPatch } = require('./lib/audio/artifact-lineage');
const { waitForAsset, refreshPendingAsset } = require('./lib/asset-db-ready');
const audioCore = require('./lib/audio/audio-core');
const { requireCurrentAudioScene } = require('./lib/audio/scene-context');
const imageAgentTools = require('./lib/asset-preview/agent-tools');
const imageArtifactService = require('./lib/asset-preview/image-artifact-service');
const imageWorkerClient = require('./lib/asset-preview/image-worker-client');
const imageReviewWarning = require('./lib/asset-preview/review-warning');
const audioAgentTools = require('./lib/audio/agent-tools');
let imageEditorCall = null;
const imageWorkbenchRevisions = new Map();
const imageWorkbenchTasks = new Map();
const imageWorkbenchArtifactsBySession = new Map();
const audioWorkbenchArtifactsBySession = new Map();
const pendingLocalImageArtifactsByTask = new Map();
const pendingAudioArtifactsByTask = new Map();
let audioToolCall = null;
let audioEditorSource = null;
let audioEditorOwner = '';
const pendingMcpAudioByTask = new Map();
const localTools = require('./lib/local-tools').createLocalTools([
  { id:'image-editor', tools:imageAgentTools.definitions, execute:executeImageAgentTool },
  { id:'audio-workflow', tools:audioAgentTools.definitions, execute:executeAudioAgentTool },
]);
const localToolCapabilityGroups = Object.freeze([
  { id:'image-editor', label:'图片编辑 Local Tools', count:imageAgentTools.definitions.length },
  { id:'audio-workflow', label:'音频编辑 Local Tools', count:audioAgentTools.definitions.length },
]);

function localToolCapabilitySnapshot() {
  return {
    count: localTools.definitions.length,
    groups: localToolCapabilityGroups.map((group) => ({ ...group })),
  };
}

function imageAgentAttachments(sessionId) {
  sessionStore.load();
  const record=sessionStore.records.get(sessionId);
  return (record?.messages||[]).flatMap(m=>[...(m.attachments||[]),...(m.followUps||[]).flatMap(f=>f.attachments||[])]);
}

function findSessionImageArtifact(sessionId,artifactId) {
  const workbenchArtifact=imageWorkbenchArtifactsBySession.get(sessionId)?.get(artifactId);
  if(workbenchArtifact)return {...workbenchArtifact};
  sessionStore.load();const record=sessionStore.records.get(sessionId);
  for(const turn of record?.messages||[])for(const message of turn.assistantMessages||[])for(const artifact of message.artifacts||[])
    if(artifact.id===artifactId&&artifact.kind==='image')return {...artifact};
  return null;
}

function findSessionAudioArtifact(sessionId,artifactId) {
  return sessionAudioArtifacts(sessionId).find(artifact => artifact.id === artifactId) || null;
}

function sessionAudioArtifacts(sessionId) {
  const artifacts = new Map(audioWorkbenchArtifactsBySession.get(sessionId) || []);
  for (const pending of pendingAudioArtifactsByTask.values()) for (const artifact of pending.values()) {
    if (artifact.sessionId === sessionId) artifacts.set(artifact.id, artifact);
  }
  sessionStore.load();const record=sessionStore.records.get(sessionId);
  for(const turn of record?.messages||[])for(const message of turn.assistantMessages||[])for(const artifact of message.artifacts||[])
    if(artifact.kind==='audio'&&!artifacts.has(artifact.id))artifacts.set(artifact.id,{...artifact});
  return [...artifacts.values()];
}

function linkAudioImport(sessionId,taskId,source,result) {
  const hash=require('crypto').createHash('sha256').update(readAudio(source.sourceRoot,source.sourcePath).bytes).digest('hex');
  for(const artifact of sessionAudioArtifacts(sessionId)) {
    const identity=artifact.id===source.artifactId || [artifact.projectAssetUrl,artifact.projectAssetCandidateUrl,artifact.projectFileUrl].includes(source.assetUrl) && Boolean(source.assetUrl);
    if(!identity)continue;
    let bytesHash;
    try{bytesHash=require('crypto').createHash('sha256').update(readAudio(fileStorageRoots.artifacts,artifact.storedPath).bytes).digest('hex');}
    catch(error){console.warn(`[AI Copilot][Audio Artifact] import link skipped id=${artifact.id}: ${error.message}`);continue;}
    if(bytesHash!==hash)continue;
    Object.assign(artifact,audioImportPatch(artifact,result));
    broadcastCodexEvent({type:'artifact-updated',sessionId,taskId,artifact,timestamp:Date.now()});
  }
}

function rememberWorkbenchImageArtifact(sessionId, artifact) {
  if (!sessionId || !artifact?.id || artifact.kind !== 'image') return;
  let artifacts=imageWorkbenchArtifactsBySession.get(sessionId);
  if(!artifacts){artifacts=new Map();imageWorkbenchArtifactsBySession.set(sessionId,artifacts);}
  artifacts.set(artifact.id,{...artifact});
  while(artifacts.size>128)artifacts.delete(artifacts.keys().next().value);
  while(imageWorkbenchArtifactsBySession.size>64)imageWorkbenchArtifactsBySession.delete(imageWorkbenchArtifactsBySession.keys().next().value);
}

function imageReviewFromArtifact(artifact) {
  if (!artifact || artifact.kind !== 'image') return null;
  return {
    kind: 'image-version',
    width: artifact.width,
    height: artifact.height,
    format: artifact.format || String(artifact.extension || '').replace(/^\./u, ''),
    hasTransparentPixels: artifact.hasTransparentPixels,
    byteLength: artifact.size,
    operations: Array.isArray(artifact.operationSummary) ? artifact.operationSummary.slice() : [],
    sourceHash: artifact.sourceHash || '',
    outputHash: artifact.outputHash || '',
  };
}
async function executeImageAgentTool(name,args,task) {
  const command=imageAgentTools.validateAction(name,args);task.assertActive();
  if(imageEditorCall)throw Error('图片编辑器正在处理另一个操作，请顺序调用。');
  const call={id:require('crypto').randomUUID(),task,command};imageEditorCall=call;
  try {
    let data;
    if(command==='sources') {
      const directory=sessionRoot(fileStorageRoots.artifacts,task.sessionId),artifacts=[];
      if(fs.existsSync(directory))for(const item of fs.readdirSync(directory,{withFileTypes:true})) {
        if(!item.isDirectory()||item.isSymbolicLink())continue;
        try { const a=resolveStoredArtifact({artifactRoot:fileStorageRoots.artifacts,sessionId:task.sessionId,artifactId:item.name});
          const image=readImage(fileStorageRoots.artifacts,a.path);artifacts.push({artifactId:item.name,name:a.displayName,width:image.width,height:image.height});
        } catch(_) { /* Only validated images are exposed. */ }
      }
      data={artifacts,attachments:imageAgentAttachments(task.sessionId).filter(a=>a.mimeType?.startsWith('image/')).map(a=>({attachmentId:a.id,name:a.displayName})),
        selected:await module.exports.methods.getAttachmentThumbnail({kind:'asset-preview-selection'})};
    } else if(command==='process') {
      const saved=await saveImageArtifactVersion(imageAgentTools.normalizeProcessArguments(args),task.sessionId,task.taskId,task);task.assertActive();
      if(!pendingLocalImageArtifactsByTask.has(task.taskId))pendingLocalImageArtifactsByTask.set(task.taskId,new Map());
      pendingLocalImageArtifactsByTask.get(task.taskId).set(saved.artifact.id,saved.artifact);
      broadcastCodexEvent({type:'assistant-artifacts',sessionId:task.sessionId,taskId:task.taskId,artifacts:[saved.artifact],timestamp:Date.now()});
      data={artifactId:saved.artifact.id,sourceArtifactId:saved.artifact.sourceArtifactId||'',parentArtifactId:saved.artifact.parentArtifactId||'',
        revision:saved.artifact.revision,width:saved.artifact.width,height:saved.artifact.height,format:saved.artifact.format,
        hasTransparentPixels:saved.artifact.hasTransparentPixels,byteLength:saved.artifact.size,operationSummary:saved.artifact.operationSummary,
        sourceHash:saved.artifact.sourceHash,outputHash:saved.artifact.outputHash};
    } else if(command==='import') {
      data=await commitImageAgentAssets({callId:call.id,action:'import-image',artifactId:args.artifactId,outputPath:args.outputPath});
      const linked=pendingLocalImageArtifactsByTask.get(task.taskId)?.get(args.artifactId)||findSessionImageArtifact(task.sessionId,args.artifactId);
      if(linked&&data?.result){Object.assign(linked,{projectImported:true,projectAssetUrl:data.result.assetUrl,projectAssetUuid:data.result.assetUuid,
        projectSpriteFrameUuid:data.result.spriteFrameUuid||'',projectTextureUuid:data.result.textureUuid||''});
        broadcastCodexEvent({type:'artifact-updated',sessionId:task.sessionId,taskId:task.taskId,artifact:linked,timestamp:Date.now()});}
    } else if(command==='configure_asset') {
      data=await commitImageAgentAssets({callId:call.id,action:'settings',target:args.target,settings:args.settings});
    } else if(command==='place_image') {
      data=await commitImageAgentAssets({callId:call.id,action:'place-image',...args,name:args.nodeName});
    } else if(command==='preview_scene') {
      data=await commitImageAgentAssets({callId:call.id,action:'preview',sceneUuid:args.sceneUuid});
    } else if(command==='runtime_state') {
      const editScene=await callSceneReviewMethod('imageSpriteState',{nodeUuid:args.nodeUuid,spriteFrameUuid:args.spriteFrameUuid,sliced:args.sliced}),preview=require('./lib/asset-preview/asset-commit').unwrap(await cocosRuntimeService.callTool('get_runtime_state',{}));
      const runtimeSprite=preview.running?await require('./lib/asset-preview/runtime-state').inspectRuntimeSprite(loadElectronMain(),{...args,nodePath:args.nodePath||editScene.path}):{available:false,verified:false,reason:'preview-not-running'};
      data={editScene,preview,runtimeSprite,verified:Boolean(editScene.verified&&preview.running&&runtimeSprite.verified)};
    } else {
      let source;
      if(command==='open') {
        if(['target','artifactId','attachmentId'].filter(k=>args[k]).length!==1)throw Error('Exactly one image source is required.');
        const attachment=args.attachmentId&&imageAgentAttachments(task.sessionId).find(a=>a.id===args.attachmentId);
        if(args.attachmentId&&!attachment)throw Error('图片附件不属于当前会话。');
        source={target:args.target,artifactId:args.artifactId,attachment,sessionId:task.sessionId,
          identity:JSON.stringify([task.sessionId,args.target||args.artifactId||args.attachmentId])};
        await readAssetPreviewSource(source);task.assertActive();
        await Editor.Panel.openBeside('scene',`${EXTENSION_NAME}.asset-preview`);
      }
      task.assertActive();
      data=await Editor.Message.request(EXTENSION_NAME,'image-editor-action',{command,args,source,sessionId:task.sessionId,callId:call.id});
    }
    task.assertActive();
    const image=data?.image;if(image)delete data.image;
    const content=[{type:'text',text:JSON.stringify(data)}];
    if(image)content.push({type:'image',mimeType:'image/png',data:image.split(',')[1]});
    return {content,structuredContent:{ok:true,tool:name,data}};
  } finally { if(imageEditorCall===call)imageEditorCall=null; }
}

function audioAgentAttachments(sessionId) {
  return imageAgentAttachments(sessionId).filter(item => String(item.mimeType || '').startsWith('audio/') || /\.(wav|mp3|ogg)$/i.test(item.displayName || ''));
}

async function resolveAudioSource(payload = {}, sessionId = payload.sessionId) {
  const selected = ['target','artifactId','attachmentId'].filter(key => payload[key]);
  if (selected.length > 1) throw new Error('只能指定一个音频来源。');
  let sourcePath, sourceRoot, displayName, asset;
  if (payload.artifactId) {
    const stored = resolveStoredArtifact({ artifactRoot:fileStorageRoots.artifacts, sessionId, artifactId:payload.artifactId });
    sourcePath = stored.path; sourceRoot = fileStorageRoots.artifacts; displayName = stored.displayName;
  } else if (payload.attachmentId || payload.attachment) {
    const attachment = payload.attachment || audioAgentAttachments(sessionId).find(item => item.id === payload.attachmentId);
    if (!attachment) throw new Error('音频附件不属于当前会话。');
    const stored = validateStoredAttachment(attachment,{attachmentRoot:fileStorageRoots.attachments,sessionId});
    if (!stored?.available || !stored.storedPath) throw new Error('音频附件已不可用。');
    sourcePath=stored.storedPath;sourceRoot=fileStorageRoots.attachments;displayName=stored.displayName;
  } else {
    const target=payload.target||Editor.Selection.getSelected('asset')[0];
    if(!target)throw new Error('请先选择项目 AudioClip，或指定 Audio Artifact / 附件。');
    const db=(...args)=>Editor.Message.request('asset-db',...args);
    await refreshPendingAsset(db,target,'cc.AudioClip');
    asset=await waitForAsset(db,target,{type:'cc.AudioClip'});
    if(!asset?.file||asset.type!=='cc.AudioClip'||!asset.url?.startsWith('db://assets/'))throw new Error('所选资源不是当前项目中的 AudioClip。');
    sourcePath=assertContained(PROJECT_ROOT,asset.file,'Audio');sourceRoot=PROJECT_ROOT;displayName=path.basename(sourcePath);
  }
  const validated=readAudio(sourceRoot,sourcePath,{displayName,productionOnly:true});
  return {sourcePath:validated.path,sourceRoot,displayName,format:validated.format,mimeType:validated.mimeType,size:validated.size,
    assetUrl:asset?.url||'',assetUuid:asset?.uuid||'',sessionId,artifactId:payload.artifactId||'',attachmentId:payload.attachmentId||'',
    identity:payload.identity||`${payload.artifactId?'artifact':payload.attachmentId?'attachment':'project'}:${payload.artifactId||payload.attachmentId||asset?.uuid}`};
}

async function describeAudioSource(payload,sessionId,includeBytes=false) {
  const source=await resolveAudioSource(payload,sessionId), inspected=await audioCore.inspectAudio(source.sourcePath,{points:0});
  const projectStatus = source.artifactId ? await readAudioArtifactStatus({ ...payload, sessionId }, false) : null;
  return {...source,...inspected,...(projectStatus ? { projectStatus } : {}),baseName:path.basename(source.displayName,path.extname(source.displayName)),available:true,
    ...(includeBytes?{base64:fs.readFileSync(source.sourcePath).toString('base64')}:{})};
}

async function linkImportedAudioArtifacts(artifacts) {
  for (const artifact of artifacts || []) {
    if (artifact.kind !== 'audio' || artifact.projectImported) continue;
    const status = await inspectAudioProjectStatus(artifact, { projectRoot: PROJECT_ROOT, artifactRoot: fileStorageRoots.artifacts,
      query: (method, ...args) => Editor.Message.request('asset-db', method, ...args) });
    Object.assign(artifact, audioStatusPatch(status, artifact));
  }
  return artifacts;
}

async function readAudioArtifactStatus(payload, searchAssets = true) {
  const stored = resolveStoredArtifact({ artifactRoot: fileStorageRoots.artifacts, sessionId: payload.sessionId, artifactId: payload.artifactId });
  const previous = findSessionAudioArtifact(payload.sessionId, payload.artifactId) || {};
  const artifact = { ...previous,
    projectAssetCandidateUrl: payload.projectFileUrl || payload.projectAssetCandidateUrl || previous.projectAssetCandidateUrl || '',
    storedPath: stored.path, displayName: stored.displayName };
  return inspectAudioProjectStatus(artifact, { projectRoot: PROJECT_ROOT, artifactRoot: fileStorageRoots.artifacts,
    searchAssets, query: (method, ...args) => Editor.Message.request('asset-db', method, ...args) });
}

async function saveAudioVersion(payload,sessionId,taskId) {
  const source=await resolveAudioSource(payload.source||payload,sessionId);
  const parent=source.artifactId?findSessionAudioArtifact(sessionId,source.artifactId):sessionAudioArtifacts(sessionId).find(item=>
    source.assetUrl&&[item.projectAssetUrl,item.projectAssetCandidateUrl,item.projectFileUrl].includes(source.assetUrl));
  const displayName=safeFileName(payload.name,'audio-edited.wav');
  if(!/\.(wav|mp3|ogg)$/i.test(displayName))throw new Error('新版本名称必须以 .wav、.mp3 或 .ogg 结尾。');
  const format=path.extname(displayName).slice(1).toLowerCase();
  const draft={...(payload.draft||{}),format};
  const id=require('crypto').randomUUID(),directory=path.join(sessionRoot(fileStorageRoots.artifacts,sessionId),id),target=path.join(directory,displayName);
  await fs.promises.mkdir(directory,{recursive:true});
  let result;
  try{result=await audioCore.processAudio({sourcePath:source.sourcePath,outputPath:target,draft});}
  catch(error){await fs.promises.rm(directory,{recursive:true,force:true}).catch(()=>{});throw error;}
  const artifact={id,type:'artifact',kind:'audio',source:'edited',displayName,storedPath:target,size:result.size,extension:`.${format}`,mimeType:result.mimeType,format,
    sourceIdentity:`audio-edit:${source.identity}:${Date.now()}`,projectImported:false,projectAssetUrl:'',projectAssetUuid:'',sessionId,turnId:taskId,createdAt:Date.now(),available:true,
    duration:result.duration,sampleRate:result.sampleRate,channels:result.channels,
    audioFamilyId:parent?.audioFamilyId||parent?.id||`audio:${source.identity}`,
    sourceArtifactId:parent?.sourceArtifactId||parent?.id||'',parentArtifactId:parent?.id||'',
    sourceHash:require('crypto').createHash('sha256').update(readAudio(source.sourceRoot,source.sourcePath).bytes).digest('hex'),
    outputHash:require('crypto').createHash('sha256').update(fs.readFileSync(target)).digest('hex')};
  if(!audioWorkbenchArtifactsBySession.has(sessionId))audioWorkbenchArtifactsBySession.set(sessionId,new Map());
  const remembered=audioWorkbenchArtifactsBySession.get(sessionId);remembered.set(id,artifact);
  while(remembered.size>128)remembered.delete(remembered.keys().next().value);
  while(audioWorkbenchArtifactsBySession.size>64)audioWorkbenchArtifactsBySession.delete(audioWorkbenchArtifactsBySession.keys().next().value);
  return {artifact,result};
}

async function commitAudioWithReview(payload,{sessionId,taskId,task=null,provenance='ui-audio-workbench'}={}) {
  if(audioCommitPending)throw new Error('另一个音频写入正在进行。');
  audioCommitPending=true;const session=getSession(sessionId);let review,result,summary,error;
  try{
    review=task?reviewForTask(task.taskId):{sessionId,taskId,turnId:taskId,threadId:session.runner.threadId||'',turnDiff:'',fileEvents:[],beforeFiles:new Map(),startFiles:captureTurnStartFileExistence(PROJECT_ROOT),beforeScene:await captureSceneForReview(),evidence:[],warnings:[]};
    if(!review)throw new Error('当前回合 Review 不可用。');
    let committedPayload=payload;
    if(['configure','preview'].includes(payload.action)) {
      const currentScene=await captureSceneForReview();task?.assertActive();
      const context=requireCurrentAudioScene(currentScene,payload.sceneUuid);
      committedPayload={...payload,...context};
    }
    result=await require('./lib/audio/asset-commit').commitAudio(committedPayload,{root:PROJECT_ROOT,request:(...args)=>{task?.assertActive();return Editor.Message.request(...args);},scene:(...args)=>{task?.assertActive();return callSceneReviewMethod(...args);},
      beforeWrite:paths=>mergeCaptures(review.beforeFiles,captureBeforePaths(PROJECT_ROOT,paths,{provenance:'pre-write'})),
      record:evidence=>review.evidence.push({...evidence,id:`${taskId}:audio:${review.evidence.length}`,provenance})});
  }catch(failure){error=failure;}finally{try{if(review&&!task)summary=await finalizeTurnChangeSet(session,review);}catch(failure){error=error||failure;}audioCommitPending=false;}
  if(error)throw error;return {...result,changeSet:summary,turnId:review?.turnId||taskId};
}

async function executeAudioAgentTool(name,args,task){
  const command=audioAgentTools.validateAction(name,args);task.assertActive();
  if(audioToolCall)throw new Error('另一个音频工具正在处理，请顺序调用。');
  audioToolCall={taskId:task.taskId,command};
  try{
    const deliveries=await Promise.all([...(pendingMcpAudioByTask.get(task.taskId)?.values()||[])]);task.assertActive();
    if(deliveries.length&&!pendingAudioArtifactsByTask.has(task.taskId))pendingAudioArtifactsByTask.set(task.taskId,new Map());
    for(const delivery of deliveries)for(const artifact of delivery.artifacts||[])pendingAudioArtifactsByTask.get(task.taskId).set(artifact.id,artifact);
    if(command==='sources'){
      const directory=sessionRoot(fileStorageRoots.artifacts,task.sessionId),artifacts=[];
      if(fs.existsSync(directory))for(const item of fs.readdirSync(directory,{withFileTypes:true}))if(item.isDirectory()&&!item.isSymbolicLink())try{
        const stored=resolveStoredArtifact({artifactRoot:fileStorageRoots.artifacts,sessionId:task.sessionId,artifactId:item.name});
        const audio=readAudio(fileStorageRoots.artifacts,stored.path,{productionOnly:true});
        const known=pendingAudioArtifactsByTask.get(task.taskId)?.get(item.name)||findSessionAudioArtifact(task.sessionId,item.name);
        const [linked]=await linkImportedAudioArtifacts([{...known,kind:'audio',storedPath:stored.path,displayName:stored.displayName}]);
        if(known)Object.assign(known,linked);
        artifacts.push({artifactId:item.name,name:stored.displayName,format:audio.format,size:audio.size,
          status:audioStatusView(linked).label,generated:true,projectFileExists:linked.projectFileExists===true,
          assetDbStatus:linked.assetDbStatus||'notChecked',assetUrl:linked.projectFileUrl||linked.projectAssetUrl||'',
          clipUuid:linked.projectImported?linked.projectAssetUuid:'',runtimeVerified:linked.runtimeVerified===true});
      }catch(_){}
      let selected=null;
      try{selected=await module.exports.methods.getAudioSource({kind:'audio-workbench-selection',sessionId:task.sessionId});}
      catch(error){console.warn(`[AI Copilot][Audio Sources] selection unavailable: ${error.message}`);}
      const data={artifacts,attachments:audioAgentAttachments(task.sessionId).map(item=>({attachmentId:item.id,name:item.displayName})),selected};
      return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:{ok:true,data}};
    }
    if(command==='inspect'){
      const data=await describeAudioSource(args,task.sessionId,false);return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:{ok:true,data}};
    }
    if(command==='process'){
      const data=await saveAudioVersion({source:args,draft:args.edits,name:args.name},task.sessionId,task.taskId);task.assertActive();
      if(!pendingAudioArtifactsByTask.has(task.taskId))pendingAudioArtifactsByTask.set(task.taskId,new Map());
      pendingAudioArtifactsByTask.get(task.taskId).set(data.artifact.id,data.artifact);
      broadcastCodexEvent({type:'assistant-artifacts',sessionId:task.sessionId,taskId:task.taskId,artifacts:[data.artifact],timestamp:Date.now()});
      return {content:[{type:'text',text:JSON.stringify(data.artifact)}],structuredContent:{ok:true,data:audioAgentTools.processResultForModel(data)}};
    }
    if(command==='import'){
      const source=await resolveAudioSource(args,task.sessionId);const data=await commitAudioWithReview({action:'import',sourcePath:source.sourcePath,sourceRoot:source.sourceRoot,outputPath:args.outputPath},{sessionId:task.sessionId,taskId:task.taskId,task,provenance:'agent-audio-tool'});
      linkAudioImport(task.sessionId,task.taskId,source,data);
      return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:{ok:true,data}};
    }
    if(command==='configure_source'){
      const data=await commitAudioWithReview({action:'configure',...args},{sessionId:task.sessionId,taskId:task.taskId,task,provenance:'agent-audio-tool'});return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:{ok:true,data}};
    }
    if(command==='start_preview'){
      const data=await commitAudioWithReview({action:'preview',...args},{sessionId:task.sessionId,taskId:task.taskId,task,provenance:'agent-audio-tool'});return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:{ok:true,data}};
    }
    if(command==='runtime_state'){
      const edit=await callSceneReviewMethod('audioSourceState',args),runtime=require('./lib/asset-preview/asset-commit').unwrap(await cocosRuntimeService.callTool('get_runtime_state',{}));
      const runtimeAudio=runtime.running?await require('./lib/audio/runtime-state').inspectRuntimeAudioSource(loadElectronMain(),{...args,nodePath:args.nodePath||edit.path}):{available:false,verified:false,reason:'preview-not-running'};
      const audioArtifacts = new Map(pendingAudioArtifactsByTask.get(task.taskId) || []);
      for (const turn of sessionStore.records.get(task.sessionId)?.messages || []) for (const message of turn.assistantMessages || []) for (const artifact of message.artifacts || []) {
        if (artifact.kind === 'audio' && !audioArtifacts.has(artifact.id)) audioArtifacts.set(artifact.id, { ...artifact });
      }
      for (const artifact of audioArtifacts.values()) {
        const patch = runtimeEvidencePatch(artifact, runtimeAudio);
        if (patch) { Object.assign(artifact, patch); broadcastCodexEvent({type:'artifact-updated',sessionId:task.sessionId,taskId:task.taskId,artifact,timestamp:Date.now()}); }
      }
      const data={editScene:edit,preview:runtime,runtimeAudio};return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:{ok:true,data}};
    }
    throw new Error('不支持的 Audio Tool。');
  }finally{audioToolCall=null;}
}
async function commitImageAgentAssets(payload) {
  const call=imageEditorCall;
  if(!call||call.id!==payload.callId)throw Error('图片编辑调用已过期。');
  const {task}=call;task.assertActive();
  const expected={import:'import-image',configure_asset:'settings',place_image:'place-image',preview_scene:'preview',save_frames:'frames',create_animation:'animation',place_in_scene:'place',start_preview:'preview'}[call.command];
  if(!expected||payload.action!==expected)throw Error('图片编辑写入动作不匹配。');
  const review=reviewForTask(task.taskId);if(!review||review.sessionId!==task.sessionId)throw Error('当前回合 Review 不可用。');
  const evidenceCount=review.evidence.length;
  try {
    if(['place','place-image','preview'].includes(expected)) {
      const snapshot=await captureSceneForReview();task.assertActive();
      if(!payload.sceneUuid||snapshot.scene?.uuid!==payload.sceneUuid)throw Error('当前 Scene 已改变，请重新检查。');
      if(['place','place-image'].includes(expected)&&!payload.targetUuid) {
        const normalize=value=>{const p=String(value||'').replace(/^\/+|\/+$/g,''),prefix=snapshot.scene.name+'/';return p.startsWith(prefix)?p.slice(prefix.length):p;};
        if(!payload.parentPath||snapshot.nodes.filter(n=>normalize(n.path)===normalize(payload.parentPath)).length!==1)throw Error('父节点不存在或不唯一。');
      }
    }
    if(expected==='import-image') {
      const image=await readAssetPreviewSource({artifactId:payload.artifactId,sessionId:task.sessionId});task.assertActive();
      const artifact=pendingLocalImageArtifactsByTask.get(task.taskId)?.get(payload.artifactId)
        ||findSessionImageArtifact(task.sessionId,payload.artifactId);
      payload={...payload,imageBytes:image.bytes,imageName:image.displayName,
        imageReview:imageReviewFromArtifact(artifact)};
    }
    const result=await require('./lib/asset-preview/asset-commit').commitAssets(payload,{
      root:PROJECT_ROOT,
      request:(...args)=>{task.assertActive();return Editor.Message.request(...args);},
      scene:(...args)=>{task.assertActive();return callSceneReviewMethod(...args);},
      beforeWrite:paths=>{task.assertActive();mergeCaptures(review.beforeFiles,captureBeforePaths(PROJECT_ROOT,paths,{provenance:'pre-write'}));},
      record:evidence=>{task.assertActive();review.evidence.push({...evidence,id:`${task.taskId}:image:${review.evidence.length}`,provenance:'agent-image-editor'});},
    });
    task.assertActive();
    imageReviewWarning.markSuccess(review,expected,payload);
    return {ok:true,result,taskId:task.taskId,turnId:review.turnId || task.taskId};
  } catch(error) {
    imageReviewWarning.markFailure(review,expected,payload,review.evidence.length>evidenceCount);
    throw error;
  }
}

function imageSourcePayload(payload,sessionId) {
  const selected=['target','artifactId','attachmentId'].filter(key=>payload?.[key]);
  if(selected.length!==1)throw new Error('必须且只能指定一个图片来源。');
  if(payload.attachmentId) {
    const attachment=imageAgentAttachments(sessionId).find(item=>item.id===payload.attachmentId);
    if(!attachment)throw new Error('图片附件不属于当前会话。');
    return {attachment,attachmentId:payload.attachmentId,sessionId,identity:`attachment:${sessionId}:${payload.attachmentId}`};
  }
  return {target:payload.target,artifactId:payload.artifactId,sessionId,
    identity:`${payload.artifactId?'artifact':'project'}:${sessionId}:${payload.artifactId||payload.target}`};
}

async function saveImageArtifactVersion(payload,sessionId,taskId,task=null) {
  const sourcePayload=imageSourcePayload(payload,sessionId),source=await readAssetPreviewSource(sourcePayload);task?.assertActive();
  const resolveSource=async ref=>{const resolved=await readAssetPreviewSource(imageSourcePayload(ref,sessionId));task?.assertActive();return resolved;};
  return imageArtifactService.saveImageVersion({source:{...source,...sourcePayload},recipe:{operations:payload.operations,output:payload.output},revision:1,
    sessionId,turnId:taskId,taskId:`${taskId}:image-process`,artifactRoot:fileStorageRoots.artifacts,resolveSource,worker:undefined,
    readSource:async()=>readAssetPreviewSource(sourcePayload),assertRevision:()=>task?.assertActive()});
}

async function readAssetPreviewSource(payload) {
  let sourcePath, displayName, asset;
  if (payload.artifactId) {
    const stored = resolveStoredArtifact({ artifactRoot: fileStorageRoots.artifacts, sessionId: payload.sessionId, artifactId: payload.artifactId });
    sourcePath = stored.path; displayName = stored.displayName;
    let linkedUuid=payload.projectAssetUuid;
    if(!linkedUuid){sessionStore.load();const record=sessionStore.records.get(payload.sessionId);outer:for(const turn of record?.messages||[])for(const message of turn.assistantMessages||[])for(const artifact of message.artifacts||[])if(artifact.id===payload.artifactId){linkedUuid=artifact.projectAssetUuid;break outer;}}
    if(linkedUuid)asset=await Editor.Message.request('asset-db','query-asset-info',linkedUuid).catch(()=>null);
  } else if (payload.attachment) {
    const stored = validateStoredAttachment(payload.attachment, { attachmentRoot: fileStorageRoots.attachments, sessionId: payload.sessionId });
    if (!stored?.available || !stored.storedPath) throw new Error('图片无法读取，附件已不可用。');
    sourcePath = stored.storedPath; displayName = stored.displayName;
  } else {
    const target = payload.target || Editor.Selection.getSelected('asset')[0];
    if (!target) throw new Error('请在资源管理器选择 PNG、JPG 或 WebP 图片。');
    asset = await Editor.Message.request('asset-db', 'query-asset-info', target);
    if (!asset?.file || !asset.url?.startsWith('db://assets/')) throw new Error('图片不是当前项目中的有效资产。');
    sourcePath = assertContained(PROJECT_ROOT, asset.file, 'Image'); displayName = path.basename(sourcePath);
  }
  if (!/\.(png|jpe?g|webp)$/i.test(displayName || sourcePath)) throw new Error('格式不支持，请选择 PNG、JPG 或 WebP。');
  const image = readImage(payload.artifactId ? fileStorageRoots.artifacts : payload.attachment ? fileStorageRoots.attachments : PROJECT_ROOT, sourcePath);
  return { available: true, ...image, sourceHash:require('./lib/asset-preview/image-core').hashBytes(image.bytes),
    displayName, assetUrl: asset?.url || '', assetUuid: asset?.uuid || '', artifactId:payload.artifactId || '',
    attachmentId:payload.attachmentId || payload.attachment?.id || '', identity:payload.identity || `${payload.artifactId?'artifact':payload.attachment?'attachment':'project'}:${payload.artifactId||payload.attachment?.id||asset?.uuid||asset?.url}` };
}

async function readChatThumbnailSource(payload = {}) {
  const sessionId = String(payload.sessionId || '').trim();
  if (!sessionId) return { available:false };
  let sourcePath, sourceId, displayName, mimeType;
  if (payload.artifactId) {
    try {
      const stored = resolveStoredArtifact({ artifactRoot:fileStorageRoots.artifacts, sessionId, artifactId:payload.artifactId });
      sourcePath=stored.path;sourceId=`artifact:${payload.artifactId}`;displayName=stored.displayName;
    } catch (_) { return { available:false }; }
  } else if (payload.attachment) {
    const stored = validateStoredAttachment(payload.attachment, { attachmentRoot:fileStorageRoots.attachments, sessionId });
    if (!stored?.available || !stored.storedPath || stored.kind === 'directory') return { available:false };
    sourcePath=stored.storedPath;sourceId=`attachment:${stored.id}`;displayName=stored.displayName;mimeType=stored.mimeType;
  } else return { available:false };
  mimeType=inferMimeType(displayName,mimeType);
  if (!mimeType.startsWith('image/') || !/\.(png|jpe?g|webp)$/iu.test(displayName || sourcePath)) return { available:false };
  try {
    const thumbnail = await chatThumbnailCache.read({ sessionId, sourceId, sourcePath, mimeType });
    return {
      ...thumbnail,
      bytes:undefined,
      dataUrl:`data:${thumbnail.mimeType};base64,${thumbnail.bytes.toString('base64')}`,
    };
  } catch (_) {
    return { available:false };
  }
}

async function commitAssetPreview(payload) {
  const sessionId = String(payload.sessionId || '').trim();
  if (!sessionId || assetPreviewCommitPending || continuationPending || undoInProgress.size || appServerClient.isRunning || guardProxy?.activeTask
    || Array.from(sessions.values()).some(item => item.runner.isRunning || item.preparingTaskId)) {
    return { ok: false, message: '请等待当前任务或撤销操作完成。' };
  }
  assetPreviewCommitPending = true;
  const session = getSession(sessionId), taskId = String(payload.taskId || `asset-preview:${Date.now()}`);
  let review, result, error, summary;
  try {
    review = { sessionId, taskId, turnId: taskId, threadId: session.runner.threadId || '', turnDiff: '', fileEvents: [],
      beforeFiles: new Map(), startFiles: captureTurnStartFileExistence(PROJECT_ROOT), beforeScene: await captureSceneForReview(), evidence: [], warnings: [] };
    if (['place', 'place-image', 'preview'].includes(payload.action) && (!payload.sceneUuid || review.beforeScene?.scene?.uuid !== payload.sceneUuid)) throw new Error('当前 Scene 已变化，请重新打开图片并确认目标。');
    if (['place', 'place-image'].includes(payload.action) && !payload.targetUuid) {
      const normalize = value => { const normalized = String(value).replace(/^\/+|\/+$/g, ''), prefix = `${review.beforeScene.scene.name}/`; return normalized.startsWith(prefix) ? normalized.slice(prefix.length) : normalized; };
      if (!payload.parentPath) throw new Error('请明确指定唯一父节点。');
      const matches = review.beforeScene.nodes.filter(node => normalize(node.path) === normalize(payload.parentPath));
      if (matches.length !== 1) throw new Error('父节点不存在或路径不唯一，请明确选择唯一父节点。');
    }
    if (payload.action === 'import-image') {
      if (!payload.artifactId) throw new Error('请选择已验证的图片产物。');
      const image = await readAssetPreviewSource({ artifactId: payload.artifactId, sessionId });
      payload = { ...payload, imageBytes: image.bytes, imageName: image.displayName,
        imageReview: imageReviewFromArtifact(findSessionImageArtifact(sessionId, payload.artifactId)) };
    }
    result = await require('./lib/asset-preview/asset-commit').commitAssets(payload, {
      root: PROJECT_ROOT, request: (...args) => Editor.Message.request(...args), scene: callSceneReviewMethod,
      beforeWrite: paths => mergeCaptures(review.beforeFiles, captureBeforePaths(PROJECT_ROOT, paths, { provenance: 'pre-write' })),
      record: evidence => review.evidence.push({ ...evidence, id: `${taskId}:${review.evidence.length}`, provenance: 'ui-asset-commit' }),
    });
  } catch (failure) { error = failure; }
  finally {
    try { if (review) summary = await finalizeTurnChangeSet(session, review); }
    catch (failure) { error = error || new Error(`无法完成 Review 记录：${failure.message}`); }
    assetPreviewCommitPending = false;
  }
  return { ok: !error, result, changeSet: summary, taskId,
    ...(error ? { message: /[\u4e00-\u9fff]/.test(error.message) ? error.message : ({ 'import-image':'图片导入失败。', settings:'图片资产设置保存或回读失败。', frames: '帧保存或 AssetDB 导入失败。', animation: 'AnimationClip 创建或重新加载失败。', place: 'Scene 放置或绑定验证失败。', 'place-image':'Sprite 放置或回读验证失败。', preview: 'Preview 启动失败。' }[payload.action] || '资产操作失败。'), technicalError: error.stack || String(error) } : {}) };
}

async function getCodexPermissionModes() {
  if (!permissionStatePromise) permissionStatePromise = appServerClient.readPermissionState();
  let state;
  try { state = await permissionStatePromise; }
  finally { permissionStatePromise = null; }
  const inherited = state.inherited || {};
  const workspaceMode = (!inherited.approvalPolicy || inherited.approvalPolicy === 'on-request')
    && (!inherited.sandbox || inherited.sandbox === 'workspace-write');
  const inheritedModeId = workspaceMode && inherited.reviewer === 'auto_review'
    ? 'auto_review'
    : workspaceMode && (!inherited.reviewer || inherited.reviewer === 'user')
      ? 'ask'
      : inherited.approvalPolicy === 'never' && inherited.sandbox === 'danger-full-access'
        ? 'full'
        : null;
  return { modes: selectablePermissionModes(state.requirements), inheritedModeId };
}

function broadcastCodexEvent(payload) {
  if (!global.Editor || !Editor.Message || typeof Editor.Message.broadcast !== 'function') {
    console.warn('[AI Copilot] Editor.Message.broadcast is unavailable.');
    return;
  }

  try {
    const result = Editor.Message.broadcast(CODEX_EVENT_CHANNEL, payload);
    if (result && typeof result.catch === 'function') {
      result.catch((error) => {
        console.warn(`[AI Copilot] Unable to broadcast a Codex event: ${error.message}`);
      });
    }
  } catch (error) {
    console.warn(`[AI Copilot] Unable to broadcast a Codex event: ${error.message}`);
  }
}

function broadcastChanges(payload) {
  if (!global.Editor?.Message || typeof Editor.Message.broadcast !== 'function') return;
  try {
    const result = Editor.Message.broadcast(CHANGES_EVENT_CHANNEL, payload);
    if (result && typeof result.catch === 'function') result.catch(() => {});
  } catch (_) { /* The Changes panel may not be open. */ }
}

function normalizeChangesNavigationTarget(value) {
  if (!value || typeof value !== 'object') return null;
  const domain = ['scene', 'file', 'asset'].includes(String(value.domain || ''))
    ? String(value.domain) : '';
  const bounded = (input) => String(input || '').trim().slice(0, 512);
  const target = {
    domain,
    changeId: bounded(value.changeId),
    anchorId: bounded(value.anchorId),
    groupKey: bounded(value.groupKey),
    groupAnchorId: bounded(value.groupAnchorId),
  };
  return target.domain || target.anchorId || target.groupAnchorId ? target : null;
}

async function callSceneReviewMethod(method, payload = {}) {
  if (!global.Editor?.Message || typeof Editor.Message.request !== 'function') {
    throw new Error('Cocos Scene bridge is unavailable.');
  }
  return Editor.Message.request('scene', 'execute-scene-script', {
    name: EXTENSION_NAME,
    method,
    args: [payload],
  });
}

async function captureSceneForReview() {
  try {
    const snapshot = await callSceneReviewMethod('captureChangeSnapshot');
    if (snapshot?.available && snapshot.scene?.uuid) {
      try {
        const identity = require('./lib/scene-asset-identity');
        let documentName = '';
        try {
          const electron = loadElectronMain();
          documentName = identity.sceneDocumentNameFromTitles(
            electron.BrowserWindow?.getAllWindows?.().filter(window => !window.isDestroyed?.())
              .map(window => window.getTitle?.() || '') || []
          );
        } catch (_) { /* Scene identity falls back to exact AssetDB/root matching. */ }
        const asset = await identity.resolveSceneAsset(
          snapshot,
          (method, value) => Editor.Message.request('asset-db', method, value),
          { documentName }
        );
        snapshot.scene.documentName = documentName;
        snapshot.scene.assetState = asset?.url ? 'saved' : 'untitled';
        snapshot.scene.assetUrl = String(asset?.url || '');
        snapshot.scene.assetUuid = String(asset?.uuid || '');
      } catch (_) { snapshot.scene.assetState = 'unknown'; }
      try { snapshot.scene.dirty = await Editor.Message.request('scene', 'query-dirty'); } catch (_) { /* unknown */ }
    }
    return snapshot;
  }
  catch (error) {
    console.warn(`[AI Copilot Review] Scene snapshot unavailable: ${error.message}`);
    return { available: false, reason: error.message, capturedAt: Date.now() };
  }
}

function filePathsFromEvent(event) {
  return (Array.isArray(event?.files) ? event.files : []).flatMap((file) => (
    [file.originalPath || file.path, file.movePath].filter(Boolean)
  ));
}

function explicitUnknownWriteEvidence(event) {
  if (!event || event.type !== 'tool' || !['success', 'completed'].includes(String(event.status || ''))) return null;
  const tool = (environmentDiscovery.registry?.tools || []).find((item) => (
    item?.serverId === event.server && item?.name === event.toolName
  ));
  // Built-in image writes record exact Evidence inside the active host call; draft edits are not Scene writes.
  if (tool?._meta?.['cocos-ai-copilot/feature'] === 'image-editor' && imageAgentTools.definitions.some(t=>t.name===event.toolName)) return null;
  if (!tool || tool.annotations?.readOnlyHint !== false) return null;
  return {
    id: String(event.id || ''), server: String(event.server || ''), toolName: String(event.toolName || ''),
    description: String(tool.description || ''),
    effects: [], targets: [], sceneWrite: true, assetWrite: false, fileWrite: false,
  };
}

function evidenceProjectPaths(evidence) {
  return (evidence?.targets || []).map((target) => String(target.path || '').trim())
    .filter(Boolean)
    .map((target) => target.startsWith('db://assets/') ? `assets/${target.slice('db://assets/'.length)}` : target);
}

function reviewForTask(taskId) {
  for (const session of sessions.values()) {
    const review = session.reviewRuns?.get(taskId);
    if (review) return review;
  }
  return null;
}

function captureGuardedFileBefore(call = {}) {
  const review = reviewForTask(call.taskId);
  if (!review) return;
  try {
    const evidence = runtimeResolver.extractChangeEvidence(call.serverId, {
      type: 'tool', server: call.serverId, toolName: call.toolName, status: 'running',
      arguments: call.arguments, reviewPayload: { arguments: call.arguments },
    }, environmentDiscovery.registry);
    if (!evidence?.fileWrite && !evidence?.assetWrite) return;
    mergeCaptures(review.beforeFiles, captureBeforePaths(
      PROJECT_ROOT, evidenceProjectPaths(evidence), { provenance: 'pre-write' }
    ));
  } catch (error) {
    console.warn(`[AI Copilot Review] Pre-write File snapshot failed: ${error.message}`);
  }
}

async function finalizeTurnChangeSet(session, review) {
  if (!review) return null;
  review.afterScene = await captureSceneForReview();
  const sceneAsset = review.afterScene?.scene;
  // Saving has a disk target even when the tool only declares SCENE_SAVE.
  if (sceneAsset?.assetState === 'saved' && review.evidence.some(item => item.effects?.includes('SCENE_SAVE') && !item.failed)) {
    review.evidence.push({ id: `scene-save:${review.taskId}`, toolName: 'save_current_scene',
      effects: ['ASSET_WRITE'], assetWrite: true, sceneWrite: false,
      targets: [{ assetUrl: sceneAsset.assetUrl, assetUuid: sceneAsset.assetUuid }] });
  }
  const finalFiles = captureTurnStartFileExistence(PROJECT_ROOT);
  const evidenceFileEvents = await reconcileEvidenceFileEvents(PROJECT_ROOT, review.evidence, {
    queryAsset: async (target) => {
      const identities = [target.assetUrl, target.assetUuid].map((value) => String(value || '').trim()).filter(Boolean);
      let completedQuery = false;
      let lastError = null;
      for (const identity of identities) {
        try {
          const info = await Editor.Message.request('asset-db', 'query-asset-info', identity);
          completedQuery = true;
          if (info) return info;
        } catch (error) {
          lastError = error;
        }
      }
      if (!completedQuery && lastError) throw lastError;
      return null;
    },
  });
  const existenceFileEvents = fileExistenceChanges(
    review.startFiles, finalFiles, [...review.fileEvents, ...evidenceFileEvents]
  );
  const changeSet = buildTurnChangeSet({
    projectRoot: PROJECT_ROOT,
    sessionId: review.sessionId,
    threadId: review.threadId || session.runner.threadId || '',
    turnId: review.turnId || review.taskId,
    taskId: review.taskId,
    turnDiff: review.turnDiff,
    fileEvents: [...review.fileEvents, ...evidenceFileEvents, ...existenceFileEvents],
    beforeFiles: review.beforeFiles,
    startFiles: review.startFiles,
    beforeScene: review.beforeScene,
    afterScene: review.afterScene,
    evidence: review.evidence,
    warnings: review.warnings,
  });
  if (!changeSet) return null;
  const stored = turnChangeStore.save(changeSet);
  const summary = changeSetSummary(stored);
  broadcastCodexEvent({
    type: 'turn-change-set', sessionId: review.sessionId, taskId: review.taskId,
    turnId: review.turnId || review.taskId, changeSet: summary, timestamp: Date.now(),
  });
  broadcastChanges({ type: 'change-set-updated', sessionId: review.sessionId,
    taskId: review.taskId, turnId: stored.turnId, changeSet: summary });
  return summary;
}

let sharedAccountState = {
  status: 'connecting', type: '', planType: '', requiresOpenaiAuth: true, error: '',
};

function broadcastModelServicesChanged(reason = 'updated') {
  if (!global.Editor?.Message || typeof Editor.Message.broadcast !== 'function') return;
  try {
    const result = Editor.Message.broadcast(MODEL_SERVICES_EVENT_CHANNEL, { reason });
    if (result && typeof result.catch === 'function') result.catch(() => {});
  } catch (_) { /* Panels also refresh whenever they regain focus. */ }
}

function broadcastMcpServicesChanged(reason = 'updated') {
  if (!global.Editor?.Message || typeof Editor.Message.broadcast !== 'function') return;
  try {
    const result = Editor.Message.broadcast(MCP_SERVICES_EVENT_CHANNEL, { reason });
    if (result?.catch) result.catch(() => {});
  } catch (_) { /* Settings may be closed. */ }
}

function managedMcpNames() {
  return settingsStore.load().managedMcpNames || [];
}

async function readManagedMcpSnapshot() {
  const current = settingsStore.load();
  const managed = current.managedMcpNames;
  const snapshot = await mcpConfigAdapter.readServices({ statusNames: managed });
  const configuredNames = new Set(snapshot.services.filter((service) => service.configuration).map((service) => service.name));
  const retained = managed.filter((name) => configuredNames.has(name));
  if (retained.length !== managed.length || retained.length !== current.managedMcpNames.length) {
    settingsStore.update({ managedMcpNames: retained });
  }
  mcpSettingsAppServerRevision = appServerClient.lifecycleRevision;
  return {
    ...snapshot,
    services: snapshot.services.filter((service) => retained.includes(service.name))
      .map((service) => ({ ...service, editor: current.mcpEditorMetadata?.[service.name] || null })),
  };
}

function syncMcpSettingsAppServerRevision() {
  const revision = appServerClient.lifecycleRevision;
  if (revision === mcpSettingsAppServerRevision) return;
  mcpSettingsAppServerRevision = revision;
  mcpSettingsState.invalidate('app-server-restarted');
}

function invalidateMcpSettingsState(reason) {
  mcpSettingsState.invalidate(reason);
  broadcastMcpServicesChanged(reason);
  mcpSettingsState.refreshInBackground();
}

function patchMcpRuntimeStatus(params = {}) {
  const name = String(params.name || '');
  if (!name) return false;
  return mcpSettingsState.patch((snapshot) => {
    const service = snapshot.services?.find((item) => item.name === name);
    if (!service) return null;
    service.runtimeStatus = String(params.status || service.runtimeStatus || 'starting');
    if (params.error) service.toolsError = String(params.error?.message || params.error);
    return snapshot;
  }, 'runtime-status');
}

function updateManagedMcpNames(update) {
  const names = new Set(managedMcpNames());
  update(names);
  return settingsStore.update({ managedMcpNames: [...names].sort() }).managedMcpNames;
}

function removeManagedMcpMetadata(name) {
  name = String(name || '').trim();
  const settings = settingsStore.load();
  return settingsStore.update({
    managedMcpNames: settings.managedMcpNames.filter((item) => item !== name),
  });
}

function installSafeStorage() {
  if (secretStore.safeStorage) return;
  try { secretStore.safeStorage = loadElectronMain().safeStorage || null; }
  catch (_) { secretStore.safeStorage = null; }
}

function runtimeSnapshotWithProviders(runtimeSnapshot = {}) {
  const settings = settingsStore.load();
  const modelProviders = [];
  const providerEnvironment = {};
  for (const providerId of ['openai', 'deepseek']) {
    const secret = secretStore.read(providerId);
    if (!secret) continue;
    const provider = runtimeProvider(providerId, settings.secretRevisions[providerId]);
    if (!provider) continue;
    modelProviders.push(provider);
    providerEnvironment[provider.envKey] = secret;
  }
  return {
    ...runtimeSnapshot,
    modelProviders,
    providerEnvironment,
    enabledInheritedMcpNames: [...new Set(managedMcpNames())].sort(),
    disabledInheritedMcpNames: [],
  };
}

function sanitizeAccount(result) {
  const account = result?.account;
  const type = account?.type === 'chatgpt' ? 'chatgpt' : account?.type === 'apiKey' ? 'apiKey' : '';
  return {
    status: type === 'chatgpt' ? 'connected' : 'unconfigured',
    type,
    planType: type === 'chatgpt' ? String(account.planType || '').slice(0, 80) : '',
    requiresOpenaiAuth: result?.requiresOpenaiAuth !== false,
    error: '',
  };
}

function modelCacheKey(providerId, settings = settingsStore.load()) {
  if (providerId === 'openai') {
    return settings.selectedOpenAiAuthMethod === 'apiKey' ? 'openaiApi' : 'openaiChatGpt';
  }
  return 'deepseek';
}

async function listAllCodexModels(runtimeSnapshot) {
  const models = [];
  let cursor = '';
  for (let page = 0; page < 20; page += 1) {
    const response = await appServerClient.listModels({
      runtimeSnapshot,
      includeHidden: true,
      limit: 100,
      cursor,
    });
    models.push(...normalizeCodexModels(response));
    cursor = String(response?.nextCursor || '').trim();
    if (!cursor) break;
  }
  return models;
}

function modelServicesPublicSnapshot() {
  const settings = settingsStore.load();
  const openAiHasKey = secretStore.has('openai');
  const deepSeekHasKey = secretStore.has('deepseek');
  const chatGptConnected = sharedAccountState.status === 'connected'
    && sharedAccountState.type === 'chatgpt';
  const selectedOpenAiConnected = settings.selectedOpenAiAuthMethod === 'apiKey'
    ? openAiHasKey : settings.selectedOpenAiAuthMethod === 'chatgpt' && chatGptConnected;
  const openAiCache = settings.modelCache[modelCacheKey('openai', settings)];
  const deepSeekCache = settings.modelCache.deepseek;
  return {
    selectedOpenAiAuthMethod: settings.selectedOpenAiAuthMethod,
    lastUsedProvider: settings.lastUsedProvider,
    hasConfiguredProvider: selectedOpenAiConnected || deepSeekHasKey,
    login: pendingChatGptLogin
      ? { status: 'connecting', startedAt: pendingChatGptLogin.startedAt }
      : { status: 'idle' },
    providers: {
      openai: {
        id: 'openai',
        displayName: PROVIDER_DEFINITIONS.openai.displayName,
        status: selectedOpenAiConnected ? 'connected'
          : pendingChatGptLogin ? 'connecting'
            : sharedAccountState.error && settings.selectedOpenAiAuthMethod === 'chatgpt' ? 'error' : 'unconfigured',
        authMethod: settings.selectedOpenAiAuthMethod,
        chatGpt: {
          status: sharedAccountState.status,
          connected: chatGptConnected,
          planType: sharedAccountState.planType,
          error: sharedAccountState.error,
        },
        apiKey: {
          hasKey: openAiHasKey,
          persistent: openAiHasKey && secretStore.persistentAvailable(),
        },
        models: openAiCache.models,
        rawModelCount: openAiCache.rawModelCount,
        agentModelCount: openAiCache.models.length,
        modelStatus: openAiCache.models.length ? (openAiCache.stale ? 'stale' : 'ready') : 'unavailable',
        fetchedAt: openAiCache.fetchedAt,
      },
      deepseek: {
        id: 'deepseek',
        displayName: PROVIDER_DEFINITIONS.deepseek.displayName,
        status: deepSeekHasKey ? 'connected' : 'unconfigured',
        apiKey: {
          hasKey: deepSeekHasKey,
          persistent: deepSeekHasKey && secretStore.persistentAvailable(),
        },
        models: deepSeekCache.models,
        rawModelCount: deepSeekCache.rawModelCount,
        agentModelCount: deepSeekCache.models.length,
        modelStatus: deepSeekCache.models.length ? (deepSeekCache.stale ? 'stale' : 'ready') : 'unavailable',
        fetchedAt: deepSeekCache.fetchedAt,
      },
    },
    runtime: {
      connection: runtimeConnection.inspect(),
      status: appServerClient.serverInfo ? 'running' : 'stopped',
      version: String(appServerClient.compatibility?.actualVersion || '').trim(),
      compatibility: appServerClient.compatibility?.status || 'unknown',
      activeVersion: appServerClient.compatibility?.activeVersion || '',
      previousKnownGoodVersion: appServerClient.compatibility?.previousKnownGoodVersion || '',
    },
    secretStorage: {
      persistent: secretStore.persistentAvailable(),
      description: secretStore.persistentAvailable()
        ? 'API Key 已使用系统加密存储。'
        : '系统加密存储不可用；API Key 仅保留到本次 Creator 关闭。',
    },
  };
}

async function refreshModelServices({ force = false, providerId = '' } = {}) {
  if (runtimeConnection.busy) return modelServicesPublicSnapshot();
  if (modelServicesRefreshPromise) return modelServicesRefreshPromise;
  modelServicesRefreshPromise = (async () => {
    installSafeStorage();
    const runtimeSnapshot = runtimeSnapshotWithProviders();
    const settings = settingsStore.load();
    if (!appServerClient.isRunning) {
      try {
        const account = await appServerClient.readAccount({ runtimeSnapshot });
        sharedAccountState = sanitizeAccount(account);
        if (sharedAccountState.status === 'connected'
          && (force || settings.selectedOpenAiAuthMethod === 'chatgpt'
            || !settings.modelCache.openaiChatGpt.models.length)) {
          try {
            const models = await listAllCodexModels(runtimeSnapshot);
            if (models.length) settingsStore.update({
              modelCache: { ...settings.modelCache,
                openaiChatGpt: { fetchedAt: Date.now(), stale: false,
                  rawModelCount: models.length, models } },
            });
          } catch (_) {
            settingsStore.update({
              modelCache: { ...settingsStore.load().modelCache,
                openaiChatGpt: { ...settingsStore.load().modelCache.openaiChatGpt, stale: true } },
            });
          }
        }
      } catch (_) {
        sharedAccountState = {
          ...sharedAccountState,
          status: sharedAccountState.status === 'connected' ? 'connected' : 'error',
          error: '暂时无法检查系统 Codex 登录，请稍后重试。',
        };
      }
    }

    const providerRefreshes = force
      ? (['openai', 'deepseek'].includes(providerId) ? [providerId] : ['openai', 'deepseek'])
      : [];
    for (const refreshProviderId of providerRefreshes.filter((id) => secretStore.has(id))) {
      const key = secretStore.read(refreshProviderId);
      try {
        const result = await verifyProviderKey(refreshProviderId, key);
        const current = settingsStore.load();
        const cacheKey = refreshProviderId === 'openai' ? 'openaiApi' : 'deepseek';
        settingsStore.update({
          modelCache: { ...current.modelCache,
            [cacheKey]: { fetchedAt: Date.now(), stale: false,
              rawModelCount: result.rawModelCount, models: result.models } },
        });
      } catch (_) {
        const current = settingsStore.load();
        const cacheKey = refreshProviderId === 'openai' ? 'openaiApi' : 'deepseek';
        settingsStore.update({
          modelCache: { ...current.modelCache,
            [cacheKey]: { ...current.modelCache[cacheKey], stale: true } },
        });
      }
    }
    const snapshot = modelServicesPublicSnapshot();
    broadcastModelServicesChanged('refreshed');
    return snapshot;
  })();
  try { return await modelServicesRefreshPromise; }
  finally { modelServicesRefreshPromise = null; }
}

function turnModelSelection(payload = {}) {
  const settings = settingsStore.load();
  const providerId = ['openai', 'deepseek'].includes(payload.providerId)
    ? payload.providerId : settings.lastUsedProvider;
  const cache = settings.modelCache[modelCacheKey(providerId, settings)]?.models || [];
  const fallbackModel = cache.find((model) => model.isDefault && !model.hidden)
    || cache.find((model) => !model.hidden);
  const modelId = String(payload.modelId || fallbackModel?.id || '').trim();
  const selectedModel = cache.find((model) => model.id === modelId) || fallbackModel;
  const supportedEfforts = selectedModel?.supportedReasoningEfforts || [];
  const requestedEffort = String(payload.reasoningEffort || '').trim();
  const defaultEffort = String(selectedModel?.defaultReasoningEffort || '').trim();
  const reasoningEffort = supportedEfforts.some((entry) => entry.reasoningEffort === requestedEffort)
    ? requestedEffort
    : supportedEfforts.some((entry) => entry.reasoningEffort === defaultEffort) ? defaultEffort : '';
  if (providerId === 'openai' && settings.selectedOpenAiAuthMethod === 'none'
    && String(payload.providerId || '').trim()) {
    throw new Error('请先在设置中选择 OpenAI 连接方式。');
  }
  if (providerId === 'deepseek' && !secretStore.has('deepseek')) throw new Error('请先连接 DeepSeek。');
  if (providerId === 'openai' && settings.selectedOpenAiAuthMethod === 'apiKey'
    && !secretStore.has('openai')) throw new Error('请先连接 OpenAI API Key。');
  const modelProvider = providerId === 'deepseek'
    ? PROVIDER_DEFINITIONS.deepseek.runtimeId
    : settings.selectedOpenAiAuthMethod === 'apiKey'
      ? PROVIDER_DEFINITIONS.openai.runtimeId : 'openai';
  return { providerId, modelId, reasoningEffort, modelProvider };
}

async function cancelPendingChatGptLogin() {
  const pending = pendingChatGptLogin;
  if (!pending) return { cancelled: false };
  clearTimeout(pending.timer);
  pendingChatGptLogin = null;
  const result = await appServerClient.cancelChatGptLogin(pending.loginId, {
    runtimeSnapshot: runtimeSnapshotWithProviders(),
  }).catch(() => ({ status: 'notFound' }));
  broadcastModelServicesChanged('login-cancelled');
  return { cancelled: result.status === 'canceled' || result.status === 'notFound' };
}

function getSession(sessionId) {
  sessionStore.load();
  let session = sessions.get(sessionId);
  if (!session) {
    const stored = sessionStore.records.get(sessionId);
    const storedSkillState = stored && stored.projectSkillState?.threadId === stored.threadId
      && stored.projectSkillState.revisions && typeof stored.projectSkillState.revisions === 'object'
      ? stored.projectSkillState.revisions : {};
    session = {
      runner: new CodexBackendSession({ projectRoot: PROJECT_ROOT, appServerClient }),
      reviewRuns: new Map(),
      projectSkillRevisions: new Map(Object.entries(storedSkillState)),
    };
    sessions.set(sessionId, session);
  }
  if (!(session.reviewRuns instanceof Map)) session.reviewRuns = new Map();
  if (!(session.projectSkillRevisions instanceof Map)) session.projectSkillRevisions = new Map();
  return session;
}

function cancelAllSessions() {
  sessions.forEach((session) => {
    session.cancelRequested = true;
    if (guardProxy && session.activeTaskId) guardProxy.abortTask(session.activeTaskId, 'session-disposed');
    session.runner.cancel();
  });
  sessions.clear();
  imageWorkbenchArtifactsBySession.clear();
  audioWorkbenchArtifactsBySession.clear();
}

async function readEditorMode() {
  try {
    const state=await previewRuntime.controlPreviewToolbar({action:'toolbar-state'});
    return state.running?'Preview':'Editor';
  } catch (_) { return 'Unknown'; }
}

function readDumpValue(value) {
  if (value && typeof value === 'object' && Object.prototype.hasOwnProperty.call(value, 'value')) {
    return readDumpValue(value.value);
  }
  return value;
}

async function readActiveSceneIdentity() {
  if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') return {};
  try {
    const tree = await Editor.Message.request('scene', 'query-node-tree');
    if (!tree || typeof tree !== 'object') return {};
    const name = String(readDumpValue(tree.name || tree.displayName) || '').trim();
    const uuid = String(readDumpValue(tree.uuid) || '').trim();
    return {
      ...(name ? { name } : {}),
      ...(uuid ? { uuid } : {}),
    };
  } catch (error) {
    return {};
  }
}

function getProjectDescriptor() {
  if (!projectDescriptorPromise) projectDescriptorPromise = readProjectDescriptor(PROJECT_ROOT);
  return projectDescriptorPromise;
}

async function prepareCodexPrompt(payload = {}, injectedSkillRevisions = new Map()) {
  const prompt = String(payload.prompt || '');
  const userRequest = String(payload.userRequest == null ? prompt : payload.userRequest);
  const [startedState, activeScene, projectDescriptor] = await Promise.all([
    readEditorMode(),
    readActiveSceneIdentity(),
    getProjectDescriptor(),
  ]);
  const contextSnapshot = createCocosContextSnapshot({
    project: projectDescriptor,
    editor: { mode: startedState, scene: activeScene },
    selection: payload.selection,
    pins: payload.pins,
  });
  const groundedPrompt = buildCocosExecutionPrompt({
    userRequest,
    attachments: payload.attachments,
    artifactOutputDir: payload.artifactOutputDir,
    snapshot: contextSnapshot,
  });
  console.debug(
    '[AI Copilot Grounding] modelFacingContextSnapshot=',
    JSON.stringify(createModelFacingContextSnapshot(contextSnapshot))
  );
  const selectedSkillNames = selectProjectSkillNames(
    buildUserMessageContent(userRequest, payload.attachments) || prompt,
    FUNPLAY_PROJECT_SKILLS
  );
  const loadedSkills = await projectSkillLoader.loadProjectSkills(selectedSkillNames);
  const injection = partitionProjectSkillInjections(loadedSkills, injectedSkillRevisions);
  if (injection.fresh.length) {
    const skillSummary = injection.fresh.map((skill) => (
      `- ${skill.name}\n  path=${skill.path}\n  bytes=${skill.bytes}\n  mtime=${new Date(skill.mtimeMs).toISOString()}`
    )).join('\n');
    console.log(`[AI Copilot Skills] Loaded project skills:\n${skillSummary}`);
  }
  if (injection.reused.length) {
    console.debug(`[AI Copilot Skills] Reusing thread-loaded skills: ${injection.reused.map((skill) => skill.name).join(', ')}`);
  }
  const promptWithState = buildPromptWithProjectSkillState(groundedPrompt, injection.reused);
  return {
    prompt: buildPromptWithProjectSkills(promptWithState, injection.fresh)
      + require('./lib/shell-environment').shellEnvironmentHint(),
    injections: injection.fresh.map((skill) => ({ name: skill.name, revision: injection.revisions.get(skill.name) })),
  };
}

async function prepareCodexFollowUpInput(payload = {}) {
  const userRequest = String(payload.userRequest == null ? payload.prompt || '' : payload.userRequest);
  const [startedState, activeScene, projectDescriptor] = await Promise.all([
    readEditorMode(),
    readActiveSceneIdentity(),
    getProjectDescriptor(),
  ]);
  const contextSnapshot = createCocosContextSnapshot({
    project: projectDescriptor,
    editor: { mode: startedState, scene: activeScene },
    selection: payload.selection,
    pins: payload.pins,
  });
  console.debug(
    '[AI Copilot Grounding] followUpContextSnapshot=',
    JSON.stringify(createModelFacingContextSnapshot(contextSnapshot))
  );
  return buildCocosFollowUpInput({
    userRequest,
    attachments: payload.attachments,
    artifactOutputDir: payload.artifactOutputDir,
    snapshot: contextSnapshot,
  });
}

function messageAttachments(attachments, sessionId) {
  return (Array.isArray(attachments) ? attachments : []).map((attachment) => {
    if (attachment?.type !== 'file') return attachment;
    return validateStoredAttachment(attachment, {
      attachmentRoot: fileStorageRoots.attachments,
      sessionId,
    });
  }).filter(Boolean);
}

async function snapshotAttachmentPaths(paths, sessionId, source = 'file-picker') {
  const attachments = [];
  const errors = [];
  const outcomes = [];
  for (const [index, sourcePath] of (Array.isArray(paths) ? paths : []).entries()) {
    try {
      const attachment = await snapshotIncomingPath({
        sourcePath,
        sessionId,
        attachmentRoot: fileStorageRoots.attachments,
        source,
      });
      attachments.push(attachment);
      outcomes.push({ index, attachment });
    } catch (error) {
      let failedKind = 'file';
      try { if (fs.lstatSync(path.resolve(String(sourcePath || ''))).isDirectory()) failedKind = 'directory'; }
      catch (_) { /* Keep the safe generic kind when the source disappeared. */ }
      const failure = {
        index,
        kind: failedKind,
        displayName: path.basename(String(sourcePath || '')) || '文件',
        code: error.code || 'ATTACHMENT_COPY_FAILED',
        message: '无法复制这个附件，请检查它是否仍然存在、是否可读取以及本地存储空间。',
      };
      errors.push(failure);
      outcomes.push({ index, error: failure });
      console.warn(`[AI Copilot] Attachment snapshot failed: ${error.message}`);
    }
  }
  return { attachments, errors, outcomes };
}

function clipboardFormatNames(clipboard) {
  if (!clipboard || typeof clipboard.availableFormats !== 'function') return [];
  try { return Array.from(clipboard.availableFormats() || [], (format) => String(format)); }
  catch (_) { return []; }
}

function splitClipboardPathBuffer(buffer, encoding) {
  if (!buffer || !buffer.length) return [];
  try {
    return buffer.toString(encoding).split(/\0+/u).map((value) => value.trim()).filter(Boolean);
  } catch (_) { return []; }
}

function parseClipboardUriList(value) {
  return String(value || '').split(/\r?\n/u).map((line) => line.trim())
    .filter((line) => line && !line.startsWith('#') && /^file:/iu.test(line))
    .map((uri) => {
      try { return fileURLToPath(uri); } catch (_) { return ''; }
    }).filter(Boolean);
}

function readClipboardFilesystemPaths(clipboard) {
  const formats = clipboardFormatNames(clipboard);
  const values = [];
  const append = (items) => {
    (Array.isArray(items) ? items : []).forEach((item) => {
      const candidate = String(item || '').trim();
      if (!candidate || !path.isAbsolute(candidate) || values.includes(candidate)) return;
      try {
        const stat = fs.lstatSync(candidate);
        if (!stat.isSymbolicLink() && (stat.isFile() || stat.isDirectory())) values.push(candidate);
      } catch (_) { /* Clipboard entries may have disappeared after Copy. */ }
    });
  };
  const uriFormat = formats.find((format) => format.toLowerCase() === 'text/uri-list');
  if (uriFormat && typeof clipboard.read === 'function') {
    try { append(parseClipboardUriList(clipboard.read(uriFormat))); } catch (_) { /* Try the raw representation below. */ }
  }
  if (uriFormat && !values.length && typeof clipboard.readBuffer === 'function') {
    try { append(parseClipboardUriList(clipboard.readBuffer(uriFormat).toString('utf8'))); } catch (_) { /* Unsupported mapping. */ }
  }
  const wideName = formats.find((format) => format.toLowerCase() === 'filenamew');
  if (wideName && typeof clipboard.readBuffer === 'function') {
    try { append(splitClipboardPathBuffer(clipboard.readBuffer(wideName), 'utf16le')); } catch (_) { /* Optional legacy format. */ }
  }
  const narrowName = formats.find((format) => format.toLowerCase() === 'filename');
  if (narrowName && typeof clipboard.readBuffer === 'function') {
    try { append(splitClipboardPathBuffer(clipboard.readBuffer(narrowName), 'latin1')); } catch (_) { /* Optional legacy format. */ }
  }
  return { formats, filePaths: values };
}

function changeSetKey(sessionId, turnId) {
  return `${String(sessionId || '')}\0${String(turnId || '')}`;
}

function changeSetNeedsScene(changeSet) {
  return [...(changeSet?.scene || []), ...(changeSet?.components || [])]
    .some((item) => (item.reversible && item.undoStatus !== 'restored')
      || (item.nodeUuid && item.kind !== 'node-delete'));
}

function revalidateStoredChangeSet(changeSet, sceneSnapshot = { available: false }) {
  const files = revalidateFileItems(PROJECT_ROOT, changeSet?.files || []);
  const assets = revalidateFileItems(PROJECT_ROOT, changeSet?.assets || []);
  const scene = revalidateSceneItems(changeSet?.scene || [], sceneSnapshot);
  const components = revalidateSceneItems(changeSet?.components || [], sceneSnapshot);
  const all = [...files, ...assets, ...scene, ...components];
  return {
    ...changeSet,
    expired: false,
    files,
    assets,
    scene,
    components,
    reversibleCount: all.filter((item) => item.reversible
      && item.undoStatus !== 'restored' && item.availability === 'afterStillPresent').length,
    conflictCount: all.filter((item) => item.availability === 'conflict').length,
  };
}

function expiredChangeSetSummary(summary) {
  const expire = (item) => ({
    ...item, reversible: false, availability: 'expired', reason: '本地撤销数据已过期。',
  });
  return {
    ...summary,
    expired: true,
    reversibleCount: 0,
    files: (summary.files || []).map(expire), assets: (summary.assets || []).map(expire),
    scene: (summary.scene || []).map(expire), components: (summary.components || []).map(expire),
  };
}

function refreshSessionFileAvailability(record, options = {}) {
  const sessionId = String(record?.id || '');
  const refresh = (attachments) => messageAttachments(attachments, sessionId);
  const refreshChangeSet = (turn) => {
    const summary = turn?.changeSet;
    if (!summary) return summary;
    const turnId = String(summary.turnId || turn.taskId || '');
    const stored = options.changeSets?.get(changeSetKey(sessionId, turnId)) || null;
    return stored ? changeSetSummary(revalidateStoredChangeSet(stored, options.sceneSnapshot))
      : expiredChangeSetSummary(summary);
  };
  const session = { ...record, draft: { ...(record.draft || {}), attachments: refresh(record.draft?.attachments) } };
  session.messages = (record.messages || []).map((turn) => ({
    ...turn,
    changeSet: refreshChangeSet(turn),
    attachments: refresh(turn.attachments),
    followUps: (turn.followUps || []).map((item) => ({ ...item, attachments: refresh(item.attachments) })),
    assistantMessages: (turn.assistantMessages || []).map((message) => ({
      ...message,
      text: sanitizeManagedPaths(message.text, { roots: managedInternalPathRoots }),
      artifacts: (message.artifacts || []).map((artifact) => {
        try {
          const file = resolveStoredArtifact({
            artifactRoot: fileStorageRoots.artifacts,
            sessionId,
            artifactId: artifact.id,
          });
          return { ...artifact, storedPath: file.path, size: file.stat.size, available: true };
        } catch (_) { return { ...artifact, storedPath: '', available: false }; }
      }),
    })),
  }));
  session.queue = {
    ...(record.queue || {}),
    queuedMessages: (record.queue?.queuedMessages || []).map((item) => ({
      ...item,
      attachments: refresh(item.attachments),
    })),
  };
  return session;
}

async function ensureGuardProxy() {
  if (guardProxy && guardProxy.isRunning) return guardProxy;
  if (guardProxyStartPromise) return guardProxyStartPromise;

  if (!toolGuard) {
    toolGuard = new ToolGuard({
      projectRoot: PROJECT_ROOT,
      stateProvider: readEditorMode,
    });
  }
  if (!guardProxy) {
    guardProxy = new GuardProxy({ guard: toolGuard, beforeToolCall: captureGuardedFileBefore, localTools:localTools.definitions, callLocalTool:(...args)=>localTools.call(...args) });
  }

  guardProxyStartPromise = guardProxy.start()
    .then(() => guardProxy)
    .finally(() => {
      guardProxyStartPromise = null;
    });
  return guardProxyStartPromise;
}

function loadElectronMain() {
  try {
    return require('electron');
  } catch (error) {
    throw new Error(`Electron main-process APIs are unavailable: ${error.message}`);
  }
}

function acquireDarkNativeMenuTheme(electron) {
  const nativeTheme = electron && electron.nativeTheme;
  if (!nativeTheme || typeof nativeTheme.themeSource !== 'string') return () => {};
  if (nativeMenuThemeLeaseCount === 0) {
    nativeMenuPreviousThemeSource = nativeTheme.themeSource;
    if (nativeTheme.themeSource !== 'dark') nativeTheme.themeSource = 'dark';
  }
  nativeMenuThemeLeaseCount += 1;
  let released = false;
  return () => {
    if (released) return;
    released = true;
    nativeMenuThemeLeaseCount = Math.max(0, nativeMenuThemeLeaseCount - 1);
    if (nativeMenuThemeLeaseCount !== 0) return;
    const previousThemeSource = nativeMenuPreviousThemeSource;
    nativeMenuPreviousThemeSource = null;
    if (previousThemeSource && nativeTheme.themeSource !== previousThemeSource) {
      nativeTheme.themeSource = previousThemeSource;
    }
  };
}

function restoreNativeMenuTheme() {
  if (!nativeMenuThemeLeaseCount || !nativeMenuPreviousThemeSource) {
    nativeMenuThemeLeaseCount = 0;
    nativeMenuPreviousThemeSource = null;
    return;
  }
  try {
    const electron = loadElectronMain();
    if (electron.nativeTheme) electron.nativeTheme.themeSource = nativeMenuPreviousThemeSource;
  } catch (error) {
    // Electron may already be shutting down during extension unload.
  }
  nativeMenuThemeLeaseCount = 0;
  nativeMenuPreviousThemeSource = null;
}

function normalizePanelBounds(bounds = {}) {
  const normalized = {
    x: Number(bounds.x),
    y: Number(bounds.y),
    width: Number(bounds.width),
    height: Number(bounds.height),
  };
  if (
    !Number.isFinite(normalized.x)
    || !Number.isFinite(normalized.y)
    || !Number.isFinite(normalized.width)
    || !Number.isFinite(normalized.height)
    || normalized.width <= 0
    || normalized.height <= 0
  ) {
    throw new Error('AI Copilot panel bounds are invalid.');
  }
  return normalized;
}

function findPanelFrame(electron, payload = {}) {
  const rendererPid = Number(payload.rendererPid);
  const frameRoutingId = Number(payload.frameRoutingId);
  if (
    !Number.isInteger(rendererPid)
    || rendererPid <= 0
    || !Number.isInteger(frameRoutingId)
  ) {
    throw new Error('AI Copilot panel did not provide a valid Electron frame identity.');
  }
  const contentsModule = electron && electron.webContents;
  if (!contentsModule || typeof contentsModule.getAllWebContents !== 'function') {
    throw new Error('electron.webContents.getAllWebContents is unavailable.');
  }

  const matches = [];
  contentsModule.getAllWebContents().forEach((contents) => {
    if (!contents || (typeof contents.isDestroyed === 'function' && contents.isDestroyed())) return;
    let frames = [];
    try {
      frames = contents.mainFrame && contents.mainFrame.framesInSubtree || [];
    } catch (error) {
      return;
    }
    frames.forEach((frame) => {
      try {
        if (frame.routingId === frameRoutingId && frame.osProcessId === rendererPid) {
          matches.push({ contents, frame });
        }
      } catch (error) {
        // A frame may detach while the registration request is being resolved.
      }
    });
  });

  if (matches.length !== 1) {
    throw new Error(
      matches.length
        ? `AI Copilot Electron frame identity is ambiguous (${matches.length} matches).`
        : 'AI Copilot Electron frame could not be found.'
    );
  }
  return matches[0];
}

function removeMainPanelContext() {
  const binding = mainPanelContext;
  mainPanelContext = null;
  if (!binding || !binding.contents) return;
  try {
    binding.contents.removeListener('context-menu', binding.contextMenuHandler);
    binding.contents.removeListener('destroyed', binding.destroyedHandler);
  } catch (error) {
    // The WebContents may already be destroyed during an editor/extension reload.
  }
}

function contextBelongsToMainPanel(binding, params = {}) {
  if (!binding || !binding.visible || !params.frame) return false;
  try {
    if (params.frame.frameTreeNodeId !== binding.frameTreeNodeId) return false;
  } catch (error) {
    return false;
  }
  if (!binding.usesBounds) return true;
  const { x, y, width, height } = binding.bounds;
  const pointX = Number(params.x);
  const pointY = Number(params.y);
  return Number.isFinite(pointX)
    && Number.isFinite(pointY)
    && pointX >= x
    && pointY >= y
    && pointX <= x + width
    && pointY <= y + height;
}

function runWebContentsEditCommand(contents, command, selectionText = '') {
  if (!contents || (typeof contents.isDestroyed === 'function' && contents.isDestroyed())) return;
  const action = contents[command];
  if (typeof action === 'function') {
    action.call(contents);
    return;
  }
  if (command === 'copy' && selectionText) {
    const electron = loadElectronMain();
    if (electron.clipboard && typeof electron.clipboard.writeText === 'function') {
      electron.clipboard.writeText(selectionText);
    }
  }
}

function broadcastNewSessionRequest() {
  if (!global.Editor || !Editor.Message || typeof Editor.Message.broadcast !== 'function') return;
  try {
    const result = Editor.Message.broadcast(NEW_SESSION_EVENT_CHANNEL, { source: 'native-context-menu' });
    if (result && typeof result.catch === 'function') {
      result.catch((error) => {
        console.warn(`[AI Copilot] Unable to request a new session: ${error.message}`);
      });
    }
  } catch (error) {
    console.warn(`[AI Copilot] Unable to request a new session: ${error.message}`);
  }
}

function showGlobalNativeContextMenu(binding, params = {}) {
  const electron = loadElectronMain();
  const Menu = electron.Menu;
  const BrowserWindow = electron.BrowserWindow;
  if (!Menu || typeof Menu.buildFromTemplate !== 'function') return false;

  const editFlags = params.editFlags || {};
  const selectionText = String(params.selectionText || '');
  const canCut = Boolean(params.isEditable && editFlags.canCut);
  const canCopy = Boolean(editFlags.canCopy || selectionText.length > 0);
  const canPaste = Boolean(params.isEditable && editFlags.canPaste);
  console.debug(
    `[AI Copilot][Global Context] context-menu editable=${Boolean(params.isEditable)} selection=${selectionText.length}`
  );
  console.debug(
    `[AI Copilot][Global Context] menu shown copy=${canCopy} cut=${canCut} paste=${canPaste}`
  );

  const imageTarget = params.mediaType === 'image';
  const menu = Menu.buildFromTemplate([
    ...(imageTarget ? [{
      label: '复制图片',
      enabled: Boolean(params.hasImageContents && typeof binding.contents.copyImageAt === 'function'),
      click: () => {
        if (!binding.contents.isDestroyed()) binding.contents.copyImageAt(params.x, params.y);
      },
    }, { type: 'separator' }] : []),
    {
      label: '剪切',
      accelerator: 'CmdOrCtrl+X',
      enabled: canCut,
      click: () => runWebContentsEditCommand(binding.contents, 'cut'),
    },
    {
      label: '复制',
      accelerator: 'CmdOrCtrl+C',
      enabled: canCopy,
      click: () => runWebContentsEditCommand(binding.contents, 'copy', selectionText),
    },
    {
      label: '粘贴',
      accelerator: 'CmdOrCtrl+V',
      enabled: canPaste,
      click: () => runWebContentsEditCommand(binding.contents, 'paste'),
    },
    { type: 'separator' },
    {
      label: '新建会话',
      click: () => broadcastNewSessionRequest(),
    },
  ]);
  const popupOptions = {};
  const ownerWindow = BrowserWindow && typeof BrowserWindow.fromWebContents === 'function'
    ? BrowserWindow.fromWebContents(binding.contents)
    : null;
  const focusedWindow = !ownerWindow && BrowserWindow && typeof BrowserWindow.getFocusedWindow === 'function'
    ? BrowserWindow.getFocusedWindow()
    : null;
  if (ownerWindow || focusedWindow) popupOptions.window = ownerWindow || focusedWindow;
  if (params.menuSourceType) popupOptions.sourceType = params.menuSourceType;
  const releaseTheme = acquireDarkNativeMenuTheme(electron);
  popupOptions.callback = releaseTheme;
  try {
    menu.popup(popupOptions);
  } catch (error) {
    releaseTheme();
    throw error;
  }
  return true;
}

function handleMainPanelContextMenu(binding, event, params = {}) {
  if (binding !== mainPanelContext || !contextBelongsToMainPanel(binding, params)) return;
  if (typeof event.preventDefault === 'function') event.preventDefault();
  if (Date.now() <= binding.suppressGlobalUntil) {
    binding.suppressGlobalUntil = 0;
    console.debug('[AI Copilot][Global Context] suppressed reason=special-context');
    return;
  }
  showGlobalNativeContextMenu(binding, params);
}

function registerMainPanelContext(payload = {}) {
  const contextId = String(payload.contextId || '').trim();
  if (!contextId) throw new Error('AI Copilot panel contextId is required.');
  const electron = loadElectronMain();
  const bounds = normalizePanelBounds(payload.bounds);
  const resolved = findPanelFrame(electron, payload);
  const frameTreeNodeId = resolved.frame.frameTreeNodeId;
  const usesBounds = Boolean(
    resolved.contents.mainFrame
    && resolved.contents.mainFrame.frameTreeNodeId === frameTreeNodeId
  );

  if (
    mainPanelContext
    && mainPanelContext.contextId === contextId
    && mainPanelContext.contents === resolved.contents
    && mainPanelContext.frameTreeNodeId === frameTreeNodeId
  ) {
    mainPanelContext.bounds = bounds;
    mainPanelContext.visible = payload.visible !== false;
    mainPanelContext.usesBounds = usesBounds;
    mainPanelContext.updatedAt = Date.now();
    return {
      registered: true,
      webContentsId: resolved.contents.id,
      frameTreeNodeId,
      reused: true,
    };
  }

  removeMainPanelContext();
  const binding = {
    contextId,
    contents: resolved.contents,
    frameTreeNodeId,
    bounds,
    usesBounds,
    visible: payload.visible !== false,
    suppressGlobalUntil: 0,
    updatedAt: Date.now(),
    contextMenuHandler: null,
    destroyedHandler: null,
  };
  binding.contextMenuHandler = (event, params) => handleMainPanelContextMenu(binding, event, params);
  binding.destroyedHandler = () => {
    if (mainPanelContext === binding) mainPanelContext = null;
  };
  resolved.contents.on('context-menu', binding.contextMenuHandler);
  resolved.contents.once('destroyed', binding.destroyedHandler);
  mainPanelContext = binding;
  console.log(
    `[AI Copilot][Global Context] registered webContents=${resolved.contents.id} frame=${frameTreeNodeId}`
  );
  return {
    registered: true,
    webContentsId: resolved.contents.id,
    frameTreeNodeId,
    reused: false,
  };
}

function unregisterMainPanelContext(payload = {}) {
  const contextId = String(payload.contextId || '').trim();
  if (!mainPanelContext || (contextId && mainPanelContext.contextId !== contextId)) return false;
  removeMainPanelContext();
  return true;
}

function suppressMainPanelGlobalContext(payload = {}) {
  const contextId = String(payload.contextId || '').trim();
  if (!mainPanelContext || !contextId || mainPanelContext.contextId !== contextId) return false;
  mainPanelContext.suppressGlobalUntil = Date.now() + SPECIAL_CONTEXT_SUPPRESSION_MS;
  return true;
}

function nativeContextMenuItems(payload = {}) {
  const kind = String(payload.kind || '').trim();
  const selectedText = String(payload.selectedText || '');
  if (kind === 'attachment') {
    return [
      { id: 'open-detail', label: '打开详情' },
      { id: 'copy-content', label: '复制内容', copyText: String(payload.copyText || '') },
    ];
  }
  if (kind === 'attachment-picker') {
    return [
      { id: 'upload-file', label: '上传文件' },
      { id: 'upload-directory', label: '上传文件夹' },
    ];
  }
  if (kind === 'mcp-source') {
    return [{ id: 'view-source', label: '查看来源' }];
  }
  if (kind === 'detail') {
    return [
      ...(selectedText.trim()
        ? [{ id: 'copy-selection', label: '复制', copyText: selectedText }]
        : []),
      { id: 'select-all', label: '全选' },
    ];
  }
  return [];
}

function showNativeContextMenu(payload = {}) {
  const electron = loadElectronMain();
  const Menu = electron && electron.Menu;
  const clipboard = electron && electron.clipboard;
  if (!Menu || typeof Menu.buildFromTemplate !== 'function') {
    throw new Error('electron.Menu.buildFromTemplate is unavailable in the extension main process.');
  }

  const items = nativeContextMenuItems(payload);
  if (!items.length) return Promise.resolve({ shown: false, action: '' });

  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      resolve(result);
    };
    const template = items.map((item) => ({
      label: item.label,
      enabled: item.copyText === undefined || Boolean(clipboard && typeof clipboard.writeText === 'function'),
      click: () => {
        let copied = false;
        if (item.copyText !== undefined && clipboard && typeof clipboard.writeText === 'function') {
          try {
            clipboard.writeText(item.copyText);
            copied = true;
          } catch (error) {
            console.warn(`[AI Copilot] Native context menu copy failed: ${error.message}`);
          }
        }
        finish({ shown: true, action: item.id, copied });
      },
    }));

    let menu;
    try {
      menu = Menu.buildFromTemplate(template);
      const releaseTheme = acquireDarkNativeMenuTheme(electron);
      const popupOptions = {
        callback: () => {
          releaseTheme();
          finish({ shown: true, action: 'dismissed', copied: false });
        },
      };
      const BrowserWindow = electron.BrowserWindow;
      const panelWindow = mainPanelContext
        && String(payload.contextId || '') === mainPanelContext.contextId
        && BrowserWindow
        && typeof BrowserWindow.fromWebContents === 'function'
        ? BrowserWindow.fromWebContents(mainPanelContext.contents)
        : null;
      const focusedWindow = !panelWindow && BrowserWindow && typeof BrowserWindow.getFocusedWindow === 'function'
        ? BrowserWindow.getFocusedWindow()
        : null;
      if (panelWindow || focusedWindow) popupOptions.window = panelWindow || focusedWindow;
      menu.popup(popupOptions);
    } catch (error) {
      restoreNativeMenuTheme();
      reject(error);
    }
  });
}

module.exports = {
  load() {
    sessionStore.load();
    settingsStore.load();
    installSafeStorage();
    if (!disposeAppServerNotification) {
      disposeAppServerNotification = appServerClient.onNotification(({ method, params }) => {
        if (method === 'account/login/completed') {
          const matches = !pendingChatGptLogin || !params.loginId
            || params.loginId === pendingChatGptLogin.loginId;
          if (!matches) return;
          if (pendingChatGptLogin?.timer) clearTimeout(pendingChatGptLogin.timer);
          pendingChatGptLogin = null;
          if (params.success === false) {
            sharedAccountState = { ...sharedAccountState, status: 'error',
              error: 'ChatGPT 登录没有完成，请重试。' };
            broadcastModelServicesChanged('login-failed');
            return;
          }
          settingsStore.update({ selectedOpenAiAuthMethod: 'chatgpt', lastUsedProvider: 'openai' });
          refreshModelServices({ force: true }).catch(() => broadcastModelServicesChanged('login-failed'));
        } else if (method === 'account/updated') {
          refreshModelServices({ force: true }).catch(() => {});
        } else if (method === 'mcpServer/oauthLogin/completed') {
          mcpConfigAdapter.handleNotification(method, params)
            .then(() => invalidateMcpSettingsState('oauth-completed')).catch(() => {});
        } else if (method === 'mcpServer/startupStatus/updated') {
          mcpConfigAdapter.handleNotification(method, params)
            .then(() => patchMcpRuntimeStatus(params)).catch(() => {});
        }
      });
    }
    const runtimeStartup = cocosRuntimeService.load();
    Promise.resolve(runtimeStartup).then(() => environmentDiscovery.refresh({ force: true })).catch(() => {});
    Promise.resolve().then(() => refreshModelServices()).catch(() => {});
  },

  unload() {
    try { sessionStore.flush(); } catch (_) { console.warn('[AI Copilot] 聊天历史暂时无法保存。'); }
    if (pendingChatGptLogin?.timer) clearTimeout(pendingChatGptLogin.timer);
    pendingChatGptLogin = null;
    if (disposeAppServerNotification) disposeAppServerNotification();
    disposeAppServerNotification = null;
    secretStore.clearMemory();
    cancelAllSessions();
    detailRegistry.clear();
    removeMainPanelContext();
    restoreNativeMenuTheme();
    const proxy = guardProxy;
    guardProxy = null;
    toolGuard = null;
    guardProxyStartPromise = null;
    return Promise.all([
      proxy ? proxy.stop() : undefined,
      cocosRuntimeService.unload(),
      mcpConfigAdapter.cancelTests(),
      appServerClient.stop(),
    ]);
  },

  methods: {
    async getCocosCapabilities() {
      await cocosRuntimeService.whenReady();
      return {
        copilotVersion: EXTENSION_VERSION,
        runtime: cocosRuntimeService.getStatus(),
        skills: builtInSkillManager.inspect(),
        localTools: localToolCapabilitySnapshot(),
      };
    },

    async restartCocosRuntime() {
      const runtime = await cocosRuntimeService.restart();
      await environmentDiscovery.refresh({ force: true }).catch(() => {});
      invalidateMcpSettingsState('cocos-runtime-restarted');
      return { runtime, skills: builtInSkillManager.inspect() };
    },

    async repairCocosCapabilities() {
      const result = await cocosRuntimeService.repair();
      await environmentDiscovery.refresh({ force: true }).catch(() => {});
      invalidateMcpSettingsState('cocos-runtime-repaired');
      return result;
    },

    async setCocosRuntimeEnabled(payload = {}) {
      settingsStore.update({ cocosRuntimeEnabled: payload.enabled !== false });
      const runtime = payload.enabled === false
        ? await cocosRuntimeService.stop() : await cocosRuntimeService.restart();
      await environmentDiscovery.refresh({ force: true }).catch(() => {});
      invalidateMcpSettingsState('cocos-runtime-toggle');
      return { runtime, skills: builtInSkillManager.inspect() };
    },

    async callCocosRuntimeTool(name, args) {
      return cocosRuntimeService.callTool(name, args || {});
    },
    getTurnPerformanceTrace(payload = {}) {
      const taskId = String(payload.taskId || '').trim();
      if (!taskId) return null;
      return activeTurnPerformanceTraces.get(taskId)?.snapshot()
        || completedTurnPerformanceTraces.get(taskId)
        || null;
    },

    async getModelServices(payload = {}) {
      return payload.refresh === true ? refreshModelServices({ force: true }) : modelServicesPublicSnapshot();
    },

    async refreshModelServices(payload = {}) {
      return refreshModelServices({ force: true, providerId: String(payload.providerId || '') });
    },

    async checkCodexRuntime(payload = {}) {
      const result = await runtimeConnection.check(payload);
      broadcastModelServicesChanged('runtime-checked');
      return { ...result, snapshot: modelServicesPublicSnapshot() };
    },

    async browseCodexRuntime() {
      if (typeof global.Editor?.Dialog?.select !== 'function') throw new Error('当前 Editor 无法打开文件选择器。');
      const result = await Editor.Dialog.select({ title: '选择 Codex 程序', type: 'file', multi: false,
        filters: [{ name: 'Codex 程序', extensions: process.platform === 'win32' ? ['exe'] : ['*'] }] });
      return { canceled: !result || result.canceled || !result.filePaths?.length, path: result?.filePaths?.[0] || '' };
    },

    async setOpenAiAuthMethod(payload = {}) {
      const authMethod = String(payload.authMethod || '');
      if (!['chatgpt', 'apiKey', 'none'].includes(authMethod)) throw new Error('不支持的认证方式。');
      if (authMethod === 'chatgpt'
        && !(sharedAccountState.status === 'connected' && sharedAccountState.type === 'chatgpt')) {
        throw new Error('系统 Codex 尚未登录 ChatGPT。');
      }
      if (authMethod === 'apiKey' && !secretStore.has('openai')) {
        throw new Error('OpenAI API Key 尚未配置。');
      }
      settingsStore.update({ selectedOpenAiAuthMethod: authMethod, lastUsedProvider: 'openai' });
      broadcastModelServicesChanged('auth-method');
      return authMethod === 'chatgpt'
        ? refreshModelServices({ force: true }) : modelServicesPublicSnapshot();
    },

    async setLastUsedProvider(payload = {}) {
      const providerId = String(payload.providerId || '');
      if (!['openai', 'deepseek'].includes(providerId)) throw new Error('不支持的模型服务。');
      settingsStore.update({ lastUsedProvider: providerId });
      broadcastModelServicesChanged('provider-preference');
      return modelServicesPublicSnapshot();
    },

    async verifyProviderKey(payload = {}) {
      const providerId = String(payload.providerId || '');
      const apiKey = String(payload.apiKey || '').trim();
      if (!['openai', 'deepseek'].includes(providerId) || !apiKey) {
        return { connected: false, message: '请输入 API Key。' };
      }
      let verified;
      try { verified = await verifyProviderKey(providerId, apiKey); }
      catch (_) {
        return { connected: false, message: '连接失败，API Key 无效或当前服务不可用。' };
      }
      const storage = secretStore.write(providerId, apiKey);
      const current = settingsStore.load();
      const nextRevision = current.secretRevisions[providerId] + 1;
      const cacheKey = providerId === 'openai' ? 'openaiApi' : 'deepseek';
      settingsStore.update({
        ...(providerId === 'openai'
          ? { selectedOpenAiAuthMethod: 'apiKey', lastUsedProvider: 'openai' }
          : { lastUsedProvider: 'deepseek' }),
        secretRevisions: { ...current.secretRevisions, [providerId]: nextRevision },
        modelCache: { ...current.modelCache,
          [cacheKey]: { fetchedAt: Date.now(), stale: false,
            rawModelCount: verified.rawModelCount, models: verified.models } },
      });
      broadcastModelServicesChanged('provider-connected');
      return { connected: true, persistent: storage.persistent, snapshot: modelServicesPublicSnapshot() };
    },

    async removeProviderKey(payload = {}) {
      const providerId = String(payload.providerId || '');
      if (!['openai', 'deepseek'].includes(providerId)) throw new Error('不支持的模型服务。');
      secretStore.delete(providerId);
      const current = settingsStore.load();
      const cacheKey = providerId === 'openai' ? 'openaiApi' : 'deepseek';
      settingsStore.update({
        ...(providerId === 'openai' && current.selectedOpenAiAuthMethod === 'apiKey'
          ? { selectedOpenAiAuthMethod: 'none' } : {}),
        secretRevisions: { ...current.secretRevisions,
          [providerId]: current.secretRevisions[providerId] + 1 },
        modelCache: { ...current.modelCache,
          [cacheKey]: { ...current.modelCache[cacheKey], stale: true } },
      });
      broadcastModelServicesChanged('provider-removed');
      return modelServicesPublicSnapshot();
    },

    async startChatGptLogin() {
      if (pendingChatGptLogin) return { started: false, duplicate: true, status: 'connecting' };
      if (appServerClient.isRunning || runtimeConnection.busy) {
        return { started: false, message: '当前任务正在运行，请在完成后连接 ChatGPT。' };
      }
      let response;
      try { response = await appServerClient.startChatGptLogin({ runtimeSnapshot: runtimeSnapshotWithProviders() }); }
      catch (_) {
        sharedAccountState = { ...sharedAccountState, status: 'error', error: '无法开始 ChatGPT 登录，请重试。' };
        broadcastModelServicesChanged('login-failed');
        return { started: false, message: sharedAccountState.error };
      }
      const loginId = String(response?.loginId || '').trim();
      const authUrl = String(response?.authUrl || '').trim();
      let parsed;
      try { parsed = new URL(authUrl); } catch (_) { /* checked below */ }
      if (!loginId || !parsed || parsed.protocol !== 'https:'
        || !(parsed.hostname === 'openai.com' || parsed.hostname.endsWith('.openai.com'))) {
        if (loginId) appServerClient.cancelChatGptLogin(loginId, {
          runtimeSnapshot: runtimeSnapshotWithProviders(),
        }).catch(() => {});
        return { started: false, message: '登录地址无效，请重试。' };
      }
      const timer = setTimeout(() => {
        const pending = pendingChatGptLogin;
        if (!pending || pending.loginId !== loginId) return;
        pendingChatGptLogin = null;
        appServerClient.cancelChatGptLogin(loginId, { runtimeSnapshot: runtimeSnapshotWithProviders() }).catch(() => {});
        sharedAccountState = { ...sharedAccountState, status: 'error', error: 'ChatGPT 登录已超时，请重试。' };
        broadcastModelServicesChanged('login-timeout');
      }, 5 * 60 * 1000);
      timer.unref?.();
      pendingChatGptLogin = { loginId, startedAt: Date.now(), timer };
      try { await loadElectronMain().shell.openExternal(authUrl); }
      catch (_) {
        clearTimeout(timer);
        pendingChatGptLogin = null;
        await appServerClient.cancelChatGptLogin(loginId, {
          runtimeSnapshot: runtimeSnapshotWithProviders(),
        }).catch(() => {});
        return { started: false, message: '无法打开系统浏览器，请重试。' };
      }
      broadcastModelServicesChanged('login-started');
      return { started: true, status: 'connecting' };
    },

    async cancelChatGptLogin() {
      return cancelPendingChatGptLogin();
    },

    async settingsPanelClosed() {
      await Promise.all([cancelPendingChatGptLogin(), mcpConfigAdapter.cancelPanelActivities()]);
      return { closed: true };
    },

    async getMcpServices(payload = {}) {
      syncMcpSettingsAppServerRevision();
      const snapshot = await mcpSettingsState.get({ refresh: payload.refresh === true });
      return {
        ...snapshot,
        cache: mcpSettingsState.inspect(),
      };
    },

    async parseMcpConfiguration(payload = {}) {
      const snapshot = await mcpConfigAdapter.readServices();
      return { services: mcpConfigAdapter.parseImport(payload.text,
        snapshot.services.filter((service) => service.configuration).map((service) => service.name)) };
    },

    async getExternalCocosServices(payload = {}) {
      return externalCocosDiscovery.get({ refresh: payload.refresh === true });
    },

    async testMcpService(payload = {}) {
      return mcpConfigAdapter.testDraft(payload.service || payload, { timeoutMs: payload.timeoutMs });
    },

    async findMcpApplication(payload = {}) {
      const { findFamiStudio } = require('./lib/mcp-application-support');
      return findFamiStudio({ currentPath: String(payload.currentPath || '') });
    },

    async browseMcpApplication() {
      return browseMcpFile(global.Editor?.Dialog, 'application');
    },

    async browseMcpFile(payload = {}) {
      return browseMcpFile(global.Editor?.Dialog, payload.kind);
    },

    async resolveMcpEntry(payload = {}) {
      return resolveMcpEntry(payload);
    },

    async saveMcpService(payload = {}) {
      const result = await mcpConfigAdapter.saveService(payload.service || payload, {
        expectedVersion: payload.expectedVersion,
        createOnly: payload.creating === true,
      });
      const service = payload.service || payload;
      updateManagedMcpNames((names) => names.add(String(service.name || '')));
      if (Object.prototype.hasOwnProperty.call(payload, 'editor')) {
        const metadata = { ...settingsStore.load().mcpEditorMetadata };
        if (payload.editor && service.transport === 'stdio') metadata[service.name] = normalizeEditorMetadata(payload.editor);
        else delete metadata[service.name];
        settingsStore.update({ mcpEditorMetadata: metadata });
      }
      invalidateMcpSettingsState(result.reloadPending ? 'saved-pending' : 'saved');
      return result;
    },

    async setMcpServiceEnabled(payload = {}) {
      const result = await mcpConfigAdapter.setEnabled(payload.name, payload.enabled, {
        expectedVersion: payload.expectedVersion,
      });
      invalidateMcpSettingsState(result.reloadPending ? 'saved-pending' : 'enabled');
      return result;
    },

    async deleteMcpService(payload = {}) {
      const result = await mcpConfigAdapter.deleteService(payload.name, {
        expectedVersion: payload.expectedVersion,
      });
      removeManagedMcpMetadata(payload.name);
      invalidateMcpSettingsState(result.reloadPending ? 'saved-pending' : 'deleted');
      return result;
    },

    async startMcpOauthLogin(payload = {}) {
      const result = await mcpConfigAdapter.loginOAuth(payload.name);
      let parsed;
      try { parsed = new URL(result.authUrl); } catch (_) { /* checked below */ }
      if (!parsed || !['http:','https:'].includes(parsed.protocol)) throw new Error('OAuth 登录地址无效。');
      await loadElectronMain().shell.openExternal(result.authUrl);
      invalidateMcpSettingsState('oauth-started');
      return { started: true };
    },

    async loadSessions() {
      const startedAt = Date.now();
      const result = sessionStore.load();
      const changeSets = new Map();
      for (const record of result.sessions || []) {
        for (const turn of record.messages || []) {
          if (!turn.changeSet) continue;
          const turnId = String(turn.changeSet.turnId || turn.taskId || '');
          const stored = turnId ? turnChangeStore.load(record.id, turnId, { withBytes: false }) : null;
          if (!stored) continue;
          changeSets.set(changeSetKey(record.id, turnId), stored);
        }
      }
      // Local content is independent of Creator IPC. Existing unavailable-state
      // projection keeps Scene Undo fail-closed until a separate revalidation.
      const restored = (result.sessions || []).map((record) => refreshSessionFileAvailability(record, { changeSets }));
      console.debug(`[AI Copilot Sessions] session-local-load count=${restored.length} elapsedMs=${Date.now() - startedAt}`);
      if (result.warnings?.length) console.warn(`[AI Copilot Sessions] ${result.warnings[0]}`);
      return {
        ...result, projectKey: sessionStore.projectKey, readOnly: sessionStore.readOnly, sessions: restored,
      };
    },

    async revalidateSessionReviews(payload = {}) {
      const projectKey = sessionStore.projectKey;
      if (payload.projectKey !== projectKey) return { projectKey, changes: [] };
      const startedAt = Date.now();
      const storedChanges = new Map();
      for (const ref of Array.isArray(payload.changes) ? payload.changes : []) {
        const stored = turnChangeStore.load(ref.sessionId, ref.turnId, { withBytes: false });
        if (stored) storedChanges.set(changeSetKey(stored.sessionId, stored.turnId), stored);
      }
      const needsScene = Array.from(storedChanges.values()).some(changeSetNeedsScene);
      const snapshot = needsScene ? await captureSceneForReview() : { available: false };
      const changes = Array.from(storedChanges.values()).map((stored) => {
        // Undo/expiry may have changed the persisted record during the IPC await.
        const current = turnChangeStore.load(stored.sessionId, stored.turnId, { withBytes: false });
        return { sessionId: stored.sessionId, turnId: stored.turnId,
          changeSet: current ? changeSetSummary(revalidateStoredChangeSet(current, snapshot))
            : expiredChangeSetSummary(changeSetSummary(stored)) };
      });
      console.debug(`[AI Copilot Sessions] review-revalidate count=${changes.length} elapsedMs=${Date.now() - startedAt} status=${needsScene && !snapshot?.available ? 'scene-unavailable' : 'complete'}`);
      return { projectKey, changes };
    },

    async selectChatAttachments(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      const requestedKind = payload.kind === 'directory' ? 'directory' : 'file';
      if (!sessionId) throw new Error('Session id is required.');
      if (!global.Editor?.Dialog || typeof Editor.Dialog.select !== 'function') {
        throw new Error('当前 Cocos Editor 无法打开文件选择器。');
      }
      const result = await Editor.Dialog.select({
        title: requestedKind === 'directory' ? '选择文件夹' : '选择文件',
        type: requestedKind,
        multi: true,
        ...(requestedKind === 'file' ? { filters: [{ name: '所有文件', extensions: ['*'] }] } : {}),
      });
      if (!result || result.canceled || !Array.isArray(result.filePaths) || !result.filePaths.length) {
        return { canceled: true, attachments: [], errors: [] };
      }
      return { canceled: false, ...await snapshotAttachmentPaths(result.filePaths, sessionId, 'file-picker') };
    },

    async ingestDroppedAttachments(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      if (!sessionId) throw new Error('Session id is required.');
      return snapshotAttachmentPaths(payload.filePaths, sessionId, String(payload.source || 'file-drop'));
    },

    async ingestClipboardAttachments(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      if (!sessionId) throw new Error('Session id is required.');
      let audit = { formats: [], filePaths: [] };
      try { audit = readClipboardFilesystemPaths(loadElectronMain().clipboard); }
      catch (_) { /* Renderer File objects remain the primary Electron 31 path. */ }
      if (!audit.filePaths.length) {
        return {
          handled: false,
          formats: audit.formats,
          attachments: [],
          errors: [],
          limitation: audit.formats.some((format) => /(?:text\/uri-list|filenamew?|cf_hdrop|shell idlist)/iu.test(format))
            ? 'Electron 31 exposed a native file-list format but did not provide safely parseable paths.'
            : '',
        };
      }
      return {
        handled: true,
        formats: audit.formats,
        ...await snapshotAttachmentPaths(audit.filePaths, sessionId, 'clipboard-file'),
      };
    },

    async ingestClipboardImage(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      const mimeType = String(payload.mimeType || '').trim().toLowerCase();
      if (!sessionId || !mimeType.startsWith('image/')) throw new Error('Clipboard image metadata is invalid.');
      const source = payload.bytes && payload.bytes.type === 'Buffer' && Array.isArray(payload.bytes.data)
        ? payload.bytes.data
        : payload.bytes;
      try {
        const attachment = await snapshotIncomingBytes({
          bytes: source,
          displayName: payload.displayName,
          mimeType,
          sessionId,
          attachmentRoot: fileStorageRoots.attachments,
        });
        return { attachment };
      } catch (error) {
        console.warn(`[AI Copilot] Clipboard image snapshot failed: ${error.message}`);
        return { attachment: null, message: '无法添加剪贴板图片，请重试。' };
      }
    },

    async commitAgentImageAssets(payload = {}) { return commitImageAgentAssets(payload); },

    async imageWorkbenchAction(payload = {}) {
      const sessionId=String(payload.sessionId||payload.source?.sessionId||'').trim();
      if(!sessionId)throw new Error('Image Workbench 原会话已不可用。');
      const sourcePayload={...(payload.source||{}),sessionId};
      const workbenchKey=JSON.stringify([sessionId,sourcePayload.identity||sourcePayload.artifactId||sourcePayload.attachmentId||sourcePayload.target||'selected']);
      const source=await readAssetPreviewSource(sourcePayload);
      const resolveSource=async ref=>readAssetPreviewSource(imageSourcePayload(ref,sessionId));
      if(payload.action==='query-settings') {
        const target=String(payload.target||source.assetUuid||'').trim();if(!target)throw new Error('当前图片尚未导入项目。');
        const info=await Editor.Message.request('asset-db','query-asset-info',target);if(!info?.uuid||info.type!=='cc.ImageAsset'||info.invalid)throw new Error('当前目标不是有效 ImageAsset。');
        const meta=await Editor.Message.request('asset-db','query-asset-meta',info.uuid);
        return {assetUrl:info.url,assetUuid:info.uuid,...require('./lib/asset-preview/image-asset-settings').readSettings(meta)};
      }
      if(payload.action==='render') {
        imageWorkbenchRevisions.set(workbenchKey,payload.revision);if(imageWorkbenchRevisions.size>128)imageWorkbenchRevisions.delete(imageWorkbenchRevisions.keys().next().value);
        const worker=imageWorkerClient.sharedImageWorker(),taskId=`image-workbench-render:${require('crypto').randomUUID()}`,previous=imageWorkbenchTasks.get(workbenchKey);
        if(previous)worker.cancel(previous,'图片预览已被更新的草稿取代。');
        imageWorkbenchTasks.set(workbenchKey,taskId);
        try {
          const processed=await imageArtifactService.processImageDraft({source:{...source,...sourcePayload},recipe:payload.recipe,revision:payload.revision,
            taskId,resolveSource,worker});
          if(imageWorkbenchTasks.get(workbenchKey)!==taskId||imageWorkbenchRevisions.get(workbenchKey)!==payload.revision)return {revision:payload.revision,cancelled:true,stale:true};
          return {revision:processed.recipe.revision,recipe:processed.recipe,metadata:processed.metadata,mimeType:processed.encoded.mimeType,base64:processed.bytes.toString('base64')};
        } catch(error) {
          if(error?.code==='IMAGE_WORKER_CANCELLED'&&imageWorkbenchTasks.get(workbenchKey)!==taskId)return {revision:payload.revision,cancelled:true,stale:true};
          throw error;
        } finally { if(imageWorkbenchTasks.get(workbenchKey)===taskId)imageWorkbenchTasks.delete(workbenchKey); }
      }
      if(payload.action==='save') {
        if(imageWorkbenchRevisions.has(workbenchKey)&&imageWorkbenchRevisions.get(workbenchKey)!==payload.revision){const error=new Error('图片草稿版本已变化，未保存旧结果。');error.code='STALE_IMAGE_REVISION';throw error;}
        imageWorkbenchRevisions.set(workbenchKey,payload.revision);
        const taskId=String(payload.taskId||`image-workbench:${Date.now()}:${Math.random().toString(36).slice(2,8)}`);
        const saved=await imageArtifactService.saveImageVersion({source:{...source,...sourcePayload},recipe:payload.recipe,revision:payload.revision,
          sessionId,turnId:taskId,taskId:`${taskId}:process`,artifactRoot:fileStorageRoots.artifacts,resolveSource,readSource:()=>readAssetPreviewSource(sourcePayload),
          assertRevision:revision=>{if(revision!==payload.revision||imageWorkbenchRevisions.get(workbenchKey)!==revision){const error=new Error('图片草稿版本已变化，未保存旧结果。');error.code='STALE_IMAGE_REVISION';throw error;}}});
        rememberWorkbenchImageArtifact(sessionId,saved.artifact);
        broadcastCodexEvent({type:'assistant-artifacts',sessionId,taskId,artifacts:[saved.artifact],timestamp:Date.now()});
        return {...saved,message:'已保存为新的 Image Artifact；原图片未修改。'};
      }
      throw new Error('不支持的 Image Workbench 操作。');
    },

    async openAssetPreview(payload = {}) {
      await Editor.Panel.openBeside('scene', `${EXTENSION_NAME}.asset-preview`);
      return Editor.Message.request(EXTENSION_NAME, 'set-preview-source', payload);
    },

    async openAudioWorkbench(payload = {}) {
      const sessionId=String(payload.sessionId||'').trim();
      audioEditorSource={...payload,sessionId};audioEditorOwner=sessionId;
      await Editor.Panel.open(`${EXTENSION_NAME}.audio-workbench`);
      return Editor.Message.request(EXTENSION_NAME,'set-audio-source',audioEditorSource);
    },

    async getAudioSource(payload = {}) {
      if(payload.kind==='audio-import-default')return (await Editor.Message.request('asset-db','query-asset-info','db://assets/audio'))?.isDirectory?'assets/audio':'assets';
      if(payload.kind==='audio-workbench-selection'){
      const target=Editor.Selection.getSelected('asset')[0],info=target&&await Editor.Message.request('asset-db','query-asset-info',target);
        return info&&!info.isDirectory&&info.type==='cc.AudioClip'&&info.url?.startsWith('db://assets/')
          ?{source:'project',target:info.uuid,assetUrl:info.url,displayName:path.basename(info.file),identity:`project:${info.uuid}`} : null;
      }
      if(payload.kind==='audio-workbench-source'){
        const data=await describeAudioSource(payload,payload.sessionId,true),audioFolder=await Editor.Message.request('asset-db','query-asset-info','db://assets/audio');
        return {...data,importDirectory:audioFolder?.isDirectory?'assets/audio':'assets'};
      }
      return {available:false};
    },

    async audioWorkbenchAction(payload = {}) {
      const sourcePayload=payload.source||audioEditorSource,sessionId=String(sourcePayload?.sessionId||audioEditorOwner||'').trim();
      if(!sessionId)throw new Error('Audio Workbench 原会话已不可用。');
      if(payload.action==='render'){
        const source=await resolveAudioSource(sourcePayload,sessionId),rendered=await audioCore.renderDraftBytes(source.sourcePath,payload.draft);
        return {...rendered,base64:rendered.bytes.toString('base64'),bytes:undefined};
      }
      if(payload.action==='save'){
        const data=await saveAudioVersion({source:sourcePayload,draft:payload.draft,name:payload.name},sessionId,`audio-workbench:${Date.now()}`);
        broadcastCodexEvent({type:'assistant-artifacts',sessionId,taskId:data.artifact.turnId,artifacts:[data.artifact],timestamp:Date.now()});
        audioEditorSource={artifactId:data.artifact.id,sessionId,identity:`artifact:${sessionId}:${data.artifact.id}`};
        return {...data,message:'已保存为新的 Audio Artifact；原音频未修改。'};
      }
      const taskId=String(payload.taskId||`audio-workbench:${Date.now()}:${Math.random().toString(36).slice(2,8)}`);
      if(payload.action==='import'){
        let source=await resolveAudioSource(sourcePayload,sessionId);
        const draft=audioCore.normalizeDraft(payload.draft||{}),edited=Boolean(draft.trim||draft.fadeIn||draft.fadeOut||draft.gainDb||draft.normalize||draft.sampleRate||draft.channels!=='source'||draft.reverse||draft.format!==source.format);
        let artifact;
        if(edited){const name=safeFileName(path.basename(payload.outputPath),`audio-edited.${draft.format}`);const saved=await saveAudioVersion({source:sourcePayload,draft,name},sessionId,taskId);artifact=saved.artifact;source=await resolveAudioSource({artifactId:artifact.id},sessionId);audioEditorSource={artifactId:artifact.id,sessionId,identity:`artifact:${sessionId}:${artifact.id}`};}
        const result=await commitAudioWithReview({action:'import',sourcePath:source.sourcePath,sourceRoot:source.sourceRoot,outputPath:payload.outputPath},{sessionId,taskId});
        linkAudioImport(sessionId,taskId,source,result);
        return {...result,artifact,message:'已通过 AssetDB 导入 AudioClip。'};
      }
      const snapshot=await captureSceneForReview();
      if(payload.action==='configure'){
        const targetUuid=String(payload.targetUuid||'');
        const parentPath=payload.parentPath||snapshot.nodes?.find(node=>node.components?.some(component=>component.type==='cc.Canvas'))?.path||'';
        const result=await commitAudioWithReview({action:'configure',clipUuid:payload.clipUuid,sceneUuid:snapshot.scene?.uuid,targetUuid,parentPath,nodeName:payload.nodeName,volume:payload.volume,loop:payload.loop,playOnAwake:payload.playOnAwake,play:false},{sessionId,taskId});
        return {...result,message:'AudioSource 已配置并完成回读。'};
      }
      if(payload.action==='preview'){
        const result=await commitAudioWithReview({action:'preview',sceneUuid:payload.sceneUuid||snapshot.scene?.uuid},{sessionId,taskId});
        return {...result,message:'Scene 已保存并启动 Game View。'};
      }
      if(payload.action==='runtime'){
        const editScene=await callSceneReviewMethod('audioSourceState',{nodeUuid:payload.nodeUuid});
        const preview=require('./lib/asset-preview/asset-commit').unwrap(await cocosRuntimeService.callTool('get_runtime_state',{}));
        return {editScene,preview,message:`AudioSource ${editScene.verified?'已验证':'未通过验证'}；Game View ${preview.running?'正在运行':'未运行'}。`};
      }
      throw new Error('不支持的 Audio Workbench 操作。');
    },

    async getAttachmentThumbnail(payload = {}) {
      if (payload.kind === 'image-import-default') return (await Editor.Message.request('asset-db','query-asset-info','db://assets/art'))?.isDirectory ? 'assets/art' : 'assets';
      if (payload.kind === 'artifact-import-status') {
        if (payload.mediaKind === 'audio') return readAudioArtifactStatus(payload);
        const verify=async info=>{
          if(!info?.uuid||!info.url?.startsWith('db://assets/')||!info.imported||info.invalid||!info.file||!fs.existsSync(info.file))return false;
          try { const original=await readAssetPreviewSource({artifactId:payload.artifactId,sessionId:payload.sessionId});return original.bytes.equals(readImage(PROJECT_ROOT,info.file).bytes); }
          catch(_){ try { const original=await resolveAudioSource({artifactId:payload.artifactId},payload.sessionId);return readAudio(original.sourceRoot,original.sourcePath).bytes.equals(readAudio(PROJECT_ROOT,info.file).bytes); } catch(__){ return false; } }
        };
        if(payload.target||payload.assetUrl){const info=await Editor.Message.request('asset-db','query-asset-info',payload.target||payload.assetUrl).catch(()=>null);return await verify(info)?{imported:true,assetUrl:info.url,assetUuid:info.uuid}:{imported:false};}
        let candidates=[];
        if(/\.(wav|mp3|ogg)$/iu.test(String(payload.displayName||'')))candidates=await Editor.Message.request('asset-db','query-assets',{ccType:'cc.AudioClip'}).catch(()=>[]);
        else if(/\.(png|jpe?g|webp)$/iu.test(String(payload.displayName||'')))candidates=await Editor.Message.request('asset-db','query-assets',{ccType:'cc.ImageAsset'}).catch(()=>[]);
        for(const candidate of candidates||[]){const reference=candidate?.uuid||candidate?.url;const info=reference?await Editor.Message.request('asset-db','query-asset-info',reference).catch(()=>null):candidate;if(await verify(info))return {imported:true,assetUrl:info.url,assetUuid:info.uuid};}
        return {imported:false};
      }
      if (payload.kind === 'asset-preview-selection') {
        const target = Editor.Selection.getSelected('asset')[0];
        const info = target && await Editor.Message.request('asset-db', 'query-asset-info', target);
        return info && !info.isDirectory && /\.(png|jpe?g|webp)$/i.test(info.url) && info.url.startsWith('db://assets/')
          ? { source: 'project', target: info.uuid, assetUrl: info.url, displayName: path.basename(info.file), identity: `project:${info.uuid}` } : null;
      }
      if (payload.kind === 'chat-thumbnail-source') return readChatThumbnailSource(payload);
      if (payload.kind === 'asset-preview-source') return readAssetPreviewSource(payload);
      if (payload.kind === 'asset-preview-context') {
        const snapshot = await captureSceneForReview();
        const nodes = snapshot.nodes || [];
        const selection = Editor.Selection.getSelected('node');
        const selected = selection.length === 1 ? nodes.find(node => node.uuid === selection[0]) : null;
        return { sceneUuid: snapshot.scene?.uuid || '', selectedNodeUuid: selected?.uuid || '',
          selectedNodeName: selected?.name || '',
          canvasPaths: nodes.filter(node => node.components?.some(component => component.type === 'cc.Canvas')).map(node => node.path) };
      }
      const sessionId = String(payload.sessionId || '').trim();
      if (!sessionId || !payload.attachment) return { available: false };
      const attachment = validateStoredAttachment(payload.attachment, {
        attachmentRoot: fileStorageRoots.attachments,
        sessionId,
      });
      if (!attachment || attachment.available === false || !attachment.storedPath) return { available: false };
      if (attachment.kind === 'directory') return { available: false };
      const mimeType = inferMimeType(attachment.displayName || attachment.title, attachment.mimeType);
      if (!mimeType.startsWith('image/')) return { available: false };
      try {
        const bytes = await fs.promises.readFile(attachment.storedPath);
        return { available: true, mimeType, bytes };
      } catch (error) {
        console.warn(`[AI Copilot] Attachment thumbnail read failed: ${error.message}`);
        return { available: false };
      }
    },

    async saveArtifact(payload = {}) {
      if (payload.kind === 'asset-preview-commit') return commitAssetPreview(payload);
      const sessionId = String(payload.sessionId || '').trim();
      const artifactId = String(payload.artifactId || '').trim();
      if (!sessionId || !artifactId) throw new Error('Artifact identity is required.');
      if (!global.Editor?.Dialog || typeof Editor.Dialog.save !== 'function') {
        throw new Error('当前 Cocos Editor 无法打开另存为窗口。');
      }
      let artifact;
      try {
        artifact = resolveStoredArtifact({
          artifactRoot: fileStorageRoots.artifacts,
          sessionId,
          artifactId,
        });
      } catch (_) {
        return { saved: false, unavailable: true, message: '文件已不可用。' };
      }
      const result = await Editor.Dialog.save({
        title: '另存为',
        path: artifact.displayName,
      });
      if (!result || result.canceled || !result.filePath) return { saved: false, canceled: true };
      try {
        await fs.promises.copyFile(artifact.path, path.resolve(result.filePath));
        return { saved: true };
      } catch (error) {
        console.warn(`[AI Copilot] Save As failed: ${error.message}`);
        return { saved: false, message: '无法保存文件，请检查目标位置和磁盘空间。' };
      }
    },

    saveSession(payload = {}) {
      const continuation = sessionStore.records.get(payload.record?.id)?.continuation;
      const saved = sessionStore.save({ ...payload.record, ...(continuation ? { continuation,
        threadId: sessionStore.records.get(payload.record.id).threadId || payload.record.threadId } : {}) }, { immediate: payload.immediate === true });
      return { saved: Boolean(saved) };
    },

    listArchivedSessions() {
      const result = sessionStore.load();
      return { projectKey: sessionStore.projectKey, warnings: result.warnings,
        sessions: result.sessions.filter((record) => record.archivedAt)
          .sort((a, b) => b.archivedAt - a.archivedAt)
          .map(({ id, title, archivedAt }) => ({ id, title, archivedAt })) };
    },

    updateSessionLifecycle(payload = {}) {
      sessionStore.load();
      const sessionId = String(payload.sessionId || '').trim();
      const action = payload.action;
      if (!sessionId || !['archive', 'unarchive', 'delete'].includes(action)) throw new Error('Invalid session action.');
      const record = sessionStore.records.get(sessionId);
      if (!record && !(action === 'delete' && sessionStore.deletedIds.has(sessionId))) {
        return { accepted: false, message: '会话已不可用，请刷新列表。' };
      }
      const runtime = sessions.get(sessionId);
      if (assetPreviewCommitPending || continuationPending || runtime?.runner.isRunning || runtime?.activeTaskId || runtime?.preparingTaskId
        || runtime?.resumePromise || [...undoInProgress].some((key) => key.startsWith(`${sessionId}\0`))) {
        return { accepted: false, message: '会话正在处理任务，请完成后再操作。' };
      }
      if (action === 'archive' && record.queue?.queuedMessages?.length) {
        return { accepted: false, message: '请先处理会话中的队列消息，再归档。' };
      }
      let archivedAt = 0;
      let message = '';
      if (action === 'delete') {
        try { sessionStore.delete(sessionId); }
        catch (error) {
          if (sessionStore.records.has(sessionId)) throw error;
          // Logical deletion committed; retry record cleanup below with the other local data.
        }
        // Only derived, session-owned local directories; never record paths or server threads.
        const roots = [...managedInternalPathRoots, turnChangeStore.directory];
        for (const root of roots) {
          try {
            const target = assertContained(root, sessionRoot(root, sessionId), 'Session data');
            if (fs.existsSync(root)) {
              const anchor = root.startsWith(fileStorageRoots.runtime + path.sep) ? PROJECT_ROOT : sessionStore.applicationRoot;
              assertContained(fs.realpathSync(anchor), fs.realpathSync(root), 'Session storage');
              if (fs.existsSync(target) && !fs.lstatSync(target).isSymbolicLink()) {
                assertContained(fs.realpathSync(root), fs.realpathSync(target), 'Session data');
              }
            }
            fs.rmSync(target, { recursive: true, force: true });
          } catch (_) { message = '会话已删除，部分本地数据暂时无法清理。'; }
        }
        try { fs.rmSync(sessionStore.filePath(sessionId), { force: true }); }
        catch (_) { message = '会话已删除，部分本地数据暂时无法清理。'; }
        sessions.delete(sessionId);
        imageWorkbenchArtifactsBySession.delete(sessionId);
        audioWorkbenchArtifactsBySession.delete(sessionId);
        if (selectedChangesRef?.sessionId === sessionId) {
          selectedChangesRef = null;
          broadcastChanges({ type: 'selection-cleared' });
        }
      } else {
        archivedAt = sessionStore.setArchived(sessionId, action === 'archive').archivedAt || 0;
      }
      const result = { accepted: true, projectKey: sessionStore.projectKey, sessionId, action, archivedAt, message };
      Editor.Message.broadcast(SESSION_LIFECYCLE_EVENT_CHANNEL, result);
      return result;
    },

    async continueSession(payload = {}) {
      if (assetPreviewCommitPending || continuationPending || appServerClient.isRunning || guardProxy?.activeTask
        || [...sessions.values()].some((item) => item.runner.isRunning || item.preparingTaskId || item.resumePromise)
        || payload.record?.messages?.some((turn) => ['running', 'pending'].includes(turn.status))) {
        return { reason: 'busy' };
      }
      if (!payload.record?.id || payload.record.queue?.queuedMessages?.length
        || sessionStore.records.get(payload.record.id)?.queue?.queuedMessages?.length) return { reason: 'queue' };
      const startedAt = Date.now();
      const snapshot = continuationSnapshot(payload.record, PROJECT_ROOT, payload.snapshotAt || startedAt);
      continuationPending = true;
      console.debug(`[AI Copilot Continuation] request source=${snapshot.record.id} at=${startedAt}`);
      try {
        const [scene, skills, project] = await Promise.all([readActiveSceneIdentity(),
          projectSkillLoader.loadProjectSkills(Object.values(FUNPLAY_PROJECT_SKILLS)), getProjectDescriptor()]);
        if (project.name) snapshot.facts.project.name = project.name;
        snapshot.facts.currentScene = scene;
        snapshot.facts.projectSkills = skills.map((skill) => skill.name);
        const selection = turnModelSelection(snapshot.record);
        const runtimeSnapshot = runtimeSnapshotWithProviders((await runtimeResolver.resolve(environmentDiscovery.registry)).snapshot());
        const last = snapshot.record.messages.at(-1);
        const lastTurnId = last?.codexTurnId || last?.changeSet?.turnId;
        const fork = snapshot.record.threadId && lastTurnId ? { threadId: snapshot.record.threadId, lastTurnId } : {};
        let semantic = '';
        console.debug(`[AI Copilot Continuation] summary-start elapsedMs=${Date.now() - startedAt} strategy=${fork.threadId ? 'fork' : 'local'}`);
        await appServerClient.run(summaryPrompt(snapshot, !fork.threadId), (event) => {
          if (event.type === 'message' && event.status === 'success') semantic = event.text;
        }, { runtimeSnapshot, summary: fork, model: selection.modelId,
          modelProvider: selection.modelProvider, effort: snapshot.record.reasoningEffort });
        const result = continuedSession(snapshot, semantic);
        console.debug(`[AI Copilot Continuation] summary-complete elapsedMs=${Date.now() - startedAt} metrics=${JSON.stringify(result.metrics)}`);
        const record = sessionStore.create(result.record);
        console.debug(`[AI Copilot Continuation] saved session=${record.id} elapsedMs=${Date.now() - startedAt}`);
        return { record, operationId: payload.operationId };
      } catch (error) {
        console.warn(`[AI Copilot Continuation] failed elapsedMs=${Date.now() - startedAt} reason=${error.code || error.message}`);
        throw error;
      } finally { continuationPending = false; }
    },

    flushSessions() { sessionStore.flush(); return { saved: true }; },

    async resumeSession(payload = {}) {
      const sessionId = String(payload.sessionId || '');
      const threadId = String(payload.threadId || '');
      const record = sessionStore.records.get(sessionId);
      if (!record || record.archivedAt || record.threadId !== threadId) return { restored: false };
      if (assetPreviewCommitPending || continuationPending || Array.from(sessions.values()).some((item) => item.runner.isRunning || item.preparingTaskId)) {
        return { deferred: true };
      }
      const session = getSession(sessionId);
      session.runner.bindThread(threadId);
      const modelSelection = turnModelSelection(payload);
      if (!session.resumePromise) {
        session.resumePromise = (async () => {
          if (permissionStatePromise) await permissionStatePromise.catch(() => {});
          try {
            await appServerClient.resumeThread(threadId, {
              permissionModeId: payload.permissionModeId,
              runtimeSnapshot: runtimeSnapshotWithProviders(),
              model: modelSelection.modelId,
            });
            return { restored: true, threadId };
          } catch (_) { return { restored: false }; }
          finally { session.resumePromise = null; }
        })();
      }
      return session.resumePromise;
    },

    async getEnvironmentSnapshot(payload = {}) {
      const snapshot=await environmentDiscovery.refresh({ force: payload.refresh === true });
      if(payload.includePreviewToolbar!==true)return snapshot;
      const previewToolbar=await previewRuntime.controlPreviewToolbar({action:'toolbar-state'}).catch(()=>null);
      return {...snapshot,previewToolbar};
    },

    getCodexPermissionModes() {
      return getCodexPermissionModes();
    },

    resolveNativeApproval(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      const taskId = String(payload.taskId || '').trim();
      const session = sessions.get(sessionId);
      if (!session?.runner.isRunning || !taskId || !Object.prototype.hasOwnProperty.call(payload, 'requestId')) {
        return { accepted: false, reason: 'stale-request' };
      }
      return appServerClient.respondToServerRequest(payload.requestId, payload.decision, {
        sessionId,
        taskId,
        threadId: String(payload.threadId || ''),
        turnId: String(payload.turnId || ''),
      });
    },

    openPanel() {
      if (!global.Editor || !Editor.Panel || typeof Editor.Panel.open !== 'function') {
        throw new Error('Editor.Panel.open is unavailable in this Cocos extension host.');
      }

      return Editor.Panel.open(EXTENSION_NAME);
    },

    async openSettings(payload = {}) {
      if (!global.Editor?.Panel || typeof Editor.Panel.open !== 'function') {
        throw new Error('Editor.Panel.open is unavailable in this Cocos extension host.');
      }
      const isOpen = typeof Editor.Panel.has === 'function'
        ? await Editor.Panel.has(SETTINGS_PANEL_NAME) : false;
      if (!isOpen) await Promise.resolve(Editor.Panel.open(SETTINGS_PANEL_NAME));
      if (global.Editor?.Message && typeof Editor.Message.broadcast === 'function') {
        await Promise.resolve(Editor.Message.broadcast(SETTINGS_NAVIGATION_EVENT_CHANNEL, {
          section: String(payload.section || 'services'),
          providerId: String(payload.providerId || ''),
        })).catch(() => {});
      }
      if (typeof Editor.Panel.focus === 'function') {
        await Promise.resolve(Editor.Panel.focus(SETTINGS_PANEL_NAME)).catch(() => {});
      }
      return { opened: true, focused: isOpen };
    },

    async openChanges(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      const turnId = String(payload.turnId || payload.taskId || '').trim();
      if (!sessionId || !turnId) throw new Error('ChangeSet identity is required.');
      const stored = turnChangeStore.load(sessionId, turnId, { withBytes: false });
      if (!stored) throw new Error('ChangeSet is no longer available.');
      const sceneSnapshot = changeSetNeedsScene(stored) ? await captureSceneForReview() : { available: false };
      const changeSet = revalidateStoredChangeSet(stored, sceneSnapshot);
      const navigationTarget = normalizeChangesNavigationTarget(payload.navigationTarget);
      selectedChangesRef = { sessionId, turnId, changeSet, navigationTarget };
      if (!global.Editor?.Panel || typeof Editor.Panel.open !== 'function') {
        throw new Error('Editor.Panel.open is unavailable in this Cocos extension host.');
      }
      const isOpen = typeof Editor.Panel.has === 'function' ? await Editor.Panel.has(CHANGES_PANEL_NAME) : false;
      if (!isOpen) await Promise.resolve(Editor.Panel.open(CHANGES_PANEL_NAME));
      broadcastChanges({ type: 'selection-changed', sessionId, turnId, navigationTarget });
      if (typeof Editor.Panel.focus === 'function') {
        await Promise.resolve(Editor.Panel.focus(CHANGES_PANEL_NAME)).catch(() => {});
      }
      return { opened: true, focused: isOpen, changeSet: changeSetSummary(changeSet), navigationTarget };
    },

    getTurnChanges(payload = {}) {
      const sessionId = String(payload.sessionId || selectedChangesRef?.sessionId || '').trim();
      const turnId = String(payload.turnId || payload.taskId || selectedChangesRef?.turnId || '').trim();
      if (!sessionId || !turnId) return { changeSet: null };
      const selected = selectedChangesRef?.sessionId === sessionId && selectedChangesRef?.turnId === turnId
        ? selectedChangesRef.changeSet : null;
      const changeSet = selected || turnChangeStore.load(sessionId, turnId, { withBytes: false })
        || (sessionStore.records.get(sessionId)?.messages || []).find((turn) => (
          String(turn.changeSet?.turnId || turn.taskId || '') === turnId
        ))?.changeSet
        || null;
      const navigationTarget = selected
        ? selectedChangesRef.navigationTarget : normalizeChangesNavigationTarget(payload.navigationTarget);
      return { changeSet, active: { sessionId, turnId, navigationTarget } };
    },

    changesSessionNavigated(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      if (!selectedChangesRef || selectedChangesRef.sessionId === sessionId) return { cleared: false };
      selectedChangesRef = null;
      broadcastChanges({ type: 'selection-cleared' });
      return { cleared: true };
    },

    async undoTurnChanges(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      const turnId = String(payload.turnId || payload.taskId || '').trim();
      const key = `${sessionId}\0${turnId}`;
      if (!sessionId || !turnId) throw new Error('ChangeSet identity is required.');
      if (assetPreviewCommitPending || Array.from(sessions.values()).some((item) => item.runner.isRunning || item.preparingTaskId)) {
        return { accepted: false, reason: 'busy', message: '任务执行期间不能撤销更改。' };
      }
      if (undoInProgress.has(key)) return { accepted: false, reason: 'busy', message: '正在撤销本轮更改。' };
      const changeSet = turnChangeStore.load(sessionId, turnId, { withBytes: true });
      if (!changeSet) return { accepted: false, reason: 'missing', message: '本轮更改记录已不可用。' };
      undoInProgress.add(key);
      let previewLease = null;
      try {
        try {
          previewLease = await preparePreviewForUndo(Editor.Message.request.bind(Editor.Message));
        } catch (error) {
          return { accepted: false, reason: 'preview-stop-failed',
            message: `Preview 正在运行，无法安全撤销：${error.message}` };
        }
        const results = undoFileItems(PROJECT_ROOT, changeSet.files || []);
        const sceneItems = [...(changeSet.components || []), ...(changeSet.scene || [])];
        const pendingScene = sceneItems.filter((item) => item.reversible && item.undoStatus !== 'restored').reverse();
        sceneItems.filter((item) => !item.reversible).forEach((item) => results.push({
          id: item.id, status: 'irreversible', message: item.reason || '此项不能安全撤销。',
        }));
        sceneItems.filter((item) => item.undoStatus === 'restored').forEach((item) => results.push({
          id: item.id, status: 'restored', message: '已经撤销。',
        }));
        if (pendingScene.length) {
          try {
            const response = await callSceneReviewMethod('applyInverseChanges', {
              sceneUuid: pendingScene[0].sceneUuid,
              changes: pendingScene,
            });
            const sceneResults = Array.isArray(response?.results) ? response.results : pendingScene.map((item) => ({
              id: item.id, status: 'conflict', message: '场景撤销没有返回结果。',
            }));
            if (sceneResults.some(item => item.status === 'restored')
              && changeSet.sceneContext?.kind === 'save') {
              let saved = false;
              let saveError = null;
              for (const method of ['save-scene', 'save']) {
                try { await Editor.Message.request('scene', method); saved = true; break; }
                catch (error) { saveError = error; }
              }
              if (!saved || await Editor.Message.request('scene', 'query-dirty').catch(() => true)) {
                sceneResults.forEach((item, index) => {
                  if (item.status === 'restored') sceneResults[index] = { ...item, status:'conflict',
                    reasonCode:'scene-save-after-undo-failed', verified:false,
                    message:`场景已在编辑器中撤销，但保存回 SceneAsset 失败：${saveError?.message || '保存后仍为未保存状态。'}` };
                });
              }
            }
            results.push(...sceneResults);
          } catch (error) {
            results.push(...pendingScene.map((item) => ({ id: item.id, status: 'conflict', message: error.message })));
          }
        }
        results.push(...await undoAssetItems(PROJECT_ROOT, changeSet.assets || [], {
          deleteAsset: assetUrl => Editor.Message.request('asset-db', 'delete-asset', assetUrl),
          queryAsset: assetUrl => Editor.Message.request('asset-db', 'query-asset-info', assetUrl),
        }));
        const undoItems = new Map([
          ...(changeSet.files || []), ...(changeSet.assets || []),
          ...(changeSet.components || []), ...(changeSet.scene || []),
        ].map((item) => [item.id, item]));
        results.splice(0, results.length, ...results.map((result) => {
          if (result.status === 'restored' && result.verified !== true
            && undoItems.get(result.id)?.undoStatus !== 'restored') {
            return { ...result, status: 'unavailable', reasonCode: 'undo-readback-missing',
              message: '逆操作没有返回实际恢复值的验证，不能标记成功。' };
          }
          if (result.reasonCode) return result;
          const item = undoItems.get(result.id) || {};
          const alreadyReverted = result.status === 'restored' && item.undoStatus === 'restored';
          const fallbackUnavailable = result.status === 'conflict' && item.category !== 'file' && item.category !== 'asset';
          return {
            ...result,
            status: alreadyReverted ? 'already-reverted' : fallbackUnavailable ? 'unavailable' : result.status,
            reasonCode: alreadyReverted ? 'already-reverted'
              : result.status === 'irreversible' ? 'unsafe-undo-unavailable'
                : fallbackUnavailable ? 'scene-bridge-unavailable' : 'undo-failed',
            targetKind: item.category === 'component' ? 'component'
              : item.category === 'scene' ? 'node' : item.category || 'file',
            targetLabel: item.nodePath || item.path || item.label || '',
          };
        }));
        const statuses = Object.fromEntries(results.map((item) => [item.id, item]));
        const restored = results.filter((item) => item.status === 'restored').length;
        const conflicts = results.filter((item) => item.status === 'conflict').length;
        const irreversible = results.filter((item) => item.status === 'irreversible').length;
        const unavailable = results.filter((item) => item.status === 'unavailable').length;
        const alreadyReverted = results.filter((item) => item.status === 'already-reverted').length;
        const undo = {
          status: conflicts || irreversible || unavailable ? 'partial' : 'completed',
          restored, conflicts, irreversible, unavailable, alreadyReverted, completedAt: Date.now(),
        };
        const stored = turnChangeStore.updateUndo(sessionId, turnId, undo, statuses);
        if (stored && selectedChangesRef?.sessionId === sessionId && selectedChangesRef?.turnId === turnId) {
          selectedChangesRef = {
            sessionId, turnId, changeSet: stored,
            navigationTarget: selectedChangesRef.navigationTarget || null,
          };
        }
        const summary = changeSetSummary(stored || changeSet);
        broadcastCodexEvent({
          type: 'turn-change-set', sessionId, taskId: changeSet.taskId, turnId,
          changeSet: summary, timestamp: Date.now(),
        });
        broadcastChanges({ type: 'change-set-updated', sessionId, taskId: changeSet.taskId,
          turnId, changeSet: summary });
        return { accepted: true, undo, changeSet: summary, results };
      } finally {
        if (previewLease?.stopped) {
          await restorePreviewModeAfterUndo(Editor.Message.request.bind(Editor.Message), previewLease)
            .catch((error) => console.warn(`[AI Copilot Review] Undo 已完成，但无法恢复 Preview 模式：${error.message}`));
        }
        undoInProgress.delete(key);
      }
    },

    async locateChangeTarget(payload = {}) {
      const nodeUuid = String(payload.nodeUuid || '').trim();
      if (nodeUuid) {
        if (!global.Editor?.Selection || typeof Editor.Selection.select !== 'function') {
          return { located: false, reason: 'selection-unavailable' };
        }
        const exists = await callSceneReviewMethod('hasChangeTarget', { nodeUuid }).catch(() => false);
        if (!exists) return { located: false, reason: 'target-missing' };
        Editor.Selection.clear?.('node');
        Editor.Selection.select('node', nodeUuid);
        return { located: true, type: 'node', uuid: nodeUuid };
      }
      if (!global.Editor?.Message || !global.Editor?.Selection) return { located: false };
      const assetUuid=String(payload.assetUuid||'').trim();
      let assetUrl=String(payload.assetUrl||payload.path||'').trim().replace(/\\/gu,'/');
      if(assetUrl&&!assetUrl.startsWith('db://')){
        if(path.isAbsolute(assetUrl)){
          const relative=path.relative(PROJECT_ROOT,assetUrl).replace(/\\/gu,'/');
          assetUrl=!relative.startsWith('../')&&relative!=='..'&&relative.startsWith('assets/')?`db://${relative}`:'';
        }else {assetUrl=assetUrl.replace(/^\/+/, '');if(!assetUrl.startsWith('assets/'))assetUrl=`assets/${assetUrl}`;assetUrl=`db://${assetUrl}`;}
      }
      if(!assetUuid&&!assetUrl)return {located:false};
      let info=assetUuid?await Editor.Message.request('asset-db','query-asset-info',assetUuid).catch(()=>null):null;
      if(!info?.uuid&&assetUrl)info=await Editor.Message.request('asset-db','query-asset-info',assetUrl).catch(()=>null);
      if (!info?.uuid) return { located: false, reason: 'asset-missing' };
      Editor.Selection.clear?.('asset');
      Editor.Selection.select('asset', info.uuid);
      try{await Promise.resolve(Editor.Message.send?.('assets','twinkle',info.uuid));}catch(_){}
      return { located: true, type: 'asset', uuid: info.uuid, url:info.url||assetUrl };
    },

    async openDetail(payload = {}) {
      if (!global.Editor || !Editor.Panel || typeof Editor.Panel.open !== 'function') {
        throw new Error('Editor.Panel.open is unavailable in this Cocos extension host.');
      }
      const document = detailRegistry.register(payload.document || payload);
      const isOpen = typeof Editor.Panel.has === 'function'
        ? await Editor.Panel.has(DETAIL_PANEL_NAME)
        : false;
      if (!isOpen) await Promise.resolve(Editor.Panel.open(DETAIL_PANEL_NAME));

      if (Editor.Message && typeof Editor.Message.broadcast === 'function') {
        try {
          await Promise.resolve(Editor.Message.broadcast(DETAIL_EVENT_CHANNEL, { detailId: document.id }));
        } catch (error) {
          console.warn(`[AI Copilot Detail] Unable to notify detail panel: ${error.message}`);
        }
      }
      if (typeof Editor.Panel.focus === 'function') {
        try {
          await Promise.resolve(Editor.Panel.focus(DETAIL_PANEL_NAME));
        } catch (error) {
          console.warn(`[AI Copilot Detail] Unable to focus detail panel: ${error.message}`);
        }
      }
      return { opened: true, detailId: document.id };
    },

    getDetail(payload = {}) {
      const detailId = String(payload.detailId || '').trim();
      return detailId ? detailRegistry.setActive(detailId) : detailRegistry.get();
    },

    showContextMenu(payload = {}) {
      if (['attachment', 'attachment-picker', 'mcp-source'].includes(String(payload.kind || ''))) suppressMainPanelGlobalContext(payload);
      return showNativeContextMenu(payload);
    },

    registerGlobalContextMenu(payload = {}) {
      return registerMainPanelContext(payload);
    },

    unregisterGlobalContextMenu(payload = {}) {
      return unregisterMainPanelContext(payload);
    },

    suppressGlobalContextMenu(payload = {}) {
      return suppressMainPanelGlobalContext(payload);
    },

    async runCodexTask(payload = {}) {
      const prompt = String(payload.prompt || '');
      const userRequest = String(payload.userRequest == null ? prompt : payload.userRequest);
      const sessionId = String(payload.sessionId || '').trim();
      const taskId = String(payload.taskId || '').trim();
      if (sessionStore.deletedIds.has(sessionId) || sessionStore.records.get(sessionId)?.archivedAt) {
        return { accepted: false, reason: 'session-unavailable', message: '会话已归档或删除，请打开其他会话。' };
      }
      const hasPastedText = Array.isArray(payload.attachments) && payload.attachments.some((item) => (
        item?.type === 'text' && typeof item.content === 'string' && item.content.length > 0
      ));
      if ((!prompt.trim() && !userRequest.trim() && !hasPastedText) || !sessionId || !taskId) {
        throw new Error('user content, sessionId and taskId are required.');
      }

      const session = getSession(sessionId);
      const stored = sessionStore.records.get(sessionId);
      const requestedThreadId = String(stored?.continuation ? stored.threadId || '' : payload.threadId || '').trim();
      if (requestedThreadId) session.runner.bindThread(requestedThreadId);
      const modelSelection = turnModelSelection(payload);
      const anotherSessionRunning = Array.from(sessions.values()).some((item) => item.runner.isRunning || item.preparingTaskId);
      if (runtimeConnection.busy || assetPreviewCommitPending || continuationPending || session.runner.isRunning || appServerClient.isRunning || anotherSessionRunning || (guardProxy && guardProxy.activeTask)) {
        return {
          accepted: false,
          reason: 'busy',
          message: '当前任务正在执行，请等待完成。',
        };
      }
      const performanceTrace = new TurnPerformanceTrace({ sessionId, taskId });
      activeTurnPerformanceTraces.set(taskId, performanceTrace);
      let traceHandedOff = false;
      // Reserve synchronously, before permission/context discovery yields.
      session.preparingTaskId = taskId;
      session.activeTaskId = taskId;
      session.cancelRequested = false;
      let artifactOutbox = '';
      let turnAttachments = [];
      try {
        if (stored?.continuation) sessionStore.flush();
        const endResumeWait = performanceTrace.span('session_resume_wait');
        await Promise.all(Array.from(sessions.values()).map((item) => item.resumePromise).filter(Boolean));
        endResumeWait();
        const permissionModeId = String(payload.permissionModeId || '');
        // A panel-open capability read may be initializing the same transport.
        // Let it settle before starting a Turn with the project's MCP snapshot.
        if (permissionStatePromise) {
          const endPermissionInitialization = performanceTrace.span('permission_initialization_wait');
          await permissionStatePromise.catch(() => {});
          endPermissionInitialization();
        }
        if (permissionModeId) {
          const endPermissionResolution = performanceTrace.span('permission_resolution');
          const { modes } = await getCodexPermissionModes();
          endPermissionResolution({ modeCount: modes.length });
          if (!modes.some((mode) => mode.id === permissionModeId)) {
            return { accepted: false, reason: 'permission-mode-unavailable',
              message: '当前 Codex 配置不允许选择此权限模式，请重新选择。' };
          }
        }
        session.permissionModeId = permissionModeId || null;

        let proxy;
        let runtimeSnapshot;
        let guardStatsAtStart;
        let codexPrompt = prompt;
        let pendingProjectSkillInjections = [];
        try {
          const endOutbox = performanceTrace.span('artifact_outbox_prepare');
          artifactOutbox = prepareTurnOutbox({
            runtimeRoot: fileStorageRoots.runtime,
            sessionId,
            taskId,
          });
          endOutbox();
          session.artifactOutbox = artifactOutbox;
          const runtimePreparation = (async () => {
            try {
              const endMcpDiscovery = performanceTrace.span('mcp_source_discovery');
              await environmentDiscovery.refreshMcp();
              endMcpDiscovery({ serverCount: environmentDiscovery.registry?.mcpServers?.length || 0 });
            } catch (error) {
              performanceTrace.mark('mcp_source_discovery_failed');
              console.warn(`[AI Copilot] Plugin MCP discovery unavailable; continuing with Codex configuration: ${error.message}`);
            }
            const endRuntimeResolution = performanceTrace.span('runtime_resolution');
            const snapshot = runtimeSnapshotWithProviders(
              (await runtimeResolver.resolve(environmentDiscovery.registry)).snapshot()
            );
            endRuntimeResolution({ serverCount: snapshot.servers.length });
            return snapshot;
          })();
          const promptPreparation = (async () => {
            const endAttachmentMaterialization = performanceTrace.span('attachment_materialization');
            turnAttachments = await materializeTurnAttachments(
              messageAttachments(payload.attachments, sessionId),
              { runtimeRoot: fileStorageRoots.runtime, sessionId, taskId, messageId: taskId }
            );
            endAttachmentMaterialization({ attachmentCount: turnAttachments.length });
            const endContextInspection = performanceTrace.span('context_scene_inspection');
            const prepared = await prepareCodexPrompt({
              prompt,
              userRequest,
              attachments: turnAttachments,
              artifactOutputDir: artifactOutbox,
              pins: payload.pins,
              selection: payload.selection,
            }, session.projectSkillRevisions);
            endContextInspection();
            return prepared;
          })();
          // Wait for both branches to settle so a failed preflight cannot race
          // attachment cleanup or leave a late runtime rejection unobserved.
          const [runtimeResult, promptResult] = await Promise.allSettled([runtimePreparation, promptPreparation]);
          if (runtimeResult.status === 'rejected') throw runtimeResult.reason;
          if (promptResult.status === 'rejected') throw promptResult.reason;
          runtimeSnapshot = runtimeResult.value;
          proxy = runtimeSnapshot.servers.length ? guardProxy : null;
          codexPrompt = promptResult.value.prompt;
          pendingProjectSkillInjections = promptResult.value.injections;
          if (proxy) {
            proxy.bindTask({ taskId, sessionId, createdAt: Date.now() });
            if (session.cancelRequested) proxy.abortTask(taskId, 'user-stop');
            guardStatsAtStart = proxy.getStats();
          }
        } catch (error) {
          if (proxy) proxy.clearTask(taskId);
          if (artifactOutbox) removeOutbox(artifactOutbox);
          removeTurnAttachments({ runtimeRoot: fileStorageRoots.runtime, sessionId, taskId });
          throw new Error(`无法启动 Codex 任务：${error.message}`);
        }

        const endBeforeScene = performanceTrace.span('review_scene_snapshot_before');
        const beforeScene = await captureSceneForReview();
        endBeforeScene({ available: beforeScene?.available === true });
        const endFileBaseline = performanceTrace.span('review_file_baseline');
        const startFiles = captureTurnStartFileExistence(PROJECT_ROOT);
        endFileBaseline({ available: startFiles.available === true, fileCount: startFiles.count || 0 });
        if (!startFiles.available) {
          console.warn(`[AI Copilot Review] Turn-start File baseline unavailable: ${startFiles.reason}`);
        }
        const review = {
          sessionId, taskId, threadId: session.runner.threadId || '', turnId: '',
          turnDiff: '', fileEvents: [], startedFilePaths: new Map(), beforeFiles: new Map(), evidence: [],
          startFiles, beforeScene, afterScene: null,
          warnings: [],
        };
        if (beforeScene?.scene?.assetUrl?.startsWith('db://assets/')) {
          const scenePath = beforeScene.scene.assetUrl.replace(/^db:\/\//u, '');
          mergeCaptures(review.beforeFiles, captureBeforePaths(PROJECT_ROOT,
            [scenePath, `${scenePath}.meta`], { provenance: 'turn-start' }));
        }
        session.reviewRuns.set(taskId, review);
        let terminalStatus = 'unknown';
        let terminalMessage = '';
        if (session.cancelRequested) {
          session.reviewRuns.delete(taskId);
          if (proxy) proxy.clearTask(taskId);
          if (artifactOutbox) removeOutbox(artifactOutbox);
          removeTurnAttachments({ runtimeRoot: fileStorageRoots.runtime, sessionId, taskId });
          if (session.artifactOutbox === artifactOutbox) session.artifactOutbox = '';
          rememberTrace(completedTurnPerformanceTraces, performanceTrace.finish('cancelled'));
          activeTurnPerformanceTraces.delete(taskId);
          traceHandedOff = true;
          return { accepted: false, reason: 'cancelled', message: '任务已停止。' };
        }
        const generated = new Map();
        const generatedAudio = new Map();
        pendingMcpAudioByTask.set(taskId,generatedAudio);
        performanceTrace.mark('model_turn_dispatch');
        const acceptThreadDeveloperContext = ({ threadId }) => {
          const record = sessionStore.records.get(sessionId);
          if (record?.continuation && !record.continuation.applied) sessionStore.save({ ...record, threadId,
            continuation: { ...record.continuation, applied: true } }, { immediate: true });
        };
        const runnerPromise = session.runner.run(codexPrompt, (event) => {
          performanceTrace.observe(event);
          if (event.type === 'generated-image') {
            if (!generated.has(event.sourceIdentity)) generated.set(event.sourceIdentity, persistGeneratedImage(event, { artifactRoot: fileStorageRoots.artifacts, sessionId, taskId }).then(artifact => ({ artifact }), error => ({ error })));
            return;
          }
          if (event.type === 'mcp-image') {
            if (!generated.has(event.sourceIdentity)) generated.set(event.sourceIdentity,
              persistMcpImages(event, { artifactRoot: fileStorageRoots.artifacts, sessionId, taskId,
                allowedRoots: [artifactOutbox, PROJECT_ROOT] })
                .then(artifacts => ({ artifacts }), error => ({ error })));
            return;
          }
          if (event.type === 'mcp-audio') {
            if (!generatedAudio.has(event.sourceIdentity)) generatedAudio.set(event.sourceIdentity,
              persistMcpAudio(event,{artifactRoot:fileStorageRoots.artifacts,sessionId,taskId,
                allowedRoots:[artifactOutbox,PROJECT_ROOT],generatedRoots:[os.tmpdir()],projectRoot:PROJECT_ROOT,
                onRejected:(error,entry)=>console.warn(`[AI Copilot][Audio Artifact] rejected source=${entry.sourceIdentity} block=${entry.index} tool=${entry.sourceTool}: ${error.message}`)})
                .then(artifacts=>({artifacts}),error=>({error})));
            return;
          }
          if (event.turnId) review.turnId = String(event.turnId);
          if (event.threadId) review.threadId = String(event.threadId);
          if (event.type === 'turn_diff') {
            review.turnDiff = String(event.diff || '');
            return;
          }
          if (event.type === 'file_change') {
            if (event.status === 'running') {
              try {
                review.startedFilePaths.set(event.id, filePathsFromEvent(event));
                mergeCaptures(review.beforeFiles, captureBeforePaths(PROJECT_ROOT, filePathsFromEvent(event), { provenance: 'observation' }));
              } catch (error) {
                console.warn(`[AI Copilot Review] File snapshot failed: ${error.message}`);
              }
            }
            if (['success', 'completed'].includes(String(event.status || ''))) review.fileEvents.push(event);
          }
          if (event.type === 'approval-request' && event.method === 'item/fileChange/requestApproval') {
            try {
              const paths = review.startedFilePaths.get(event.itemId) || [];
              mergeCaptures(review.beforeFiles, captureBeforePaths(PROJECT_ROOT, paths, { provenance: 'pre-write' }));
            } catch (error) {
              console.warn(`[AI Copilot Review] Approved File snapshot failed: ${error.message}`);
            }
          }
          if (event.type === 'tool') {
            const extracted = runtimeResolver.extractChangeEvidence(
              event.server, event, environmentDiscovery.registry
            );
            if (event.status === 'failed' && explicitUnknownWriteEvidence({ ...event, status: 'success' })) {
              review.warnings.push('写入工具失败，可能存在部分写入；本轮 Review 覆盖不完整。');
            }
            if (extracted?.observedExistence === 'absent') {
              try {
                captureObservedEvidence(PROJECT_ROOT, review.beforeFiles, extracted, { provenance: 'observation' });
              } catch (error) {
                console.warn(`[AI Copilot Review] Asset observation snapshot failed: ${error.message}`);
              }
            }
            if (event.status === 'running' && extracted && (extracted.assetWrite || extracted.fileWrite)) {
              try {
                mergeCaptures(review.beforeFiles, captureBeforePaths(PROJECT_ROOT, evidenceProjectPaths(extracted), { provenance: 'observation' }));
              } catch (error) {
                console.warn(`[AI Copilot Review] MCP target snapshot failed: ${error.message}`);
              }
            }
            if (['success', 'completed'].includes(String(event.status || ''))) {
              const evidence = extracted || explicitUnknownWriteEvidence(event);
              const isWriteEvidence = evidence
                && (evidence.sceneWrite || evidence.assetWrite || evidence.fileWrite || evidence.sceneContext);
              if (isWriteEvidence && !review.evidence.some((item) => item.id && item.id === evidence.id)) {
                review.evidence.push(evidence);
              }
            }
          }
          if (event.type === 'tool' && /ECONNRESET/u.test(String(event.error || ''))) {
            console.warn(
              `[AI Copilot][MCP ECONNRESET] session=${sessionId} task=${taskId} `
              + `tool=${event.toolName || 'unknown'} call=${event.callId || event.id || 'unknown'} `
              + `trace=${event.traceId || 'none'}`
            );
          }
          if (event.type === 'completed' || event.type === 'turn.completed') {
            terminalStatus = 'completed';
          } else if (
            event.type === 'failed'
            || event.type === 'turn.failed'
            || event.type === 'error'
          ) {
            terminalStatus = 'failed';
          }
          let visibleEvent = event.type === 'tool'
            ? { ...event, activityEvidence: catalogEvidence(event, environmentDiscovery.registry?.tools) }
            : event;
          if (event.type === 'failed' || event.type === 'error' || event.type === 'turn.failed') {
            const normalizedError = normalizeProviderError(event.message || event.error, modelSelection.providerId);
            visibleEvent = { ...event, message: normalizedError.message, detail: normalizedError.detail };
          }
          if (event.type === 'message') {
            let artifactPaths = [];
            try { artifactPaths = listOutboxFiles(artifactOutbox).map((item) => item.path); }
            catch (_) { /* A raced or empty outbox has no paths to expose. */ }
            visibleEvent = {
              ...event,
              text: sanitizeManagedPaths(event.text, {
                roots: managedInternalPathRoots,
                paths: [...turnAttachments.map((attachment) => attachment.storedPath), ...artifactPaths],
              }),
            };
          }
          broadcastCodexEvent({
            ...visibleEvent,
            sessionId,
            taskId,
          });
        }, {
          runtimeSnapshot,
          developerInstructions: [
            buildCocosDeveloperInstructions(),
            sessionStore.records.get(sessionId)?.continuation?.applied === false
              ? sessionStore.records.get(sessionId).continuation.context : '',
          ].filter(Boolean).join('\n\n'),
          onThreadStarted: acceptThreadDeveloperContext,
          onThreadResumed: acceptThreadDeveloperContext,
          onTurnStarted: (turn) => {
            for (const skill of pendingProjectSkillInjections) {
              session.projectSkillRevisions.set(skill.name, skill.revision);
            }
            pendingProjectSkillInjections = [];
            const record = sessionStore.records.get(sessionId);
            const skillThreadId = String(turn?.threadId || session.runner.threadId || record?.threadId || review.threadId || '').trim();
            if (record && skillThreadId && session.projectSkillRevisions.size) {
              sessionStore.save({
                ...record,
                threadId: skillThreadId,
                projectSkillState: {
                  threadId: skillThreadId,
                  revisions: Object.fromEntries(session.projectSkillRevisions),
                },
              }, { immediate: true });
            }
            proxy?.bindTurn(taskId, turn);
          },
          onMcpCatalog: (entries) => {
            environmentDiscovery.applyMcpStatus(entries);
            performanceTrace.mark('mcp_process_ready', {
              serverCount: Array.isArray(entries) ? entries.length : 0,
              toolCount: Array.isArray(entries) ? entries.reduce((sum, entry) => (
                sum + Object.keys(entry?.tools || {}).length
              ), 0) : 0,
            });
          },
          sessionId,
          taskId,
          permissionModeId,
          model: modelSelection.modelId,
          effort: modelSelection.reasoningEffort,
          modelProvider: requestedThreadId ? '' : modelSelection.modelProvider,
          localImages: (payload.supportsImageInput === false ? [] : turnAttachments).filter((attachment) => (
            attachment?.type === 'file'
            && attachment.kind !== 'directory'
            && attachment.available !== false
            && String(attachment.mimeType || '').startsWith('image/')
          )).map((attachment) => attachment.storedPath),
        });
        traceHandedOff = true;

        runnerPromise.then(() => {
          if (terminalStatus === 'unknown') terminalStatus = 'completed';
        }).catch((error) => {
          terminalStatus = error.code === 'CODEX_CANCELLED' ? 'cancelled' : 'failed';
          terminalMessage = error.message;
          if (error.code !== 'CODEX_CANCELLED') {
            console.error(`[AI Copilot] Codex task failed: ${error.message}`);
          }
        }).finally(async () => {
          performanceTrace.mark('model_terminal', { terminalStatus });
          if (proxy) {
            const finalStats = proxy.getStats();
            const initialStats = guardStatsAtStart || {};
            console.log(
              `[AI Copilot MCP Proxy] task=${taskId} `
              + `received=${finalStats.receivedToolCalls - (initialStats.receivedToolCalls || 0)} `
              + `forwarded=${finalStats.forwardedToolCalls - (initialStats.forwardedToolCalls || 0)}`
            );
            proxy.clearTask(taskId);
          }
          if (session.activeTaskId === taskId) session.activeTaskId = '';
          const endArtifactRegistration = performanceTrace.span('artifact_registration');
          try {
            const outboxArtifacts = await persistOutboxArtifacts({
              outbox: artifactOutbox,
              artifactRoot: fileStorageRoots.artifacts,
              sessionId,
              taskId,
            });
            const generatedArtifacts = [];
            for (const pending of generated.values()) {
              const delivery = await pending;
              if (delivery.artifact) generatedArtifacts.push(delivery.artifact);
              else if (delivery.artifacts) generatedArtifacts.push(...delivery.artifacts);
              else broadcastCodexEvent({ type: 'artifact-error', sessionId, taskId, message: '未收到可验证的图片产物。', timestamp: Date.now() });
            }
            const structuredAudio=[];
            for(const pending of generatedAudio.values()){
              const delivery=await pending;
              if(delivery.artifacts)structuredAudio.push(...delivery.artifacts);
              else broadcastCodexEvent({type:'artifact-error',sessionId,taskId,message:'未收到可验证的音频产物。',timestamp:Date.now()});
            }
            const artifacts = await linkImportedAudioArtifacts(enrichAudioArtifacts(mergeImageArtifacts(outboxArtifacts, generatedArtifacts, fileStorageRoots.artifacts).concat(structuredAudio),fileStorageRoots.artifacts));
            if (artifacts.length) {
              broadcastCodexEvent({
                type: 'assistant-artifacts',
                sessionId,
                taskId,
                artifacts,
                timestamp: Date.now(),
              });
            }
          } catch (error) {
            console.warn(`[AI Copilot] Artifact registration failed: ${error.message}`);
            broadcastCodexEvent({
              type: 'artifact-error',
              sessionId,
              taskId,
              message: '生成的文件无法加入聊天附件，请检查本地存储空间。',
              timestamp: Date.now(),
            });
          } finally {
            pendingMcpAudioByTask.delete(taskId);
            pendingLocalImageArtifactsByTask.delete(taskId);
            pendingAudioArtifactsByTask.delete(taskId);
            try { if (artifactOutbox) removeOutbox(artifactOutbox); }
            catch (error) { console.warn(`[AI Copilot] Artifact outbox cleanup failed: ${error.message}`); }
            try { removeTurnAttachments({ runtimeRoot: fileStorageRoots.runtime, sessionId, taskId }); }
            catch (error) { console.warn(`[AI Copilot] Attachment exchange cleanup failed: ${error.message}`); }
            if (session.artifactOutbox === artifactOutbox) session.artifactOutbox = '';
            endArtifactRegistration();
          }
          const endReviewProjection = performanceTrace.span('review_projection');
          try {
            await finalizeTurnChangeSet(session, review);
          } catch (error) {
            console.warn(`[AI Copilot Review] Unable to finalize ChangeSet: ${error.message}`);
          } finally {
            session.reviewRuns.delete(taskId);
            endReviewProjection();
          }
          const endMcpReload = performanceTrace.span('mcp_reload_flush');
          try {
            const reload = await mcpConfigAdapter.flushReload();
            if (reload.reloaded) invalidateMcpSettingsState('reload-applied');
          } catch (error) {
            console.warn(`[AI Copilot MCP Settings] deferred reload failed: ${error.message}`);
            invalidateMcpSettingsState('reload-failed');
          } finally {
            endMcpReload();
          }
          performanceTrace.mark('task_cleanup_complete');
          rememberTrace(completedTurnPerformanceTraces, performanceTrace.finish(terminalStatus));
          activeTurnPerformanceTraces.delete(taskId);
          broadcastCodexEvent({
            type: 'task-ended',
            sessionId,
            taskId,
            terminalStatus,
            message: terminalMessage,
            timestamp: Date.now(),
          });
        });

        return {
          accepted: true,
          threadId: session.runner.threadId || null,
        };
      } finally {
        if (!traceHandedOff) {
          rememberTrace(completedTurnPerformanceTraces, performanceTrace.finish('failed'));
          activeTurnPerformanceTraces.delete(taskId);
        }
        if (session.preparingTaskId === taskId) session.preparingTaskId = '';
        if (!session.runner.isRunning && session.activeTaskId === taskId) session.activeTaskId = '';
      }
    },

    async steerCodexTask(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      const taskId = String(payload.taskId || '').trim();
      const clientUserMessageId = String(payload.clientUserMessageId || '').trim();
      const userRequest = String(payload.userRequest == null ? payload.prompt || '' : payload.userRequest);
      const hasContent = Boolean(
        userRequest.trim()
        || String(payload.prompt || '').trim()
        || (Array.isArray(payload.attachments) && payload.attachments.length)
        || (Array.isArray(payload.pins) && payload.pins.length)
      );
      if (!sessionId || !taskId || !clientUserMessageId || !hasContent) {
        return {
          accepted: false,
          reason: 'invalid-request',
          message: '调整方向所需的消息或运行标识不完整。',
        };
      }

      const session = sessions.get(sessionId);
      if (!session?.runner.isRunning) {
        return {
          accepted: false,
          reason: 'turn-not-running',
          message: '当前任务已经结束，这条消息将继续保留在队列中。',
        };
      }
      const requestedThreadId = String(payload.threadId || '').trim();
      if (requestedThreadId && session.runner.threadId && requestedThreadId !== session.runner.threadId) {
        return {
          accepted: false,
          reason: 'stale-thread',
          message: '当前会话已切换，未提交这条调整方向消息。',
        };
      }

      try {
        const followUpAttachments = await materializeTurnAttachments(
          messageAttachments(payload.attachments, sessionId),
          { runtimeRoot: fileStorageRoots.runtime, sessionId, taskId, messageId: clientUserMessageId }
        );
        const codexPrompt = await prepareCodexFollowUpInput({
          prompt: payload.prompt,
          userRequest,
          attachments: followUpAttachments,
          artifactOutputDir: session.artifactOutbox,
          pins: payload.pins,
          selection: payload.selection,
        });
        const result = await session.runner.steer(codexPrompt, {
          sessionId,
          taskId,
          clientUserMessageId,
          localImages: followUpAttachments.filter((attachment) => (
            attachment?.type === 'file'
            && attachment.kind !== 'directory'
            && attachment.available !== false
            && String(attachment.mimeType || '').startsWith('image/')
          )).map((attachment) => attachment.storedPath),
        });
        return { accepted: true, ...result };
      } catch (error) {
        try {
          removeMaterializedMessageAttachments({
            runtimeRoot: fileStorageRoots.runtime,
            sessionId,
            taskId,
            messageId: clientUserMessageId,
          });
        } catch (_) { /* The Turn cleanup also removes this bounded exchange directory. */ }
        const retryable = [
          'CODEX_NOT_RUNNING',
          'CODEX_STEER_NOT_READY',
          'CODEX_STEER_STALE',
        ].includes(error.code);
        return {
          accepted: false,
          reason: error.code || 'steer-failed',
          message: retryable
            ? '当前 Turn 暂时无法接收调整，这条消息仍保留在队列中。'
            : `无法调整当前方向：${error.message}`,
        };
      }
    },

    cancelCodexSession(payload = {}) {
      const sessionId = String(payload.sessionId || '').trim();
      if (!sessionId) return false;

      const session = sessions.get(sessionId);
      if (!session) return false;
      const taskId = session.activeTaskId || session.preparingTaskId;
      if (payload.taskId && payload.taskId !== taskId) return false;
      session.cancelRequested = true;
      if (guardProxy && taskId) guardProxy.abortTask(taskId, 'user-stop');
      const cancelled = session.runner.cancel() || Boolean(session.preparingTaskId);
      if (payload.dispose === true) {
        sessions.delete(sessionId);
      }
      return cancelled;
    },
  },
};
