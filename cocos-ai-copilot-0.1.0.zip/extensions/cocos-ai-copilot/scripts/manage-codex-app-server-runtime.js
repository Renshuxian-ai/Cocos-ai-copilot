'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { manifest, assertCompatible } = require('../lib/codex-app-server-compatibility');
const { managedAppServerExecutable } = require('../lib/codex-runner');
const { applicationRoot } = require('../lib/application-paths');

function versionRecord(alias) {
  const distribution = manifest.distribution;
  if (alias === 'active' || alias === distribution.activeVersion) return {
    version: distribution.activeVersion,
    integrity: distribution.activeIntegrity,
    role: 'active',
  };
  if (alias === 'previous' || alias === distribution.previousKnownGoodVersion) {
    assertCompatible({ version: distribution.previousKnownGoodVersion });
    return {
    version: distribution.previousKnownGoodVersion,
    integrity: distribution.previousKnownGoodIntegrity,
    role: 'previous',
    };
  }
  throw new Error('Version must be active, previous, or one of the two locked exact versions.');
}

function selectionPath(root) {
  return path.join(root, 'runtimes', 'codex-app-server', 'selection.json');
}

function writeSelection(root, version) {
  const target = selectionPath(root);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const temporary = `${target}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify({ schemaVersion: 1, version }, null, 2)}\n`, { flag: 'wx' });
  fs.renameSync(temporary, target);
}

function verifyInstall(target, record) {
  const lock = JSON.parse(fs.readFileSync(path.join(target, 'package-lock.json'), 'utf8'));
  const installed = lock.packages?.['node_modules/@openai/codex'];
  if (installed?.version !== record.version || installed?.integrity !== record.integrity) {
    throw new Error('Installed app-server package does not match the locked version and integrity.');
  }
  const executable = managedAppServerExecutable(path.resolve(target, '..', '..', '..'), record.version);
  if (!fs.statSync(executable).isFile()) throw new Error('Installed app-server executable is missing.');
  return executable;
}

function install(root, record, activate) {
  const target = path.join(root, 'runtimes', 'codex-app-server', record.version);
  fs.mkdirSync(target, { recursive: true });
  const npmCli = path.join(path.dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js');
  const command = fs.existsSync(npmCli) ? process.execPath : process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const prefixArgs = fs.existsSync(npmCli) ? [npmCli] : [];
  const result = spawnSync(command, [...prefixArgs,
    'install', '--prefix', target, '--save-exact', '--omit=dev',
    `${manifest.distribution.package}@${record.version}`,
  ], { stdio: 'inherit', windowsHide: true, shell: command.endsWith('.cmd') });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`npm install failed with exit code ${result.status}.`);
  const executable = verifyInstall(target, record);
  if (activate) writeSelection(root, record.version);
  return { target, executable };
}

function status(root) {
  let selected = manifest.distribution.activeVersion;
  try { selected = JSON.parse(fs.readFileSync(selectionPath(root), 'utf8')).version || selected; }
  catch (_) { /* Default exact pin. */ }
  return {
    root,
    selected,
    active: {
      version: manifest.distribution.activeVersion,
      installed: fs.existsSync(managedAppServerExecutable(root, manifest.distribution.activeVersion)),
    },
    previous: {
      version: manifest.distribution.previousKnownGoodVersion,
      installed: fs.existsSync(managedAppServerExecutable(root, manifest.distribution.previousKnownGoodVersion)),
    },
  };
}

function main(argv = process.argv.slice(2), environment = process.env) {
  const [action = 'status', alias = 'active', ...flags] = argv;
  const root = applicationRoot(environment);
  if (action === 'status') {
    process.stdout.write(`${JSON.stringify(status(root), null, 2)}\n`);
    return;
  }
  if (action !== 'install') throw new Error('Action must be status or install.');
  const record = versionRecord(alias);
  const result = install(root, record, flags.includes('--activate'));
  process.stdout.write(`${JSON.stringify({ ...record, ...result, activated: flags.includes('--activate') }, null, 2)}\n`);
}

if (require.main === module) {
  try { main(); }
  catch (error) {
    process.stderr.write(`${error.stack || error.message}\n`);
    process.exitCode = 1;
  }
}

module.exports = { applicationRoot, install, main, selectionPath, status, verifyInstall, versionRecord, writeSelection };
