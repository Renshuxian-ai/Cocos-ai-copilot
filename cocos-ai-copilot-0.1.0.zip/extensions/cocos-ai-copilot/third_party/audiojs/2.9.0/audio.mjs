var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn3, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn3 && (res = (0, fn3[__getOwnPropNames(fn3)[0]])(fn3 = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/@audio/mic/src/backends/miniaudio.js
var miniaudio_exports = {};
__export(miniaudio_exports, {
  open: () => open
});
import { createRequire } from "node:module";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { arch, platform } from "node:os";
function open({ sampleRate: sampleRate2 = 44100, channels: channels2 = 1, bitDepth = 16, bufferSize = 50 } = {}) {
  const handle = addon.open(sampleRate2, channels2, bitDepth, bufferSize);
  const bpf = channels2 * (bitDepth / 8);
  return {
    read(cb) {
      const buf = Buffer.alloc(Math.round(sampleRate2 * bufferSize / 1e3) * bpf);
      addon.readAsync(handle, buf, (err, frames) => {
        if (frames > 0) cb?.(err, buf.subarray(0, frames * bpf));
        else cb?.(err, null);
      });
    },
    close() {
      addon.close(handle);
    }
  };
}
var require2, root, plat, addon, loaders;
var init_miniaudio = __esm({
  "node_modules/@audio/mic/src/backends/miniaudio.js"() {
    require2 = createRequire(import.meta.url);
    root = join(dirname(fileURLToPath(import.meta.url)), "../..");
    plat = `${platform()}-${arch()}`;
    loaders = [
      () => require2(`@audio/mic-${plat}`),
      () => require2(join(root, "packages", `mic-${plat}`, "mic.node")),
      () => require2(join(root, "prebuilds", plat, "audio-mic.node")),
      () => require2(join(root, "prebuilds", plat, "mic.node")),
      () => require2(join(root, "build", "Release", "mic.node")),
      () => require2(join(root, "build", "Debug", "mic.node"))
    ];
    for (const load of loaders) {
      try {
        addon = load();
        break;
      } catch {
      }
    }
    if (!addon) throw new Error("miniaudio addon not found \u2014 install @audio/mic-" + plat + " or run npm run build");
  }
});

// node_modules/@audio/mic/src/backends/process.js
var process_exports = {};
__export(process_exports, {
  open: () => open2
});
import { spawn, execSync } from "node:child_process";
import { platform as platform2 } from "node:os";
function tryExec(cmd) {
  try {
    execSync(cmd, { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}
function findRecorder(sampleRate2, channels2, bitDepth) {
  const os = platform2();
  const fmt3 = bitDepth === 8 ? "u8" : bitDepth === 32 ? "f32le" : `s${bitDepth}le`;
  if (os === "darwin" && tryExec("ffmpeg -version"))
    return ["ffmpeg", ["-f", "avfoundation", "-i", ":default", "-f", fmt3, "-ar", sampleRate2, "-ac", channels2, "-"]];
  if (os === "linux" && tryExec("ffmpeg -version"))
    return ["ffmpeg", ["-f", "pulse", "-i", "default", "-f", fmt3, "-ar", sampleRate2, "-ac", channels2, "-"]];
  if (tryExec("sox --version"))
    return ["sox", ["-d", "-t", "raw", "-r", sampleRate2, "-c", channels2, "-b", bitDepth, "-e", "signed-integer", "-L", "-"]];
  if (os === "linux" && tryExec("arecord --version")) {
    const afmt = bitDepth === 8 ? "U8" : bitDepth === 32 ? "FLOAT_LE" : `S${bitDepth}_LE`;
    return ["arecord", ["-f", afmt, "-r", sampleRate2, "-c", channels2, "-t", "raw"]];
  }
  return null;
}
function open2({ sampleRate: sampleRate2 = 44100, channels: channels2 = 1, bitDepth = 16 } = {}) {
  const recorder = findRecorder(sampleRate2, channels2, bitDepth);
  if (!recorder) throw new Error("No audio recorder found (install ffmpeg or sox)");
  const [cmd, args] = recorder;
  const proc = spawn(cmd, args.map(String), { stdio: ["ignore", "pipe", "ignore"] });
  let closed = false;
  let pending = null;
  proc.on("close", () => {
    closed = true;
  });
  proc.stdout.on("data", (chunk) => {
    if (pending) {
      const cb = pending;
      pending = null;
      cb(null, chunk);
    }
  });
  proc.stdout.on("error", () => {
  });
  return {
    read(cb) {
      if (closed) return cb?.(new Error("Process exited"), null);
      pending = cb;
    },
    close() {
      if (closed) return;
      closed = true;
      pending = null;
      proc.stdout.destroy();
      proc.kill();
    }
  };
}
var init_process = __esm({
  "node_modules/@audio/mic/src/backends/process.js"() {
  }
});

// node_modules/@audio/mic/src/backends/null.js
var null_exports = {};
__export(null_exports, {
  open: () => open3
});
function open3({ sampleRate: sampleRate2 = 44100, channels: channels2 = 1, bitDepth = 16, bufferSize = 50 } = {}) {
  const bpf = channels2 * (bitDepth / 8);
  const chunkFrames = Math.round(sampleRate2 * bufferSize / 1e3);
  const chunkBytes = chunkFrames * bpf;
  let closed = false;
  return {
    read(cb) {
      if (closed) return cb?.(null, null);
      setTimeout(() => {
        if (closed) return cb?.(null, null);
        cb?.(null, Buffer.alloc(chunkBytes));
      }, bufferSize);
    },
    close() {
      closed = true;
    }
  };
}
var init_null = __esm({
  "node_modules/@audio/mic/src/backends/null.js"() {
  }
});

// node_modules/@audio/mic/src/backend.js
function open4(opts, preference) {
  const order = preference ? backends.filter((b) => b.name === preference) : backends;
  let lastErr;
  for (const { name, open: open5 } of order) {
    try {
      return { name, device: open5(opts) };
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error(
    "No audio backend available. Install @audio/mic-* for your platform or run npm run build." + (lastErr ? ` Last error: ${lastErr.message}` : "")
  );
}
var miniaudio, process_, null_, backends;
var init_backend = __esm({
  async "node_modules/@audio/mic/src/backend.js"() {
    try {
      miniaudio = await Promise.resolve().then(() => (init_miniaudio(), miniaudio_exports));
    } catch {
    }
    try {
      process_ = await Promise.resolve().then(() => (init_process(), process_exports));
    } catch {
    }
    try {
      null_ = await Promise.resolve().then(() => (init_null(), null_exports));
    } catch {
    }
    backends = [
      miniaudio && { name: "miniaudio", open: miniaudio.open },
      process_ && { name: "process", open: process_.open },
      null_ && { name: "null", open: null_.open }
    ].filter(Boolean);
  }
});

// node_modules/@audio/mic/index.js
var mic_exports = {};
__export(mic_exports, {
  default: () => mic
});
function mic(opts) {
  const config = { ...defaults, ...opts };
  const { name, device } = open4(config, config.backend);
  read.close = () => {
    device.close();
  };
  read.end = () => {
    device.close();
  };
  read.backend = name;
  read[Symbol.asyncIterator] = () => ({
    next: () => new Promise((resolve, reject) => {
      device.read((err, chunk) => {
        if (err) return reject(err);
        if (!chunk) return resolve({ done: true, value: void 0 });
        resolve({ done: false, value: chunk });
      });
    })
  });
  return read;
  function read(cb) {
    if (cb == null) {
      device.close();
      return;
    }
    device.read(cb);
  }
}
var defaults;
var init_mic = __esm({
  async "node_modules/@audio/mic/index.js"() {
    await init_backend();
    defaults = {
      sampleRate: 44100,
      channels: 1,
      bitDepth: 16,
      bufferSize: 50
    };
  }
});

// node_modules/audio-type/audio-type.js
function audioType(buf) {
  if (!buf) return;
  buf = new Uint8Array(buf.buffer || buf);
  if (isWav(buf)) return "wav";
  if (isAiff(buf)) return "aiff";
  if (isMp3(buf)) return "mp3";
  if (isAac(buf)) return "aac";
  if (isFlac(buf)) return "flac";
  if (isTta(buf)) return "tta";
  if (isM4a(buf)) return "m4a";
  if (isOpus(buf)) return "opus";
  if (isOggFlac(buf)) return "flac";
  if (isOgg(buf)) return "oga";
  if (isQoa(buf)) return "qoa";
  if (isMidi(buf)) return "mid";
  if (isCaf(buf)) return "caf";
  if (isWma(buf)) return "wma";
  if (isAmr(buf)) return "amr";
  if (isWv(buf)) return "wv";
  if (isMpc(buf)) return "mpc";
  if (isApe(buf)) return "ape";
  if (isDsf(buf)) return "dsf";
  if (isDff(buf)) return "dff";
  if (isEac3(buf)) return "eac3";
  if (isAc3(buf)) return "ac3";
  if (isDts(buf)) return "dts";
  if (isIt(buf)) return "it";
  if (isS3m(buf)) return "s3m";
  if (isXm(buf)) return "xm";
  if (isMod(buf)) return "mod";
  if (isMkv(buf)) return "mkv";
  if (isWebm(buf)) return "webm";
  if (isAvi(buf)) return "avi";
  let id3 = skipId3(buf);
  if (id3) {
    if (id3 >= buf.length) return "mp3";
    let rest = buf.subarray(id3);
    if (isMp3(rest)) return "mp3";
    if (isFlac(rest)) return "flac";
    if (isTta(rest)) return "tta";
    if (isAac(rest)) return "aac";
  }
}
function skipId3(buf) {
  if (!buf || buf.length < 10) return 0;
  if (buf[0] !== 73 || buf[1] !== 68 || buf[2] !== 51) return 0;
  let size = (buf[6] & 127) << 21 | (buf[7] & 127) << 14 | (buf[8] & 127) << 7 | buf[9] & 127;
  let footer = buf[5] & 16 ? 10 : 0;
  return 10 + size + footer;
}
function isMp3(buf) {
  if (!buf || buf.length < 3) return;
  return buf[0] === 255 && (buf[1] & 224) === 224 && (buf[1] & 6) !== 0 || // MPEG sync, layer != 0 (excludes AAC)
  buf[0] === 84 && buf[1] === 65 && buf[2] === 71;
}
function isWav(buf) {
  if (!buf || buf.length < 12) return;
  return buf[0] === 82 && buf[1] === 73 && buf[2] === 70 && buf[3] === 70 && buf[8] === 87 && buf[9] === 65 && buf[10] === 86 && buf[11] === 69;
}
function isOgg(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 79 && buf[1] === 103 && buf[2] === 103 && buf[3] === 83;
}
function isFlac(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 102 && buf[1] === 76 && buf[2] === 97 && buf[3] === 67;
}
function isM4a(buf) {
  if (!buf || buf.length < 8) return;
  return buf[4] === 102 && buf[5] === 116 && buf[6] === 121 && buf[7] === 112 || buf[0] === 77 && buf[1] === 52 && buf[2] === 65 && buf[3] === 32;
}
function isOpus(buf) {
  if (!buf || buf.length < 36) return;
  return buf[0] === 79 && buf[1] === 103 && buf[2] === 103 && buf[3] === 83 && buf[28] === 79 && buf[29] === 112 && buf[30] === 117 && buf[31] === 115 && buf[32] === 72 && buf[33] === 101 && buf[34] === 97 && buf[35] === 100;
}
function isOggFlac(buf) {
  if (!buf || buf.length < 33) return;
  return isOgg(buf) && buf[28] === 127 && buf[29] === 70 && buf[30] === 76 && buf[31] === 65 && buf[32] === 67;
}
function isQoa(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 113 && buf[1] === 111 && buf[2] === 97 && buf[3] === 102;
}
function isAiff(buf) {
  if (!buf || buf.length < 12) return;
  return buf[0] === 70 && buf[1] === 79 && buf[2] === 82 && buf[3] === 77 && buf[8] === 65 && buf[9] === 73 && buf[10] === 70 && (buf[11] === 70 || buf[11] === 67);
}
function isAac(buf) {
  if (!buf || buf.length < 2) return;
  return buf[0] === 255 && (buf[1] & 240) === 240 && (buf[1] & 6) === 0;
}
function isMidi(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 77 && buf[1] === 84 && buf[2] === 104 && buf[3] === 100;
}
function isCaf(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 99 && buf[1] === 97 && buf[2] === 102 && buf[3] === 102;
}
function isWma(buf) {
  if (!buf || buf.length < 8) return;
  return buf[0] === 48 && buf[1] === 38 && buf[2] === 178 && buf[3] === 117 && buf[4] === 142 && buf[5] === 102 && buf[6] === 207 && buf[7] === 17;
}
function isAmr(buf) {
  if (!buf || buf.length < 5) return;
  return buf[0] === 35 && buf[1] === 33 && buf[2] === 65 && buf[3] === 77 && buf[4] === 82;
}
function isWebm(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 26 && buf[1] === 69 && buf[2] === 223 && buf[3] === 163;
}
function isAvi(buf) {
  if (!buf || buf.length < 12) return;
  return buf[0] === 82 && buf[1] === 73 && buf[2] === 70 && buf[3] === 70 && buf[8] === 65 && buf[9] === 86 && buf[10] === 73 && buf[11] === 32;
}
function isMkv(buf) {
  if (!isWebm(buf)) return;
  let n = Math.min(buf.length, 64);
  for (let i = 4; i < n - 8; i++)
    if (buf[i] === 66 && buf[i + 1] === 130)
      return buf[i + 3] === 109 && buf[i + 4] === 97 && buf[i + 5] === 116 && buf[i + 6] === 114;
}
function isAc3(buf) {
  if (!buf || buf.length < 6) return;
  return buf[0] === 11 && buf[1] === 119 && (buf[4] & 63) < 38 && buf[5] >> 3 <= 8;
}
function isEac3(buf) {
  if (!buf || buf.length < 6) return;
  let bsid = buf[5] >> 3;
  return buf[0] === 11 && buf[1] === 119 && bsid >= 11 && bsid <= 16;
}
function isDts(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 127 && buf[1] === 254 && buf[2] === 128 && buf[3] === 1 || buf[0] === 254 && buf[1] === 127 && buf[2] === 1 && buf[3] === 128 || buf[0] === 31 && buf[1] === 255 && buf[2] === 232 && buf[3] === 0;
}
function isWv(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 119 && buf[1] === 118 && buf[2] === 112 && buf[3] === 107;
}
function isTta(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 84 && buf[1] === 84 && buf[2] === 65 && buf[3] === 49;
}
function isMpc(buf) {
  if (!buf || buf.length < 4) return;
  if (buf[0] === 77 && buf[1] === 80 && buf[2] === 43 && (buf[3] & 15) === 7) return true;
  return buf[0] === 77 && buf[1] === 80 && buf[2] === 67 && buf[3] === 75;
}
function isApe(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 77 && buf[1] === 65 && buf[2] === 67 && buf[3] === 32;
}
function isDsf(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 68 && buf[1] === 83 && buf[2] === 68 && buf[3] === 32;
}
function isDff(buf) {
  if (!buf || buf.length < 16) return;
  return buf[0] === 70 && buf[1] === 82 && buf[2] === 77 && buf[3] === 56 && buf[12] === 68 && buf[13] === 83 && buf[14] === 68 && buf[15] === 32;
}
var MOD_TAGS = /* @__PURE__ */ new Set(["M.K.", "M!K!", "FLT4", "FLT8", "CD81", "OKTA"]);
function isMod(buf) {
  if (!buf || buf.length < 1084) return;
  let tag = String.fromCharCode(buf[1080], buf[1081], buf[1082], buf[1083]);
  return MOD_TAGS.has(tag) || /^\dCHN$/.test(tag) || /^\d\dCH$/.test(tag) || /^TDZ\d$/.test(tag);
}
function isXm(buf) {
  if (!buf || buf.length < 17) return;
  const tag = "Extended Module: ";
  for (let i = 0; i < 17; i++) if (buf[i] !== tag.charCodeAt(i)) return false;
  return true;
}
function isS3m(buf) {
  if (!buf || buf.length < 48) return;
  return buf[44] === 83 && buf[45] === 67 && buf[46] === 82 && buf[47] === 77;
}
function isIt(buf) {
  if (!buf || buf.length < 4) return;
  return buf[0] === 73 && buf[1] === 77 && buf[2] === 80 && buf[3] === 77;
}

// node_modules/@audio/decode/audio-decode.js
var EMPTY = Object.freeze({ channelData: Object.freeze([]), sampleRate: 0 });
function decode(src, format) {
  if (format) return decodeChunked(src, format);
  return decodeWhole(src);
}
async function decodeWhole(src) {
  if (src && typeof src.arrayBuffer === "function") src = await src.arrayBuffer();
  if (!src || typeof src === "string" || !(src.buffer || src.byteLength || src.length))
    throw TypeError("Expected ArrayBuffer, Uint8Array, Buffer, Blob, File, or Response");
  let buf = new Uint8Array(src);
  let type = audioType(buf);
  if (!type) throw Error("Unknown audio format");
  if (!decode[type]) throw Error("No decoder for " + type);
  let dec = await decode[type]();
  try {
    let result = await dec(buf);
    let flushed = await dec();
    return merge(result, flushed);
  } catch (e) {
    dec.free();
    throw e;
  }
}
async function* decodeChunked(source, format) {
  if (!decode[format]) throw Error("No decoder for " + format);
  let dec = await decode[format]();
  try {
    if (source.getReader) {
      let reader3 = source.getReader();
      while (true) {
        let { done, value } = await reader3.read();
        if (done) break;
        let result = await dec(value instanceof Uint8Array ? value : new Uint8Array(value));
        if (result.channelData.length) yield result;
      }
    } else {
      for await (let chunk of source) {
        let result = await dec(chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk));
        if (result.channelData.length) yield result;
      }
    }
    let flushed = await dec();
    if (flushed.channelData.length) yield flushed;
  } finally {
    dec.free();
  }
}
function reg(name, load, dedupe) {
  decode[name] = fmt(name, async () => {
    let mod = await load();
    if (mod.decoder) {
      let codec2 = await mod.decoder();
      return streamDecoder(
        (chunk) => codec2.decode(chunk),
        codec2.flush ? () => codec2.flush() : null,
        codec2.free ? () => codec2.free() : null,
        dedupe
      );
    }
    let init = mod.default || mod;
    let codec = typeof init === "function" ? await init() : init;
    if (codec.ready) await codec.ready;
    return streamDecoder(
      (chunk) => codec.decode(chunk),
      codec.flush ? () => codec.flush() : null,
      codec.free ? () => codec.free() : null,
      dedupe
    );
  });
}
function fmt(name, init) {
  let fn3 = (src) => {
    if (!src) return init();
    if (src[Symbol.asyncIterator] || src.getReader) return decodeChunked(src, name);
    console.warn("decode." + name + "(data) is deprecated, use decode(data)");
    return (async () => {
      let dec = await init();
      try {
        let result = await dec(src instanceof Uint8Array ? src : new Uint8Array(src.buffer || src));
        let flushed = await dec();
        return merge(result, flushed);
      } catch (e) {
        dec.free();
        throw e;
      }
    })();
  };
  return fn3;
}
reg("mp3", () => import("@audio/decode-mp3"), true);
reg("flac", () => import("@audio/decode-flac"));
reg("opus", () => import("@audio/decode-opus"));
reg("oga", () => import("@audio/decode-vorbis"));
reg("m4a", () => import("@audio/decode-mp4"), true);
reg("mp4", () => import("@audio/decode-mp4"), true);
reg("mov", () => import("@audio/decode-mp4"), true);
reg("wav", () => import("@audio/decode-wav"));
reg("qoa", () => import("@audio/decode-qoa"));
reg("aac", () => import("@audio/decode-aac"), true);
reg("aiff", () => import("@audio/decode-aiff"));
reg("caf", () => import("@audio/decode-caf"));
reg("webm", () => import("@audio/decode-webm"));
reg("mkv", () => import("@audio/decode-webm"), true);
reg("avi", () => import("@audio/decode-avi"), true);
reg("ac3", () => import("@audio/decode-ac3"));
reg("dts", () => import("@audio/decode-dts"));
reg("amr", () => import("@audio/decode-amr"));
reg("wma", () => import("@audio/decode-wma"), true);
reg("wv", () => import("@audio/decode-wavpack"));
reg("tta", () => import("@audio/decode-tta"));
reg("ape", () => import("@audio/decode-ape"));
reg("mpc", () => import("@audio/decode-mpc"));
reg("eac3", () => import("@audio/decode-eac3"));
reg("dsf", () => import("@audio/decode-dsd"));
reg("dff", () => import("@audio/decode-dsd"));
reg("mod", () => import("@audio/decode-mod"));
reg("xm", () => import("@audio/decode-mod"));
reg("s3m", () => import("@audio/decode-mod"));
reg("it", () => import("@audio/decode-mod"));
function streamDecoder(onDecode, onFlush, onFree, dedupe) {
  let done = false;
  let dd = dedupe ? { live: true } : null;
  let fn3 = async (chunk) => {
    if (chunk) {
      if (done) throw Error("Decoder already freed");
      try {
        return norm(await onDecode(chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk)), dd);
      } catch (e) {
        done = true;
        onFree?.();
        throw e;
      }
    }
    if (done) return EMPTY;
    done = true;
    try {
      let result = onFlush ? norm(await onFlush(), dd) : EMPTY;
      onFree?.();
      return result;
    } catch (e) {
      onFree?.();
      throw e;
    }
  };
  fn3.flush = async () => {
    if (done) return EMPTY;
    return onFlush ? norm(await onFlush(), dd) : EMPTY;
  };
  fn3.free = () => {
    if (done) return;
    done = true;
    onFree?.();
  };
  return fn3;
}
function norm(r, dd) {
  if (!r?.channelData?.length) return EMPTY;
  let { channelData, sampleRate: sampleRate2, samplesDecoded } = r;
  if (samplesDecoded != null && samplesDecoded < channelData[0].length)
    channelData = channelData.map((ch) => ch.subarray(0, samplesDecoded));
  if (!channelData[0]?.length) return EMPTY;
  if (dd?.live && channelData.length === 2) {
    let a = channelData[0], b = channelData[1], same = true;
    for (let i = 0; i < a.length; i += 37) {
      if (a[i] !== b[i]) {
        same = false;
        break;
      }
    }
    if (same) channelData = [a];
    else dd.live = false;
  }
  return { channelData, sampleRate: sampleRate2 };
}
function merge(a, b) {
  if (!b?.channelData?.length) return a;
  if (!a?.channelData?.length) return b;
  let ach = a.channelData.length, bch = b.channelData.length;
  let ch = Math.max(ach, bch);
  return {
    channelData: Array.from({ length: ch }, (_, i) => {
      let ac = a.channelData[i % ach], bc = b.channelData[i % bch];
      let merged = new Float32Array(ac.length + bc.length);
      merged.set(ac);
      merged.set(bc, ac.length);
      return merged;
    }),
    sampleRate: a.sampleRate
  };
}

// node_modules/@audio/encode/audio-encode.js
var EMPTY2 = new Uint8Array(0);
function encode(format, data, opts) {
  if (!encode[format]) throw Error("Unknown format: " + format);
  return encode[format](data, opts);
}
var audio_encode_default = encode;
function isAudioData(d2) {
  return d2 instanceof Float32Array || Array.isArray(d2) || d2?.getChannelData && d2?.numberOfChannels;
}
async function* encodeChunked(source, format, opts) {
  let enc = await encode[format](opts);
  try {
    for await (let chunk of source) {
      let buf = await enc(chunk);
      if (buf.length) yield buf;
    }
    let final = await enc();
    if (final.length) yield final;
  } catch (e) {
    enc.free();
    throw e;
  }
}
var META_WRITERS = {
  wav: () => import("@audio/encode-wav/meta").then((m2) => m2.writeMeta),
  mp3: () => import("@audio/encode-mp3/meta").then((m2) => m2.writeMeta),
  flac: () => import("@audio/encode-flac/meta").then((m2) => m2.writeMeta),
  aiff: () => import("@audio/encode-aiff/meta").then((m2) => m2.writeMeta),
  ogg: () => import("@audio/encode-ogg/meta").then((m2) => m2.writeMeta)
};
var NATIVE_META = /* @__PURE__ */ new Set(["opus", "wv", "m4a", "mp4"]);
function reg2(name, load) {
  encode[name] = fmt2(name, async (opts) => {
    let { meta, markers, regions, stream: stream2, ...rest } = opts || {};
    let hasMeta = meta || markers?.length || regions?.length || rest.chapters?.length;
    let init = (await load()).default;
    let native = stream2 || NATIVE_META.has(name);
    let codec = await init(native && hasMeta ? { ...rest, meta, markers, regions, stream: stream2 } : stream2 ? { ...rest, stream: stream2 } : rest);
    if (native || !META_WRITERS[name] || !hasMeta)
      return streamEncoder((ch) => codec.encode(ch), () => codec.flush(), () => codec.free(), () => codec.head?.());
    let writeMeta = await META_WRITERS[name]();
    let parts = [], fed = 0;
    return streamEncoder(
      async (ch) => {
        fed += ch[0].length;
        let b = await codec.encode(ch);
        if (b?.length) parts.push(b);
        return EMPTY2;
      },
      async () => {
        let f = await codec.flush();
        if (f?.length) parts.push(f);
        let total = 0;
        for (let p of parts) total += p.length;
        let all = new Uint8Array(total), off = 0;
        for (let p of parts) {
          all.set(p, off);
          off += p.length;
        }
        let h2 = codec.head?.();
        if (h2) all.set(h2, 0);
        return writeMeta(all, { meta: meta || {}, markers: markers || [], regions: regions || [], chapters: rest.chapters || [], duration: fed / rest.sampleRate });
      },
      () => codec.free()
    );
  });
}
reg2("wav", () => import("@audio/encode-wav"));
reg2("aiff", () => import("@audio/encode-aiff"));
reg2("caf", () => import("@audio/encode-caf"));
reg2("mp3", () => import("@audio/encode-mp3"));
reg2("ogg", () => import("@audio/encode-ogg"));
reg2("flac", () => import("@audio/encode-flac"));
reg2("opus", () => import("@audio/encode-opus"));
reg2("webm", () => import("@audio/encode-webm"));
reg2("aac", () => import("@audio/encode-aac"));
reg2("qoa", () => import("@audio/encode-qoa"));
reg2("wv", () => import("@audio/encode-wavpack"));
reg2("m4a", () => import("@audio/encode-mp4"));
reg2("mp4", () => import("@audio/encode-mp4"));
for (let name of ["m4a", "mp4"]) {
  let container = encode[name];
  encode[name] = (data, opts) => (opts ?? data)?.codec === "alac" ? fmt2(name, async (o) => {
    let init = (await import("@audio/encode-alac")).default;
    let c = await init(o);
    return streamEncoder((ch) => c.encode(ch), () => c.flush(), () => c.free());
  })(data, opts) : container(data, opts);
}
var formats = ["wav", "aiff", "caf", "mp3", "ogg", "flac", "opus", "webm", "aac", "qoa", "wv", "m4a", "mp4"];
var mime = {
  wav: "audio/wav",
  aiff: "audio/aiff",
  caf: "audio/x-caf",
  mp3: "audio/mpeg",
  ogg: "audio/ogg",
  flac: "audio/flac",
  opus: "audio/ogg",
  webm: "audio/webm",
  aac: "audio/aac",
  qoa: "audio/qoa",
  wv: "audio/wavpack",
  m4a: "audio/mp4",
  mp4: "audio/mp4"
};
encode.formats = formats;
encode.mime = mime;
function fmt2(name, init) {
  let fn3 = (data, opts) => {
    if (!opts) return init(data);
    if (data && (typeof data[Symbol.asyncIterator] === "function" || typeof data[Symbol.iterator] === "function" && !isAudioData(data)))
      return encodeChunked(data, name, opts);
    return wholeFile(data, opts, init);
  };
  return fn3;
}
async function wholeFile(data, opts, init) {
  if (!opts.sampleRate) throw Error("sampleRate is required");
  let ch = channels(data);
  if (!ch.length || !ch[0].length) return EMPTY2;
  let enc = await init({ channels: ch.length, ...opts });
  try {
    let result = await enc(ch);
    let flushed = await enc();
    let out = merge2(result, flushed), h2 = enc.head();
    if (h2) {
      if (out === result || out === flushed) out = out.slice();
      out.set(h2, 0);
    }
    return out;
  } catch (e) {
    enc.free();
    throw e;
  }
}
function channels(data) {
  if (!data) return [];
  if (Array.isArray(data)) {
    if (data[0] instanceof Float32Array) return data;
    return [];
  }
  if (data instanceof Float32Array) return [data];
  if (data.getChannelData && data.numberOfChannels) {
    let ch = [];
    for (let i = 0; i < data.numberOfChannels; i++) ch.push(data.getChannelData(i));
    return ch;
  }
  return [];
}
function streamEncoder(onEncode, onFlush, onFree, onHead) {
  let done = false;
  let fn3 = async (data) => {
    if (data) {
      if (done) throw Error("Encoder already freed");
      let ch = channels(data);
      try {
        return norm2(await onEncode(ch));
      } catch (e) {
        done = true;
        onFree?.();
        throw e;
      }
    }
    if (done) return EMPTY2;
    done = true;
    try {
      let result = onFlush ? norm2(await onFlush()) : EMPTY2;
      onFree?.();
      return result;
    } catch (e) {
      onFree?.();
      throw e;
    }
  };
  fn3.flush = async () => {
    if (done) return EMPTY2;
    return onFlush ? norm2(await onFlush()) : EMPTY2;
  };
  fn3.free = () => {
    if (done) return;
    done = true;
    onFree?.();
  };
  fn3.head = () => {
    let h2 = onHead?.();
    return h2?.length ? norm2(h2) : null;
  };
  return fn3;
}
function norm2(r) {
  if (!r?.length) return EMPTY2;
  if (r instanceof Uint8Array) return r;
  if (r.buffer) return new Uint8Array(r.buffer, r.byteOffset, r.byteLength);
  return new Uint8Array(r);
}
function merge2(a, b) {
  if (!b?.length) return a || EMPTY2;
  if (!a?.length) return b || EMPTY2;
  let out = new Uint8Array(a.length + b.length);
  out.set(a);
  out.set(b, a.length);
  return out;
}

// node_modules/@audio/resample-polyphase/polyphase.js
var ZC = 16;
var tapsFor = (L, M) => 2 * Math.ceil(ZC * Math.max(1, M / L));
function i0(x) {
  let s = 1, t = 1, k = 0;
  while (t > 1e-12 * s) {
    k++;
    t *= (x / (2 * k)) ** 2;
    s += t;
  }
  return s;
}
var gcd = (a, b) => b ? gcd(b, a % b) : a;
function design(L, M, taps) {
  let n = taps * L, D = taps >> 1;
  let c = L * D;
  let fc = Math.min(1, L / M) / L;
  let beta = 8.6;
  let ib = i0(beta);
  let proto = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let x = i - c;
    let sinc2 = x === 0 ? 1 : Math.sin(Math.PI * fc * x) / (Math.PI * fc * x);
    let r = (i - c) / c;
    proto[i] = fc * L * sinc2 * i0(beta * Math.sqrt(Math.max(0, 1 - r * r))) / ib;
  }
  let phases = [];
  for (let p = 0; p < L; p++) {
    let h2 = new Float32Array(taps);
    for (let k = 0; k < taps; k++) h2[k] = proto[k * L + p];
    phases.push(h2);
  }
  return phases;
}
function stream({ from, to } = {}) {
  if (!(from > 0) || !(to > 0)) throw new RangeError("resample: from/to must be positive sample rates");
  let g = gcd(Math.round(from), Math.round(to));
  let L = Math.round(to) / g, M = Math.round(from) / g;
  let taps = from === to ? 0 : tapsFor(L, M), D = taps >> 1;
  let phases = taps ? design(L, M, taps) : null;
  let hist = new Float32Array(taps);
  let consumed = 0;
  let m2 = 0;
  function run(data, avail) {
    if (!phases) return Float32Array.from(data);
    let out = [];
    while (Math.floor(m2 * M / L) + D < avail) {
      let up = m2 * M;
      let base = Math.floor(up / L) + D;
      let h2 = phases[up % L], sum = 0;
      for (let k = 0; k < taps; k++) {
        let idx = base - k;
        if (idx < 0) break;
        let rel = idx - consumed;
        sum += h2[k] * (rel >= 0 ? data[rel] : hist[taps + rel]);
      }
      out.push(sum);
      m2++;
    }
    if (data.length >= taps) hist.set(data.subarray(data.length - taps));
    else {
      hist.copyWithin(0, data.length);
      hist.set(data, taps - data.length);
    }
    consumed += data.length;
    return Float32Array.from(out);
  }
  return {
    write: (chunk) => run(chunk, consumed + chunk.length),
    flush() {
      let expect = Math.round(consumed * L / M);
      let pad = new Float32Array(taps);
      let tail = run(pad, consumed + taps + D);
      return tail.subarray(0, Math.max(0, expect - (m2 - tail.length)));
    }
  };
}
function polyphase(data, opts = {}) {
  let s = stream(opts);
  let a = s.write(data), b = s.flush();
  let n = Math.round(data.length * (opts.to / opts.from));
  let out = new Float32Array(n);
  out.set(a.subarray(0, Math.min(a.length, n)));
  if (a.length < n) out.set(b.subarray(0, Math.min(b.length, n - a.length)), a.length);
  return out;
}

// node_modules/pcm-convert/index.js
var sampleRate = [8e3, 11025, 16e3, 22050, 44100, 48e3, 88200, 96e3, 176400, 192e3, 352800, 384e3];
var _AudioBuffer = typeof AudioBuffer !== "undefined" ? AudioBuffer : null;
var _loading = false;
var ready = Promise.resolve();
if (!_AudioBuffer) {
  try {
    _AudioBuffer = globalThis.process?.getBuiltinModule?.("module").createRequire(import.meta.url)("audio-buffer").default ?? null;
  } catch {
  }
  if (!_AudioBuffer) {
    _loading = true;
    ready = import("audio-buffer").then((m2) => {
      _AudioBuffer ??= m2.default;
    }, () => {
    }).finally(() => {
      _loading = false;
    });
  }
}
var RATE_SET = new Set(sampleRate);
var DTYPE = {
  float32: { C: Float32Array, min: -1, max: 1 },
  float64: { C: Float64Array, min: -1, max: 1 },
  uint8: { C: Uint8Array, min: 0, max: 255 },
  uint16: { C: Uint16Array, min: 0, max: 65535 },
  uint32: { C: Uint32Array, min: 0, max: 4294967295 },
  int8: { C: Int8Array, min: -128, max: 127 },
  int16: { C: Int16Array, min: -32768, max: 32767 },
  int32: { C: Int32Array, min: -2147483648, max: 2147483647 }
};
var dtype = (d2) => DTYPE[d2] && d2 || DTYPE[d2 + "32"] && d2 + "32";
var CONTAINER = { array: 1, arraybuffer: 1, buffer: 1, audiobuffer: 1 };
var CHANNELS = { mono: 1, stereo: 2, "2.1": 3, quad: 4, "5.1": 6 };
for (let i = 3; i <= 32; i++) CHANNELS[i + "-channel"] ||= i;
var CHANNEL_NAME = {};
for (let k in CHANNELS) CHANNEL_NAME[CHANNELS[k]] ||= k;
var isTyped = (v) => ArrayBuffer.isView(v) && !(v instanceof DataView);
var isPlanar = (v) => Array.isArray(v) && v.length > 0 && isTyped(v[0]);
var isContainer = (v) => v != null && typeof v !== "string" && !isPlanar(v) && (Array.isArray(v) || isTyped(v) || v instanceof ArrayBuffer);
var isAudioBuffer = (v) => v != null && typeof v.getChannelData === "function" && typeof v.numberOfChannels === "number";
function parse(fmt3) {
  if (!fmt3) return {};
  if (typeof fmt3 !== "string") {
    let r2 = {};
    let d2 = fmt3.dtype || fmt3.type;
    if (dtype(d2)) r2.dtype = dtype(d2);
    if (d2 && CONTAINER[d2]) r2.container = d2;
    if (fmt3.channels != null) r2.channels = CHANNELS[fmt3.channels] || +fmt3.channels;
    if (fmt3.numberOfChannels != null) r2.channels ??= fmt3.numberOfChannels;
    if (fmt3.interleaved != null) r2.interleaved = fmt3.interleaved;
    if (fmt3.endianness) r2.endianness = fmt3.endianness;
    if (fmt3.sampleRate != null) r2.sampleRate = fmt3.sampleRate;
    if (fmt3.rate != null) r2.sampleRate ??= fmt3.rate;
    if (fmt3.container) r2.container = fmt3.container;
    return r2;
  }
  let r = {};
  for (let t of fmt3.split(/\s*[,;_]\s*|\s+/)) {
    let lo = t.toLowerCase();
    if (dtype(lo)) r.dtype = dtype(lo);
    else if (CONTAINER[lo]) r.container = lo;
    else if (CHANNELS[lo]) r.channels = CHANNELS[lo];
    else if (lo === "interleaved") r.interleaved = true;
    else if (lo === "planar") r.interleaved = false;
    else if (lo === "le") r.endianness = "le";
    else if (lo === "be") r.endianness = "be";
    else if (/^\d+$/.test(lo) && RATE_SET.has(+lo)) r.sampleRate = +lo;
    else throw Error("Unknown format token: " + t);
  }
  return r;
}
function detect(data) {
  if (data == null) return {};
  if (isAudioBuffer(data))
    return { dtype: "float32", channels: data.numberOfChannels, interleaved: false, sampleRate: data.sampleRate };
  if (typeof Buffer !== "undefined" && Buffer.isBuffer(data)) return { dtype: "uint8", container: "buffer" };
  if (data instanceof Float32Array) return { dtype: "float32" };
  if (data instanceof Float64Array) return { dtype: "float64" };
  if (data instanceof Int8Array) return { dtype: "int8" };
  if (data instanceof Int16Array) return { dtype: "int16" };
  if (data instanceof Int32Array) return { dtype: "int32" };
  if (data instanceof Uint8Array) return { dtype: "uint8" };
  if (data instanceof Uint8ClampedArray) return { dtype: "uint8" };
  if (data instanceof Uint16Array) return { dtype: "uint16" };
  if (data instanceof Uint32Array) return { dtype: "uint32" };
  if (data instanceof ArrayBuffer) return { container: "arraybuffer" };
  if (Array.isArray(data)) {
    if (isPlanar(data))
      return { ...detect(data[0]), channels: data.length, interleaved: false };
    return { container: "array" };
  }
  return {};
}
function range(d2) {
  return DTYPE[d2] || { min: -1, max: 1 };
}
function span(r, other) {
  return r.max > 1 && other.max === 1 && other.min === -1 ? r.max - r.min + 1 : r.max - r.min;
}
function convert(src, from, to, dst) {
  if (!src) throw Error("Source data required");
  if (from == null) throw Error("Format required");
  let srcInfo = detect(src);
  if (to === void 0 && dst === void 0) {
    if (isContainer(from)) {
      dst = from;
      to = detect(dst);
      from = srcInfo;
    } else {
      to = parse(from);
      from = srcInfo;
    }
  } else if (dst === void 0) {
    if (isContainer(to)) {
      dst = to;
      to = parse(from);
      from = srcInfo;
    } else {
      from = { ...srcInfo, ...parse(from) };
      to = parse(to);
    }
  } else {
    from = { ...srcInfo, ...parse(from) };
    to = { ...dst ? detect(dst) : {}, ...parse(to) };
  }
  if (to.container === "audiobuffer") to.dtype = "float32";
  if (!to.dtype) to.dtype = from.dtype;
  if (to.channels == null && from.channels != null) to.channels = from.channels;
  if (to.interleaved != null && from.interleaved == null) {
    from.interleaved = !to.interleaved;
    if (!from.channels) from.channels = 2;
  }
  if (from.interleaved != null && !from.channels) from.channels = 2;
  let fromR = from.container === "array" ? { min: -1, max: 1 } : range(from.dtype);
  let toR = to.container === "array" ? { min: -1, max: 1 } : range(to.dtype);
  let samples;
  if (isPlanar(src)) {
    let ch2 = src.length, len2 = src[0].length;
    samples = new src[0].constructor(len2 * ch2);
    for (let c = 0; c < ch2; c++) samples.set(src[c], len2 * c);
  } else if (isAudioBuffer(src)) {
    let nc = src.numberOfChannels, len2 = src.length;
    samples = new Float32Array(len2 * nc);
    for (let c = 0; c < nc; c++) samples.set(src.getChannelData(c), len2 * c);
  } else if (src instanceof ArrayBuffer) {
    samples = new (DTYPE[from.dtype]?.C || Uint8Array)(src);
  } else if (typeof Buffer !== "undefined" && Buffer.isBuffer(src)) {
    samples = new (DTYPE[from.dtype]?.C || Uint8Array)(
      src.buffer.slice(src.byteOffset, src.byteOffset + src.byteLength)
    );
  } else {
    samples = src;
  }
  if (from.sampleRate && to.sampleRate && from.sampleRate !== to.sampleRate) {
    let ch2 = from.channels || 1;
    let n = Math.floor(samples.length / ch2);
    let interleaved = from.interleaved ?? false;
    let fromSpan = span(fromR, { min: -1, max: 1 });
    let planar = [];
    for (let c = 0; c < ch2; c++) {
      let f = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        let v = samples[interleaved ? i * ch2 + c : c * n + i];
        f[i] = (v - fromR.min) / fromSpan * 2 - 1;
      }
      planar.push(polyphase(f, { from: from.sampleRate, to: to.sampleRate }));
    }
    let rn = planar[0].length;
    samples = new Float32Array(rn * ch2);
    for (let c = 0; c < ch2; c++) samples.set(planar[c], c * rn);
    if (to.interleaved == null && from.interleaved != null) to.interleaved = from.interleaved;
    from.interleaved = false;
    from.dtype = "float32";
    fromR = { min: -1, max: 1 };
  }
  let len = samples.length;
  let needsMap = fromR.min !== toR.min || fromR.max !== toR.max;
  let reinterleave = from.interleaved != null && to.interleaved != null && from.interleaved !== to.interleaved;
  let ch = from.channels || 1, seg2 = Math.floor(len / ch);
  let Ctor = DTYPE[to.dtype]?.C || Float32Array;
  let out;
  if (!needsMap && !reinterleave) {
    out = to.container === "array" ? Array.from(samples) : new Ctor(samples);
  } else {
    out = to.container === "array" ? new Array(len) : new Ctor(len);
    let fromSpan = span(fromR, toR), toSpan = span(toR, fromR);
    let roundInt = fromR.min === -1 && fromR.max === 1 && toR.max > 1;
    if (!reinterleave) {
      for (let i = 0; i < len; i++) {
        let v = (samples[i] - fromR.min) / fromSpan * toSpan + toR.min;
        if (roundInt) v = Math.round(v);
        out[i] = v < toR.min ? toR.min : v > toR.max ? toR.max : v;
      }
    } else {
      let deint = from.interleaved;
      for (let i = 0; i < len; i++) {
        let si = deint ? i % seg2 * ch + ~~(i / seg2) : i % ch * seg2 + ~~(i / ch);
        let v = samples[si];
        if (needsMap) {
          v = (v - fromR.min) / fromSpan * toSpan + toR.min;
          if (roundInt) v = Math.round(v);
          if (v < toR.min) v = toR.min;
          else if (v > toR.max) v = toR.max;
        }
        out[i] = v;
      }
    }
  }
  if (dst) {
    if (Array.isArray(dst)) {
      for (let i = 0; i < len; i++) dst[i] = out[i];
      out = dst;
    } else if (dst instanceof ArrayBuffer) {
      let tc = new (DTYPE[to.dtype]?.C || Uint8Array)(dst);
      tc.set(out);
      out = tc;
    } else {
      dst.set(out);
      out = dst;
    }
  }
  let info = DTYPE[to.dtype];
  if (info && info.C.BYTES_PER_ELEMENT > 1 && from.endianness && to.endianness && from.endianness !== to.endianness && out.buffer) {
    let le = to.endianness === "le";
    let view2 = new DataView(out.buffer);
    let step = info.C.BYTES_PER_ELEMENT;
    let fn3 = "set" + to.dtype[0].toUpperCase() + to.dtype.slice(1);
    for (let i = 0; i < len; i++) view2[fn3](i * step, out[i], le);
  }
  if (to.container === "audiobuffer") {
    let ABCtor = typeof AudioBuffer !== "undefined" ? AudioBuffer : _AudioBuffer;
    if (!ABCtor) throw Error(_loading ? "AudioBuffer not loaded yet: `await ready` (import { ready } from 'pcm-convert') before converting to 'audiobuffer'" : "AudioBuffer not available. In Node.js: install audio-buffer package or set globalThis.AudioBuffer");
    let ch2 = to.channels || 1, segLen = Math.floor(out.length / ch2);
    let sr = to.sampleRate || from.sampleRate || 44100;
    let ab = new ABCtor({ length: segLen, numberOfChannels: ch2, sampleRate: sr });
    let interleaved = reinterleave ? to.interleaved : from.interleaved ?? false;
    if (interleaved && ch2 > 1) {
      for (let c = 0; c < ch2; c++) {
        let data = new Float32Array(segLen);
        for (let i = 0; i < segLen; i++) data[i] = out[i * ch2 + c];
        ab.copyToChannel(data, c);
      }
    } else {
      for (let c = 0; c < ch2; c++) ab.copyToChannel(out.subarray(c * segLen, (c + 1) * segLen), c);
    }
    return ab;
  }
  if (to.container === "arraybuffer" || to.container === "buffer") return out.buffer || out;
  return out;
}

// node_modules/parse-duration/locale/en.js
var unit = /* @__PURE__ */ Object.create(null);
var m = 6e4;
var h = m * 60;
var d = h * 24;
var y = d * 365.25;
unit.year = unit.yr = unit.y = y;
unit.month = unit.mo = unit.mth = y / 12;
unit.week = unit.wk = unit.w = d * 7;
unit.day = unit.d = d;
unit.hour = unit.hr = unit.h = h;
unit.minute = unit.min = unit.m = m;
unit.second = unit.sec = unit.s = 1e3;
unit.millisecond = unit.millisec = unit.ms = 1;
unit.microsecond = unit.microsec = unit.us = unit.\u00B5s = 1e-3;
unit.nanosecond = unit.nanosec = unit.ns = 1e-6;
unit.group = ",";
unit.decimal = ".";
unit.placeholder = " _";
var en_default = unit;

// node_modules/parse-duration/index.js
var durationRE = /((?:\d+(?:\.\d+)?|\.\d+)(?:[eE][-+]?\d+)?)\s*([\p{L}]{0,14})/gu;
parse2.unit = en_default;
var groupRE;
var placeholder = null;
var group;
var lookupUnit = (unit2, name) => {
  name = String(name).toLowerCase();
  return unit2[name] ?? (name.endsWith("s") ? unit2[name.slice(0, -1)] : void 0);
};
function parse2(str = "", format = "ms") {
  let result = null, prevUnits, unit2 = parse2.unit;
  if (unit2.placeholder !== placeholder || unit2.group !== group)
    groupRE = new RegExp(`(\\d)[${(placeholder = unit2.placeholder) ?? ""}${(group = unit2.group) ?? ""}](\\d)`, "g");
  str = String(str);
  let s = str.replace(groupRE, "$1$2");
  if (unit2.decimal !== ".") s = s.replaceAll(unit2.decimal, ".");
  durationRE.lastIndex = 0;
  for (let m2; m2 = durationRE.exec(s); ) {
    let units = m2[2];
    if (!units) {
      if (prevUnits) {
        for (const u in unit2) if (unit2[u] < prevUnits) {
          units = u;
          break;
        }
      } else units = format;
    }
    prevUnits = units = lookupUnit(unit2, units);
    if (typeof units == "number") result = (result || 0) + m2[1] * units;
  }
  return result && result / (lookupUnit(unit2, format) || 1) * (str.trimStart()[0] === "-" ? -1 : 1);
}

// batch.js
var LAYOUTS = { mono: 1, stereo: 2, quad: 4, "5.1": 6, "7.1": 8 };
function layoutChannels(tag) {
  if (tag in LAYOUTS) return LAYOUTS[tag];
  let n = /^ambisonic-(\d+)$/.exec(tag)?.[1];
  if (n) return (+n + 1) ** 2;
  throw new Error(`unknown layout "${tag}"`);
}
function sideBuses(decl) {
  let bus = (d2) => typeof d2 === "number" || d2 === "any" ? { count: d2 } : typeof d2 === "string" ? { layouts: [d2] } : d2?.layouts ? { layouts: [].concat(d2.layouts) } : { count: "any" };
  if (decl == null) return [{ count: "any" }];
  if (!Array.isArray(decl)) return [bus(decl)];
  if (decl.length && decl.every((d2) => typeof d2 === "string")) return [{ layouts: decl }];
  return decl.map(bus);
}
function resolveBuses(channels2 = "any", widths = [], chosen = {}) {
  let decl = typeof channels2 === "object" && !Array.isArray(channels2) ? channels2 : { inputs: channels2, outputs: channels2 };
  let named2 = false;
  let pick = (bus, b, side, want, prefer) => {
    if (!bus.layouts) return { layout: void 0, channels: bus.count === "any" ? widths[0] ?? 1 : bus.count };
    named2 = true;
    let tag = chosen?.[side]?.[b];
    if (tag != null && !bus.layouts.includes(tag)) throw new Error(`${side} bus ${b}: layout "${tag}" is not declared (${bus.layouts.join(", ")})`);
    tag ??= want != null ? bus.layouts.find((t) => layoutChannels(t) === want) : bus.layouts.includes(prefer) ? prefer : bus.layouts[0];
    if (tag == null) throw new Error(`${side} bus ${b}: ${want} channels fit none of its layouts (${bus.layouts.join(", ")})`);
    if (want != null && layoutChannels(tag) !== want) throw new Error(`${side} bus ${b}: layout "${tag}" has ${layoutChannels(tag)} channels, the input ${want}`);
    return { layout: tag, channels: layoutChannels(tag) };
  };
  let inputs = sideBuses(decl.inputs).map((bus, b) => pick(bus, b, "inputs", widths[b]));
  let outputs = sideBuses(decl.outputs).map((bus, b) => pick(bus, b, "outputs", void 0, inputs[b]?.layout));
  return { inputs, outputs, layouts: named2 ? { inputs: inputs.map((b) => b.layout), outputs: outputs.map((b) => b.layout) } : void 0 };
}

// core.js
audio.version = "2.9.0";
function named(o) {
  if (o == null || typeof o !== "object" || o.d === void 0 && o.xfade === void 0) return o;
  let { d: d2, xfade, ...rest } = o;
  if (d2 !== void 0) rest.duration ??= d2;
  if (xfade !== void 0) rest.crossfade ??= xfade;
  return rest;
}
function parseTime(v) {
  if (v == null) return v;
  if (typeof v === "number") {
    if (!Number.isFinite(v)) throw new Error(`Invalid time: ${v}`);
    return v;
  }
  let tc = v.match(/^(\d+):(\d{1,2})(?::(\d{1,2}))?(?:\.(\d+))?$/);
  if (tc) {
    let [, a, b, c, frac] = tc;
    let s2 = c != null ? +a * 3600 + +b * 60 + +c : +a * 60 + +b;
    if (frac) s2 += +("0." + frac);
    return s2;
  }
  let s = parse2(v, "s");
  if (s != null && isFinite(s)) return s;
  throw new Error(`Invalid time: ${v}`);
}
function audio(source, opts = {}) {
  if (opts.worker) {
    let aw = globalThis[/* @__PURE__ */ Symbol.for("audio.worker")];
    if (!aw) throw new Error('audio: { worker } requires `import "audio/worker"` first \u2014 the worker facade stays out of the main bundle');
    return aw(source, opts);
  }
  if (source == null) {
    let sr = opts.sampleRate || 44100, ch = opts.channels || 1;
    let waiters2 = [];
    let notify2 = () => {
      for (let w of waiters2.splice(0)) w();
      scheduleEvict(a2);
    };
    let a2 = create([], sr, ch, 0, opts, null);
    a2.decoded = false;
    a2.recording = false;
    a2._.push = true;
    a2._.acc = pageAccumulator({ pages: a2.pages, notify: notify2, ondata: (...args) => emit(a2, "data", ...args) });
    a2._.waiters = waiters2;
    return a2;
  }
  if (source && typeof source === "object" && !Array.isArray(source) && source.edits) {
    if (!source.source) throw new TypeError("audio: cannot restore document without source reference");
    let a2 = audio(source.source, opts);
    if (a2.run) for (let e of source.edits) a2.run(e);
    return a2;
  }
  if (Array.isArray(source) && source.length && !(source[0] instanceof Float32Array)) {
    let instances = source.map((s) => s?.pages ? s : audio(s, opts));
    let first = instances[0].clip ? instances[0].clip() : audio.from(instances[0]);
    if (!first.insert) throw new Error('audio([...]): concat requires insert plugin \u2014 import "audio" instead of "audio/core.js"');
    let xf = opts?.crossfade;
    for (let i = 1; i < instances.length; i++) {
      let d2 = Array.isArray(xf) ? xf[i - 1] : xf;
      if (d2 && first.crossfade) first.crossfade(instances[i], d2, opts?.curve);
      else first.insert(instances[i]);
    }
    let loading = instances.filter((s) => !s.decoded);
    if (loading.length) {
      first.ready = Promise.all(loading.map((s) => s.ready)).then(() => {
        delete first.then;
        delete first.catch;
        return true;
      });
      first.ready.catch((e) => emit(first, "error", e));
      makeThenable(first);
    }
    return first;
  }
  if (source?.getChannelData && source?.numberOfChannels) return audio.from(source, opts);
  if (Array.isArray(source) && source[0] instanceof Float32Array || typeof source === "number") {
    let a2 = audio.from(source, opts);
    if (audio.evict && a2.cache && a2.budget !== Infinity) {
      a2.ready = audio.evict(a2).then(() => {
        delete a2.then;
        delete a2.catch;
        return true;
      });
      a2.ready.catch((e) => emit(a2, "error", e));
      makeThenable(a2);
    }
    return a2;
  }
  let ref = typeof source === "string" ? source : source instanceof URL ? source.href : null;
  let pages = [], waiters = [];
  let notify = () => {
    for (let w of waiters.splice(0)) w();
    scheduleEvict(a);
  };
  let dataQueue = [], metaEmitted = false;
  let emitData = (...args) => metaEmitted ? emit(a, "data", ...args) : dataQueue.push(args);
  let a = create(pages, 0, 0, 0, { ...opts, source: ref }, null);
  a._.waiters = waiters;
  a.decoded = false;
  const abort = a._.abort = new AbortController();
  let readyResolve, readyReject;
  a._.ready = new Promise((r, j) => {
    readyResolve = r;
    readyReject = j;
  });
  a._.readyResolve = readyResolve;
  a._.ready.catch(() => {
  });
  a.ready = (async () => {
    try {
      if (opts.storage === "persistent") {
        if (!audio.opfsCache) throw new Error('Persistent storage requires cache module (import "./cache.js")');
        try {
          opts = { ...opts, cache: await audio.opfsCache(), budget: opts.budget ?? await audio.detectBudget?.() ?? audio.DEFAULT_BUDGET ?? Infinity };
        } catch {
          throw new Error('OPFS not available (required by storage: "persistent")');
        }
        if (a._.disposed) return true;
        a.cache = opts.cache;
        a.budget = opts.budget;
      }
      let result = await decodeSource(source, { pages, notify, ondata: emitData, disposed: () => a._.disposed, signal: abort.signal });
      if (a._.disposed) return true;
      a.sampleRate = result.sampleRate;
      a._.ch = result.channels;
      a._.fmtV = -1;
      if (result.acc) a._.acc = result.acc;
      if (result.estDuration) a._.estDur = result.estDuration;
      if (result.header) {
        a._.header = result.header;
        a._.format = result.format;
        a._.bits = headerBits(result.format, result.header);
      }
      emit(a, "metadata", { sampleRate: result.sampleRate, channels: result.channels, estDuration: result.estDuration });
      metaEmitted = true;
      for (let args of dataQueue.splice(0)) emit(a, "data", ...args);
      readyResolve();
      a._.readyResolve = null;
      let final = await result.decoding;
      if (a._.disposed) return true;
      a._.len = final.length;
      a._.lenV = -1;
      a.stats = final.stats;
      if (final.header) {
        a._.header = final.header;
        a._.metaDone = false;
      }
      a.decoded = true;
      notify();
      audio.evict?.(a);
      delete a.then;
      delete a.catch;
      return true;
    } catch (e) {
      if (a._.disposed) return true;
      readyReject(e);
      a._.readyResolve = null;
      emit(a, "error", e);
      throw e;
    } finally {
      if (a._.abort === abort) a._.abort = null;
    }
  })();
  a.ready.catch(() => {
  });
  makeThenable(a);
  return a;
}
function makeThenable(a) {
  a.then = function(resolve, reject) {
    return a.ready.then(() => {
      delete a.then;
      delete a.catch;
      return a;
    }).then(resolve, reject);
  };
  a.catch = function(reject) {
    return a.then(null, reject);
  };
}
function follow(b, a, keep) {
  b.pages = a.pages;
  let own = false;
  for (let k of ["len", "acc", "waiters", "ready", "estDur", "header", "format", "bits", ...keep.sr ? ["sr"] : [], ...keep.ch ? ["ch"] : []])
    Object.defineProperty(b._, k, { get: () => a._[k], set() {
    }, enumerable: true, configurable: true });
  Object.defineProperty(b._, "disposed", { get: () => own || a._.disposed, set(v) {
    own = v;
  }, enumerable: true, configurable: true });
  for (let k of ["decoded", "stats"])
    Object.defineProperty(b, k, { get: () => a[k], set() {
    }, enumerable: true, configurable: true });
  if (!a._.sr) {
    let meta = () => {
      a.off("metadata", meta);
      b._.fmtV = b._.lenV = -1;
    };
    a.on("metadata", meta);
  }
  b.ready = a.ready.then(() => true);
  b.ready.catch(() => {
  });
  makeThenable(b);
}
audio.from = function(source, opts = {}) {
  if (Array.isArray(source) && source[0] instanceof Float32Array) return fromChannels(source, opts);
  if (typeof source === "number") return fromSilence(source, opts);
  if (typeof source === "function") return fromFunction(source, opts);
  if (source?.pages) {
    let b = create(
      [...source.pages],
      opts.sampleRate ?? source.sampleRate,
      opts.channels ?? source._.ch,
      source._.len,
      { source: source.source, storage: source.storage, cache: source.cache, budget: opts.budget ?? source.budget, bitDepth: opts.bitDepth ?? source._.bits },
      source.stats
    );
    if (source._.waiters && !source.decoded) follow(b, source, { sr: !opts.sampleRate || opts.sampleRate === source._.sr, ch: !opts.channels || opts.channels === source._.ch });
    return b;
  }
  if (source?.getChannelData) {
    let chs = Array.from({ length: source.numberOfChannels }, (_, i) => new Float32Array(source.getChannelData(i)));
    return fromChannels(chs, { sampleRate: source.sampleRate, ...opts });
  }
  if (ArrayBuffer.isView(source) && opts.format) {
    let fmt3 = parse(opts.format);
    let ch = fmt3.channels || opts.channels || 1;
    let sr = fmt3.sampleRate || opts.sampleRate || 44100;
    let src = { ...fmt3, channels: ch };
    if (ch > 1 && src.interleaved == null) src.interleaved = true;
    let pcm = convert(source, src, { dtype: "float32", interleaved: false, channels: ch });
    let perCh = pcm.length / ch;
    let chs = Array.from({ length: ch }, (_, c) => pcm.subarray(c * perCh, (c + 1) * perCh));
    return fromChannels(chs, { sampleRate: sr });
  }
  throw new TypeError("audio.from: expected Float32Array[], AudioBuffer, audio instance, function, or number");
};
function headerBits(format, h2) {
  if (!h2?.length) return null;
  let dv = new DataView(h2.buffer, h2.byteOffset, h2.byteLength), id = (o) => String.fromCharCode(h2[o], h2[o + 1], h2[o + 2], h2[o + 3]);
  try {
    if (format === "flac") return id(0) === "fLaC" ? ((h2[20] & 1) << 4 | h2[21] >> 4) + 1 : null;
    let le = format === "wav", want = le ? "fmt " : format === "aiff" ? "COMM" : null;
    if (!want) return null;
    for (let o = 12; o + 8 <= h2.length; ) {
      let size = dv.getUint32(o + 4, le);
      if (id(o) === want) {
        if (le) return dv.getUint16(o + 22, true);
        let fl = size >= 22 ? id(o + 26).toLowerCase() : "";
        return fl === "fl32" ? 32 : fl === "fl64" ? 64 : dv.getUint16(o + 14);
      }
      o += 8 + size + (size & 1);
    }
  } catch {
  }
  return null;
}
var fn = {};
audio.fn = fn;
audio.BLOCK_SIZE = 1024;
audio.PAGE_SIZE = 1024 * audio.BLOCK_SIZE;
var FULL = 32767 / 32768;
var LOAD = /* @__PURE__ */ Symbol("load");
var READ = /* @__PURE__ */ Symbol("read");
var yieldTask = typeof setImmediate === "function" ? () => new Promise((r) => setImmediate(r)) : globalThis.scheduler?.yield ? () => globalThis.scheduler.yield() : typeof MessageChannel === "function" ? () => new Promise((r) => {
  let mc = new MessageChannel();
  mc.port1.onmessage = () => {
    mc.port1.close();
    r();
  };
  mc.port2.postMessage(0);
}) : () => new Promise((r) => setTimeout(r, 0));
function resolveChannels(channel2, total) {
  let perCh = Array.isArray(channel2);
  let chs = channel2 != null ? perCh ? channel2 : [channel2] : Array.from({ length: total }, (_, i) => i);
  for (let c of chs) if (!Number.isInteger(c) || c < 0 || c >= total) throw new RangeError(`channel ${c}: the audio has ${total} channel${total === 1 ? "" : "s"}`);
  return { chs, perCh };
}
function emit(a, event, ...args) {
  let arr = a._.ev[event];
  if (arr) for (let cb of arr.slice()) cb(...args);
}
fn.on = function(event, cb) {
  (this._.ev[event] ??= []).push(cb);
  return this;
};
fn.off = function(event, cb) {
  if (!event) {
    this._.ev = {};
    return this;
  }
  if (!cb) {
    delete this._.ev[event];
    return this;
  }
  let arr = this._.ev[event];
  if (arr) {
    let i = arr.indexOf(cb);
    if (i >= 0) arr.splice(i, 1);
  }
  return this;
};
fn.dispose = function() {
  this._.disposed = true;
  this.stop();
  this._.abort?.abort();
  this._.abort = null;
  this._.readyResolve?.();
  this._.readyResolve = null;
  for (const url of this._.urls || []) URL.revokeObjectURL(url);
  this._.urls = null;
  this._.ev = {};
  this._.meters = null;
  this._.pcm = null;
  this._.plan = null;
  this._.wrc = null;
  this._.rsc = null;
  this._.srcStats = null;
  this._.header = null;
  this._.meta = null;
  this._.markers = null;
  this._.regions = null;
  this._.lru.clear();
  this.edits.length = 0;
  this.block = null;
  this.pages = [];
  this.stats = null;
  if (this._.waiters) for (let w of this._.waiters.splice(0)) w();
  this._.waiters = null;
  this._.acc = null;
  this.cache = null;
};
if (Symbol.dispose) fn[Symbol.dispose] = fn.dispose;
var isOp = (p) => typeof p === "function" && Object.hasOwn(p, "params") && typeof p.params === "object";
var isStat = (p) => p != null && typeof p === "object" && typeof p.stat === "string" && typeof p.compute === "function";
var isCodec = (p) => p != null && typeof p === "object" && typeof p.codec === "string" && (typeof p.decode === "function" || typeof p.encode === "function");
audio.use = function(...plugins) {
  let loads = null;
  for (let p of plugins) {
    if (typeof p === "string") {
      let spec = audio.plugins?.[p] ?? audio.atoms?.[p];
      if (!spec) throw new Error(`audio.use: unknown plugin '${p}' \u2014 not in audio.plugins registry`);
      (loads ??= []).push(audio.import(spec).then((ns) => {
        for (let k of Object.keys(ns)) {
          if (isOp(ns[k])) useOp(ns[k]);
          else if (isStat(ns[k])) useStat(ns[k]);
          else if (isCodec(ns[k])) useCodec(ns[k]);
        }
      }, (e) => {
        throw new Error(`audio.use('${p}'): install ${spec.split("/").slice(0, 2).join("/")} \u2014 ${e.message}`);
      }));
    } else if (isOp(p)) useOp(p);
    else if (isStat(p)) useStat(p);
    else if (isCodec(p)) useCodec(p);
    else p(audio);
  }
  return loads ? Promise.all(loads).then(() => audio) : audio;
};
audio.import = (spec) => import(spec);
function useCodec(m2) {
  let reg3 = audio.codecs ??= {};
  reg3[m2.codec] = { ...reg3[m2.codec], ...m2 };
}
function useStat(m2) {
  if (!audio.stat) throw new Error('audio.use(stat): stat registry required \u2014 import "audio", not "audio/core.js"');
  let name = m2.stat;
  audio.stat(name, {});
  audio.fn[name] = async function(opts) {
    let { at, duration, ...rest } = opts || {};
    for (let k in rest) if (rest[k]?.pages && rest[k].read) rest[k] = await rest[k].read();
    let pcm = await this.read(at != null || duration != null ? { at, duration } : void 0);
    return m2.compute(pcm, { sampleRate: this.sampleRate, ...rest });
  };
}
function useOp(m2) {
  if (!audio.op) throw new Error('audio.use(module): op registry required \u2014 import "audio", not "audio/core.js"');
  let specs = m2.params || {};
  let names = Object.keys(specs);
  let id = m2.id || (m2.name || "module").replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
  let tail = m2.tail || 0;
  let given = (get, name) => get(name) ?? (specs[name].alias != null ? get(specs[name].alias) : void 0);
  let snapParams = (get) => {
    let s = {};
    for (let name of names) {
      let sp = specs[name], v = given(get, name) ?? sp.default;
      s[name] = sp.type === "number" ? new Float32Array([v]) : v;
    }
    return s;
  };
  let latency = typeof m2.latency === "function" ? (o, sr) => m2.latency({ sampleRate: sr, params: snapParams((n) => o?.[n]) }) | 0 : m2.latency | 0;
  let init = (ctx, maxBlock = audio.BLOCK_SIZE, width) => {
    let snapshot = snapParams((name) => ctx[name]);
    let mctx = {
      sampleRate: ctx.sampleRate,
      maxBlockSize: maxBlock,
      maxChannels: 32,
      render: "offline",
      duration: ctx.totalDuration,
      currentTime: 0,
      // declared layouts (contract §Buses) resolve against the input width; `layouts` option picks
      params: snapshot,
      layouts: resolveBuses(m2.channels, width == null ? [] : [width], ctx.layouts).layouts,
      events: void 0,
      // events.out declaration validated; host routing of emissions is future work
      emit(name) {
        if (!(name in (m2.events?.out || {}))) throw new Error(`emit: "${name}" not declared in events.out`);
      }
    };
    let st = { mctx, live: {}, bufs: {} };
    for (let name of names) if (specs[name].type === "number") st.bufs[name] = new Float32Array(1);
    st.process = m2(mctx);
    return st;
  };
  let fill = (st, ctx) => {
    for (let name of names) {
      let sp = specs[name];
      let v = given((n) => ctx[n], name) ?? sp.default;
      if (sp.type === "number") {
        if (v < sp.min) v = sp.min;
        else if (v > sp.max) v = sp.max;
        st.bufs[name][0] = v;
        st.live[name] = st.bufs[name];
      } else st.live[name] = sp.type === "enum" && !sp.values.includes(v) ? sp.default : v;
    }
  };
  let keyed = Array.isArray(m2.channels?.inputs) && m2.channels.inputs.length > 1;
  let busN = (side) => typeof side === "number" ? side : Array.isArray(side) && typeof side[0] === "number" ? side[0] : null;
  let outN = busN(m2.channels?.outputs);
  let ch = outN != null && outN !== busN(m2.channels?.inputs) ? () => outN : void 0;
  let { inputs: li, outputs: lo } = m2.channels ?? {};
  if (resolveBuses(m2.channels).layouts && JSON.stringify(li) !== JSON.stringify(lo))
    ch = (n, o) => resolveBuses(m2.channels, [n], o?.layouts).outputs[0]?.channels;
  let process = (input, output, ctx) => {
    let st = ctx._am ??= init(ctx, void 0, input.length);
    st.mctx.currentTime = ctx.blockOffset || 0;
    if (noteIn) feedEvents(st, ctx, input[0].length);
    fill(st, ctx);
    if (keyed && ctx.key != null && audio.renderAt) {
      let n = input[0].length;
      let off = Math.round((ctx.blockOffset || 0) * ctx.sampleRate);
      st.process([input, audio.renderAt(ctx.render, ctx.key, off, n, ctx.sampleRate)], [output], st.live);
    } else st.process(keyed ? [input, void 0] : [input], [output], st.live);
  };
  let feedEvents = (st, ctx, frames) => {
    if (ctx.notes && st.slots?.src !== ctx.notes)
      st.slots = { src: ctx.notes, evs: noteSlots(ctx.notes, ctx.sampleRate), pool: [], view: [] };
    if (!st.slots) {
      st.mctx.events = ctx.notes === void 0 ? st.mctx.events : void 0;
      return;
    }
    let { evs, pool, view: view2 } = st.slots;
    let b0 = Math.round((ctx.blockOffset || 0) * ctx.sampleRate), b1 = b0 + frames;
    let lo2 = 0, hi = evs.length;
    while (lo2 < hi) {
      let mid = lo2 + hi >> 1;
      if (evs[mid].time < b0) lo2 = mid + 1;
      else hi = mid;
    }
    let n = 0;
    for (let i = lo2; i < evs.length && evs[i].time < b1; i++, n++) {
      let s = pool[n] ??= {};
      let e = evs[i];
      s.time = e.time - b0;
      s.type = e.type;
      s.kind = e.kind;
      s.pitch = e.pitch;
      s.velocity = e.velocity;
      s.channel = e.channel;
      s.id = e.id;
      view2[n] = s;
    }
    view2.length = n;
    st.mctx.events = view2;
  };
  let noteIn = m2.events?.in?.includes("note");
  let noteSlots = (notes, sr) => {
    let evs = [];
    for (let i = 0; i < notes.length; i++) {
      let n = notes[i];
      let pitch = n.midi ?? (n.freq != null ? 69 + 12 * Math.log2(n.freq / 440) : 69);
      let on = Math.round((n.time ?? 0) * sr);
      let velocity = n.velocity ?? 1;
      evs.push({ time: on, type: "note", kind: "on", pitch, velocity, channel: 0, id: i });
      if (n.duration != null) evs.push({ time: on + Math.round(n.duration * sr), type: "note", kind: "off", pitch, velocity: 0, channel: 0, id: i });
    }
    return evs.sort((a, b) => a.time - b.time);
  };
  if (m2.streaming === false) {
    let wholeTail = typeof m2.tail === "function" ? (o, sr) => m2.tail({ sampleRate: sr, params: snapParams((n) => o?.[n]) }) : m2.tail || 0;
    let frames = m2.frames ? (n, o, sr) => m2.frames(n, { sampleRate: sr, params: snapParams((k) => o?.[k]) }) : void 0;
    return audio.op(id, {
      params: names,
      plugin: m2,
      atom: m2,
      ch,
      tail: wholeTail,
      frames,
      whole(input, output, ctx) {
        let st = init(ctx, input[0].length, input.length);
        if (noteIn && ctx.notes) st.mctx.events = noteSlots(ctx.notes, ctx.sampleRate);
        fill(st, ctx);
        st.process([input], [output], st.live);
      }
    });
  }
  if (!tail) return audio.op(id, { params: names, plugin: m2, atom: m2, latency, process, ch });
  audio.op("_" + id, { params: names, hidden: true, plugin: m2, atom: m2, latency, process, ch });
  audio.op(id, {
    params: names,
    tail,
    plugin: m2,
    atom: m2,
    ch,
    expand: (ctx) => {
      let o = {};
      for (let k of names) if (ctx[k] !== void 0) o[k] = ctx[k];
      let t = typeof tail === "function" ? tail({ sampleRate: ctx.sampleRate, params: snapParams((n) => o[n]) }) : tail;
      return [["pad", { before: 0, after: t }], ["_" + id, o]];
    }
  });
}
function create(pages, sampleRate2, ch, length, opts = {}, stats) {
  let a = Object.create(fn);
  a.pages = pages;
  a.source = opts.source ?? null;
  a.storage = opts.storage || "memory";
  a.cache = opts.cache || null;
  a.budget = opts.budget ?? Infinity;
  a.stats = stats;
  a.decoded = true;
  a.ready = Promise.resolve(true);
  Object.defineProperty(a, "_", {
    value: {
      sr: sampleRate2,
      // source sample rate
      ch,
      // source channel count
      len: length,
      // source sample length
      waiters: null,
      // decode notify queue (null when not streaming)
      ev: {},
      // instance event listeners
      ct: 0,
      ctStamp: 0,
      // currentTime wall-clock interpolation
      vol: 1,
      muted: false,
      // volume 0..1 linear with change events
      rate: 1,
      // playbackRate
      keep: true,
      // preservesPitch
      loop: false,
      push: false,
      // true only for pushable (audio(null)) instances — gates fn.stop()'s finalize branch
      disposed: false,
      // set by fn.dispose() — in-flight async continuations check this to abort
      evicting: false,
      // non-reentrant guard for scheduleEvict
      bits: opts.bitDepth ?? null
      // stored sample depth of a PCM source (header), null when lossy/unknown
    },
    writable: false,
    enumerable: false,
    configurable: false
  });
  a.edits = [];
  a.version = 0;
  a._.pcm = null;
  a._.pcmV = -1;
  a._.plan = null;
  a._.planV = -1;
  a._.statsV = -1;
  a._.lenC = a._.len;
  a._.lenV = 0;
  a._.fmt = null;
  a._.fmtV = -1;
  Object.defineProperties(a, {
    currentTime: {
      get() {
        let heard = this._.clock?.();
        if (heard != null) return heard;
        if (this.playing && !this.paused) {
          let t = this._.ct + (performance.now() - this._.ctStamp) / 1e3 * (this._.rate || 1);
          let d2 = this.duration;
          return d2 > 0 ? Math.min(t, d2) : t;
        }
        return this._.ct;
      },
      set(v) {
        this._.ct = v;
        this._.ctStamp = performance.now();
      },
      enumerable: true,
      configurable: true
    },
    volume: {
      get() {
        return this._.vol;
      },
      set(v) {
        v = Math.max(0, Math.min(1, +v || 0));
        if (this._.vol !== v) {
          this._.vol = v;
          emit(this, "volumechange");
        }
      },
      enumerable: true,
      configurable: true
    },
    muted: {
      get() {
        return this._.muted;
      },
      set(v) {
        v = !!v;
        if (this._.muted !== v) {
          this._.muted = v;
          emit(this, "volumechange");
        }
      },
      enumerable: true,
      configurable: true
    },
    playbackRate: {
      get() {
        return this._.rate;
      },
      set(v) {
        v = Math.max(0.0625, Math.min(16, +v || 1));
        if (this._.rate !== v) {
          this._.rate = v;
          emit(this, "ratechange");
        }
      },
      enumerable: true,
      configurable: true
    },
    // at a rate other than 1, the pitch kept (true, as a media element's) or following the speed, as a tape's
    preservesPitch: {
      get() {
        return this._.keep;
      },
      set(v) {
        v = !!v;
        if (this._.keep !== v) {
          this._.keep = v;
          emit(this, "ratechange");
        }
      },
      enumerable: true,
      configurable: true
    },
    loop: {
      get() {
        return this._.loop;
      },
      set(v) {
        v = !!v;
        if (this._.loop !== v) {
          this._.loop = v;
          this._.onloop?.(v);
        }
      },
      enumerable: true,
      configurable: true
    }
  });
  a.playing = false;
  a.paused = false;
  a.ended = false;
  a.seeking = false;
  a.block = null;
  a._.lru = /* @__PURE__ */ new Set();
  return a;
}
function fromChannels(channelData, opts = {}) {
  let sr = opts.sampleRate || 44100;
  return create(paginate(channelData), sr, channelData.length, channelData[0].length, opts, audio.statSession?.(sr).page(channelData).done());
}
function fromSilence(seconds2, opts = {}) {
  let sr = opts.sampleRate || 44100, ch = opts.channels || 1;
  return fromChannels(Array.from({ length: ch }, () => new Float32Array(Math.round(seconds2 * sr))), { ...opts, sampleRate: sr });
}
function fromFunction(fn3, opts = {}) {
  let sr = opts.sampleRate || 44100, ch = opts.channels || 1;
  let dur = named(opts).duration;
  if (dur == null) throw new TypeError("audio.from(fn): duration required");
  let len = Math.round(dur * sr);
  let chs = Array.from({ length: ch }, () => new Float32Array(len));
  for (let i = 0; i < len; i++) {
    let v = fn3(i / sr, i);
    if (typeof v === "number") for (let c = 0; c < ch; c++) chs[c][i] = v;
    else for (let c = 0; c < ch; c++) chs[c][i] = v[c] ?? 0;
  }
  return fromChannels(chs, { sampleRate: sr });
}
Object.defineProperties(fn, {
  sampleRate: { get() {
    return this._.sr;
  }, set(v) {
    this._.sr = v;
  }, enumerable: true, configurable: true },
  length: { get() {
    return this._.len;
  }, configurable: true },
  duration: { get() {
    return this.length / this.sampleRate;
  }, configurable: true },
  channels: { get() {
    return this._.ch;
  }, configurable: true },
  /** Stored sample depth of the source (16, 24, 32 = float); null for lossy or generated audio. */
  bitDepth: { get() {
    return this._.bits;
  }, configurable: true },
  /** Source stats (pre-edit snapshot) — used by resolve-stage ops like normalize/trim. */
  srcStats: { get() {
    return this._.srcStats || this.stats || this._.acc?.stats;
  }, configurable: true }
});
async function loadOps(a) {
  for (let [type] of a.edits ?? []) {
    let d2 = audio.op?.(type);
    if (d2?.load && !d2.mod) d2.mod = await (d2.loading ??= d2.load());
  }
  for (let i = 0; i < (a.edits?.length ?? 0); i++) await audio.op?.(a.edits[i][0])?.prepare?.(a, i);
}
fn[LOAD] = async function() {
  await loadOps(this);
  if (this._.ready) await this._.ready;
  if (!this.decoded && this.ready && this.edits?.some((e) => audio.op?.(e[0])?.whole)) await this.ready;
  this._.acc?.drain();
};
async function arrived(a) {
  if (a.ready) await a.ready;
  while (!a.decoded && a._.waiters && !a._.disposed) await new Promise((r) => a._.waiters.push(r));
}
async function fromEnd(a, at) {
  if (!(at < 0)) return at;
  await arrived(a);
  return Math.max(0, a.duration + at);
}
async function collect(blocks, nch) {
  let parts = [], n = 0;
  for await (let b of blocks) {
    parts.push(b);
    n += b[0].length;
  }
  let out = Array.from({ length: parts[0]?.length ?? nch }, () => new Float32Array(n));
  for (let i = 0, o = 0; i < parts.length; o += parts[i++][0].length) parts[i].forEach((c, k) => out[k].set(c, o));
  return out;
}
fn[READ] = async function(offset, duration) {
  if (audio.ensurePages) await audio.ensurePages(this, offset, duration);
  return readPages(this, offset, duration);
};
fn.push = function(data, fmt3) {
  let acc = this._.acc;
  if (!acc) throw new Error("push: instance is not pushable \u2014 create with audio()");
  let ch = this._.ch, sr = this.sampleRate;
  let chData;
  if (Array.isArray(data) && data[0] instanceof Float32Array) chData = data;
  else if (data instanceof Float32Array) chData = [data];
  else if (ArrayBuffer.isView(data)) {
    let f = fmt3 || {};
    let srcFmt = typeof f === "string" ? f : f.format || "int16";
    let nch = f.channels || ch;
    let src = { dtype: srcFmt, channels: nch };
    if (nch > 1) src.interleaved = true;
    let pcm = convert(data, src, { dtype: "float32", interleaved: false, channels: nch });
    let perCh = pcm.length / nch;
    chData = Array.from({ length: nch }, (_, c) => pcm.subarray(c * perCh, (c + 1) * perCh));
  } else throw new TypeError("push: expected Float32Array[], Float32Array, or typed array");
  if (!this._.ch) {
    this._.ch = chData.length;
    this._.fmtV = -1;
  } else if (chData.length !== this._.ch) throw new TypeError(`push: expected ${this._.ch} channels, got ${chData.length}`);
  acc.push(chData, fmt3 && fmt3.sampleRate || sr);
  this._.len = acc.length;
  this._.lenV = -1;
  scheduleEvict(this);
  return this;
};
fn.stop = function() {
  this.playing = false;
  this.paused = false;
  this.seeking = false;
  this._.cancelPlay?.();
  if (this.recording) {
    this.recording = false;
    this._.recording = null;
    if (this._._mic) {
      this._._mic(null);
      this._._mic = null;
    }
  }
  if (this._.push && this._.acc && !this.decoded) {
    this._.acc.drain();
    this.decoded = true;
    if (this._.waiters) for (let w of this._.waiters.splice(0)) w();
  }
  return this;
};
fn.record = function(opts = {}) {
  if (this._.disposed) throw new Error("audio: instance disposed");
  if (!this._.acc) throw new Error("record: instance is not pushable \u2014 create with audio()");
  if (this.recording) return this;
  this.recording = true;
  this.decoded = false;
  let self = this, sr = this.sampleRate, ch = this._.ch;
  const request = this._.recording = {};
  let _rec = (async () => {
    let { default: mic2 } = await init_mic().then(() => mic_exports);
    if (self._.recording !== request) return;
    let read = await mic2({ sampleRate: sr, channels: ch, bitDepth: 16, ...opts });
    if (self._.recording !== request) {
      read(null);
      return;
    }
    self._._mic = read;
    const take = (err, buf) => {
      if (self._.recording !== request) return;
      if (err || !buf) return;
      self.push(new Int16Array(buf.buffer, buf.byteOffset, buf.byteLength / 2), "int16");
      read(take);
    };
    read(take);
  })();
  _rec.catch((error) => {
    if (self._.recording !== request) return;
    self.stop();
    emit(self, "error", error);
  });
  return this;
};
fn.seek = function(t) {
  t = Math.max(0, t);
  this.seeking = true;
  this.currentTime = t;
  if (this.cache) {
    let page = Math.floor(t * this.sampleRate / audio.PAGE_SIZE);
    (async () => {
      for (let i = Math.max(0, page - 1); i <= Math.min(page + 2, this.pages.length - 1); i++) {
        if (this._.disposed) return;
        if (this.pages[i] === null && await this.cache.has(i)) {
          if (this._.disposed) return;
          const data = await this.cache.read(i);
          if (this._.disposed) return;
          this.pages[i] = data;
          touchLru(this, i);
        }
      }
    })().catch(() => {
    });
  }
  if (this.playing && this._.seek) this._.seek(t);
  else this.seeking = false;
  return this;
};
fn.read = async function(opts) {
  if (typeof opts !== "object" || opts === null) opts = {};
  opts = named(opts);
  let { at, duration, format, channel: channel2, meta } = opts;
  at = parseTime(at);
  duration = parseTime(duration);
  await this[LOAD]();
  at = await fromEnd(this, at);
  let pcm = !this.decoded && this._.waiters && duration != null ? await collect(this.stream({ at, duration }), this._.ch) : (await arrived(this), await this[READ](at, duration));
  if (channel2 != null) pcm = [pcm[channel2]];
  if (!format) return channel2 != null ? pcm[0] : pcm;
  let converted = audio_encode_default[format] ? await audio_encode_default[format](pcm, { sampleRate: this.sampleRate, ...meta }) : pcm.map((ch) => convert(ch, "float32", format));
  return channel2 != null ? Array.isArray(converted) ? converted[0] : converted : converted;
};
function paginate(channelData) {
  let len = channelData[0].length, pages = [];
  for (let off = 0; off < len; off += audio.PAGE_SIZE)
    pages.push(channelData.map((ch) => ch.subarray(off, Math.min(off + audio.PAGE_SIZE, len))));
  return pages;
}
function touchLru(a, i) {
  let lru = a._.lru;
  if (lru && lru._last !== i) {
    lru.delete(i);
    lru.add(i);
    lru._last = i;
  }
}
function scheduleEvict(a) {
  if (!a.cache || !audio.evict || a._.evicting) return;
  a._.evicting = true;
  audio.evict(a).catch(() => {
  }).then(() => {
    a._.evicting = false;
  });
}
function walkPages(a, c, srcOff, len, visitor) {
  let pages = a.pages, PS = audio.PAGE_SIZE;
  let p0 = Math.floor(srcOff / PS), pos = p0 * PS;
  for (let p = p0; p < pages.length && pos < srcOff + len; p++) {
    let pg = pages[p], pLen = pg ? pg[0].length : PS;
    if (pos + pLen > srcOff && pg) {
      let s = Math.max(srcOff - pos, 0), e = Math.min(srcOff + len - pos, pLen);
      touchLru(a, p);
      visitor(pg, c, s, e, Math.max(pos - srcOff, 0));
    }
    pos += pLen;
  }
  let acc = a._.acc;
  if (acc && pos < srcOff + len) {
    let partial = acc.partial;
    if (partial) {
      let s = Math.max(srcOff - pos, 0), e = Math.min(srcOff + len - pos, partial[0].length);
      if (e > s) visitor(partial, c, s, e, Math.max(pos - srcOff, 0));
    }
  }
}
function copyPages(a, c, srcOff, len, target, tOff) {
  walkPages(a, c, srcOff, len, (pg, ch, s, e, off) => target.set(pg[ch].subarray(s, e), tOff + off));
}
function readPages(a, offset, duration) {
  let sr = a.sampleRate, ch = a._.ch;
  let s = offset != null ? Math.min(Math.max(Math.round(offset * sr), 0), a._.len) : 0;
  let len = duration != null ? Math.round(duration * sr) : a._.len - s;
  len = Math.min(Math.max(len, 0), a._.len - s);
  let out = Array.from({ length: ch }, () => new Float32Array(len));
  for (let c = 0; c < ch; c++) copyPages(a, c, s, len, out[c], 0);
  return out;
}
async function toPath(source) {
  if (!source.startsWith("file:")) return source;
  let { fileURLToPath: fileURLToPath2 } = await import("url");
  return fileURLToPath2(source);
}
async function resolveSource(source, signal) {
  if (source instanceof ArrayBuffer) return source;
  if (source instanceof Uint8Array) return source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
  if (source instanceof URL) return resolveSource(source.href, signal);
  if (typeof Blob !== "undefined" && source instanceof Blob) return source.arrayBuffer();
  if (typeof Response !== "undefined" && source instanceof Response) return source.arrayBuffer();
  if (typeof source === "string") {
    if (/^(https?|data|blob):/.test(source) || typeof window !== "undefined")
      return (await fetch(source, { signal })).arrayBuffer();
    source = await toPath(source);
    let { readFile } = await import("fs/promises");
    let buf = await readFile(source, { signal });
    return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  }
  throw new TypeError("audio: unsupported source type");
}
var SNIFF = 64;
var detectType = (bytes) => audioType(bytes) || sniffCodecLocal(bytes);
var sniffCodecLocal = (bytes) => {
  for (let k in audio.codecs || {}) if (audio.codecs[k].test?.(bytes)) return k;
};
async function detectSource(source, signal) {
  if (source instanceof ArrayBuffer || source instanceof Uint8Array) {
    let bytes2 = source instanceof ArrayBuffer ? new Uint8Array(source) : source.byteOffset || source.byteLength !== source.buffer.byteLength ? new Uint8Array(source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength)) : new Uint8Array(source.buffer);
    return { format: detectType(bytes2), bytes: bytes2 };
  }
  if (typeof source === "string" && !/^(https?|data|blob):/.test(source) && typeof window === "undefined") {
    let path = await toPath(source);
    let { open: open5, stat } = await import("fs/promises");
    let fh = await open5(path, "r");
    let hdr = new Uint8Array(SNIFF);
    let { bytesRead } = await fh.read(hdr, 0, SNIFF, 0);
    await fh.close();
    let format = detectType(hdr.subarray(0, bytesRead));
    let fileSize = (await stat(path)).size;
    let { createReadStream } = await import("fs");
    const reader3 = (async function* () {
      yield* createReadStream(path, { signal, highWaterMark: 1 << 20 });
    })();
    return { format, reader: reader3, fileSize };
  }
  if (typeof Blob !== "undefined" && source instanceof Blob) {
    let hdr = new Uint8Array(await source.slice(0, SNIFF).arrayBuffer());
    return { format: detectType(hdr), reader: iterateStream(source.stream(), signal), fileSize: source.size };
  }
  if (source instanceof URL) source = source.href;
  if (typeof source === "string" && /^https?:/.test(source)) {
    let res = await fetch(source, { signal });
    if (!res.ok) throw new Error(`audio: ${source}: HTTP ${res.status}`);
    source = res;
  }
  if (typeof Response !== "undefined" && source instanceof Response && source.body)
    return { ...await streamed(iterateStream(source.body, signal)), fileSize: +source.headers.get("content-length") || void 0 };
  if (typeof source?.getReader === "function") return streamed(iterateStream(source, signal));
  if (source?.[Symbol.asyncIterator] && !source.pages) return streamed(source, signal);
  let buf = await resolveSource(source, signal);
  let bytes = new Uint8Array(buf);
  return { format: detectType(bytes), bytes };
}
async function streamed(chunks, signal) {
  let it = chunks[Symbol.asyncIterator](), head = [], n = 0;
  let ended = new Promise((r) => signal?.aborted ? r() : signal?.addEventListener("abort", r, { once: true }));
  signal?.addEventListener("abort", () => {
    chunks.destroy?.();
    it.return?.()?.catch?.(() => {
    });
  }, { once: true });
  const next = () => signal ? Promise.race([it.next(), ended.then(() => ({ done: true }))]) : it.next();
  const bytes = (v) => v instanceof Uint8Array ? v : new Uint8Array(v.buffer ?? v, v.byteOffset ?? 0, v.byteLength);
  while (n < SNIFF) {
    let { done, value } = await next();
    if (done) break;
    value = bytes(value);
    head.push(value);
    n += value.length;
  }
  let hdr = new Uint8Array(Math.min(n, SNIFF)), o = 0;
  for (let h2 of head) {
    if (o >= hdr.length) break;
    let k = Math.min(h2.length, hdr.length - o);
    hdr.set(h2.subarray(0, k), o);
    o += k;
  }
  const reader3 = (async function* () {
    yield* head;
    for (let r; !(r = await next()).done; ) yield bytes(r.value);
  })();
  return { format: detectType(hdr), reader: reader3 };
}
async function* iterateStream(stream2, signal) {
  let reader3 = stream2.getReader();
  const cancel = () => reader3.cancel().catch(() => {
  });
  signal?.addEventListener("abort", cancel, { once: true });
  try {
    if (signal?.aborted) return;
    while (true) {
      let { done, value } = await reader3.read();
      if (done) return;
      yield value;
    }
  } finally {
    signal?.removeEventListener("abort", cancel);
    await cancel();
    reader3.releaseLock();
  }
}
function pageAccumulator(opts = {}) {
  let { pages = [], notify, ondata } = opts;
  let sr = 0, ch = 0, totalLen = 0, pagePos = 0;
  let pageBuf = null, session;
  function emit2(page) {
    pages.push(page);
    totalLen += page[0].length;
    notify?.();
  }
  return {
    pages,
    get sampleRate() {
      return sr;
    },
    get channels() {
      return ch;
    },
    get length() {
      return totalLen + pagePos;
    },
    get partial() {
      return pagePos > 0 ? pageBuf.map((c) => c.subarray(0, pagePos)) : null;
    },
    get partialLen() {
      return pagePos;
    },
    get stats() {
      return session?.snapshot?.() ?? null;
    },
    push(chData, sampleRate2) {
      if (!pageBuf) {
        sr = sampleRate2;
        ch = chData.length;
        pageBuf = Array.from({ length: ch }, () => new Float32Array(audio.PAGE_SIZE));
        session = audio.statSession?.(sr);
      }
      session?.page(chData);
      let srcPos = 0, chunkLen = chData[0].length;
      while (srcPos < chunkLen) {
        let n = Math.min(chunkLen - srcPos, audio.PAGE_SIZE - pagePos);
        for (let c = 0; c < ch; c++) pageBuf[c].set(chData[c].subarray(srcPos, srcPos + n), pagePos);
        srcPos += n;
        pagePos += n;
        if (pagePos === audio.PAGE_SIZE) {
          emit2(pageBuf);
          pageBuf = Array.from({ length: ch }, () => new Float32Array(audio.PAGE_SIZE));
          pagePos = 0;
        }
      }
      if (ondata) {
        let delta = session?.delta();
        if (delta) ondata({ delta, offset: (totalLen + pagePos) / sr, sampleRate: sr, channels: ch });
      }
      notify?.();
    },
    /** Flush partial page into pages array. Non-destructive — accumulator stays open. */
    drain() {
      if (pagePos > 0) {
        emit2(pageBuf.map((c) => c.slice(0, pagePos)));
        pageBuf = Array.from({ length: ch }, () => new Float32Array(audio.PAGE_SIZE));
        pagePos = 0;
      }
    },
    done() {
      if (pagePos > 0) {
        emit2(pageBuf.map((c) => c.slice(0, pagePos)));
        pagePos = 0;
      }
      session?.flush();
      if (ondata && session) {
        let delta = session.delta();
        if (delta) ondata({ delta, offset: totalLen / sr, sampleRate: sr, channels: ch });
      }
      return { stats: session?.done(), length: totalLen };
    }
  };
}
function estimateDuration(fileSize, format, sampleRate2, channels2, header) {
  let known = header?.length ? headerDuration(format, header, fileSize) : null;
  if (known > 0) return known;
  if (!fileSize || !sampleRate2 || !channels2) return null;
  if (format === "wav") return Math.max(0, (fileSize - 44) / (sampleRate2 * channels2 * 2));
  if (format === "flac") return fileSize / (sampleRate2 * channels2 * 0.7);
  if (format === "mp3") return fileSize / (128e3 / 8);
  if (format === "ogg" || format === "opus") return fileSize / (96e3 / 8);
  return null;
}
var MPEG_KBPS = [
  [[0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256], [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160]],
  [[0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448], [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384], [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320]]
];
var MPEG_HZ = { 3: [44100, 48e3, 32e3], 2: [22050, 24e3, 16e3], 0: [11025, 12e3, 8e3] };
function headerDuration(format, h2, fileSize) {
  let dv = new DataView(h2.buffer, h2.byteOffset, h2.byteLength), id = (o) => String.fromCharCode(h2[o], h2[o + 1], h2[o + 2], h2[o + 3]);
  try {
    if (format === "wav" || format === "aiff") {
      let le = format === "wav", rate = 0, frames = 0, bytes = 0, data = 0;
      for (let o = 12; o + 8 <= h2.length; ) {
        let size = dv.getUint32(o + 4, le);
        if (le && id(o) === "fmt ") rate = dv.getUint32(o + 16, true);
        if (le && id(o) === "data") {
          data = o + 8;
          bytes = size;
          break;
        }
        if (!le && id(o) === "COMM") {
          frames = dv.getUint32(o + 10);
          let e = dv.getUint16(o + 16) & 32767, m2 = dv.getUint32(o + 18) * 2 ** 32 + dv.getUint32(o + 22);
          return frames / (m2 * 2 ** (e - 16383 - 63));
        }
        o += 8 + size + (size & 1);
      }
      if (bytes === 0 || bytes === 4294967295) bytes = fileSize ? fileSize - data : 0;
      return rate && data ? bytes / rate : null;
    }
    if (format === "flac") {
      if (id(0) !== "fLaC") return null;
      let rate = h2[18] << 12 | h2[19] << 4 | h2[20] >> 4, total = (h2[21] & 15) * 2 ** 32 + dv.getUint32(22);
      return rate && total ? total / rate : null;
    }
    if (format === "mp3") {
      let o = 0;
      if (h2[0] === 73 && h2[1] === 68 && h2[2] === 51) o = 10 + (h2[6] << 21 | h2[7] << 14 | h2[8] << 7 | h2[9]) + (h2[5] & 16 ? 10 : 0);
      for (let end = Math.min(h2.length - 4, o + 65536); o < end; o++) if (h2[o] === 255 && (h2[o + 1] & 224) === 224) {
        let version = h2[o + 1] >> 3 & 3, layer = 4 - (h2[o + 1] >> 1 & 3), kbps = MPEG_KBPS[+(version === 3)][layer - 1]?.[h2[o + 2] >> 4], hz = MPEG_HZ[version]?.[h2[o + 2] >> 2 & 3];
        if (version === 1 || layer > 3 || !kbps || !hz) continue;
        let mono = h2[o + 3] >> 6 === 3, spf = layer === 1 ? 384 : layer === 2 || version === 3 ? 1152 : 576;
        let x = o + 4 + (version === 3 ? mono ? 17 : 32 : mono ? 9 : 17);
        if (x + 12 <= h2.length && (id(x) === "Xing" || id(x) === "Info") && h2[x + 7] & 1) {
          let f = h2[x + 7], l = x + 12 + (f & 2 ? 4 : 0) + (f & 4 ? 100 : 0) + (f & 8 ? 4 : 0);
          let trim = l + 24 <= h2.length && /^(LAME|Lavc|Lavf)$/.test(id(l)) ? (h2[l + 21] << 4 | h2[l + 22] >> 4) + ((h2[l + 22] & 15) << 8 | h2[l + 23]) : 0;
          return (dv.getUint32(x + 8) * spf - trim) / hz;
        }
        if (o + 54 <= h2.length && id(o + 36) === "VBRI") return dv.getUint32(o + 50) * spf / hz;
        return fileSize ? (fileSize - o) * 8 / (kbps * 1e3) : null;
      }
    }
  } catch {
  }
  return null;
}
async function waDecode(bytes) {
  let OAC = globalThis.OfflineAudioContext || globalThis.webkitOfflineAudioContext;
  if (!OAC) return null;
  try {
    let ab = await new OAC(1, 1, 44100).decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
    let channelData = [];
    for (let c = 0; c < ab.numberOfChannels; c++) channelData.push(ab.getChannelData(c));
    return { channelData, sampleRate: ab.sampleRate };
  } catch {
    return null;
  }
}
async function decodeSource(source, opts = {}) {
  let { format, bytes, reader: reader3, fileSize } = await detectSource(source, opts.signal);
  if (!format || !decode[format]) {
    if (!bytes) bytes = new Uint8Array(await resolveSource(source, opts.signal));
    let dec2 = format && audio.codecs?.[format]?.decode;
    let decoded;
    if (dec2) decoded = await dec2(bytes);
    else try {
      decoded = await decode(bytes.buffer || bytes);
    } catch (e) {
      decoded = await waDecode(bytes);
      if (!decoded) throw e;
    }
    let { channelData, sampleRate: sampleRate2 } = decoded;
    let pages = opts.pages || [];
    if (!opts.disposed?.()) for (let p of paginate(channelData)) {
      pages.push(p);
      opts.notify?.();
    }
    let stats = audio.statSession?.(sampleRate2)?.page(channelData)?.done() ?? null;
    let header2 = bytes.slice(0, Math.min(bytes.length, 256 * 1024));
    return { pages, sampleRate: sampleRate2, channels: channelData.length, header: header2, format, decoding: Promise.resolve({ stats, length: channelData[0].length }) };
  }
  let dec = await decode[format]();
  let t = performance.now();
  let yieldLoop = () => {
    let now = performance.now();
    if (now - t > 8) {
      t = now;
      return yieldTask();
    }
  };
  let firstResolve;
  let origNotify = opts.notify;
  let disposed = opts.disposed || (() => false);
  let firstReady = new Promise((r) => {
    firstResolve = r;
  });
  let resolveFirst = () => {
    if (firstResolve) {
      let f = firstResolve;
      firstResolve = null;
      f();
    }
  };
  let acc = pageAccumulator({
    pages: opts.pages,
    ondata: opts.ondata,
    notify: () => {
      origNotify?.();
      resolveFirst();
    }
  });
  let HEADER_CAP = 256 * 1024, headerChunks = [], headerLen = 0, headerDone = false, headerBytes = null;
  let addHeader = (buf) => {
    if (headerDone || !headerChunks) return;
    buf = buf.subarray(0, HEADER_CAP - headerLen);
    headerChunks.push(buf);
    headerLen += buf.length;
    if (headerLen >= HEADER_CAP) headerDone = true;
  };
  let flushHeader = () => {
    if (headerBytes) return headerBytes;
    if (!headerChunks) return new Uint8Array(0);
    headerBytes = new Uint8Array(headerLen);
    let pos = 0;
    for (let c of headerChunks) {
      headerBytes.set(c, pos);
      pos += c.length;
    }
    headerChunks = null;
    return headerBytes;
  };
  const FEED = 64 * 1024;
  let feed = async (buf) => {
    for (let off = 0; off < buf.length; off += FEED) {
      if (disposed()) return false;
      let r = await dec(buf.subarray(off, Math.min(off + FEED, buf.length)));
      if (disposed()) return false;
      if (r.channelData.length) acc.push(r.channelData, r.sampleRate);
      await yieldLoop();
    }
    return true;
  };
  let decoding = (async () => {
    try {
      if (reader3) {
        for await (let chunk of reader3) {
          let buf = chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk);
          addHeader(buf);
          if (!await feed(buf)) return { stats: null, length: acc.length };
        }
      } else {
        addHeader(bytes);
        if (!await feed(bytes)) return { stats: null, length: acc.length };
      }
      if (disposed()) return { stats: null, length: acc.length };
      let flushed = await dec();
      if (disposed()) return { stats: null, length: acc.length };
      if (flushed.channelData.length) acc.push(flushed.channelData, flushed.sampleRate);
      let final = acc.done();
      final.header = flushHeader();
      return final;
    } finally {
      dec.free();
      resolveFirst();
    }
  })();
  decoding.catch(() => {
  });
  await firstReady;
  if (!acc.sampleRate) {
    await decoding;
    throw new Error("audio: decoded no audio data");
  }
  let header = flushHeader(), estDuration = estimateDuration(fileSize || bytes?.length, format, acc.sampleRate, acc.channels, header);
  return { pages: acc.pages, sampleRate: acc.sampleRate, channels: acc.channels, header: flushHeader(), format, decoding, acc, estDuration };
}

// plan.js
var fn2 = audio.fn;
var ops = {};
function seg(from, count, to, rate, ref, interp, env) {
  let s = [from, count, to];
  if (rate != null && rate !== 1) s[3] = rate;
  if (ref !== void 0) s[4] = ref;
  if (interp) s[5] = interp;
  if (env) s[6] = env;
  return s;
}
function subSeg(s, at, n, to, count = n, rate = s[3], flip = false) {
  let e = s[6], env;
  if (e) {
    let u = (at - s[2]) / s[1], v = (at + n - s[2]) / s[1];
    env = [];
    for (let k = 0; k < e.length; k += 2) {
      let a = e[k] + (e[k + 1] - e[k]) * u, b = e[k] + (e[k + 1] - e[k]) * v;
      env.push(flip ? b : a, flip ? a : b);
    }
  }
  return seg(segSrcStart(s, at, n), count, to, flip ? -(rate || 1) : rate, s[4], s[5], env);
}
function segSrcStart(sg, iStart, n) {
  let rate = sg[3] || 1, absR = Math.abs(rate);
  return rate < 0 ? sg[0] + (sg[1] - (iStart - sg[2]) - n) * absR : sg[0] + (iStart - sg[2]) * absR;
}
function sliceSegs(segs, off, len) {
  let r = [], end = off + len;
  for (let s of segs) {
    let a = Math.max(s[2], off), b = Math.min(s[2] + s[1], end);
    if (a < b) r.push(subSeg(s, a, b - a, a - off));
  }
  return r;
}
function planOffset(offset, total, dflt = 0) {
  let s = offset ?? dflt;
  if (s < 0) s = total + s;
  return Math.min(Math.max(0, s), total);
}
function opRange(ctx, len) {
  let sr = ctx.sampleRate;
  let s = ctx.at != null ? Math.round(ctx.at * sr) : -Math.round((ctx.blockOffset || 0) * sr);
  return [s, ctx.duration != null ? s + Math.round(ctx.duration * sr) : len];
}
function isOpts(v) {
  return v != null && typeof v === "object" && !Array.isArray(v) && !ArrayBuffer.isView(v) && !v.pages && !v.getChannelData && !isCurve(v);
}
function mapParams(params, args, ctx) {
  if (params) for (let i = 0; i < params.length && i < args.length; i++) {
    if (params[i].startsWith("...")) {
      ctx[params[i].slice(3)] = args.slice(i);
      break;
    }
    ctx[params[i]] = args[i];
  }
}
function normalizeOpts(opts, sr) {
  let o = isOpts(opts) ? { ...named(opts) } : {};
  if (o.at != null) o.at = parseTime(o.at);
  if (o.duration != null) o.duration = parseTime(o.duration);
  if (o.offset != null) {
    o.at = o.offset / sr;
    delete o.offset;
  }
  if (o.length != null) {
    o.duration = o.length / sr;
    delete o.length;
  }
  return o;
}
function normalizeEdit(edit, sr) {
  if (!Array.isArray(edit) || typeof edit[0] !== "string") throw new TypeError("audio.run: edit must be [type, opts?]");
  let [type, opts] = edit;
  return [type, normalizeOpts(opts || {}, sr)];
}
function hasFunction(v, seen = /* @__PURE__ */ new Set()) {
  if (typeof v === "function") return true;
  if (!v || typeof v !== "object") return false;
  if (v.pages || ArrayBuffer.isView(v)) return false;
  if (seen.has(v)) return false;
  seen.add(v);
  if (Array.isArray(v)) return v.some((x) => hasFunction(x, seen));
  for (let k of Object.keys(v)) if (hasFunction(v[k], seen)) return true;
  return false;
}
audio.op = function(name, arg1, arg2, arg3) {
  if (!arguments.length) return ops;
  if (arguments.length === 1) return ops[name];
  let desc;
  if (typeof arg1 !== "function") {
    desc = arg1;
  } else {
    let plan, opts;
    if (typeof arg2 === "function") {
      plan = arg2;
      opts = arg3;
    } else opts = arg2;
    desc = { process: arg1 };
    if (plan) desc.plan = plan;
    if (opts) Object.assign(desc, opts);
  }
  if (!fn2[name] && !desc.hidden) fn2[name] = opMethod(name);
  ops[name] = desc;
};
function opMethod(name) {
  return function(...a) {
    let hasOpts = a.length && isOpts(a.at(-1));
    let o = hasOpts ? { ...named(a.pop()) } : {};
    let d2 = ops[name];
    if (d2) {
      let p = d2.params || [];
      if (!p.at(-1)?.startsWith("...") && a.length > p.length)
        throw new TypeError(p.length ? `${name}: expected at most ${p.length} argument${p.length === 1 ? "" : "s"} (${p.join(", ")}), got ${a.length}` : `${name}: takes options ({ at, duration, \u2026 }), not positional arguments`);
      mapParams(p, a, o);
    } else if (a.length) o.args = a;
    for (let k in o) if (typeof o[k] === "number" && Number.isNaN(o[k])) throw new RangeError(`${name}: ${k} is NaN`);
    if (d2?.ch && (o.at != null || o.duration != null)) throw new TypeError(`${name}: range options not supported for channel-changing ops`);
    return this.run([name, o]);
  };
}
function pushEdit(a, edit) {
  a.edits.push(edit);
  a.version++;
  emit(a, "change");
}
function popEdit(a) {
  let e = a.edits.pop();
  if (e) {
    a.version++;
    emit(a, "change");
  }
  return e;
}
function deriveFormat(a) {
  if (a._.fmtV === a.version) return a._.fmt;
  let sr = a._.sr, ch = a._.ch;
  for (let [type, o = {}] of a.edits) {
    let desc = ops[type];
    if (!desc) continue;
    if (desc.sr) sr = desc.sr(sr, o) || sr;
    if (desc.ch) {
      let { at, duration, channel: channel2, ...extra } = o;
      ch = desc.ch(ch, extra) || ch;
    }
  }
  a._.fmt = { sr, ch };
  a._.fmtV = a.version;
  return a._.fmt;
}
Object.defineProperties(fn2, {
  sampleRate: {
    get() {
      return this.edits?.length ? deriveFormat(this).sr : this._.sr;
    },
    set(v) {
      this._.sr = v;
      this._.fmtV = -1;
    },
    enumerable: true,
    configurable: true
  },
  length: { get() {
    if (this._.lenV === this.version && this._.lenL === this._.len) return this._.lenC;
    let len = this.edits.length ? buildPlan(this).totalLen : this._.len;
    this._.lenC = len;
    this._.lenV = this.version;
    this._.lenL = this._.len;
    return len;
  }, configurable: true },
  channels: {
    get() {
      return this.edits?.length ? deriveFormat(this).ch : this._.ch;
    },
    configurable: true
  }
});
async function ensurePlan(a, plan, offset, duration, visiting = /* @__PURE__ */ new Set()) {
  if (!audio.ensurePages || duration === 0) return;
  if (visiting.has(a)) throw new Error("audio: circular source reference");
  visiting.add(a);
  const restore = (ref, at, duration2) => ref.edits.length ? ensurePlan(ref, buildPlan(ref), at, duration2, visiting) : audio.ensurePages(ref, at, duration2);
  const prime = async (plan2, offset2, duration2) => {
    let { segs, sr, latency = 0 } = plan2;
    let s = Math.round((offset2 || 0) * sr);
    let e = duration2 != null ? s + Math.round(duration2 * sr) : plan2.totalLen;
    e = Math.min(e + latency, plan2.totalLen);
    if (plan2.pipeline.length) s = warmStart(s, s + latency, plan2.warmup);
    if (plan2.pulls) for (let p of plan2.pulls) {
      let S = s / sr, E = e / sr;
      let o1 = Math.max(S, p.at), o2 = Math.min(E, p.at + p.ref.duration);
      if (o2 > o1) await restore(p.ref, o1 - p.at, o2 - o1);
    }
    for (let sg of segs) {
      let iStart = Math.max(s, sg[2]), iEnd = Math.min(e, sg[2] + sg[1]);
      if (iStart >= iEnd) continue;
      let rate = sg[3] || 1, absR = Math.abs(rate), n = iEnd - iStart;
      let margin = sg[5] && sg[5].margin || 0;
      let srcStart = segSrcStart(sg, iStart, n);
      let srcLen = n * absR + 1 + 2 * margin;
      let target = sg[4] === null ? null : sg[4] || a;
      if (target?.segs) await prime(target, Math.max(0, srcStart - margin) / target.sr, srcLen / target.sr);
      else if (target) {
        let rate2 = target.sampleRate;
        let at = Math.max(0, srcStart - margin) / rate2, duration3 = srcLen / rate2;
        if (target === a) await audio.ensurePages(target, at, duration3);
        else await restore(target, at, duration3);
      }
    }
  };
  try {
    await prime(plan, offset, duration);
  } finally {
    visiting.delete(a);
  }
}
function eachRef(a, cb) {
  for (let edit of a.edits) {
    let o = edit[1];
    if (!o) continue;
    for (let k in o) if (o[k]?.pages) cb(o[k]);
  }
}
async function loadRefs(a) {
  let refs = [];
  eachRef(a, (r) => refs.push(r));
  for (let r of refs) {
    if (r.ready) await r.ready;
    await r[LOAD]();
  }
}
fn2[READ] = async function(offset, duration) {
  if (!this.edits.length) {
    if (audio.ensurePages) await audio.ensurePages(this, offset, duration);
    return readPages(this, offset, duration);
  }
  await this[LOAD]();
  if (!this.decoded && this.edits.some((e2) => e2[0] === "copy" || e2[0] === "cut")) await this.ready;
  await loadRefs(this);
  let plan = buildPlan(this);
  let s = Math.round((offset || 0) * plan.sr);
  let e = duration != null ? s + Math.round(duration * plan.sr) : plan.totalLen;
  if (e - s > MAX_FLAT_SIZE) throw new Error(`Audio too large for flat read (${((e - s) / 1e6).toFixed(0)}M samples). Use streaming.`);
  await ensurePlan(this, plan, offset, duration);
  return readPlan(this, plan, offset, duration);
};
fn2[Symbol.asyncIterator] = fn2.stream = async function* (opts) {
  opts = named(opts);
  let offset = parseTime(opts?.at), duration = parseTime(opts?.duration);
  if (this._.disposed) return;
  if (this._.ready) await this._.ready;
  offset = await fromEnd(this, offset);
  if (this._.disposed) return;
  await loadRefs(this);
  let a = this, sr = a.sampleRate, BS = audio.BLOCK_SIZE;
  let live = !!a._.waiters && !a.decoded;
  if (!live) await a[LOAD]();
  let startSample = offset ? Math.round(offset * sr) : 0;
  let endSample = duration != null ? startSample + Math.round(duration * sr) : Infinity;
  let durExplicit = duration != null;
  let builtLen = 0, plan = null, procs = null, outPos = startSample, ensured = false;
  let lastVer = a.version;
  let T = 0;
  let nch = a._.ch;
  let bufA = Array.from({ length: nch }, () => new Float32Array(BS));
  let xf = null, sigP = "", yielded = false;
  while (!a._.disposed && outPos < endSample + T) {
    let acc = a._.acc;
    let avail = a.decoded ? a._.len : acc ? acc.length : a._.len;
    if (avail > builtLen || a.decoded && !ensured || a.version !== lastVer && !xf) {
      let verChanged = plan != null && a.version !== lastVer, old = plan, warm = null;
      lastVer = a.version;
      builtLen = Math.max(builtLen, avail);
      plan = compilePlan(a, builtLen, a.decoded);
      let sig = pipelineSig(plan.pipeline), width = plan.ch ?? nch;
      const fresh = (t) => {
        nch = width;
        T = plan.latency;
        sigP = sig;
        bufA = Array.from({ length: nch }, () => new Float32Array(BS));
        procs = initProcs(plan.pipeline, plan.totalLen / sr, sr, nch);
        outPos = t + T;
        warm = t;
      };
      if (procs && yielded && verChanged && (plan.latency !== T || width !== nch || sig !== sigP || !sameTimeline(old.segs, plan.segs))) {
        let n = Math.min(2048, Math.round(sr * 0.02));
        xf = { plan: old, procs, pos: outPos, buf: bufA, n, left: n };
        fresh(outPos - T);
      } else if (procs && yielded && (width !== nch || sig !== sigP)) fresh(outPos - T);
      else if (!procs || width !== nch || sig !== sigP) {
        nch = width;
        T = plan.latency;
        sigP = sig;
        bufA = Array.from({ length: nch }, () => new Float32Array(BS));
        procs = initProcs(plan.pipeline, plan.totalLen / sr, sr, nch);
        outPos = (startSample > 0 || T > 0) && procs.length ? warmStart(startSample, startSample + T, plan.warmup) : startSample;
      } else {
        if (plan.latency !== T) {
          outPos += plan.latency - T;
          T = plan.latency;
        }
        if (procs.length) patchProcs(procs, plan.pipeline);
      }
      if (verChanged) await loadRefs(a);
      if (!a.decoded) {
        let td = plan.totalLen / sr;
        for (let p of procs) {
          p.ctx.totalDuration = td;
          if (p.origAt != null && p.origAt < 0) p.at = td + p.origAt;
        }
      }
      if (a.decoded && (!ensured || verChanged)) {
        ensured = true;
        if (endSample === Infinity || verChanged && !durExplicit) endSample = plan.totalLen;
        let td = plan.totalLen / sr;
        for (let p of procs) {
          p.ctx.totalDuration = td;
          if (p.origAt != null && p.origAt < 0) p.at = td + p.origAt;
        }
        await ensurePlan(a, plan, offset, duration);
        let seen = /* @__PURE__ */ new Set();
        for (let s of plan.segs) if (s[4]?.pages && !seen.has(s[4])) {
          seen.add(s[4]);
          await s[4][LOAD]();
        }
      }
      if (warm != null && procs.length) for (let p = warmStart(warm, outPos, plan.warmup); p < outPos; ) {
        let len2 = Math.min(BS, outPos - p);
        for (let b of bufA) b.fill(0, 0, len2);
        renderBlock(a, plan.segs, p, len2, bufA);
        applyProcs(len2 < BS ? bufA.map((b) => b.subarray(0, len2)) : bufA, procs, p, sr);
        p += len2;
      }
    }
    if (a._.disposed) return;
    if (!plan || outPos >= plan.totalLen + T) {
      if (a.decoded) break;
      await new Promise((r) => a._.waiters.push(r));
      continue;
    }
    let bound = a.decoded ? plan.totalLen + T : Math.min(plan.limit, plan.totalLen);
    let blockEnd = Math.min(outPos < startSample + T ? startSample + T : endSample + T, bound);
    let len = Math.min(BS, blockEnd - outPos);
    if (len <= 0) {
      if (a.decoded) break;
      await new Promise((r) => a._.waiters.push(r));
      continue;
    }
    let needed = maxSrcSample(plan.segs, outPos, outPos + len);
    if (needed > builtLen && !a.decoded) {
      await new Promise((r) => a._.waiters.push(r));
      continue;
    }
    for (let b of bufA) b.fill(0, 0, len);
    renderBlock(a, plan.segs, outPos, len, bufA);
    let src = len < BS ? bufA.map((b) => b.subarray(0, len)) : bufA;
    let out = procs.length ? applyProcs(src, procs, outPos, sr) : src;
    if (xf) {
      let ob = xf.buf;
      for (let b of ob) b.fill(0, 0, len);
      renderBlock(a, xf.plan.segs, xf.pos, len, ob);
      let os = len < BS ? ob.map((b) => b.subarray(0, len)) : ob;
      let oo = xf.procs.length ? applyProcs(os, xf.procs, xf.pos, sr) : os, k = xf.n - xf.left;
      for (let c = 0; c < out.length; c++) {
        let o = oo[c % oo.length], y2 = out[c];
        for (let i = 0; i < len; i++) {
          let t = Math.min(1, (k + i + 1) / xf.n);
          y2[i] = o[i] * (1 - t) + y2[i] * t;
        }
      }
      xf.pos += len;
      if ((xf.left -= len) <= 0) xf = null;
    }
    if (outPos >= startSample + T) {
      yielded = true;
      yield out.map((b) => b.slice(0, len));
    }
    outPos += len;
  }
};
fn2.undo = function(n = 1) {
  if (!this.edits.length) return n === 1 ? null : [];
  let removed = [];
  for (let i = 0; i < n && this.edits.length; i++) removed.push(popEdit(this));
  return n === 1 ? removed[0] : removed;
};
fn2.run = function(...edits) {
  let sr = this.sampleRate;
  for (let e of edits) {
    if (e[0] === "paste" && !this.edits.some((e2) => e2[0] === "copy" || e2[0] === "cut")) throw new Error("paste: clipboard is empty; call copy() or cut() first");
    pushEdit(this, normalizeEdit(e, sr));
  }
  return this;
};
fn2.toJSON = function() {
  let edits = this.edits.filter((e) => !hasFunction(e[1]));
  return { source: this.source, edits, sampleRate: this.sampleRate, channels: this.channels, duration: this.duration };
};
fn2.clone = function() {
  let b = audio.from(this, { sampleRate: this._.sr });
  for (let [type, opts] of this.edits) pushEdit(b, [type, opts ? { ...opts } : {}]);
  return b;
};
var MAX_FLAT_SIZE = 2 ** 29;
var WARMUP = 8;
audio.renderAt = renderAt;
function renderAt(render2, source, srcOff, n, sr) {
  let ssr = source?.sampleRate;
  let ratio = ssr && ssr !== sr ? ssr / sr : 1;
  if (ratio === 1) return render2(source, srcOff, n);
  let src = render2(source, Math.floor(srcOff * ratio), Math.ceil(n * ratio) + 1);
  return src.map((ch) => {
    let o = new Float32Array(n);
    resample(ch, o, 0, n, ratio, srcOff * ratio % 1);
    return o;
  });
}
function render(a, offset, count) {
  if (Array.isArray(a) && a[0] instanceof Float32Array) {
    return offset != null ? a.map((ch) => ch.subarray(offset, offset + count)) : a;
  }
  if (a?.getChannelData && !a.pages) {
    let chs = Array.from({ length: a.numberOfChannels }, (_, i) => new Float32Array(a.getChannelData(i)));
    return offset != null ? chs.map((ch) => ch.subarray(offset, offset + count)) : chs;
  }
  if (offset != null) return readRange(a, offset, count);
  if (a._.pcm && a._.pcmV === a.version) return a._.pcm;
  if (!a.edits.length) {
    let r2 = readPages(a);
    a._.pcm = r2;
    a._.pcmV = a.version;
    return r2;
  }
  let plan = buildPlan(a);
  let virtualLen = planLen(plan.segs);
  if (virtualLen > MAX_FLAT_SIZE) throw new Error(`Audio too large for flat render (${(virtualLen / 1e6).toFixed(0)}M samples). Use streaming.`);
  let r = readPlan(a, plan);
  a._.pcm = r;
  a._.pcmV = a.version;
  return r;
}
function planLen(segs) {
  let m2 = 0;
  for (let s of segs) m2 = Math.max(m2, s[2] + s[1]);
  return m2;
}
function adjustLimit(limit, type, ctx) {
  if (limit <= 0) return 0;
  let { offset, length, sampleRate: sr } = ctx;
  if (type === "speed") return Math.round(limit / Math.abs(ctx.rate || 1));
  if (type === "crop") {
    let at = offset ?? 0, dur = length ?? limit - at;
    return Math.max(0, Math.min(dur, limit - at));
  }
  if (type === "remove") {
    let at = offset ?? 0, dur = length ?? limit - at;
    let h2 = Math.round((parseTime(ctx.crossfade) || 0) * sr / 2);
    if (h2 && limit < at + dur + h2) return Math.max(0, Math.min(limit, at - h2));
    return at < limit ? limit - Math.min(dur, limit - at) : limit;
  }
  if (type === "insert") {
    let x = Math.round((parseTime(ctx.crossfade) || 0) * sr);
    if (x && offset != null && limit < offset + x) return Math.max(0, Math.min(limit, Math.min(offset, ctx.total) - x));
    if (offset != null && offset <= limit) {
      let s = ctx.source;
      let iLen = typeof s === "number" ? Math.round(s * sr) : s?.sampleRate && s.sampleRate !== sr ? Math.round((s.length ?? 0) * sr / s.sampleRate) : s?.length ?? 0;
      if (length != null) iLen = Math.min(iLen, length);
      return limit + iLen;
    }
    return limit;
  }
  if (type === "repeat") {
    let at = offset ?? 0, dur = length ?? limit - at;
    if (at < limit) return limit + dur * (ctx.times ?? 1);
    return limit;
  }
  if (type === "pad") return limit + Math.round((ctx.before ?? 0) * sr);
  if (type === "reverse") return length == null || limit < (offset ?? 0) + length ? Math.min(limit, offset ?? 0) : limit;
  if (type === "_resample_seg") return Math.round(limit * (ctx.rate || sr) / sr);
  if (type === "_stretch_seg") {
    if (ctx.fv) {
      let q = ctx.q || 2048, out = 0;
      for (let k = 0; k * q < limit; k++)
        out += Math.round(Math.min(q, limit - k * q) * (ctx.fv[Math.min(k, ctx.fv.length - 1)] || 1));
      return out;
    }
    return Math.round(limit * (ctx.factor || 1));
  }
  return limit;
}
function mkPlanCtx(total, sr, offset, length, extra) {
  return { total, sampleRate: sr, offset, length, ...extra };
}
function procLatency(desc, o, sr) {
  let l = desc?.latency;
  return (typeof l === "function" ? Math.round(l(o || {}, sr)) : l) || 0;
}
function procWarmup(desc, o, sr) {
  let w = desc?.warmup;
  return (typeof w === "function" ? Math.round(w(o || {}, sr)) : w) || 0;
}
function procHoldback(desc, o, sr, total) {
  let h2 = desc?.holdback;
  return (typeof h2 === "function" ? Math.round(h2(o || {}, sr, total)) : h2) || 0;
}
var warmStart = (s, sc, warmup = 0) => Math.max(0, Math.min(s, s - warmup, sc - audio.BLOCK_SIZE * WARMUP));
function resolveCtxStats(a, index, st) {
  let src = a.srcStats, { segs, pipeline, sr } = st;
  if (!src) return src;
  if (!pipeline.length && segs.length === 1 && segs[0][0] === 0 && segs[0][2] === 0 && segs[0][1] === a._.len && !segs[0][3] && segs[0][4] === void 0) return src;
  let adapted = audio.adaptStats?.(src, st, sr);
  if (adapted) return adapted;
  if (!audio.statSession) return null;
  let edit = a.edits[index], all = a._.rstats ??= /* @__PURE__ */ new WeakMap(), c = all.get(edit), rv = refVersion(a);
  if (!c || c.rv !== rv || c.prefix.length !== index || c.prefix.some((e, i) => e !== a.edits[i]))
    all.set(edit, c = { prefix: a.edits.slice(0, index), rv, pos: 0, hl: 0 });
  if (!c.st || c.st.sr !== sr || c.st.ch !== st.ch || c.st.latency !== st.latency || pipelineSig(c.st.pipeline) !== pipelineSig(pipeline) || !sameTimeline(c.st.segs, segs)) {
    c.procs = null;
    c.st = null;
    c.session = audio.statSession(sr);
    c.done = 0;
    c.stats = null;
  }
  if (c.stats) return c.stats;
  st.outCh = stageWidth(pipeline, st.ch, st.totalLen / sr, sr);
  st.cur = c;
  let settled = st.final ? st.totalLen : Math.max(0, Math.min(st.limit, st.totalLen) - st.latency);
  for (let n; (n = Math.min(1 << 16, settled - c.done)) > 0; c.done += n) c.session.page(readStage(a, st, c.done, n));
  return st.final ? c.stats = c.session.done() : c.session.snapshot();
}
function compilePlan(a, len, final) {
  let sr = a._.sr, ch = a._.ch;
  let segs = [[0, len, 0]], pipeline = [], limit = len, pulls = [], latency = 0, warmup = 0, clipboard;
  const snapshot = (index2) => {
    let ref = audio.from(a, { sampleRate: a._.sr });
    ref.edits = a.edits.slice(0, index2);
    ref.version = ref.edits.length;
    return ref;
  };
  let pushProc = (ed) => {
    pipeline.push(ed);
    latency += procLatency(ops[ed[0]], ed[1], sr);
    warmup = Math.max(warmup, procWarmup(ops[ed[0]], ed[1], sr));
    let o = ed[1];
    if (o) {
      for (let k in o) if (o[k]?.pages) pulls.push({ ref: o[k], at: o.at ?? 0 });
    }
    if (!final) {
      let t = planLen(segs), hb = procHoldback(ops[ed[0]], o, sr, t);
      if (o?.at < 0) hb = Math.max(hb, Math.round(-o.at * sr) + procWarmup(ops[ed[0]], o, sr));
      if (hb) limit = Math.min(limit, Math.max(0, t - hb));
    }
  };
  let index = 0, bakes = 0;
  let bake = () => {
    if (!pipeline.length) return;
    let st = { segs, pipeline, totalLen: planLen(segs), sr, ch, latency, warmup, pulls, limit };
    st.outCh = stageWidth(pipeline, ch, st.totalLen / sr, sr);
    st.cur = stageCursor(a, index, bakes++);
    segs = [seg(0, st.totalLen, 0, void 0, st)];
    ch = st.outCh;
    pipeline = [];
    pulls = [];
    latency = 0;
    warmup = 0;
  };
  let applyEmitted = (emitted, at, duration, channel2) => {
    let edits = Array.isArray(emitted) && typeof emitted[0] !== "string" ? emitted : [emitted];
    for (let re of edits) {
      re = normalizeEdit(re, sr);
      let [rType, rOpts = {}] = re;
      let o = { ...rOpts };
      o.at ??= at;
      o.duration ??= duration;
      o.channel ??= channel2;
      re = [rType, o];
      let rOp = ops[rType];
      if (rOp?.whole) throw new Error(`audio: whole-render op '${rType}' cannot be emitted by expand/resolve`);
      if (rOp?.plan && typeof rOp.plan === "function") {
        bake();
        let { at: rAt, duration: rDur, channel: rCh, ...rExtra } = o;
        let t = planLen(segs), rOff = rAt != null ? Math.round(rAt * sr) : null, rLen = rDur != null ? Math.round(rDur * sr) : null;
        let rpctx = mkPlanCtx(t, sr, rOff, rLen, rExtra);
        segs = rOp.plan(segs, rpctx);
        if (!final) limit = adjustLimit(limit, rType, rpctx);
      } else {
        pushProc(re);
      }
      if (rOp?.sr) {
        let ns = rOp.sr(sr, o);
        if (ns) sr = ns;
      }
    }
  };
  for (let [i, edit] of a.edits.entries()) {
    index = i;
    bakes = 0;
    let [type, o = {}] = edit;
    let { at, duration, channel: channel2, ...extra } = o;
    let op = ops[type];
    if (!op) throw new Error(`Unknown op: ${type}`);
    if (type === "copy" || type === "cut") {
      if (!final) {
        limit = 0;
        continue;
      }
      clipboard = snapshot(index).crop(o);
      if (type === "copy") continue;
    }
    if (type === "paste" || type === "cut") {
      if (!final) {
        limit = 0;
        continue;
      }
      if (!clipboard) throw new Error("paste: clipboard is empty; call copy() or cut() first");
      if (type === "paste") extra.source = clipboard;
    }
    if (!final && at != null && at < 0 && (op.plan || op.whole || op.resolve)) limit = 0;
    if (op.expand) {
      let ctx = { sampleRate: sr, channelCount: ch, channel: channel2, at, duration, totalDuration: planLen(segs) / sr, final, ...extra };
      let expanded = op.expand(ctx);
      if (expanded !== null && expanded !== void 0) {
        if (expanded !== false) applyEmitted(expanded, at, duration, channel2);
        if (op.sr) {
          let ns = op.sr(sr, extra);
          if (ns) sr = ns;
        }
        continue;
      }
    }
    if (op.resolve) {
      let stats = resolveCtxStats(a, i, { segs, pipeline, totalLen: planLen(segs), sr, ch, latency, warmup, pulls, limit, final });
      if (!final) {
        let t = planLen(segs), hb = procHoldback(op, o, sr, t);
        if (stats?.min) limit = Math.min(limit, stats.min[0].length * (stats.blockSize || audio.BLOCK_SIZE));
        if (hb) limit = Math.min(limit, Math.max(0, t - hb));
      }
      let ctx = { stats, sampleRate: sr, channelCount: ch, channel: channel2, at, duration, totalDuration: planLen(segs) / sr, final, ...extra };
      if (final && audio.statSession) ctx.measure = (emitted) => {
        let pl = pipeline.slice(), lat = latency, wu = warmup;
        for (let re of Array.isArray(emitted[0]) ? emitted : [emitted]) {
          let [t, o2] = normalizeEdit(re, sr);
          if (ops[t]?.plan || ops[t]?.whole) throw new Error(`measure: '${t}' is structural; pipeline ops only`);
          o2.at ??= at;
          o2.duration ??= duration;
          o2.channel ??= channel2;
          pl.push([t, o2]);
          lat += procLatency(ops[t], o2, sr);
          wu = Math.max(wu, procWarmup(ops[t], o2, sr));
        }
        let s = audio.statSession(sr);
        for (let chunk of streamPlan(a, { segs, pipeline: pl, totalLen: planLen(segs), sr, ch, latency: lat, warmup: wu, pulls })) s.page(chunk);
        return s.done();
      };
      let resolved = op.resolve(ctx);
      if (resolved === false) {
        if (op.sr) {
          let ns = op.sr(sr, extra);
          if (ns) sr = ns;
        }
        ;
        continue;
      }
      if (resolved) {
        applyEmitted(resolved, at, duration, channel2);
        if (op.sr) {
          let ns = op.sr(sr, extra);
          if (ns) sr = ns;
        }
        continue;
      }
    }
    if (op.whole) {
      if (!final) {
        limit = 0;
        continue;
      }
      let t = planLen(segs);
      if (t > MAX_FLAT_SIZE) throw new Error(`Audio too large for whole-render op '${type}' (${(t / 1e6).toFixed(0)}M samples)`);
      if (a._.wrc?.v !== a.version) a._.wrc = { v: a.version, m: /* @__PURE__ */ new Map() };
      let key = a.edits.indexOf(edit) + ":" + a._.len + ":" + t;
      let ref = a._.wrc.m.get(key);
      if (!ref) {
        let input = readPlan(a, { segs, pipeline, totalLen: t, sr, ch, latency, pulls });
        if (!input.length) input = Array.from({ length: ch || 1 }, () => new Float32Array(0));
        let tailN = Math.round((typeof op.tail === "function" ? op.tail(extra, sr) : op.tail || 0) * sr);
        if (tailN > 0) input = input.map((chn) => {
          let e = new Float32Array(chn.length + tailN);
          e.set(chn);
          return e;
        });
        let outCh = op.ch && op.ch(input.length, extra) || input.length;
        let outLen = op.frames ? Math.max(0, Math.round(op.frames(input[0].length, extra, sr))) : input[0].length;
        if (outLen > MAX_FLAT_SIZE) throw new Error(`Audio too large for whole-render op '${type}' (${(outLen / 1e6).toFixed(0)}M samples out)`);
        let output = Array.from({ length: outCh }, () => new Float32Array(outLen));
        let wctx = { sampleRate: sr, channelCount: input.length, totalDuration: input[0].length / sr, at, duration, channel: channel2, render, ...extra };
        op.whole(input, output, wctx);
        a._.wrc.m.set(key, ref = audio.from(output, { sampleRate: sr }));
        if (!op.frames) ref._.timeline = { segs, sr };
      }
      segs = [seg(0, ref._.len, 0, void 0, ref)];
      ch = ref._.ch;
      pipeline = [];
      latency = 0;
      warmup = 0;
      pulls = [];
      if (op.sr) {
        let ns = op.sr(sr, extra);
        if (ns) sr = ns;
      }
      continue;
    }
    if (op.plan) {
      bake();
      let t = planLen(segs), offset = at != null ? Math.round(at * sr) : null, length = duration != null ? Math.round(duration * sr) : null;
      let pctx = mkPlanCtx(t, sr, offset, length, extra);
      segs = op.plan(segs, pctx);
      if (!final) limit = adjustLimit(limit, type, pctx);
    } else {
      pushProc(edit);
    }
    if (op.sr) {
      let ns = op.sr(sr, extra);
      if (ns) sr = ns;
    }
  }
  let totalLen = planLen(segs);
  if (final) limit = totalLen;
  return { segs, pipeline, totalLen, sr, ch, limit: Math.max(0, limit), pulls, latency, warmup };
}
function refVersion(a) {
  let v = 0;
  eachRef(a, (r) => v += r.version + r._.len);
  return v;
}
var compileStack = /* @__PURE__ */ new Set();
function buildPlan(a) {
  let rv = refVersion(a);
  if (a._.plan && a._.planV === a.version && a._.planL === a._.len && a._.planR === rv) return a._.plan;
  if (compileStack.has(a)) throw new Error("audio: circular source reference");
  compileStack.add(a);
  try {
    let plan = compilePlan(a, a._.len, true);
    a._.plan = plan;
    a._.planV = a.version;
    a._.planL = a._.len;
    a._.planR = rv;
    return plan;
  } finally {
    compileStack.delete(a);
  }
}
var _rsBuf = null;
var _rsLen = 0;
function readSource(a, c, srcOff, n, target, tOff, rate, interp) {
  let r = rate || 1, absR = Math.abs(r);
  if (absR === 1) {
    let base2 = Math.floor(srcOff);
    if (r > 0) return copyPages(a, c, base2, n, target, tOff);
    return walkPages(a, c, base2, n, (pg, ch, s, e, off) => {
      for (let i = s; i < e; i++) target[tOff + (n - 1 - (off + i - s))] = pg[ch][i];
    });
  }
  let margin = interp && interp.margin || 0;
  let base = Math.floor(srcOff), frac = srcOff - base;
  let srcN = Math.ceil(frac + n * absR) + 1 + 2 * margin;
  if (srcN > _rsLen) {
    _rsLen = srcN;
    _rsBuf = new Float32Array(srcN);
  }
  let buf = _rsBuf.subarray(0, srcN);
  buf.fill(0);
  let bufStart = base - margin;
  let copyOff = bufStart < 0 ? -bufStart : 0;
  let copyStart = Math.max(0, bufStart);
  let copyLen = srcN - copyOff;
  if (copyLen > 0) copyPages(a, c, copyStart, copyLen, buf, copyOff);
  (interp || resample)(buf, target, tOff, n, r, margin + frac);
}
function resample(src, target, tOff, n, rate, phase = 0) {
  let absR = Math.abs(rate), rev = rate < 0;
  for (let i = 0; i < n; i++) {
    let pos = (rev ? n - 1 - i : i) * absR + phase;
    let idx = pos | 0, frac = pos - idx;
    target[tOff + i] = idx + 1 < src.length ? src[idx] + (src[idx + 1] - src[idx]) * frac : src[idx] || 0;
  }
}
var refStack = /* @__PURE__ */ new Set();
function readRange(a, srcStart, n, sg, at) {
  if (!a.edits.length) {
    return Array.from({ length: a._.ch }, (_, c) => {
      let out = new Float32Array(n);
      copyPages(a, c, srcStart, n, out, 0);
      return out;
    });
  }
  if (refStack.has(a)) throw new Error("audio: circular source reference");
  refStack.add(a);
  try {
    let plan = buildPlan(a);
    plan.cur ??= a._.cursor ??= { pos: 0, hl: 0 };
    plan.outCh ??= stageWidth(plan.pipeline, plan.ch, plan.totalLen / plan.sr, plan.sr);
    return readStage(a, plan, srcStart, n, sg, at);
  } finally {
    refStack.delete(a);
  }
}
function eachSeg(segs, from, to, cb) {
  let n = segs.length, lo = 0;
  if (n > 64) {
    if (segs._sorted === void 0) {
      let ok = true;
      for (let i = 1; i < n; i++) if (segs[i][2] < segs[i - 1][2]) {
        ok = false;
        break;
      }
      Object.defineProperty(segs, "_sorted", { value: ok });
    }
    if (segs._sorted) {
      let a0 = 0, b0 = n;
      while (a0 < b0) {
        let m2 = a0 + b0 >> 1;
        if (segs[m2][2] <= from) a0 = m2 + 1;
        else b0 = m2;
      }
      lo = a0;
      while (lo > 0 && segs[lo - 1][2] + segs[lo - 1][1] > from) lo--;
      for (let i = lo; i < n && segs[i][2] < to; i++) cb(segs[i]);
      return;
    }
  }
  for (let i = 0; i < n; i++) cb(segs[i]);
}
function renderBlock(a, segs, outOff, len, chunk) {
  eachSeg(segs, outOff, outOff + len, (sg) => {
    let iStart = Math.max(outOff, sg[2]), iEnd = Math.min(outOff + len, sg[2] + sg[1]);
    if (iStart >= iEnd) return;
    if (sg[6]) renderEnvSeg(a, sg, chunk, iStart - outOff, iEnd - iStart, iStart);
    else renderSeg(a, sg, chunk, iStart - outOff, iEnd - iStart, iStart);
  });
}
var _envPool = [];
var _envDepth = 0;
function renderEnvSeg(a, sg, chunk, dstOff, n, at) {
  let pool = _envPool[_envDepth] ??= [];
  let tmp = Array.from({ length: chunk.length }, (_, c) => {
    if (!(pool[c]?.length >= n)) pool[c] = new Float32Array(Math.max(n, audio.BLOCK_SIZE));
    return pool[c].fill(0, 0, n);
  });
  _envDepth++;
  try {
    renderSeg(a, sg, tmp, 0, n, at);
  } finally {
    _envDepth--;
  }
  let e = sg[6], L = sg[1], h2 = Math.PI / 2;
  for (let i = 0; i < n; i++) {
    let u = (at + i - sg[2] + 0.5) / L, g = 1;
    for (let k = 0; k < e.length; k += 2) g *= Math.sin((e[k] + (e[k + 1] - e[k]) * u) * h2);
    for (let c = 0; c < chunk.length; c++) chunk[c][dstOff + i] += tmp[c][i] * g;
  }
}
function renderSeg(a, sg, chunk, dstOff, n, at) {
  let rate = sg[3] || 1, ref = sg[4], interp = sg[5], absR = Math.abs(rate);
  let srcStart = segSrcStart(sg, at, n);
  if (ref === null) return;
  if (ref === void 0) {
    for (let c = 0, N = Math.min(chunk.length, a._.ch); c < N; c++) readSource(a, c, srcStart, n, chunk[c], dstOff, rate, interp);
    return;
  }
  if (!ref.segs && !ref.edits.length) {
    for (let c = 0; c < chunk.length; c++) readSource(ref, c % ref._.ch, srcStart, n, chunk[c], dstOff, rate, interp);
    return;
  }
  let margin = interp && interp.margin || 0;
  let base = Math.floor(srcStart), frac = srcStart - base;
  let srcN = Math.ceil(frac + n * absR) + 1 + 2 * margin;
  let bufStart = base - margin;
  let copyOff = bufStart < 0 ? -bufStart : 0;
  let copyStart = Math.max(0, bufStart);
  let srcPcm = ref.segs ? readStage(a, ref, copyStart, srcN - copyOff, sg, at) : readRange(ref, copyStart, srcN - copyOff, sg, at);
  for (let c = 0; c < chunk.length; c++) {
    let src = srcPcm[c % srcPcm.length];
    if (copyOff || src.length < srcN) {
      let buf = new Float32Array(srcN);
      buf.set(src.subarray(0, srcN - copyOff), copyOff);
      src = buf;
    }
    if (absR === 1) {
      if (rate < 0) {
        for (let i = 0; i < n; i++) chunk[c][dstOff + i] = src[n - 1 - i];
      } else chunk[c].set(src.subarray(0, n), dstOff);
    } else (interp || resample)(src, chunk[c], dstOff, n, rate, margin + frac);
  }
}
function stageWidth(pipeline, ch, totalDur, sr) {
  for (let [type, o = {}] of pipeline) {
    let desc = ops[type];
    if (!desc?.ch) continue;
    let { at, duration, channel: channel2, ...extra } = o;
    ch = desc.ch(ch, { duration, sampleRate: sr, totalDuration: totalDur, render, ...extra }) || ch;
  }
  return ch;
}
function stageCursor(a, index, n) {
  let edit = a.edits[index], stages = a._.stages ??= /* @__PURE__ */ new WeakMap();
  let list = stages.get(edit);
  if (!list) stages.set(edit, list = []);
  let c = list[n], rv = refVersion(a);
  if (!c || c.rv !== rv || c.prefix.length !== index || c.prefix.some((e, i) => e !== a.edits[i]))
    list[n] = c = { prefix: a.edits.slice(0, index), rv, pos: 0, hl: 0 };
  return c;
}
function sameTimeline(x, y2) {
  if (x.length !== y2.length) return false;
  for (let i = 0; i < x.length; i++) {
    let s = x[i], t = y2[i];
    if (s[0] !== t[0] || s[2] !== t[2] || s[3] !== t[3] || s[5] !== t[5]) return false;
    if (s[6] !== t[6] && String(s[6]) !== String(t[6])) return false;
    if (s[4] !== t[4] && !(s[4]?.cur && s[4].cur === t[4]?.cur)) return false;
    if (s[1] !== t[1] && !(i === x.length - 1 && t[1] > s[1])) return false;
  }
  return true;
}
function carryStage(c, st) {
  let old = c.st;
  c.st = st;
  if (!c.procs) return;
  if (!old || old.sr !== st.sr || old.ch !== st.ch || old.latency !== st.latency || pipelineSig(st.pipeline) !== c.sig || !sameTimeline(old.segs, st.segs)) {
    c.procs = null;
    return;
  }
  let td = st.totalLen / st.sr;
  for (let p of c.procs) p.ctx.totalDuration = td;
  patchProcs(c.procs, st.pipeline);
}
var READERS = 4;
var readTick = 0;
var reading = null;
function reader(st, s, sg, at) {
  let main = st.cur, all = [main, ...main.more ??= []], BS = audio.BLOCK_SIZE, best = null, gap = Infinity;
  let mine = (r) => !sg || r.till == null || at >= r.till || r.from === sg[0] && r.to === sg[2] && r.by === reading;
  for (let r of all) {
    if (r.st !== st) carryStage(r, st);
    let d2 = Math.abs(s - r.pos);
    if (!r.procs || s < r.pos - r.hl || s > r.pos + BS * WARMUP || !mine(r) || d2 > gap || d2 === gap && r.used < best.used) continue;
    best = r;
    gap = d2;
  }
  if (!best) {
    best = all.find((r) => !r.procs) ?? (all.length < READERS ? main.more[main.more.push({ pos: 0, hl: 0, st }) - 1] : all.reduce((p, q) => p.used <= q.used ? p : q));
    seekStage(st, best, s);
  }
  Object.assign(best, { used: ++readTick, from: sg?.[0], to: sg?.[2], till: sg ? sg[2] + sg[1] : null, by: reading });
  return best;
}
function seekStage(st, c, s) {
  let BS = audio.BLOCK_SIZE, T = st.latency, sc = s + T;
  c.procs = initProcs(st.pipeline, st.totalLen / st.sr, st.sr, st.ch);
  c.sig = pipelineSig(st.pipeline);
  c.buf = Array.from({ length: st.ch }, () => new Float32Array(BS));
  c.hist = Array.from({ length: st.outCh }, () => new Float32Array(BS));
  c.hl = 0;
  c.pos = (sc > 0 ? warmStart(s, sc, st.warmup) : sc) - T;
}
function readStage(a, st, s, n, sg, at) {
  let c = reader(st, s, sg, at), BS = audio.BLOCK_SIZE, T = st.latency;
  let out = Array.from({ length: st.outCh }, () => new Float32Array(n));
  let k = Math.min(c.pos, s + n) - s;
  if (k > 0) for (let ch = 0; ch < out.length; ch++) out[ch].set(c.hist[ch].subarray(BS - (c.pos - s), BS - (c.pos - s) + k));
  while (c.pos < s + n) {
    let len = Math.min(BS, (c.pos < s ? s : s + n) - c.pos);
    for (let b of c.buf) b.fill(0, 0, len);
    let was = reading;
    reading = c;
    try {
      renderBlock(a, st.segs, c.pos + T, len, c.buf);
    } finally {
      reading = was;
    }
    let src = len < BS ? c.buf.map((b) => b.subarray(0, len)) : c.buf;
    let blk = applyProcs(src, c.procs, c.pos + T, st.sr);
    for (let ch = 0; ch < out.length; ch++) {
      let b = blk[ch % blk.length].subarray(0, len), h2 = c.hist[ch];
      if (c.pos >= s) out[ch].set(b, c.pos - s);
      if (len >= BS) h2.set(b.subarray(len - BS));
      else {
        h2.copyWithin(0, len);
        h2.set(b, BS - len);
      }
    }
    c.hl = Math.min(BS, c.hl + len);
    c.pos += len;
  }
  return out;
}
var SUB = 128;
var isCurve = (x) => x != null && typeof x === "object" && x.t?.length > 0 && x.v?.length === x.t.length && typeof x.t[0] === "number";
function curveFn(c) {
  let { t, v } = c;
  return (time) => {
    let n = t.length;
    if (time <= t[0]) return v[0];
    if (time >= t[n - 1]) return v[n - 1];
    let i = 1;
    while (t[i] < time) i++;
    let f = (time - t[i - 1]) / (t[i] - t[i - 1]);
    return v[i - 1] + (v[i] - v[i - 1]) * f;
  };
}
function applyProcs(bufA, procs, outOff, sr) {
  let cur = bufA;
  for (let proc of procs) {
    let { op, at, dur, channel: channel2, ctx } = proc;
    if (!op) continue;
    let BS = cur[0].length;
    let out = proc.out[0].length === BS ? proc.out : proc.out.map((ch) => ch.subarray(0, BS));
    let tOff = outOff - proc.preLat;
    let run = (i02, i1) => {
      ctx.blockOffset = (tOff + i02) / sr;
      ctx.at = at != null ? at - ctx.blockOffset : void 0;
      let full = i02 === 0 && i1 === BS;
      let inV = full ? cur : cur.map((ch) => ch.subarray(i02, i1));
      let outV = full ? out : out.map((ch) => ch.subarray(i02, i1));
      if (channel2 != null) {
        let { chs } = resolveChannels(channel2, inV.length);
        for (let c = 0; c < inV.length; c++) if (!chs.includes(c)) {
          if (!proc.lat) {
            outV[c].set(inV[c]);
            continue;
          }
          let d2 = (proc.dl ??= [])[c] ??= new Float32Array(proc.lat), x = inV[c], y2 = outV[c];
          let j = (proc.di ??= [])[c] ?? 0;
          for (let i = 0; i < x.length; i++) {
            y2[i] = d2[j];
            d2[j] = x[i];
            if (++j === d2.length) j = 0;
          }
          proc.di[c] = j;
        }
        op(chs.map((c) => inV[c]), chs.map((c) => outV[c]), ctx);
      } else op(inV, outV, ctx);
    };
    let s = 0, e = BS;
    if (!proc.ranged && (at != null || dur != null)) {
      let a0 = at != null ? Math.round(at * sr) : 0;
      let a1 = dur != null ? a0 + Math.round(dur * sr) : Infinity;
      s = Math.max(0, Math.min(a0 - tOff, BS));
      e = Math.max(s, Math.min(a1 - tOff, BS));
      if (s > 0 || e < BS) for (let c = 0; c < out.length; c++) out[c].set(cur[c % cur.length]);
      if (e <= s) {
        cur = out;
        continue;
      }
    }
    let { autos, ramp } = proc;
    if (autos || ramp) {
      for (let i = s; i < e; i += SUB) {
        let j = Math.min(i + SUB, e);
        if (autos) for (let k of autos) ctx[k] = proc.fns[k]((tOff + (i + j) / 2) / sr);
        if (ramp) {
          let p = (j - s) / (e - s);
          for (let k in ramp) ctx[k] = ramp[k][0] + (ramp[k][1] - ramp[k][0]) * p;
        }
        run(i, j);
      }
      proc.ramp = ramp = null;
    } else run(s, e);
    cur = out;
  }
  return cur;
}
function pipelineSig(pipeline) {
  return pipeline.map((ed) => ed[0]).join("|");
}
function patchProcs(procs, pipeline) {
  for (let i = 0; i < procs.length && i < pipeline.length; i++) {
    let p = procs[i], o = pipeline[i][1] || {};
    let { at, duration, channel: channel2, ...extra } = o;
    p.origAt = at;
    p.at = at != null && at < 0 ? p.ctx.totalDuration + at : at;
    p.dur = p.ctx.duration = duration;
    p.channel = channel2;
    let ramp = null;
    for (let k in extra) {
      let v = extra[k];
      if (isCurve(v)) v = curveFn(v);
      if (typeof v === "function") {
        if (p.fns?.[k]) p.fns[k] = v;
        else if (p.desc.auto === "sample") p.ctx[k] = v;
        continue;
      }
      if (typeof v === "number" && typeof p.ctx[k] === "number" && p.ctx[k] !== v) (ramp ??= {})[k] = [p.ctx[k], v];
      p.ctx[k] = v;
    }
    if (ramp) p.ramp = ramp;
  }
}
function initProcs(pipeline, totalDur, sr, nch) {
  let curCh = nch, BS = audio.BLOCK_SIZE, preLat = 0;
  return pipeline.map((ed) => {
    let desc = ops[ed[0]];
    let o = ed[1] || {};
    let { at, duration: dur, channel: channel2, ...extra } = o;
    let ctx = { duration: dur, sampleRate: sr, totalDuration: totalDur, render, ...extra };
    let outCh = desc.ch ? desc.ch(curCh, ctx) : 0;
    let w = outCh || curCh;
    if (outCh) curCh = outCh;
    let myPre = preLat, lat = procLatency(desc, o, sr);
    preLat += lat;
    let fns = null, autos = null;
    for (let k in extra) {
      let val = extra[k];
      if (isCurve(val)) val = curveFn(val);
      if (typeof val !== "function" || desc.fnArgs?.includes(k)) continue;
      if (desc.auto === "sample") {
        ctx[k] = val;
        continue;
      }
      ;
      (fns ??= {})[k] = val;
      (autos ??= []).push(k);
      ctx[k] = val(0);
    }
    return {
      op: desc.process,
      desc,
      origAt: at,
      at: at != null && at < 0 ? totalDur + at : at,
      dur,
      channel: channel2,
      outCh,
      ranged: !!desc.ranged,
      preLat: myPre,
      lat,
      out: Array.from({ length: w }, () => new Float32Array(BS)),
      fns,
      autos,
      ramp: null,
      ctx
    };
  });
}
function maxSrcSample(segs, start, end) {
  let max = 0;
  eachSeg(segs, start, end, (sg) => {
    let iStart = Math.max(start, sg[2]), iEnd = Math.min(end, sg[2] + sg[1]);
    if (iStart >= iEnd) return;
    let ref = sg[4];
    if (ref === null || ref?.pages) return;
    let rate = sg[3] || 1, absR = Math.abs(rate), margin = sg[5] && sg[5].margin || 0;
    let n = iEnd - iStart, top = Math.ceil(segSrcStart(sg, iStart, n) + n * absR) + 1 + margin;
    max = Math.max(max, ref ? maxSrcSample(ref.segs, 0, top + ref.latency) : top);
  });
  return max;
}
function* streamPlan(a, plan, offset, duration) {
  let { segs, pipeline, totalLen, sr, ch = a._.ch, latency: T = 0 } = plan;
  let s = Math.round((offset || 0) * sr), e = duration != null ? s + Math.round(duration * sr) : totalLen;
  let procs = initProcs(pipeline, totalLen / sr, sr, ch);
  let sc = s + T, ec = e + T;
  let ws = sc > 0 && procs.length ? warmStart(s, sc, plan.warmup) : sc;
  let BS = audio.BLOCK_SIZE, nch = ch;
  let bufA = Array.from({ length: nch }, () => new Float32Array(BS));
  for (let outOff = ws; outOff < ec; ) {
    let blockEnd = outOff < sc ? sc : ec;
    let len = Math.min(BS, blockEnd - outOff);
    for (let b of bufA) b.fill(0, 0, len);
    renderBlock(a, segs, outOff, len, bufA);
    let src = len < BS ? bufA.map((b) => b.subarray(0, len)) : bufA;
    let out = procs.length ? applyProcs(src, procs, outOff, sr) : src;
    if (outOff >= sc) yield out.map((b) => b.subarray(0, len));
    outOff += len;
  }
}
function readPlan(a, plan, offset, duration) {
  let { sr } = plan, out = null, nch = 0, pos = 0;
  for (let chunk of streamPlan(a, plan, offset, duration)) {
    if (!out) {
      nch = chunk.length;
      let s = Math.round((offset || 0) * sr), e = duration != null ? s + Math.round(duration * sr) : plan.totalLen;
      out = Array.from({ length: nch }, () => new Float32Array(e - s));
    }
    let n = chunk[0].length;
    for (let c = 0; c < nch; c++) out[c].set(chunk[c], pos);
    pos += n;
  }
  if (!out) return Array.from({ length: a.channels }, () => new Float32Array(0));
  return pos < out[0].length ? out.map((ch) => ch.subarray(0, pos)) : out;
}

// fn/cuts.js
var one = (r) => Math.abs(r - 1) < 1e-9 ? 1 : r;
function flatten(segs, sr, inst, cx, out = []) {
  for (let [from, count, to, rate = 1, ref] of segs) {
    if (ref === null) continue;
    let tl = null, owner = inst;
    if (ref?.segs) tl = ref;
    else if (ref?._.timeline) tl = ref._.timeline;
    else if (ref) {
      owner = ref;
      if (ref.edits.length) tl = buildPlan(ref);
    }
    let inner = tl ? tl.sr : owner._.sr, r = one(rate * sr / inner);
    let at = to / sr, d2 = count / sr, lo = from / inner, hi = lo + d2 * Math.abs(r);
    if (!tl) {
      let source = cx.fileOf(owner);
      if (source != null) out.push({ at, duration: d2, from: r < 0 ? hi : lo, rate: r, source, inst: owner });
      continue;
    }
    let sub = cx.memo.get(tl);
    if (!sub) {
      sub = flatten(tl.segs, tl.sr, owner, cx).sort((p, q) => p.at - q.at);
      let m2 = -Infinity;
      sub.ends = sub.map((c) => m2 = Math.max(m2, c.at + c.duration));
      cx.memo.set(tl, sub);
    }
    let t0 = r > 0 ? lo : hi, i = 0, j = sub.length;
    while (i < j) {
      let k = i + j >> 1;
      if (sub.ends[k] > lo) j = k;
      else i = k + 1;
    }
    for (; i < sub.length && sub[i].at < hi; i++) {
      let c = sub[i], a = Math.max(lo, c.at), b = Math.min(hi, c.at + c.duration), e = r > 0 ? a : b;
      if (b - a > 1e-9) out.push({ ...c, at: at + (e - t0) / r, duration: (b - a) / Math.abs(r), from: c.from + (e - c.at) * c.rate, rate: one(c.rate * r) });
    }
  }
  return out;
}
var runsOn = (p, c) => p.source === c.source && p.rate === c.rate && Math.abs(p.at + p.duration - c.at) < 1e-6 && Math.abs(p.from + p.duration * p.rate - c.from) < 1e-6;
function arrange(clips) {
  clips.sort((a, b) => a.at - b.at);
  let runs = [], ends = /* @__PURE__ */ new Map(), key = (t) => Math.round(t * 1e6);
  for (let c of clips) {
    let k = key(c.at), r = null;
    for (let j = k - 1; j <= k + 1 && !r; j++) {
      let list = ends.get(j), i = list ? list.findIndex((p) => runsOn(p, c)) : -1;
      if (i >= 0) r = list.splice(i, 1)[0];
    }
    if (r) r.duration += c.duration;
    else runs.push(r = { ...c });
    let e = key(r.at + r.duration);
    ends.has(e) ? ends.get(e).push(r) : ends.set(e, [r]);
  }
  let out = [];
  for (let c of runs) {
    let p = out.at(-1), end = p && p.at + p.duration;
    if (p && c.at < end - 1e-9) {
      if (c.at + c.duration <= end + 1e-9) continue;
      let mid = (c.at + end) / 2;
      p.duration = mid - p.at;
      c = { ...c, from: c.from + (mid - c.at) * c.rate, duration: c.at + c.duration - mid, at: mid };
    }
    if (p && runsOn(p, c)) p.duration += c.duration;
    else if (c.duration > 1e-9) out.push(c);
  }
  return out;
}
async function reader2(src) {
  if (typeof src === "string" && !/^\w+:\/\//.test(src)) {
    let fh = await (await import("fs/promises")).open(src);
    let size = (await fh.stat()).size;
    return { size, read: async (o, n) => {
      let b2 = new Uint8Array(Math.min(n, size - o));
      await fh.read(b2, 0, b2.length, o);
      return b2;
    }, close: () => fh.close() };
  }
  let b = src instanceof ArrayBuffer ? new Uint8Array(src) : ArrayBuffer.isView(src) ? new Uint8Array(src.buffer, src.byteOffset, src.byteLength) : null;
  if (b) return { size: b.length, read: async (o, n) => b.subarray(o, o + n), close() {
  } };
  if (typeof Blob !== "undefined" && src instanceof Blob) return { size: src.size, read: async (o, n) => new Uint8Array(await src.slice(o, o + n).arrayBuffer()), close() {
  } };
  return null;
}
async function boxes(r, start, end) {
  let out = [];
  for (let o = start; o + 8 <= end; ) {
    let h2 = await r.read(o, 16), v = new DataView(h2.buffer, h2.byteOffset, h2.byteLength);
    let size = v.getUint32(0), type = String.fromCharCode(h2[4], h2[5], h2[6], h2[7]), head = 8;
    if (size === 1) {
      size = Number(v.getBigUint64(8));
      head = 16;
    } else if (size === 0) size = end - o;
    if (size < head) break;
    out.push({ type, start: o + head, end: Math.min(end, o + size) });
    o += size;
  }
  return out;
}
var child = async (r, box, type) => (await boxes(r, box.start, box.end)).find((b) => b.type === type);
var view = (b) => new DataView(b.buffer, b.byteOffset, b.byteLength);
async function videoInfo(src) {
  let r = await reader2(src);
  if (!r) return null;
  try {
    let moov = (await boxes(r, 0, r.size)).find((b) => b.type === "moov");
    if (!moov) return null;
    let video = null, tc = null;
    for (let trak of (await boxes(r, moov.start, moov.end)).filter((b) => b.type === "trak")) {
      let mdia = await child(r, trak, "mdia"), hdlr = mdia && await child(r, mdia, "hdlr");
      let kind = hdlr && String.fromCharCode(...await r.read(hdlr.start + 8, 4));
      if (kind !== "vide" && kind !== "tmcd" || kind === "vide" && video) continue;
      let stbl = await child(r, await child(r, mdia, "minf"), "stbl");
      if (kind === "tmcd") {
        tc ??= await timecode0(r, stbl);
        continue;
      }
      let tkhd = await child(r, trak, "tkhd"), whv = view(await r.read(tkhd.end - 8, 8));
      let mdhd = await child(r, mdia, "mdhd"), m2 = await r.read(mdhd.start, 32);
      let timescale = view(m2).getUint32(m2[0] === 1 ? 20 : 12), stts = await child(r, stbl, "stts");
      let tv = view(await r.read(stts.start, stts.end - stts.start)), best = null, frames = 0;
      for (let i = 0, n = tv.getUint32(4); i < n; i++) {
        let count = tv.getUint32(8 + i * 8), delta = tv.getUint32(12 + i * 8);
        frames += count;
        if (delta && (!best || count > best.count)) best = { count, delta };
      }
      if (best) video = { timescale, delta: best.delta, width: whv.getUint32(0) >>> 16, height: whv.getUint32(4) >>> 16, frames };
    }
    return video && { ...video, start: tc?.start ?? 0, drop: !!tc?.drop };
  } finally {
    await r.close();
  }
}
async function timecode0(r, stbl) {
  let stsd = await child(r, stbl, "stsd"), d2 = stsd && await r.read(stsd.start, 40);
  if (!d2 || d2.length < 40 || String.fromCharCode(d2[12], d2[13], d2[14], d2[15]) !== "tmcd") return null;
  let flags = view(d2).getUint32(28), scale = view(d2).getUint32(32), duration = view(d2).getUint32(36);
  let co = await child(r, stbl, "stco") ?? await child(r, stbl, "co64"), c = co && view(await r.read(co.start, 16));
  if (!c || !scale || c.getUint32(4) < 1) return null;
  let at = co.type === "stco" ? c.getUint32(8) : Number(c.getBigUint64(8)), s = await r.read(at, 4);
  return s.length === 4 ? { start: view(s).getUint32(0) * duration / scale, drop: !!(flags & 1) } : null;
}
function events(clips, fps, files) {
  let out = [];
  let nearest = (x, own) => Math.abs(x - Math.floor(x) - 0.5) < 1e-6 ? own < x ? Math.floor(x) : Math.ceil(x) : Math.round(x);
  clips.forEach((c, i) => {
    let end = c.at + c.duration, next = clips[i + 1];
    let rIn = Math.round(c.at * fps), rOut = Math.round((next && Math.abs(next.at - end) < 1e-6 ? next.at : end) * fps);
    if (rOut <= rIn) return;
    let m2 = Math.max(1, Math.round((rOut - rIn) * Math.abs(c.rate))), entry = nearest((c.from + (rIn / fps - c.at) * c.rate) * fps, c.from * fps);
    let sIn = Math.max(0, Math.min(c.rate < 0 ? entry - m2 : entry, files.get(c.source).frames - m2));
    let e = { source: c.source, rate: c.rate, rIn, rOut, sIn, sOut: sIn + m2 }, p = out.at(-1);
    if (p && p.source === e.source && p.rate === e.rate && p.rOut === rIn && (e.rate > 0 ? p.sOut === e.sIn : p.sIn === e.sOut))
      Object.assign(p, { rOut, sIn: Math.min(p.sIn, e.sIn), sOut: Math.max(p.sOut, e.sOut) });
    else out.push(e);
  });
  return out;
}
function timecode(frames, fps, drop = false) {
  let n = Math.round(fps), p = (v) => String(v).padStart(2, "0");
  if (drop) {
    let d2 = n / 15, minute = n * 60 - d2, ten = minute * 10 + d2, k = frames % ten;
    frames += 9 * d2 * Math.floor(frames / ten) + (k > d2 ? d2 * Math.floor((k - d2) / minute) : 0);
  }
  let s = Math.floor(frames / n);
  return `${p(Math.floor(s / 3600))}:${p(Math.floor(s / 60) % 60)}:${p(s % 60)}${drop ? ";" : ":"}${p(frames % n)}`;
}
function rational(fps) {
  let n = Math.round(fps);
  if (Math.abs(fps - n) < 1e-6) return { timescale: n, delta: 1 };
  if (Math.abs(fps - n * 1e3 / 1001) < 5e-3) return { timescale: n * 1e3, delta: 1001 };
  return { timescale: Math.round(fps * 1e3), delta: 1e3 };
}
var SMPTE = [24e3 / 1001, 24, 25, 3e4 / 1001, 30, 48e3 / 1001, 48, 50, 6e4 / 1001, 60];
var DROP = [3e4 / 1001, 6e4 / 1001];
var dropRate = (fps) => DROP.some((r) => Math.abs(r - fps) < 1e-6);
function nameOf(src) {
  let n = String(src).split(/[\\/]/).pop().split(/[?#]/)[0];
  try {
    return /^\w+:\/\//.test(src) ? decodeURIComponent(n) : n;
  } catch {
    return n;
  }
}
async function fileUrl(src) {
  if (/^\w+:\/\//.test(src)) return src;
  try {
    let { pathToFileURL } = await import("url");
    return pathToFileURL((await import("path")).resolve(src)).href;
  } catch {
    return src;
  }
}
var xml = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
var oneLine = (s) => String(s).replace(/\s+/g, " ").trim();
var gcd2 = (a, b) => b ? gcd2(b, a % b) : a;
var seconds = (num, den) => {
  let g = gcd2(num, den) || 1;
  return den / g === 1 ? `${num / g}s` : `${num / g}/${den / g}s`;
};
var channel = (f) => f.video ? f.channels > 1 ? "AA/V" : "B" : f.channels > 1 ? "AA" : "A";
var HZ = { 32e3: "32k", 44100: "44.1k", 48e3: "48k", 88200: "88.2k", 96e3: "96k", 176400: "176.4k", 192e3: "192k" };
var FORMATS = {
  // CMX 3600 (CMX Systems 907567): TITLE (70 characters) and FCM, then a statement per event: its number (1 to 999;
  // past that the numbers widen, as Avid's longer lists do), reel AX (an auxiliary source: a file, not a tape) named by
  // its FROM CLIP NAME comment (Premiere, Resolve, Avid), channels, C (a cut), source in and out (the range used,
  // ascending), record in and out. A rate is an M2 motion memory line: reel, speed in frames per second to a tenth
  // (negative: reversed), the event's source in (Avid; Premiere's reverse, as pycmx's samples have it). Markers are Avid
  // locators, `* LOC: <record timecode> <colour> <text>`, after the event they fall in (OpenTimelineIO reads them too).
  edl({ events: events2, fps, drop, title, files, markers }) {
    if (!SMPTE.some((r) => Math.abs(r - fps) < 0.01)) throw new RangeError(`cuts: EDL timecode runs at 23.976 to 60 fps (SMPTE ST 12-1), not ${+fps.toFixed(3)}: use fcpxml or otio, or set fps`);
    let n = Math.round(fps), tc = (f) => timecode(f, fps, drop), k = 0;
    let lines = [`TITLE: ${oneLine(title).slice(0, 70)}`, `FCM: ${drop ? "DROP FRAME" : "NON-DROP FRAME"}`, ""];
    events2.forEach((e, i) => {
      let f = files.get(e.source), till = events2[i + 1]?.rIn ?? Infinity;
      lines.push(`${String(i + 1).padStart(3, "0")}  AX       ${channel(f).padEnd(5)} C        ${tc(f.start + e.sIn)} ${tc(f.start + e.sOut)} ${tc(e.rIn)} ${tc(e.rOut)}`);
      if (e.rate !== 1) lines.push(`M2   ${"AX".padEnd(8)}       ${(e.rate < 0 ? "-" : "") + Math.abs(e.rate * n).toFixed(1).padStart(5, "0")}                ${tc(f.start + e.sIn)}`);
      lines.push(`* FROM CLIP NAME: ${f.name}`);
      for (; k < markers.length && markers[k].at < till; k++) lines.push(`* LOC: ${tc(markers[k].at)} ${"RED".padEnd(7)} ${oneLine(markers[k].label)}`.trimEnd());
      lines.push("");
    });
    return lines.join("\n");
  },
  // OpenTimelineIO (ASWF), its JSON as opentimelineio 0.18 writes it: a Timeline of a Stack of tracks, a video track
  // when a file has a picture and an audio track, each its Clips (an ExternalReference to the file) and Gaps tiling the
  // output. A clip's source_range starts where it reads and lasts as long as it lasts on the track; a LinearTimeWarp's
  // time_scalar sets how fast it reads (it "does not affect the duration of the item this effect is attached to",
  // OTIO's time_scalar docs). The markers are the timeline's: on the Stack.
  otio({ events: events2, fps, title, files, markers, total }) {
    let rt = (v) => ({ OTIO_SCHEMA: "RationalTime.1", rate: fps, value: v });
    let range2 = (s, d2) => ({ OTIO_SCHEMA: "TimeRange.1", duration: rt(d2), start_time: rt(s) });
    let item = (schema, name, source_range) => ({ OTIO_SCHEMA: schema, metadata: {}, name, source_range, effects: [], markers: [], enabled: true, color: null });
    let track = (kind, takes) => {
      let children = [], at = 0, gap = (n) => n > 0 && children.push(item("Gap.1", "", range2(0, n)));
      for (let e of events2) {
        let f = files.get(e.source);
        if (!takes(f)) continue;
        gap(e.rIn - at);
        children.push({
          ...item("Clip.2", f.name, range2(f.start + e.sIn, e.rOut - e.rIn)),
          ...e.rate !== 1 && { effects: [{ OTIO_SCHEMA: "LinearTimeWarp.1", metadata: {}, name: "", effect_name: "LinearTimeWarp", enabled: true, time_scalar: e.rate }] },
          media_references: { DEFAULT_MEDIA: { OTIO_SCHEMA: "ExternalReference.1", metadata: {}, name: "", available_range: range2(f.start, f.frames), available_image_bounds: null, target_url: f.url } },
          active_media_reference_key: "DEFAULT_MEDIA"
        });
        at = e.rOut;
      }
      gap(total - at);
      return { ...item("Track.1", kind[0] + "1", null), children, kind };
    };
    let marks = markers.map((m2) => ({ OTIO_SCHEMA: "Marker.2", metadata: {}, name: m2.label, color: "RED", marked_range: range2(m2.at, m2.duration), comment: "" }));
    let video = [...files.values()].some((f) => f.video);
    return JSON.stringify({
      OTIO_SCHEMA: "Timeline.1",
      metadata: {},
      name: title,
      global_start_time: null,
      tracks: { ...item("Stack.1", "tracks", null), markers: marks, children: [...video ? [track("Video", (f) => f.video)] : [], track("Audio", () => true)] }
    }, null, 2);
  },
  // FCPXML 1.9 (Apple, FCPXMLv1_9.dtd: the first with media-rep, read by Final Cut Pro 10.5 on and Resolve): a format
  // of the frame duration, an asset per file (its start: the file's timecode), a project whose spine tiles the output
  // with asset-clips and gaps, every time a whole number of frames as a rational ("1001/30000s"). A rate is a timeMap:
  // timept time is the clip's own, retimed time, value the file's, linear between. A marker goes in the clip or gap it
  // falls in, at that item's own time.
  fcpxml({ events: events2, frame, drop, title, files, markers, total, sampleRate: sampleRate2, channels: channels2 }) {
    let t = (n) => seconds(n * frame.delta, frame.timescale), id = new Map([...files.keys()].map((s, i) => [s, `r${i + 2}`]));
    let picture = [...files.values()].find((f) => f.video)?.video, fmt3 = drop ? "DF" : "NDF";
    let assets = [...files].map(([s, f]) => `    <asset id="${id.get(s)}" name="${xml(f.name)}" start="${t(f.start)}" hasVideo="${f.video ? 1 : 0}" hasAudio="1"${f.video ? ' format="r1"' : ""} audioSources="1" audioChannels="${f.channels}" audioRate="${f.sampleRate}">
      <media-rep kind="original-media" src="${xml(f.url)}"/>
    </asset>`);
    let items = [], at = 0;
    let gap = (n) => {
      if (n > 0) items.push({ at, n, start: 0, open: `gap name="Gap" offset="${t(at)}" start="0s" duration="${t(n)}"`, tag: "gap", body: [] });
      at += Math.max(0, n);
    };
    for (let e of events2) {
      gap(e.rIn - at);
      let f = files.get(e.source), s = f.start + e.sIn, n = e.rOut - e.rIn, [v0, v1] = e.rate > 0 ? [e.sIn, e.sOut] : [e.sOut, e.sIn];
      items.push({
        at,
        n,
        start: s,
        tag: "asset-clip",
        open: `asset-clip ref="${id.get(e.source)}" offset="${t(at)}" name="${xml(f.name)}" start="${t(s)}" duration="${t(n)}" tcFormat="${fmt3}"`,
        body: e.rate === 1 ? [] : ["<timeMap>", `  <timept time="${t(s)}" value="${t(f.start + v0)}" interp="linear"/>`, `  <timept time="${t(s + n)}" value="${t(f.start + v1)}" interp="linear"/>`, "</timeMap>"]
      });
      at += n;
    }
    gap(total - at);
    let k = 0, spine = [];
    for (let it of items) {
      for (; k < markers.length && markers[k].at < it.at + it.n; k++)
        it.body.push(`<marker start="${t(it.start + markers[k].at - it.at)}" duration="${t(Math.max(1, markers[k].duration))}" value="${xml(oneLine(markers[k].label))}"/>`);
      spine.push(...it.body.length ? [`<${it.open}>`, ...it.body.map((b) => "  " + b), `</${it.tag}>`] : [`<${it.open}/>`]);
    }
    return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.9">
  <resources>
    <format id="r1" frameDuration="${t(1)}"${picture ? ` width="${picture.width}" height="${picture.height}"` : ""}/>
${assets.join("\n")}
  </resources>
  <library>
    <event name="${xml(title)}">
      <project name="${xml(title)}">
        <sequence format="r1" duration="${t(total)}" tcStart="0s" tcFormat="${fmt3}" audioLayout="${channels2 > 2 ? "surround" : channels2 > 1 ? "stereo" : "mono"}"${HZ[sampleRate2] ? ` audioRate="${HZ[sampleRate2]}"` : ""}>
          <spine>
${spine.map((l) => "            " + l).join("\n")}
          </spine>
        </sequence>
      </project>
    </event>
  </library>
</fcpxml>
`;
  }
};
var formats2 = Object.keys(FORMATS);
audio.fn.cuts = async function(format, opts = {}) {
  if (format && typeof format === "object") opts = format, format = null;
  if (format && !FORMATS[format]) throw new RangeError(`cuts: unknown format '${format}' (${formats2.join(", ")})`);
  await this[LOAD]();
  if (!this.decoded && this.ready) await this.ready;
  await loadRefs(this);
  let main = this.source ?? opts.url ?? null, page = this.pages[0];
  let fileOf = (i) => i === this || i.source == null && page && i.pages[0] === page ? main : i.source;
  let plan = buildPlan(this), clips = arrange(flatten(plan.segs, plan.sr, this, { memo: /* @__PURE__ */ new Map(), fileOf }));
  if (!clips.length) throw new Error("cuts: generated audio has no file for a cut list to point at");
  let video = await videoInfo(main).catch(() => null);
  let frame = opts.fps ? rational(opts.fps) : video ?? { timescale: 30, delta: 1 };
  let fps = frame.timescale / frame.delta;
  if (!format) return { fps, clips: clips.map(({ inst, ...c }) => c) };
  let drop = opts.dropFrame ?? (!!video?.drop && dropRate(fps));
  if (drop && !dropRate(fps)) throw new RangeError(`cuts: drop-frame timecode counts 29.97 or 59.94 fps (SMPTE ST 12-1), not ${+fps.toFixed(3)}`);
  let files = /* @__PURE__ */ new Map();
  for (let { source, inst } of clips) if (!files.has(source)) {
    let v = source === main ? video : await videoInfo(source).catch(() => null);
    files.set(source, {
      name: nameOf(source),
      url: source === main && opts.url || await fileUrl(source),
      video: v,
      channels: inst._.ch,
      sampleRate: inst._.sr,
      start: Math.round((v?.start ?? 0) * fps),
      frames: v ? Math.round(v.frames * v.delta / v.timescale * fps) : Math.ceil(inst._.len / inst._.sr * fps - 1e-9)
    });
  }
  let marks = opts.meta === false ? [] : [
    ...(opts.markers ?? this.markers).map((m2) => ({ at: Math.round(m2.time * fps), duration: 0, label: m2.label || "" })),
    ...(opts.regions ?? this.regions).map((r) => ({ at: Math.round(r.at * fps), duration: Math.round(r.duration * fps), label: r.label || "" }))
  ].sort((a, b) => a.at - b.at);
  return FORMATS[format]({
    events: events(clips, fps, files),
    fps,
    frame,
    drop,
    files,
    markers: marks,
    total: Math.round(this.duration * fps),
    title: opts.title ?? `${nameOf(main ?? clips[0].source).replace(/\.\w+$/, "")} cuts`,
    sampleRate: this.sampleRate,
    channels: this.channels
  });
};

// fn/save.js
var FMT_ALIAS = { aif: "aiff", oga: "ogg", mov: "mp4", m4v: "mp4" };
function encoderFor(fmt3) {
  return audio_encode_default[fmt3] || audio.codecs?.[fmt3]?.encode;
}
function resolveFormat(fmt3) {
  if (typeof fmt3 === "string") fmt3 = fmt3.toLowerCase();
  return FMT_ALIAS[fmt3] || fmt3 || "wav";
}
function gatherMeta(inst, opts) {
  if (opts.meta === false) return null;
  let meta = opts.meta && typeof opts.meta === "object" ? opts.meta : inst.meta;
  let sr = inst.sampleRate;
  let markers = (opts.markers ?? inst.markers ?? []).map((m2) => ({ sample: Math.round(m2.time * sr), label: m2.label || "" }));
  let regions = (opts.regions ?? inst.regions ?? []).map((r) => ({ sample: Math.round(r.at * sr), length: Math.round(r.duration * sr), label: r.label || "" }));
  let hasAny = meta && Object.keys(meta).some((k) => k !== "raw" && k !== "pictures" && meta[k] != null && meta[k] !== "") || meta?.pictures?.length || markers.length || regions.length;
  if (!hasAny) return null;
  return { meta: meta || {}, markers, regions };
}
var DEPTHS = { wav: [16, 24, 32], aiff: [16, 24], caf: [16, 32], flac: [16, 24], wv: [16, 24, 32], m4a: [16, 24, 32], mp4: [16, 24, 32] };
var ENCODE_OPTS = ["bitDepth", "bitrate", "quality", "codec", "compression"];
function encodeOpts(inst, fmt3, opts, m2) {
  let o = {};
  for (let k of ENCODE_OPTS) if (opts[k] != null) o[k] = opts[k];
  let depths = DEPTHS[fmt3], src = inst.bitDepth;
  if (o.bitDepth == null && depths && src > 16) o.bitDepth = depths.find((d2) => d2 >= src) ?? depths.at(-1);
  if ((fmt3 === "m4a" || fmt3 === "mp4" || fmt3 === "mp3") && m2) {
    let sr = inst.sampleRate;
    let ch = [...m2.markers.map((x) => ({ time: x.sample / sr, title: x.label })), ...m2.regions.map((x) => ({ time: x.sample / sr, title: x.label }))];
    if (ch.length) o.chapters = ch.sort((a, b) => a.time - b.time);
  }
  return o;
}
function hasVideo(b) {
  for (let i = 4; i + 16 <= b.length; i++)
    if (b[i] === 104 && b[i + 1] === 100 && b[i + 2] === 108 && b[i + 3] === 114 && b[i + 12] === 118 && b[i + 13] === 105 && b[i + 14] === 100 && b[i + 15] === 101) return true;
  return false;
}
async function videoSource(inst, fmt3, opts) {
  if (fmt3 !== "mp4" || opts.video === false) return null;
  let src = inst.source;
  if (typeof src === "string") {
    if (/^\w+:\/\//.test(src)) return null;
    try {
      src = new Uint8Array(await (await import("fs/promises")).readFile(src));
    } catch {
      return null;
    }
  } else if (src instanceof ArrayBuffer) src = new Uint8Array(src);
  else if (ArrayBuffer.isView(src)) src = new Uint8Array(src.buffer, src.byteOffset, src.byteLength);
  return src instanceof Uint8Array && hasVideo(src) ? src : null;
}
async function assertFrames(inst, opts, verb) {
  if (inst._.waiters && !inst.decoded) return;
  await inst[LOAD]();
  let at = await fromEnd(inst, parseTime(opts.at)) ?? 0;
  let dur = parseTime(opts.duration) ?? inst.duration - at;
  if (Math.round(Math.min(dur, inst.duration - at) * inst.sampleRate) < 1)
    throw new Error(`${verb}: nothing to ${verb} \u2014 empty range (audio is ${(inst.duration || 0).toFixed(3)}s)`);
}
var ENCODE_BATCH = 1 << 17;
async function encodeStream(inst, fmt3, opts, sink, stream2) {
  if (inst._.ready) await inst._.ready;
  let live = !!inst._.waiters && !inst.decoded && !inst.edits?.some((e) => audio.op?.(e[0])?.whole);
  if (fmt3 === "m4a" || fmt3 === "mp4") stream2 &&= live;
  let offset = await fromEnd(inst, parseTime(opts.at)), duration = parseTime(opts.duration), plan = null, frames;
  if (!live) {
    await inst[LOAD]();
    await loadRefs(inst);
    plan = buildPlan(inst);
    let s = Math.round((offset || 0) * plan.sr);
    frames = (duration != null ? s + Math.round(duration * plan.sr) : plan.totalLen) - s;
  }
  let m2 = gatherMeta(inst, opts);
  let enc = await encoderFor(fmt3)({ sampleRate: inst.sampleRate, channels: inst.channels, ...m2 || {}, ...encodeOpts(inst, fmt3, opts, m2), ...stream2 && { stream: true, frames } });
  let total = opts.duration != null ? parseTime(opts.duration) : null;
  if (live) {
    total ??= inst.duration;
    let written = 0, t = performance.now();
    for await (let chunk of inst.stream({ at: offset, duration })) {
      let buf = await enc(chunk);
      if (buf.length) await sink(buf);
      written += chunk[0].length;
      let now = performance.now();
      if (now - t > 8) {
        await yieldTask();
        t = performance.now();
      }
      emit(inst, "progress", { offset: written / inst.sampleRate, total });
    }
    if (!written) throw new Error("encode: nothing to encode \u2014 source ended empty");
  } else {
    total ??= inst.duration;
    await ensurePlan(inst, plan, offset, duration);
    let sr = inst.sampleRate, written = 0, batch = null, n = 0;
    let drain = async () => {
      let buf = await enc(n < batch[0].length ? batch.map((c) => c.subarray(0, n)) : batch);
      if (buf.length) await sink(buf);
      written += n;
      batch = null;
      n = 0;
      emit(inst, "progress", { offset: written / sr, total });
    };
    for (let chunk of streamPlan(inst, plan, offset, duration)) {
      let len = chunk[0].length;
      if (batch && n + len > batch[0].length) await drain();
      batch ??= chunk.map(() => new Float32Array(Math.max(ENCODE_BATCH, len)));
      for (let c = 0; c < chunk.length; c++) batch[c].set(chunk[c], n);
      n += len;
    }
    if (n) await drain();
  }
  let final = await enc();
  if (final.length) await sink(final);
  return sink(null, enc.head?.() || null);
}
audio.fn.encode = async function(fmt3, opts = {}) {
  if (typeof fmt3 === "object") {
    opts = fmt3;
    fmt3 = void 0;
  }
  opts = named(opts);
  fmt3 = resolveFormat(fmt3);
  if (formats2.includes(fmt3)) return new TextEncoder().encode(await this.cuts(fmt3, opts));
  if (!encoderFor(fmt3)) throw new Error(`encode: unknown format '${fmt3}'`);
  await assertFrames(this, opts, "encode");
  let parts = [], head = null;
  await encodeStream(this, fmt3, opts, (buf, h2) => {
    if (buf) parts.push(buf);
    else head = h2;
  });
  let total = 0;
  for (let p of parts) total += p.length;
  let out = new Uint8Array(total), pos = 0;
  for (let p of parts) {
    out.set(p, pos);
    pos += p.length;
  }
  if (head) out.set(head, 0);
  return out;
};
audio.fn.save = async function(target, opts = {}) {
  opts = named(opts);
  let fmt3 = opts.format ?? (typeof target === "string" ? target.split(".").pop() : "wav");
  fmt3 = resolveFormat(fmt3);
  if (!encoderFor(fmt3) && !formats2.includes(fmt3)) throw new Error(`save: unknown format '${fmt3}'`);
  await assertFrames(this, opts, "save");
  let write, finish;
  if (typeof target === "string") {
    let { createWriteStream } = await import("fs");
    let ws = createWriteStream(target, { highWaterMark: 1 << 22 });
    let err = null;
    ws.on("error", (e) => {
      err = e;
    });
    write = (buf) => {
      if (err) throw err;
      if (!ws.write(Buffer.from(buf))) return new Promise((res, rej) => {
        let settle = (e) => {
          ws.off("drain", settle);
          ws.off("error", settle);
          e ? rej(e) : res();
        };
        ws.on("drain", settle);
        ws.on("error", settle);
      });
    };
    finish = async (head) => {
      await new Promise((res, rej) => {
        if (err) return rej(err);
        ws.on("finish", res);
        ws.on("error", rej);
        ws.end();
      });
      if (!head) return;
      let fh = await (await import("fs/promises")).open(target, "r+");
      try {
        await fh.write(head, 0, head.length, 0);
      } finally {
        await fh.close();
      }
    };
  } else if (target?.write) {
    write = (buf) => target.write(buf);
    finish = async (head) => {
      if (head && typeof target.seek === "function") {
        await target.seek(0);
        await target.write(head);
      }
      return target.close?.();
    };
  } else throw new Error("Invalid save target");
  if (formats2.includes(fmt3)) {
    await write(await this.encode(fmt3, opts));
    return finish();
  }
  let video = await videoSource(this, fmt3, opts);
  if (video) {
    let { remux } = await import("@audio/encode-mp4/remux");
    await write(remux(video, await this.encode(fmt3, opts)));
    return finish?.();
  }
  await encodeStream(this, fmt3, opts, (buf, head) => buf ? write(buf) : finish(head), true);
};

// fn/crop.js
var cropPlan = (segs, ctx) => {
  let { total, length } = ctx;
  let s = planOffset(ctx.offset, total);
  return sliceSegs(segs, s, Math.max(0, Math.min(length ?? total - s, total - s)));
};
audio.op("crop", { plan: cropPlan });

// fn/gain.js
var gain = (input, output, ctx) => {
  let lin = ctx.unit === "linear", val = ctx.value ?? (lin ? 1 : 0);
  let len = input[0].length;
  let [s, end] = opRange(ctx, len);
  let auto = typeof val === "function";
  let f = auto ? 0 : lin ? +val : 10 ** (+val / 20);
  if (!auto && Number.isNaN(f)) throw new TypeError(`gain: invalid value '${ctx.value}'`);
  let off = (ctx.blockOffset || 0) * ctx.sampleRate;
  let toMul = lin ? (v) => v : (v) => 10 ** (v / 20);
  s = Math.max(0, Math.min(s, len));
  end = Math.max(s, Math.min(end, len));
  for (let c = 0; c < input.length; c++) {
    let inp = input[c], out = output[c];
    if (s > 0) out.set(inp.subarray(0, s));
    for (let i = s; i < end; i++) out[i] = inp[i] * (auto ? toMul(val((off + i) / ctx.sampleRate)) : f);
    if (end < len) out.set(inp.subarray(end), end);
  }
};
audio.op("gain", {
  params: ["value"],
  ranged: true,
  auto: "sample",
  process: gain,
  deriveStats: (stats, opts) => {
    let val = opts.value ?? 0;
    if (typeof val === "function" || typeof val === "object") return false;
    let lin = opts.unit === "linear";
    let g = lin ? val : 10 ** (val / 20);
    let g2 = g * g;
    let ch = stats.min.length;
    for (let c = 0; c < ch; c++) {
      let n = stats.min[c].length;
      for (let i = 0; i < n; i++) {
        let lo = stats.min[c][i] * g, hi = stats.max[c][i] * g;
        stats.min[c][i] = Math.min(lo, hi);
        stats.max[c][i] = Math.max(lo, hi);
        if (stats.dc) stats.dc[c][i] *= g;
        if (stats.ms) stats.ms[c][i] *= g2;
        if (stats.energy) stats.energy[c][i] *= g2;
      }
      if (stats.clipping) for (let i = 0; i < n; i++)
        stats.clipping[c][i] = stats.min[c][i] <= -FULL || stats.max[c][i] >= FULL ? Math.max(1, stats.clipping[c][i]) : 0;
    }
  }
});

// fn/fade.js
var CURVES = {
  linear: (t) => t,
  exp: (t) => t * t,
  log: (t) => Math.sqrt(t),
  cos: (t) => (1 - Math.cos(t * Math.PI)) / 2
};
var fade = (input, output, ctx) => {
  let dur = ctx.in;
  if (!dur) {
    for (let c = 0; c < input.length; c++) output[c].set(input[c]);
    return;
  }
  let fn3 = CURVES[ctx.curve] ?? CURVES.linear;
  let fadeIn = dur > 0, n = Math.abs(dur);
  let sr = ctx.sampleRate, blockOffset = ctx.blockOffset || 0;
  let at = ctx.at != null ? ctx.at + blockOffset : void 0;
  if (at != null && at < 0) at = ctx.totalDuration + at;
  let { start, end, mid } = ctx;
  let skew = mid > 0 && mid < 1 ? Math.log(0.5) / Math.log(mid) : 1;
  let levels = start != null || end != null || skew !== 1;
  let s0 = start ?? (fadeIn ? 0 : 1), s1 = end ?? (fadeIn ? 1 : 0);
  let totalSamples = Math.round((ctx.totalDuration || input[0].length / sr + blockOffset) * sr);
  let fadeStart = at != null ? Math.round(at * sr) : fadeIn ? 0 : totalSamples - Math.round(n * sr);
  let samples = Math.round(n * sr);
  let chunkStart = Math.round(blockOffset * sr);
  for (let c = 0; c < input.length; c++) {
    let inp = input[c], out = output[c];
    for (let i = 0; i < inp.length; i++) {
      let fi = chunkStart + i - fadeStart;
      if (fi < 0 || fi >= samples) {
        out[i] = inp[i];
        continue;
      }
      let u = fi / samples;
      out[i] = inp[i] * (levels ? s0 + (s1 - s0) * fn3(skew === 1 ? u : u ** skew) : fn3(fadeIn ? u : 1 - u));
    }
  }
};
audio.op("fade", {
  params: ["in", "out", "curve"],
  // the level along a fade in, 0..1 over 0..1, by the name `curve` takes: audio.op('fade').curves
  curves: CURVES,
  ranged: true,
  holdback: (o, sr) => o.in < 0 && o.at == null ? -o.in * sr : 0,
  // a fade-out ends where the audio does
  process: fade,
  expand: (ctx) => {
    if (typeof ctx.out === "string") return [["fade", { in: ctx.in, curve: ctx.out, ...ctx.mid != null && { mid: ctx.mid } }]];
    if (typeof ctx.out !== "number") return null;
    let base = { ...ctx.curve && { curve: ctx.curve }, ...ctx.mid != null && { mid: ctx.mid } };
    let edits = [];
    if (typeof ctx.in === "number") edits.push(["fade", { in: ctx.in, ...base }]);
    edits.push(["fade", { in: -Math.abs(ctx.out), ...base }]);
    return edits;
  }
});

// fn/resample.js
var SINC_HALF = 16;
var MAX_HALF = 64;
var sinc = (x) => x === 0 ? 1 : Math.sin(Math.PI * x) / (Math.PI * x);
var lanczos = (x, a) => sinc(x) * sinc(x / a);
var PHASES = 2048;
var banks = /* @__PURE__ */ new Map();
function bank(scale) {
  let b = banks.get(scale);
  if (b) return b;
  let half = Math.min(MAX_HALF, Math.ceil(SINC_HALF / scale - 1e-9)), taps = 2 * half, a = half * scale;
  let P = Math.ceil(PHASES * scale), T = new Float64Array((P + 1) * taps), W = new Float64Array(P + 1);
  for (let p = 0; p <= P; p++) {
    let w = 0;
    for (let j = 0; j < taps; j++) w += T[p * taps + j] = lanczos((j + 1 - half - p / P) * scale, a);
    W[p] = w;
  }
  banks.set(scale, b = { T, W, P, half, taps, a });
  return b;
}
function sincInterp(src, target, tOff, n, rate, phase = 0) {
  let absR = Math.abs(rate), rev = rate < 0;
  let scale = absR > 1 ? 1 / absR : 1;
  let k = bank(scale), { T, W, P, half, taps } = k, len = src.length;
  for (let i = 0; i < n; i++) {
    let pos = (rev ? n - 1 - i : i) * absR + phase;
    let base = Math.floor(pos), f = (pos - base) * P, p = Math.floor(f), mu = f - p, s0 = base + 1 - half;
    if (s0 < 0 || s0 + taps > len) {
      target[tOff + i] = edge(src, base, pos - base, scale, k);
      continue;
    }
    let r0 = p * taps, r1 = r0 + taps, a0 = 0, a1 = 0, b0 = 0, b1 = 0;
    for (let j = 0; j < taps; j += 2) {
      let x = src[s0 + j], y2 = src[s0 + j + 1];
      a0 += T[r0 + j] * x;
      a1 += T[r0 + j + 1] * y2;
      b0 += T[r1 + j] * x;
      b1 += T[r1 + j + 1] * y2;
    }
    let a = a0 + a1, w = W[p] + mu * (W[p + 1] - W[p]);
    target[tOff + i] = w !== 0 ? (a + mu * (b0 + b1 - a)) / w : 0;
  }
}
sincInterp.margin = MAX_HALF;
function edge(src, base, frac, scale, { half, a }) {
  let sum = 0, w = 0;
  for (let t = 1 - half; t <= half; t++) {
    let idx = base + t;
    if (idx < 0 || idx >= src.length) continue;
    let k = lanczos((t - frac) * scale, a);
    sum += src[idx] * k;
    w += k;
  }
  return w !== 0 ? sum / w : 0;
}
var INTERP = { sinc: sincInterp };
function readRate(rate) {
  if (typeof rate !== "number" || !Number.isFinite(rate) || rate <= 0)
    throw new RangeError("resample: rate must be a positive finite number");
  return Math.round(rate);
}
function readType(type) {
  if (type == null) return null;
  if (!Object.hasOwn(INTERP, type) && type !== "linear")
    throw new RangeError(`resample: unknown type "${type}"`);
  return type;
}
function resampleSegs(segs, factor, interp) {
  return segs.map((s) => {
    let a = Math.round(s[2] * factor), b = Math.round((s[2] + s[1]) * factor);
    let rate = s[4] === null ? void 0 : (s[3] || 1) / factor;
    let nextInterp = interp === null ? void 0 : interp || s[5];
    return seg(s[0], b - a, a, rate, s[4], s[4] === null ? void 0 : nextInterp, s[6]);
  });
}
var resamplePlan = (segs, ctx) => {
  let targetRate = readRate(ctx.rate);
  let factor = targetRate / ctx.sampleRate;
  if (factor === 1) return segs;
  let type = readType(ctx.type);
  let interp = type === "linear" ? null : INTERP[type] || (factor < 1 ? sincInterp : void 0);
  return resampleSegs(segs, factor, interp);
};
audio.op("_resample_seg", { hidden: true, plan: resamplePlan, sr: (curSr, ctx) => readRate(ctx.rate) });
audio.op("resample", {
  params: ["rate"],
  sr: (curSr, ctx) => readRate(ctx.rate),
  expand: (ctx) => {
    let targetRate = readRate(ctx.rate);
    let type = readType(ctx.type);
    if (targetRate === ctx.sampleRate) return false;
    let opts = { rate: Math.round(targetRate) };
    if (type) opts.type = type;
    return ["_resample_seg", opts];
  }
});

// fn/remix.js
var K = Math.SQRT1_2;
var DOWN = {
  1: [[K, K, 1, 0.5, 0.5]],
  2: [[1, 0, K, K, 0], [0, 1, K, 0, K]],
  3: [[1, 0, 0, K, 0], [0, 1, 0, 0, K], [0, 0, 1, 0, 0]],
  4: [[1, 0, K, 0, 0], [0, 1, K, 0, 0], [0, 0, 0, 1, 0], [0, 0, 0, 0, 1]],
  5: [[1, 0, 0, 0, 0], [0, 1, 0, 0, 0], [0, 0, 1, 0, 0], [0, 0, 0, 1, 0], [0, 0, 0, 0, 1]]
};
var SRC = {
  3: [[0], [1], [2], [], []],
  // L R C
  4: [[0], [1], [], [2], [3]],
  // L R Ls Rs
  5: [[0], [1], [2], [3], [4]],
  // L R C Ls Rs
  6: [[0], [1], [2], [4], [5]],
  // L R C LFE Ls Rs
  8: [[0], [1], [2], [4, 6], [5, 7]]
  // L R C LFE Lb Rb Ls Rs
};
function downmix(n, m2) {
  if (m2 === 6) {
    let rows2 = n > 6 && downmix(n, 5);
    if (!rows2) return null;
    let lfe = new Float64Array(n);
    lfe[3] = 1;
    return [...rows2.slice(0, 3), lfe, ...rows2.slice(3)];
  }
  let rows = DOWN[m2], src = SRC[n];
  if (!rows || !src) return null;
  return rows.map((row) => {
    let r = new Float64Array(n);
    for (let s = 0; s < 5; s++) for (let c of src[s]) r[c] += row[s];
    return r;
  });
}
var remix = (input, output, ctx) => {
  let arg = ctx.layout, len = input[0].length;
  if (Array.isArray(arg)) {
    for (let c = 0; c < output.length; c++) {
      let src = arg[c];
      if (src == null) output[c].fill(0);
      else output[c].set(input[(src % input.length + input.length) % input.length]);
    }
    return;
  }
  let n = input.length, m2 = arg;
  if (n === m2) {
    for (let c = 0; c < n; c++) output[c].set(input[c]);
    return;
  }
  let mx = m2 < n && (ctx._mx?.n === n ? ctx._mx.rows : (ctx._mx = { n, rows: downmix(n, m2) }).rows);
  if (mx) {
    for (let o = 0; o < m2; o++) {
      let out = output[o], row = mx[o];
      out.fill(0);
      for (let c = 0; c < n; c++) {
        let k = row[c];
        if (k) {
          let x = input[c];
          for (let i = 0; i < len; i++) out[i] += k * x[i];
        }
      }
    }
    return;
  }
  if (m2 < n) {
    output[0].fill(0);
    for (let c = 0; c < n; c++)
      for (let i = 0; i < len; i++) output[0][i] += input[c][i];
    let inv = 1 / n;
    for (let i = 0; i < len; i++) output[0][i] *= inv;
    for (let c = 1; c < m2; c++) output[c].set(output[0]);
    return;
  }
  for (let c = 0; c < m2; c++) output[c].set(input[c % n]);
};
var remixCh = (curCh, ctx) => {
  let m2 = Array.isArray(ctx.layout) ? ctx.layout.length : ctx.layout;
  return m2 === curCh ? 0 : m2;
};
audio.op("remix", { params: ["layout"], process: remix, ch: remixCh });

// fn/reverse.js
function reverseSegs(segs, off, end) {
  let r = [];
  for (let s of segs) {
    let se = s[2] + s[1];
    if (se <= off || s[2] >= end) {
      r.push(s);
      continue;
    }
    if (s[2] < off) r.push(subSeg(s, s[2], off - s[2], s[2]));
    let iStart = Math.max(s[2], off), iEnd = Math.min(se, end);
    r.push(subSeg(s, iStart, iEnd - iStart, off + end - iEnd, iEnd - iStart, s[3], true));
    if (se > end) r.push(subSeg(s, end, se - end, end));
  }
  r.sort((a, b) => a[2] - b[2]);
  return r;
}
var reversePlan = (segs, ctx) => {
  let { total, length } = ctx;
  let s = planOffset(ctx.offset, total);
  return reverseSegs(segs, s, s + (length ?? total - s));
};
audio.op("reverse", { plan: reversePlan });

// .work/game-audio-entry.js
var game_audio_entry_default = audio;
export {
  game_audio_entry_default as default
};
