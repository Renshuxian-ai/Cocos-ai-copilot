'use strict';

const NAME = 'cocos-ai-copilot';
const { createAssetPreview } = require('./asset-preview');
const { createSourceSwitch } = require('../lib/asset-preview/source-switch');
const request = (method, payload) => Editor.Message.request(NAME, method, payload);
module.exports = Editor.Panel.define({
  template: `<div id="root"><div id="viewer"></div><div id="notice" role="status">选择图片或从聊天打开预览。</div><div id="confirm" hidden><p>当前图片有未保存修改。切换图片将放弃这些修改。</p><button id="discard">放弃并切换</button><button id="keep">继续编辑</button></div></div>`,
  style: `:host{display:block;height:100%;min-height:0;color-scheme:dark}#root{height:100%;position:relative;overflow:hidden;background:#0b0c0e;color:#dedfe1;font:12px/1.45 Inter,"Segoe UI",system-ui,sans-serif}#viewer{position:absolute;inset:0}#notice{padding:12px;color:#8f9196;pointer-events:none}#confirm{position:absolute;z-index:50;left:50%;bottom:18px;width:min(420px,calc(100% - 28px));transform:translateX(-50%);padding:14px;border:0;border-radius:11px;background:linear-gradient(145deg,rgba(54,55,59,.94),rgba(27,28,31,.96));box-shadow:0 16px 46px rgba(0,0,0,.48),inset 0 1px rgba(255,255,255,.06);backdrop-filter:blur(18px)}#confirm[hidden]{display:none}#confirm p{margin:0 0 12px;color:#dadadd}button{height:30px;margin-right:7px;padding:4px 11px;border:0;border-radius:7px;background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.055));color:#e5e5e6;box-shadow:inset 0 1px rgba(255,255,255,.04);cursor:pointer}button:hover{background:linear-gradient(180deg,rgba(255,255,255,.15),rgba(255,255,255,.08))}#keep{background:rgba(255,255,255,.13)}#discard{color:#efb4b0}`,
  $: { root:'#root', viewer:'#viewer', notice:'#notice', confirm:'#confirm', discard:'#discard', keep:'#keep' },
  listeners: {
    hide() { this._switch?.viewer?.actions.pause(); },
    show() { this._switch?.viewer?.fit(); },
  },
  methods: {
    async agentAction(payload) {
      if(this._agentCall)throw Error('图片编辑器正在处理另一个操作。');
      this._agentCall=payload.callId;
      try {
        if(payload.command==='open') {
          if(this._switch.viewer?.state.dirty||this._switch.viewer?.state.busy)throw Error('已有未保存的图片草稿，请先保存或由用户明确关闭。');
          const ok=await this.setSource({...payload.source,sessionId:payload.sessionId,identity:payload.source.identity,mode:'sheet'});
          if(!ok)throw Error('无法打开图片。');
          this._agentOwner=payload.sessionId;
        }
        const viewer=this._switch.viewer;
        if(!viewer||this._agentOwner!==payload.sessionId)throw Error('请先通过 image_editor_open 打开本会话的图片。');
        if(payload.args.editorId&&payload.args.editorId!==this._editorId)throw Error('图片已切换，请重新打开并检查。');
        const data=await viewer.agentAction(payload.command==='open'?'inspect':payload.command,payload.args);
        return {editorId:this._editorId,...data};
      } finally { this._agentCall=null; }
    },
    async setSource(source) {
      if (this._closing || !source) return false;
      this._selectionToken = (this._selectionToken || 0) + 1;
      this._sessionId = source.sessionId || this._sessionId;
      if (source.empty) return true;
      try { return await this._switch.select(source); }
      catch (error) { if (!this._closing) (this._switch.viewer || this._emptyViewer)?.showError(error); return false; }
    },
    async commitFromWorkbench(params, source = {}) {
      const sessionId = source.sessionId || this._sessionId;
      const payload = { ...params, sessionId };
      const panelResult = await request('commit-preview-assets', payload);
      if (panelResult && typeof panelResult === 'object') return panelResult;
      // Asset Preview can stay open while the chat panel is closed or is being
      // recreated. Keep project writes functional and Review-backed in that state.
      const taskId = `asset-preview:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;
      return request('save-artifact', { ...payload, kind:'asset-preview-commit', taskId });
    },
    async requestClose(options = {}) {
      const state = this._switch?.viewer?.state;
      if (state?.busy || state?.preparing || state?.drag) throw Error('图片编辑器正在操作，请稍后关闭。');
      if (state?.dirty && options.discard !== true && !await this.confirmDiscard('close')) return false;
      await Editor.Panel.close(`${NAME}.asset-preview`); return true;
    },
    confirmDiscard(action = 'switch') {
      this.$.confirm.querySelector('p').textContent = action === 'close'
        ? '当前图片有未保存修改。关闭将放弃这些修改。'
        : '当前图片有未保存修改。切换图片将放弃这些修改。';
      this.$.discard.textContent = action === 'close' ? '放弃并关闭' : '放弃并切换';
      this.$.confirm.hidden = false;
      return new Promise(resolve => { this._resolveDiscard = value => { this.$.confirm.hidden = true; this._resolveDiscard = null; resolve(value); }; });
    },
  },
  ready() {
    this._closing = false; this._editorSequence=0;
    this.$.notice.textContent = '';
    this._emptyViewer = createAssetPreview(this.$.viewer, {
      read: async () => null,
      requestClose: options => this.requestClose(options),
    });
    this._switch = createSourceSwitch({
      read: source => request('get-attachment-thumbnail', { ...source, kind:'asset-preview-source' }),
      confirmDiscard: () => this.confirmDiscard(),
      mount: (loaded, source) => {
        this._editorId=`image-editor:${Date.now()}:${++this._editorSequence}`;this._agentOwner=null;
        this._emptyViewer?.destroy(); this._emptyViewer = null;
        this.$.notice.textContent = '';
        return createAssetPreview(this.$.viewer, {
          read: async () => loaded,
          context: () => request('get-attachment-thumbnail', { kind:'asset-preview-context' }),
          process: params => request('image-workbench-action', { ...params, source:{...source,sessionId:source.sessionId||this._sessionId}, sessionId:source.sessionId||this._sessionId }),
          commit: params => this._agentCall
            ? request('image-editor-commit', { ...params, callId:this._agentCall })
            : this.commitFromWorkbench(params, source),
          locate: value => request('locate-change-target', { assetUuid:value.assetUuid, assetUrl:value.assetUrl }),
          review: result => {
            const turnId = result?.changeSet?.turnId || result?.turnId || result?.taskId;
            if (!turnId) throw Error('当前还没有可查看的改动记录。');
            return request('open-changes', { sessionId:source.sessionId, turnId });
          },
          requestClose: options => this.requestClose(options),
          showPreview: async () => {
            await Editor.Panel.focus('scene');
            // Creator measures the docked guest during initialization. Let the
            // newly selected tab finish layout before starting Game View.
            const view = this.$.viewer.ownerDocument.defaultView;
            await new Promise(resolve => view.requestAnimationFrame(() => view.requestAnimationFrame(resolve)));
          },
        });
      },
    });
    this._discard = () => this._resolveDiscard?.(true);
    this._keep = () => this._resolveDiscard?.(false);
    this.$.discard.addEventListener('click', this._discard); this.$.keep.addEventListener('click', this._keep);
    this._selection = async type => {
      if (this._closing || this._agentCall) return;
      if (type === 'node') {
        try { await this._switch.viewer?.refreshContext(); }
        catch (error) { this._switch.viewer?.showError(error); }
        return;
      }
      if (type !== 'asset') return;
      const token = this._selectionToken = (this._selectionToken || 0) + 1;
      try {
        const source = await request('get-attachment-thumbnail', { kind:'asset-preview-selection' });
        // Locate selects the image already displayed. Preserve its draft and
        // Agent ownership even when the selection broadcast arrives after the call.
        if (source?.target && source.target === this._switch.viewer?.agentSnapshot().source.assetUuid) return;
        if (!this._closing && token === this._selectionToken && source) await this.setSource({ ...source, sessionId:this._sessionId });
      } catch (_) { /* A disappeared or non-image selection leaves the current viewer intact. */ }
    };
    Editor.Message.addBroadcastListener('selection:select', this._selection);
    this._unselection = type => { if (type === 'node') return this._selection(type); };
    Editor.Message.addBroadcastListener('selection:unselect', this._unselection);
  },
  close() {
    this._closing = true; this._selectionToken++;
    Editor.Message.removeBroadcastListener('selection:select', this._selection);
    Editor.Message.removeBroadcastListener('selection:unselect', this._unselection);
    this._resolveDiscard?.(false); this._switch?.destroy(); this._emptyViewer?.destroy(); this._emptyViewer = null;
    this.$.discard.removeEventListener('click', this._discard); this.$.keep.removeEventListener('click', this._keep);
  },
});
