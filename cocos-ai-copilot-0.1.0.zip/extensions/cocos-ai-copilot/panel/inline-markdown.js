'use strict';

const INLINE_TOKEN = /(`([^`\r\n]+)`)|(\*\*([^*\r\n]+)\*\*)|(\[([^\]\r\n]+)\]\(([^)\r\n]+)\))/gu;

function tokenizeInlineMarkdown(value) {
  const text = String(value || '');
  const tokens = [];
  let cursor = 0;
  let match;
  INLINE_TOKEN.lastIndex = 0;
  while ((match = INLINE_TOKEN.exec(text))) {
    if (match.index > cursor) tokens.push({ type: 'text', text: text.slice(cursor, match.index) });
    if (match[1]) tokens.push({ type: 'code', text: match[2] });
    else if (match[3]) tokens.push({ type: 'strong', text: match[4] });
    else tokens.push({ type: 'reference', text: match[6], target: match[7] });
    cursor = match.index + match[0].length;
  }
  if (cursor < text.length) tokens.push({ type: 'text', text: text.slice(cursor) });
  return tokens;
}

module.exports = { tokenizeInlineMarkdown };
