'use strict';

const { mcpStatus } = require('../lib/mcp-service-presentation');
const { normalizeService } = require('../lib/mcp-config-normalizer');
const { entryLaunch, localFormState, applicationEnvName, applyApplication } = require('../lib/mcp-local-form');

const EXTENSION_NAME = 'cocos-ai-copilot';
const MODEL_SERVICES_EVENT_CHANNEL = `${EXTENSION_NAME}:model-services-changed`;
const SETTINGS_NAVIGATION_EVENT_CHANNEL = `${EXTENSION_NAME}:settings-navigation`;
const SESSION_LIFECYCLE_EVENT_CHANNEL = `${EXTENSION_NAME}:session-lifecycle-changed`;
const MCP_SERVICES_EVENT_CHANNEL = `${EXTENSION_NAME}:mcp-services-changed`;

// Static help copy only. Keep the explanation available to assistive technology
// without adding another permanent row to the form.
function mcpHelp(id, label, explanation) {
  return `<span class="mcp-help"><button class="mcp-help-trigger" type="button" aria-label="${label}说明" aria-describedby="${id}"><svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6"/><path d="M8 7v4M8 4.7v.1"/></svg></button><span id="${id}" class="mcp-help-tooltip" role="tooltip"><span>${explanation}</span></span></span>`;
}

const template = `
  <main class="settings-root">
    <header class="settings-header">
      <h1>设置</h1>
    </header>
    <div class="settings-layout">
      <nav class="settings-nav" aria-label="设置分类">
        <button id="servicesNav" class="nav-item is-active" type="button">模型服务</button>
        <button id="cocosNav" class="nav-item" type="button">Cocos MCP</button>
        <button id="mcpNav" class="nav-item" type="button">MCP 服务</button>
        <button id="environmentNav" class="nav-item" type="button">工具环境</button>
        <button id="runtimeNav" class="nav-item" type="button">Runtime</button>
        <button id="archivedNav" class="nav-item" type="button">已归档的会话</button>
      </nav>
      <section class="settings-content">
        <div id="servicesPage" class="settings-page">
          <div id="providerListView">
            <div class="page-heading"><div class="heading-actions"><h2>模型服务</h2><button id="servicesCheckButton" class="text-button" type="button">检查模型状态</button></div><p>选择 AI Copilot 使用的模型 Provider。</p></div>
            <div class="provider-list">
              <button id="openaiRow" class="provider-row" type="button">
                <span id="openaiDot" class="status-dot"></span>
                <span class="provider-row-copy"><strong>OpenAI</strong><small id="openaiRowSummary">正在检查…</small></span>
                <span class="provider-chevron" aria-hidden="true">›</span>
              </button>
              <button id="deepseekRow" class="provider-row" type="button">
                <span id="deepseekDot" class="status-dot"></span>
                <span class="provider-row-copy"><strong>DeepSeek</strong><small id="deepseekRowSummary">正在检查…</small></span>
                <span class="provider-chevron" aria-hidden="true">›</span>
              </button>
            </div>
            <p id="storageNotice" class="storage-notice"></p>
          </div>

          <section id="openaiDetail" class="provider-detail" hidden>
            <button id="openaiBack" class="back-action" type="button">← <span>OpenAI</span></button>
            <div class="detail-heading"><h2>OpenAI</h2><p id="openaiCurrentAuth">当前使用：未选择</p></div>
            <div class="method-tabs" role="group" aria-label="OpenAI 当前认证方式">
              <button id="chatgptMethod" class="method-tab" type="button"><span>ChatGPT</span><small id="chatgptMethodState">未登录</small></button>
              <button id="openaiKeyMethod" class="method-tab" type="button"><span>API Key</span><small id="openaiKeyMethodState">未配置</small></button>
            </div>

            <div id="chatgptPane" class="method-pane">
              <div class="credential-row">
                <div><strong>ChatGPT</strong><p id="chatgptState">系统 Codex 未登录</p></div>
                <button id="chatgptLoginButton" class="icon-button credential-refresh" type="button" title="重新检查登录状态" aria-label="重新检查登录状态">
                  <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M13 5.5A5.5 5.5 0 1 0 13.2 10M13 2v3.5H9.5"/></svg>
                </button>
              </div>
              <div class="button-row">
                <button id="chatgptStartButton" class="primary-button" type="button">使用 ChatGPT 登录</button>
                <button id="chatgptDisconnectButton" class="text-button" type="button" hidden>不再用于 AI Copilot</button>
              </div>
              <p id="chatgptMessage" class="inline-message" hidden></p>
              <p class="muted">断开后，系统 Codex 登录仍然保留，也不会影响 VS Code Codex 或 Codex CLI。</p>
            </div>

            <div id="openaiKeyPane" class="method-pane" hidden>
              <div id="openaiSavedKey" class="saved-secret" hidden>
                <div><strong>API Key</strong><p>已配置 · 已验证</p></div><span class="masked-secret">••••••••••••</span>
                <div class="button-row"><button id="openaiChangeButton" class="secondary-button" type="button">更换 Key</button><button id="openaiRemoveButton" class="text-button danger" type="button">删除 Key</button></div>
              </div>
              <div id="openaiKeyEditor" class="secret-editor">
                <label class="field-label" for="openaiKeyInput">输入新的 API Key</label>
                <div class="secret-row"><input id="openaiKeyInput" type="password" autocomplete="off" spellcheck="false" placeholder="API Key"/><button id="openaiRevealButton" class="icon-button reveal-button" type="button" title="暂时显示" aria-label="暂时显示当前输入的 API Key">◉</button></div>
                <div class="button-row"><button id="openaiVerifyButton" class="primary-button" type="button">验证并使用</button><button id="openaiCancelEdit" class="text-button" type="button" hidden>取消</button></div>
              </div>
              <p id="openaiKeyMessage" class="inline-message" hidden></p>
            </div>
            <div class="model-summary"><span class="summary-label">模型</span><strong id="openaiModelStatus">模型列表尚不可用</strong></div>
          </section>

          <section id="deepseekDetail" class="provider-detail" hidden>
            <button id="deepseekBack" class="back-action" type="button">← <span>DeepSeek</span></button>
            <div class="detail-heading"><h2>DeepSeek</h2><p id="deepseekSummary">未配置</p></div>
            <div id="deepseekSavedKey" class="saved-secret" hidden>
              <div><strong>API Key</strong><p>已配置 · 已验证</p></div><span class="masked-secret">••••••••••••</span>
              <div class="button-row"><button id="deepseekChangeButton" class="secondary-button" type="button">更换 Key</button><button id="deepseekRemoveButton" class="text-button danger" type="button">删除 Key</button></div>
            </div>
            <div id="deepseekKeyEditor" class="secret-editor">
              <label class="field-label" for="deepseekKeyInput">输入新的 API Key</label>
              <div class="secret-row"><input id="deepseekKeyInput" type="password" autocomplete="off" spellcheck="false" placeholder="API Key"/><button id="deepseekRevealButton" class="icon-button reveal-button" type="button" title="暂时显示" aria-label="暂时显示当前输入的 API Key">◉</button></div>
              <div class="button-row"><button id="deepseekVerifyButton" class="primary-button" type="button">验证并使用</button><button id="deepseekCancelEdit" class="text-button" type="button" hidden>取消</button></div>
            </div>
            <p id="deepseekKeyMessage" class="inline-message" hidden></p>
            <div class="model-summary"><span class="summary-label">模型</span><strong id="deepseekModelStatus">模型列表尚不可用</strong></div>
          </section>
        </div>

        <div id="archivedPage" class="settings-page" hidden>
          <div class="page-heading"><div class="heading-actions"><h2>已归档的会话</h2><button id="archivedCheckButton" class="text-button" type="button">重新读取</button></div><p>当前项目的本地聊天。</p></div>
          <p id="archivedMessage" class="inline-message" role="status" hidden></p>
          <div id="archivedList" class="archived-list" aria-label="已归档的会话"></div>
        </div>

        <div id="cocosPage" class="settings-page" hidden>
          <div class="page-heading">
            <h2>Copilot 内置能力</h2>
            <p>Copilot 在当前项目中直接使用的 Tools 与 Skills。</p>
          </div>
          <section class="capability-card">
            <details class="builtin-capability">
              <summary>
                <span class="builtin-capability-copy"><strong>Tools</strong><small id="cocosRuntimeTools">正在检查…</small></span>
                <span id="cocosRuntimeDot" class="status-dot"></span>
              </summary>
              <div id="cocosToolDetails" class="builtin-detail-list"></div>
            </details>
            <details class="builtin-capability">
              <summary>
                <span class="builtin-capability-copy"><strong>Skills</strong><small id="cocosRuntimeSkills">正在检查…</small></span>
                <span id="cocosSkillsDot" class="status-dot"></span>
              </summary>
              <div id="cocosSkillDetails" class="builtin-detail-list"></div>
            </details>
            <p id="cocosRuntimeMessage" class="inline-message" role="status" hidden></p>
            <details class="capability-advanced">
              <summary>查看详情</summary>
              <dl>
                <div><dt>状态</dt><dd id="cocosRuntimeSummary">正在检查…</dd></div>
                <div><dt>版本</dt><dd id="cocosRuntimeVersion">—</dd></div>
                <div><dt>Endpoint</dt><dd id="cocosRuntimeEndpoint">—</dd></div>
                <div><dt>项目</dt><dd id="cocosRuntimeProject">—</dd></div>
              </dl>
              <button id="cocosRuntimeToggle" class="secondary-button" type="button">取消使用</button>
              <p id="cocosRuntimeToggleHint" class="muted">取消使用不会删除或修改任何 MCP 配置。</p>
              <button id="cocosBuiltinCheckButton" class="text-button" type="button">重新检查内置能力</button>
            </details>
          </section>
          <section class="cocos-external-section" aria-labelledby="cocosExternalHeading">
            <div class="heading-actions"><h3 id="cocosExternalHeading">其他 Cocos MCP</h3><button id="cocosMcpManage" class="text-button" type="button">重新检查</button></div>
            <p class="muted">自动识别当前 Cocos 编辑器扩展中配置的 Cocos 操作服务。</p>
            <p id="cocosExternalMessage" class="muted" role="status">正在识别已配置的服务…</p>
            <div id="cocosExternalList" class="mcp-list"></div>
          </section>
        </div>

        <div id="mcpPage" class="settings-page" hidden>
          <div id="mcpListView">
            <div class="page-heading heading-actions"><div><h2>外部 MCP 服务</h2><p>管理你在 Copilot 中添加的外部工具连接。</p></div><button id="mcpAddButton" class="primary-button" type="button">+ 添加服务</button></div>
            <div class="mcp-list-actions"><button id="mcpCheckButton" class="text-button" type="button">检查连接状态</button></div>
            <div id="mcpAddChoices" class="compact-actions" hidden><button id="mcpAddLocal" type="button">本地 stdio</button><button id="mcpAddRemote" type="button">远程 HTTP</button><button id="mcpImportOpen" type="button">导入配置</button></div>
            <p id="mcpListMessage" class="inline-message" role="status" hidden></p>
            <div id="mcpList" class="mcp-list"></div>
          </div>
          <section id="mcpDetailView" class="mcp-detail" hidden>
            <button id="mcpDetailBack" class="back-action" type="button">← MCP 服务</button>
            <div class="detail-heading"><h2 id="mcpDetailName"></h2><p id="mcpDetailMeta"></p></div>
            <div class="mcp-status-line"><span id="mcpDetailDot" class="status-dot"></span><span id="mcpDetailStatus"></span></div>
            <p id="mcpDetailHint" class="muted" hidden></p>
            <div id="mcpDetailActions" class="button-row"><button id="mcpEditButton" class="secondary-button" type="button">编辑配置</button><button id="mcpToggleButton" class="secondary-button" type="button"></button><button id="mcpOauthButton" class="secondary-button" type="button" hidden>OAuth 登录</button><button id="mcpDeleteButton" class="secondary-button mcp-delete" type="button">删除</button></div>
            <details id="mcpToolsGroup" class="mcp-tools-section"><summary id="mcpToolsHeading">工具</summary><div id="mcpTools"></div></details>
          </section>
          <section id="mcpEditorView" class="mcp-editor" hidden>
            <button id="mcpEditorBack" class="back-action" type="button">← MCP 服务</button>
            <div class="detail-heading"><h2 id="mcpEditorTitle">添加 MCP 服务</h2><p id="mcpEditorHelp">按服务提供方的说明填写。测试连接不会保存配置或调用业务工具。</p></div>
            <section class="mcp-form-section">
              <h3>基本设置</h3>
              <label class="field-label" for="mcpName">名称 <span>必填</span></label><input id="mcpName" autocomplete="off" spellcheck="false" placeholder="例如 my_mcp" aria-describedby="mcpNameHelp"/>
              <p id="mcpNameHelp" class="field-help">使用字母、数字、下划线或短横线，最多 64 个字符。</p>
              <label class="check-row mcp-enable-row"><input id="mcpEnabled" type="checkbox" role="switch" checked/> 启用此服务</label>
            </section>
            <label class="field-label" for="mcpConnectionMode">连接方式</label><select id="mcpConnectionMode"><option value="file">本地文件</option><option value="command">启动命令</option><option value="remote">远程地址</option></select>
            <div id="mcpLocalFields">
              <section id="mcpEntryFields" class="mcp-form-section">
                <div class="mcp-label-row"><label class="field-label" for="mcpEntryPath">MCP 服务入口 <span>必填</span></label>${mcpHelp('mcpEntryHelp', 'MCP 服务入口', '选择 MCP 服务的脚本或可执行文件，例如 index.js。JavaScript 运行环境 Node.js 自动查找；找不到时再提示选择。')}</div>
                <div class="mcp-path-row"><input id="mcpEntryPath" autocomplete="off" spellcheck="false" placeholder="选择 MCP 服务的 index.js 或可执行文件"/><button id="mcpEntryBrowse" class="secondary-button" type="button">浏览</button></div>
                <div id="mcpRuntimeFallback" class="mcp-field" hidden><label class="field-label" for="mcpRuntimePath">Node.js 运行程序</label><div class="mcp-path-row"><input id="mcpRuntimePath" autocomplete="off" spellcheck="false" placeholder="选择已安装的 node.exe 或 node"/><button id="mcpRuntimeBrowse" class="secondary-button" type="button">浏览</button></div><p class="field-help">未找到 JavaScript 运行环境。安装 Node.js 后可重新测试，或在此选择已安装的程序。</p></div>
              </section>
              <section id="mcpCommandFields" class="mcp-form-section" hidden>
                <div class="mcp-label-row"><label class="field-label" for="mcpCommand">启动命令 <span>必填</span></label>${mcpHelp('mcpCommandHelp', '启动命令', '只填可执行程序或完整路径，例如 npx、uvx。不要在这里拼接参数。')}</div><div class="mcp-path-row"><input id="mcpCommand" autocomplete="off" spellcheck="false" placeholder="例如 npx 或 uvx"/><button id="mcpCommandBrowse" class="secondary-button" type="button">浏览</button></div>
                <label class="field-label">启动参数 <span>可选 · 每行一个</span><textarea id="mcpArgs" rows="3" spellcheck="false" placeholder="按服务提供方的说明填写"></textarea></label>
              </section>
              <section class="mcp-form-section">
                <div class="mcp-label-row"><label class="field-label" for="mcpApplicationPath">目标应用程序 <span>可选</span></label>${mcpHelp('mcpApplicationHelp', '目标应用程序', 'MCP 需要调用的外部软件，例如 FamiStudio.exe；无需外部软件时留空。不会把已有环境变量搬到这里。')}</div>
                <div class="mcp-path-row"><input id="mcpApplicationPath" autocomplete="off" spellcheck="false" placeholder="无需外部应用时留空"/><button id="mcpApplicationBrowse" class="secondary-button" type="button">浏览</button></div>
                <div id="mcpApplicationBinding" class="mcp-field" hidden><div class="mcp-label-row"><label class="field-label" for="mcpApplicationEnvName">应用路径变量名 <span>必填</span></label>${mcpHelp('mcpApplicationBindingHelp', '应用路径变量名', '各 MCP 接收应用路径的方式不同。仅在服务文档要求通过环境变量传入路径时，填写该变量名；其他传入方式请使用启动参数。')}</div><input id="mcpApplicationEnvName" autocomplete="off" spellcheck="false" placeholder="填写该 MCP 文档规定的变量名"/></div>
              </section>
              <details id="mcpStartupGroup" class="mcp-advanced"><summary>高级启动配置</summary>
                <label id="mcpExtraArgsField" class="field-label">附加参数 <span>可选 · 每行一个</span><textarea id="mcpExtraArgs" rows="3" spellcheck="false" placeholder="服务提供方要求的其他参数"></textarea></label>
                <div class="mcp-label-row"><label class="field-label" for="mcpCwd">工作目录 <span>可选</span></label>${mcpHelp('mcpCwdHelp', '工作目录', '服务启动时所在的文件夹，不是输出目录；没有要求可留空。')}</div><div class="mcp-path-row"><input id="mcpCwd" autocomplete="off" spellcheck="false" placeholder="没有要求时留空"/><button id="mcpCwdBrowse" class="secondary-button" type="button">浏览</button></div>
              </details>
              <details id="mcpEnvironmentGroup" class="mcp-advanced"><summary>高级运行环境</summary>
                <div class="mcp-label-row"><label class="field-label" for="mcpEnv">环境变量</label>${mcpHelp('mcpEnvHelp', '环境变量', '启动 MCP 服务时额外传入的配置，没有要求就留空。手动填写的内容保持原位，不会在保存后自动搬到其他字段。')}</div>
                <textarea id="mcpEnv" rows="3" spellcheck="false" autocomplete="off" placeholder="每行一个：名称=值" aria-describedby="mcpEnvHelp"></textarea>
                <p class="field-help">已有密钥以 •••••• 隐藏，保留占位符即可保留原值。程序路径不会隐藏。</p>
                <div class="mcp-label-row"><label class="field-label" for="mcpEnvVars">继承系统变量</label>${mcpHelp('mcpEnvVarsHelp', '继承系统变量', '指定允许 MCP 服务从当前系统继承的变量名称。通常无需设置。')}</div>
                <textarea id="mcpEnvVars" rows="2" spellcheck="false" placeholder="每行一个变量名，例如 MY_VARIABLE" aria-describedby="mcpEnvVarsHelp"></textarea>
              </details>
            </div>
            <div id="mcpRemoteFields" hidden>
              <label class="field-label">服务地址<input id="mcpUrl" autocomplete="off" spellcheck="false" placeholder="https://example.com/mcp"/></label>
              <label class="field-label">认证<select id="mcpAuth"><option value="none">无</option><option value="oauth">OAuth</option><option value="bearer">从环境变量读取 Bearer Token</option></select></label>
              <label id="mcpBearerRow" class="field-label" hidden>Bearer Token 环境变量<input id="mcpBearer" autocomplete="off" spellcheck="false" placeholder="MCP_TOKEN"/></label>
              <details id="mcpRemoteAdvanced" class="mcp-advanced"><summary>高级请求配置</summary><label class="field-label">静态请求头 <span>Header=value，每行一个</span><textarea id="mcpHeaders" rows="3" spellcheck="false"></textarea></label><label class="field-label">环境变量请求头 <span>Header=ENV_NAME，每行一个</span><textarea id="mcpEnvHeaders" rows="3" spellcheck="false"></textarea></label></details>
            </div>
            <div class="button-row mcp-editor-footer"><button id="mcpTestButton" class="secondary-button" type="button">测试连接</button><span class="mcp-action-spacer"></span><button id="mcpCancelButton" class="secondary-button" type="button">取消</button><button id="mcpSaveButton" class="primary-button" type="button">保存</button></div>
            <div id="mcpTestResult" class="mcp-test-result" role="status" hidden></div>
          </section>
          <section id="mcpImportView" class="mcp-editor" hidden>
            <button id="mcpImportBack" class="back-action" type="button">← MCP 服务</button>
            <div class="detail-heading"><h2>导入配置</h2><p>粘贴包含 mcpServers 的 JSON，确认预览后再保存。</p></div>
            <textarea id="mcpImportText" class="mcp-import-text" rows="12" spellcheck="false" placeholder='{"mcpServers":{"example":{"command":"npx","args":[]}}}'></textarea>
            <p id="mcpImportMessage" class="inline-message" hidden></p><div id="mcpImportPreview" class="mcp-import-preview"></div>
            <div class="button-row"><button id="mcpImportPreviewButton" class="secondary-button" type="button">预览</button><button id="mcpImportSaveButton" class="primary-button" type="button" hidden>确认导入</button><button id="mcpImportCancel" class="text-button" type="button">取消</button></div>
          </section>
        </div>

        <div id="environmentPage" class="settings-page" hidden><div class="page-heading"><div class="heading-actions"><h2>工具环境</h2><button id="environmentCheckButton" class="text-button" type="button">重新检查 Skills</button></div><p>当前项目可用的 Skills。</p></div><div id="environmentStatus"></div></div>
        <div id="runtimePage" class="settings-page" hidden>
          <div class="page-heading"><div class="heading-actions"><h2>Runtime</h2><button id="runtimeCheckButton" class="text-button" type="button">检查运行状态</button></div><p>AI Copilot 当前使用的 Agent Harness。</p></div>
          <section class="runtime-section">
            <div><h3>Codex Runtime</h3><p>模型服务、MCP、Skills、权限与审批继续由 Codex 承载。</p></div>
            <dl><div><dt>Version</dt><dd id="runtimeVersion">—</dd></div><div><dt>Status</dt><dd id="runtimeStatus">Stopped</dd></div></dl>
          </section>
          <p id="runtimeConnectionMessage" class="inline-message" role="status" hidden></p>
          <div id="runtimeManualConnection" hidden>
            <label class="field-label" for="runtimeExecutableInput">Codex 程序位置</label>
            <div class="secret-row"><input id="runtimeExecutableInput" type="text" spellcheck="false" placeholder="选择电脑上已安装的 Codex 程序"/><button id="runtimeBrowseButton" class="secondary-button" type="button">浏览</button></div>
            <p class="field-help">选择 Codex 程序，不是 Cocos 或 ChatGPT 的桌面快捷方式。未安装时，请先安装 Codex。</p>
            <div class="button-row"><button id="runtimeConnectButton" class="primary-button" type="button">测试连接并保存</button><button id="runtimeAutomaticButton" class="text-button" type="button" hidden>恢复自动检测</button></div>
          </div>
        </div>
      </section>
    </div>
  </main>
`;

const style = `
  .environment-group { margin: 0 0 24px; }
  .environment-heading { display:flex; align-items:center; gap:8px; margin:0; padding:10px 0; font-size:12px; font-weight:600; border-bottom:1px solid rgba(128,128,128,.2); }
  .environment-row { display:flex; align-items:center; justify-content:space-between; gap:16px; padding:12px 0; font-size:12px; border-bottom:1px solid rgba(128,128,128,.1); }
  .environment-name { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .environment-service > summary { cursor:pointer; list-style:none; }
  .environment-service > summary::-webkit-details-marker { display:none; }
  .environment-service > summary:hover,.environment-service > summary:focus-visible { background:rgba(255,255,255,.035); color:#ddd; }
  .environment-service-detail { padding:4px 0 12px; color:#999; font-size:11px; line-height:1.7; overflow-wrap:anywhere; }
  .environment-dot { flex:0 0 6px; width:6px; height:6px; border-radius:50%; background:#777; }
  .environment-dot[data-status=connected] { background:#75ba80; }
  .environment-count { color:#999; font-size:11px; white-space:nowrap; font-weight:400; }
  .environment-skills > summary { cursor:pointer; user-select:none; }
  .environment-skills > summary::before { content:'›'; color:#999; width:8px; }
  .environment-skills[open] > summary::before { content:'⌄'; }
  .environment-count { margin-left:auto; }
  .environment-skill { padding:9px 0; color:#bbb; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .heading-actions { display:flex; align-items:flex-start; justify-content:space-between; gap:18px; }
  .compact-actions { display:flex; gap:6px; margin:-8px 0 12px; padding:8px; border:1px solid var(--border); border-radius:5px; background:rgba(0,0,0,.08); }
  .compact-actions button { height:28px; padding:0 9px; border:1px solid var(--border); border-radius:4px; color:var(--secondary); background:transparent; cursor:pointer; }
  .compact-actions button:hover { color:var(--text); background:var(--surface-hover); }
  .mcp-list { border-top:1px solid var(--border); }
  .mcp-list-actions { display:flex; justify-content:flex-end; margin:-8px 0 8px; }
  .heading-actions > .text-button { flex:0 0 auto; white-space:nowrap; font-size:11.5px; }
  .cocos-external-section { margin-top:26px; }
  .cocos-external-section .heading-actions { align-items:center; gap:12px; }
  .cocos-external-section h3 { font-size:13px; font-weight:600; }
  .cocos-external-section .text-button { white-space:nowrap; font-size:11.5px; }
  .cocos-external-section > .mcp-list { margin-top:12px; }
  #cocosExternalMessage { margin-top:14px; }
  #cocosExternalMessage.is-error { color:#d18a85; }
  .mcp-row { display:grid; grid-template-columns:8px minmax(0,1fr); align-items:center; gap:11px; width:100%; min-height:52px; padding:7px; border:0; border-bottom:1px solid var(--border); background:transparent; color:var(--text); text-align:left; cursor:pointer; }
  .mcp-row:hover,.mcp-row:focus-visible { background:var(--surface-hover); outline:0; }
  .mcp-row-copy { min-width:0; } .mcp-row-copy strong { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:13px; font-weight:500; }
  .mcp-row-copy small { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:var(--muted); font-size:11px; line-height:17px; }
  .mcp-status-line { padding:9px 10px; border:1px solid var(--border); border-radius:5px; color:var(--secondary); background:rgba(0,0,0,.08); font-size:12px; line-height:18px; }
  .mcp-tools-section { margin-top:22px; padding-top:14px; border-top:1px solid var(--border); }
  .mcp-tools-section h3 { margin-bottom:7px; }
  .mcp-tool { border-bottom:1px solid var(--border); } .mcp-tool summary { padding:9px 3px; cursor:pointer; font-size:12px; }
  .mcp-tool p { padding:0 3px 7px; color:var(--muted); font-size:11.5px; line-height:18px; }
  .mcp-tool pre { max-height:220px; overflow:auto; margin:0 3px 9px; padding:8px; border:1px solid var(--border); border-radius:4px; color:#bbb; background:rgba(0,0,0,.15); font-size:10.5px; white-space:pre-wrap; }
  .mcp-editor .field-label { margin-bottom:12px; } .mcp-editor .field-label span { margin-left:5px; color:var(--muted); font-weight:400; }
  .mcp-editor input,.mcp-editor textarea,.mcp-editor select,.mcp-import-text { display:block; width:100%; margin-top:5px; padding:6px 8px; border:1px solid rgba(128,128,128,.27); border-radius:4px; outline:0; color:var(--text); background:rgba(0,0,0,.16); resize:vertical; }
  .mcp-editor input,.mcp-editor select { height:31px; } .mcp-editor input:focus,.mcp-editor textarea:focus,.mcp-editor select:focus,.mcp-import-text:focus { border-color:rgba(160,160,160,.55); }
  .mcp-editor input:read-only { color:var(--muted); background:rgba(0,0,0,.08); }
  .check-row { display:flex; align-items:center; gap:7px; margin:4px 0; color:var(--secondary); font-size:12px; }
  .check-row input { display:inline-block; width:14px; height:14px; margin:0; padding:0; }
  .mcp-advanced { margin:4px 0 12px; border-top:1px solid var(--border); } .mcp-advanced summary { padding:9px 0; color:var(--secondary); cursor:pointer; font-size:12px; }
  .mcp-form-section { margin:0 0 14px; }
  .mcp-form-section h3 { margin-bottom:8px; font-size:12px; font-weight:600; }
  .mcp-editor > .back-action { margin-bottom:10px; }
  .mcp-editor > .detail-heading { margin-bottom:14px; }
  .mcp-editor .field-label { margin-bottom:6px; }
  .mcp-editor .field-help { margin:5px 0 12px; color:var(--muted); font-size:11px; line-height:17px; overflow-wrap:anywhere; }
  .mcp-editor .field-help.is-error { color:#d18a85; }
  .mcp-label-row { display:flex; align-items:center; gap:5px; margin-bottom:6px; }
  .mcp-editor .mcp-label-row .field-label { margin:0; }
  .mcp-field { margin-bottom:12px; }
  .mcp-help { position:relative; display:inline-flex; width:18px; height:18px; vertical-align:middle; margin-left:4px; }
  .mcp-label-row .mcp-help { margin:0; }
  .mcp-help-trigger { display:inline-flex; align-items:center; justify-content:center; width:18px; height:18px; padding:1px; border:0; border-radius:50%; background:transparent; color:var(--muted); cursor:help; }
  .mcp-help-trigger svg { width:16px; height:16px; fill:none; stroke:currentColor; stroke-width:1.3; stroke-linecap:round; }
  .mcp-help-trigger:hover,.mcp-help-trigger:focus-visible { color:var(--text); }
  .mcp-help-trigger:focus-visible { outline:1px solid var(--secondary); outline-offset:2px; }
  .mcp-help-tooltip { position:absolute; z-index:20; top:100%; left:0; width:260px; padding-top:6px; visibility:hidden; font-size:11px; font-weight:400; line-height:17px; text-align:left; white-space:normal; cursor:default; }
  .mcp-help-tooltip > span { display:block; padding:8px 10px; border:1px solid rgba(128,128,128,.35); border-radius:5px; color:var(--text); background:var(--surface-raised); overflow-wrap:anywhere; }
  .mcp-help:not([data-dismissed]):hover > .mcp-help-tooltip,.mcp-help:not([data-dismissed]):focus-within > .mcp-help-tooltip { visibility:visible; }
  .mcp-help.is-above > .mcp-help-tooltip { top:auto; bottom:100%; padding-top:0; padding-bottom:6px; }
  .mcp-editor .mcp-enable-row { margin-top:10px; }
  .mcp-enable-row input { appearance:none; flex:0 0 26px; width:26px; height:15px; border-radius:9px; background:#555; border:1px solid #666; position:relative; cursor:pointer; }
  .mcp-enable-row input::after { content:''; position:absolute; left:2px; top:2px; width:9px; height:9px; border-radius:50%; background:#ccc; }
  .mcp-enable-row input:checked { background:#4e7557; border-color:#668c6e; }
  .mcp-enable-row input:checked::after { left:13px; background:#eee; }
  .mcp-path-row { display:flex; flex-wrap:wrap; align-items:center; gap:6px; }
  .mcp-path-row input { flex:1 1 190px; width:auto; min-width:150px; margin:0; }
  .mcp-path-row button { flex:0 0 auto; padding:0 9px; font-size:11px; white-space:nowrap; }
  .mcp-advanced { margin:0; }
  .mcp-advanced > summary { min-height:36px; }
  .mcp-advanced > summary:hover { color:var(--text); background:var(--surface-hover); }
  .mcp-advanced > summary small { margin-left:7px; font-size:10.5px; color:var(--muted); font-weight:400; }
  .mcp-editor-footer { padding-top:12px; border-top:1px solid var(--border); font-size:12px; }
  .mcp-action-spacer { flex:1; }
  .mcp-status-line { display:flex; align-items:center; gap:7px; }
  .mcp-delete { margin-left:auto; }
  .mcp-tools-section > summary { padding:8px 0; color:var(--secondary); font-size:13px; font-weight:500; cursor:pointer; }
  .mcp-tools-section > summary:hover { color:var(--text); }
  #mcpDetailHint { margin-bottom:10px; overflow-wrap:anywhere; }
  #mcpDetailActions { flex-wrap:wrap; font-size:12px; }
  .mcp-test-result { margin-top:13px; padding:10px; border:1px solid var(--border); border-radius:5px; color:var(--secondary); background:rgba(0,0,0,.1); font-size:12px; line-height:18px; }
  .mcp-test-result.is-error { border-color:rgba(190,95,90,.35); color:#d18a85; }
  .mcp-test-result .mcp-check-ok { color:#82aa8c; }
  .mcp-test-result details { margin-top:6px; color:var(--muted); }
  .mcp-test-result .mcp-error-details { padding-top:5px; border-top:1px solid rgba(128,128,128,.18); }
  .mcp-test-result .mcp-error-details summary { cursor:pointer; color:var(--secondary); }
  .mcp-test-result .mcp-error-code { display:block; margin-top:6px; font-family:monospace; opacity:.78; }
  .mcp-test-result pre { max-height:180px; margin:6px 0 0; padding:7px 8px; overflow:auto; border-radius:3px; background:rgba(0,0,0,.14); white-space:pre-wrap; overflow-wrap:anywhere; color:var(--muted); }
  .mcp-import-preview { margin-top:10px; border-top:1px solid var(--border); }
  .mcp-import-item { display:flex; justify-content:space-between; gap:12px; padding:8px 2px; border-bottom:1px solid var(--border); font-size:12px; }
  .capability-card { overflow:hidden; border:1px solid var(--border); border-radius:7px; background:rgba(255,255,255,.012); }
  .builtin-capability { border-bottom:1px solid var(--border); }
  .builtin-capability > summary { display:flex; min-height:56px; align-items:center; gap:12px; padding:9px 12px; list-style:none; cursor:pointer; }
  .builtin-capability > summary::-webkit-details-marker { display:none; }
  .builtin-capability > summary::before { width:12px; flex:0 0 12px; color:var(--muted); content:'›'; font-size:17px; transform:rotate(0deg); transition:transform 120ms ease; }
  .builtin-capability[open] > summary::before { transform:rotate(90deg); }
  .builtin-capability > summary:hover { background:var(--surface-hover); }
  .builtin-capability-copy { flex:1; min-width:0; }
  .builtin-capability-copy strong,.builtin-capability-copy small { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .builtin-capability-copy strong { font-size:13px; font-weight:500; }
  .builtin-capability-copy small { margin-top:2px; color:var(--muted); font-size:11px; line-height:17px; }
  .builtin-detail-list { padding:0 12px 9px 36px; }
  .builtin-detail-row { display:flex; min-height:38px; align-items:center; justify-content:space-between; gap:16px; border-top:1px solid rgba(128,128,128,.1); }
  .builtin-detail-row strong { overflow:hidden; color:var(--secondary); font-size:11.5px; font-weight:400; text-overflow:ellipsis; white-space:nowrap; }
  .builtin-detail-row small { flex:0 0 auto; color:var(--muted); font-size:10.5px; }
  .capability-card > .inline-message { margin:9px 12px; }
  .capability-advanced { padding:9px 12px 12px; color:var(--secondary); font-size:11.5px; }
  .capability-advanced > summary { padding:4px 0; cursor:pointer; color:var(--muted); }
  .capability-advanced dl { margin:8px 0 10px; padding:8px 10px; border-radius:5px; background:rgba(0,0,0,.1); } .capability-advanced dd { max-width:320px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

  :host { --surface:var(--color-normal-fill,#242424); --surface-raised:var(--color-normal-fill-emphasis,#2b2b2b); --surface-hover:rgba(128,128,128,.09); --text:var(--color-normal-contrast,#dedede); --secondary:var(--color-normal-contrast-weak,#aaa); --muted:var(--color-normal-contrast-weakest,#7f7f7f); --border:var(--color-normal-border,rgba(128,128,128,.17)); display:block; width:100%; height:100%; color:var(--text); background:var(--surface); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
  * { box-sizing:border-box; } button,input { font:inherit; } button { color:inherit; } [hidden] { display:none !important; } h1,h2,h3,p { margin:0; }
  .settings-root { display:flex; height:100%; min-width:0; min-height:0; flex-direction:column; }
  .settings-header { display:flex; min-height:52px; padding:9px 17px; align-items:center; justify-content:space-between; border-bottom:1px solid var(--border); }
  h1 { font-size:18px; line-height:25px; font-weight:600; } h2 { font-size:16px; line-height:23px; font-weight:600; } h3 { font-size:14px; line-height:20px; font-weight:600; }
  .settings-layout { display:flex; flex:1 1 auto; min-height:0; }
  .settings-nav { width:144px; flex:0 0 144px; padding:12px 9px; border-right:1px solid var(--border); }
  .nav-item { display:block; width:100%; height:32px; padding:0 9px; border:0; border-radius:5px; color:var(--secondary); background:transparent; font-size:13px; text-align:left; cursor:pointer; }
  .nav-item:hover { color:var(--text); background:var(--surface-hover); } .nav-item.is-active { color:var(--text); background:rgba(128,128,128,.14); }
  .settings-content { flex:1 1 auto; min-width:0; min-height:0; overflow:auto; }
  .settings-page { width:min(100%,610px); padding:24px 30px 38px; }
  .page-heading { margin-bottom:20px; } .page-heading p,.detail-heading p,.muted,.runtime-section p { margin-top:3px; color:var(--muted); font-size:12px; line-height:18px; }
  .provider-list { border-top:1px solid var(--border); }
  .provider-row { display:grid; grid-template-columns:8px minmax(0,1fr) 16px; width:100%; min-height:58px; align-items:center; gap:11px; padding:8px 7px; border:0; border-bottom:1px solid var(--border); color:var(--text); background:transparent; text-align:left; cursor:pointer; }
  .provider-row:hover,.provider-row:focus-visible { background:var(--surface-hover); outline:0; }
  .status-dot { width:6px; height:6px; border-radius:50%; background:#666; } .status-dot.is-connected { background:#82aa8c; } .status-dot.is-available { background:#9d936d; } .status-dot.is-error { background:#b77772; }
  .provider-row-copy { min-width:0; } .provider-row-copy strong { display:block; font-size:13px; line-height:19px; font-weight:500; } .provider-row-copy small { display:block; overflow:hidden; color:var(--muted); font-size:11.5px; line-height:17px; text-overflow:ellipsis; white-space:nowrap; }
  .provider-chevron { color:#707070; font-size:19px; text-align:center; }
  .storage-notice { margin-top:14px; color:#707070; font-size:11px; line-height:17px; }
  .provider-detail { min-width:0; } .back-action { margin:0 0 16px -4px; padding:3px 4px; border:0; color:var(--muted); background:transparent; font-size:12px; cursor:pointer; } .back-action:hover { color:var(--text); }
  .detail-heading { margin-bottom:18px; }
  .method-tabs { display:flex; gap:3px; margin-bottom:18px; padding-bottom:8px; border-bottom:1px solid var(--border); }
  .method-tab { display:flex; min-width:112px; height:33px; align-items:center; gap:6px; padding:0 9px; border:0; border-radius:5px; color:var(--muted); background:transparent; cursor:pointer; }
  .method-tab span { font-size:12.5px; } .method-tab small { color:#727272; font-size:10.5px; } .method-tab:hover { color:var(--secondary); background:var(--surface-hover); } .method-tab.is-active { color:var(--text); background:rgba(128,128,128,.14); } .method-tab.is-active small { color:var(--secondary); }
  .method-pane { max-width:500px; min-height:120px; }
  .credential-row,.saved-secret { display:flex; min-height:42px; align-items:center; justify-content:space-between; gap:14px; }
  .credential-row strong,.saved-secret strong { font-size:13px; font-weight:500; } .credential-row p,.saved-secret p { margin-top:2px; color:var(--muted); font-size:11.5px; line-height:17px; }
  .masked-secret { color:#777; font-size:13px; letter-spacing:.5px; }
  .saved-secret { flex-wrap:wrap; } .saved-secret > .button-row { flex-basis:100%; }
  .secret-editor { max-width:500px; } .field-label { display:block; margin:0 0 6px; color:var(--secondary); font-size:12px; }
  .secret-row { display:flex; gap:6px; } .secret-row input { flex:1 1 auto; min-width:0; height:32px; padding:0 9px; border:1px solid rgba(128,128,128,.27); border-radius:5px; outline:0; color:var(--text); background:rgba(0,0,0,.16); }
  .secret-row input:focus { border-color:rgba(160,160,160,.55); } .secret-row input::placeholder { color:#606060; }
  .button-row { display:flex; align-items:center; gap:12px; margin-top:10px; }
  .primary-button,.secondary-button { min-height:29px; padding:0 11px; border-radius:5px; cursor:pointer; }
  .primary-button { border:1px solid rgba(190,190,190,.25); color:#e2e2e2; background:rgba(128,128,128,.17); } .primary-button:hover { background:rgba(128,128,128,.24); }
  .secondary-button { border:1px solid var(--border); color:var(--secondary); background:transparent; } .secondary-button:hover { color:var(--text); background:var(--surface-hover); }
  .text-button { padding:4px 1px; border:0; color:var(--muted); background:transparent; cursor:pointer; } .text-button:hover { color:var(--secondary); } .text-button.danger:hover { color:#df8e88; }
  button:disabled { opacity:.46; cursor:default; }
  .icon-button { display:inline-grid; width:28px; height:28px; padding:0; border:0; border-radius:5px; place-items:center; color:#929292; background:transparent; cursor:pointer; } .icon-button:hover { color:var(--text); background:var(--surface-hover); }
  .icon-button svg { width:15px; height:15px; fill:none; stroke:currentColor; stroke-width:1.4; stroke-linecap:round; stroke-linejoin:round; }
  .credential-refresh { flex:0 0 28px; } .reveal-button { width:32px; height:32px; border:1px solid rgba(128,128,128,.2); }
  .inline-message { margin-top:8px; color:#c9b477; font-size:12px; line-height:18px; } .inline-message.is-error { color:#d18a85; }
  .muted { margin-top:13px; }
  .model-summary { display:flex; align-items:center; justify-content:space-between; gap:16px; margin-top:22px; padding-top:14px; border-top:1px solid var(--border); font-size:12px; } .summary-label { color:var(--muted); } .model-summary strong { color:var(--secondary); font-weight:400; text-align:right; }
  .runtime-section { display:flex; align-items:flex-start; justify-content:space-between; gap:28px; padding-top:17px; border-top:1px solid var(--border); } .runtime-section > div { max-width:350px; }
  dl { min-width:160px; margin:0; } dl div { display:flex; justify-content:space-between; gap:18px; padding:4px 0; font-size:12px; } dt { color:var(--muted); } dd { margin:0; color:var(--secondary); }
  .settings-content::-webkit-scrollbar { width:6px; } .settings-content::-webkit-scrollbar-thumb { border-radius:6px; background:rgba(128,128,128,.24); }
  .archived-list { margin-top:12px; }
  .archived-row { display:flex; min-height:52px; align-items:center; gap:12px; border-bottom:1px solid var(--border); }
  .archived-copy { flex:1; min-width:0; } .archived-title { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:13px; font-weight:400; }
  .archived-time,.archived-empty { color:var(--muted); font-size:11.5px; line-height:20px; }
  .archived-row .text-button { flex:0 0 auto; font-size:12px; white-space:nowrap; }
  @media (max-width:680px) { .settings-nav { width:126px; flex-basis:126px; } .settings-page { padding-left:20px; padding-right:20px; } }
`;

function modelSummary(provider = {}) {
  const agent = Number.isSafeInteger(provider.agentModelCount)
    ? provider.agentModelCount : Array.isArray(provider.models) ? provider.models.length : 0;
  const raw = Number.isSafeInteger(provider.rawModelCount) ? provider.rawModelCount : agent;
  if (!agent) return '模型列表暂时不可用';
  const value = raw > agent ? `已发现 ${raw} 个 · 可用于 Agent ${agent} 个` : `Agent 模型 ${agent} 个可用`;
  return provider.modelStatus === 'stale' ? `${value} · 可能不是最新` : value;
}

module.exports = Editor.Panel.define({
  template,
  style,
  $: Object.fromEntries([
    'servicesCheckButton','archivedCheckButton','cocosBuiltinCheckButton','mcpCheckButton','environmentCheckButton','runtimeCheckButton',
    'servicesNav','cocosNav','runtimeNav','servicesPage','cocosPage','runtimePage','providerListView',
    'archivedNav','archivedPage','archivedList','archivedMessage','environmentNav','environmentPage','environmentStatus',
    'mcpNav','mcpPage','mcpListView','mcpAddButton','mcpAddChoices','mcpAddLocal','mcpAddRemote','mcpImportOpen','mcpListMessage','mcpList',
    'mcpDetailView','mcpDetailBack','mcpDetailName','mcpDetailMeta','mcpDetailStatus','mcpDetailActions','mcpEditButton','mcpToggleButton','mcpOauthButton','mcpDeleteButton','mcpToolsHeading','mcpTools',
    'mcpDetailDot','mcpDetailHint','mcpToolsGroup','mcpEditorHelp','mcpNameHelp',
    'mcpConnectionMode','mcpEntryFields','mcpEntryPath','mcpEntryBrowse','mcpCommandFields','mcpCommandBrowse','mcpExtraArgs','mcpExtraArgsField','mcpCwdBrowse',
    'mcpApplicationPath','mcpApplicationBrowse','mcpApplicationBinding','mcpApplicationEnvName','mcpRuntimeFallback','mcpRuntimePath','mcpRuntimeBrowse','mcpStartupGroup','mcpEnvironmentGroup','mcpRemoteAdvanced',
    'mcpEditorView','mcpEditorBack','mcpEditorTitle','mcpName','mcpLocalFields','mcpCommand','mcpArgs','mcpCwd','mcpEnv','mcpEnvVars','mcpRemoteFields','mcpUrl','mcpAuth','mcpBearerRow','mcpBearer','mcpHeaders','mcpEnvHeaders','mcpEnabled','mcpTestButton','mcpSaveButton','mcpCancelButton','mcpTestResult',
    'mcpImportView','mcpImportBack','mcpImportText','mcpImportMessage','mcpImportPreview','mcpImportPreviewButton','mcpImportSaveButton','mcpImportCancel',
    'openaiRow','openaiDot','openaiRowSummary','deepseekRow','deepseekDot','deepseekRowSummary','storageNotice',
    'openaiDetail','openaiBack','openaiCurrentAuth','chatgptMethod','chatgptMethodState','openaiKeyMethod','openaiKeyMethodState',
    'chatgptPane','chatgptState','chatgptLoginButton','chatgptStartButton','chatgptDisconnectButton','chatgptMessage',
    'openaiKeyPane','openaiSavedKey','openaiKeyEditor','openaiKeyInput','openaiRevealButton','openaiVerifyButton','openaiCancelEdit','openaiChangeButton','openaiRemoveButton','openaiKeyMessage','openaiModelStatus',
    'deepseekDetail','deepseekBack','deepseekSummary','deepseekSavedKey','deepseekKeyEditor','deepseekKeyInput','deepseekRevealButton','deepseekVerifyButton','deepseekCancelEdit','deepseekChangeButton','deepseekRemoveButton','deepseekKeyMessage','deepseekModelStatus',
    'runtimeVersion','runtimeStatus',
    'runtimeConnectionMessage','runtimeManualConnection','runtimeExecutableInput','runtimeBrowseButton','runtimeConnectButton','runtimeAutomaticButton',
    'cocosRuntimeSummary','cocosRuntimeDot','cocosSkillsDot','cocosRuntimeTools','cocosRuntimeSkills','cocosToolDetails','cocosSkillDetails','cocosRuntimeVersion','cocosRuntimeMessage','cocosRuntimeEndpoint','cocosRuntimeProject','cocosRuntimeToggle','cocosRuntimeToggleHint',
    'cocosExternalList','cocosExternalMessage','cocosMcpManage',
  ].map((id) => [id, `#${id}`])),
  methods: {
    request(message, payload = {}) { return Editor.Message.request(EXTENSION_NAME, message, payload); },

    showPage(page) {
      this._page = ['runtime', 'archived', 'environment', 'mcp', 'cocos'].includes(page) ? page : 'services';
      for (const name of ['services', 'cocos', 'runtime', 'archived', 'environment', 'mcp']) {
        this.$[`${name}Page`].hidden = this._page !== name;
        this.$[`${name}Nav`].classList.toggle('is-active', this._page === name);
      }
      if (this._page === 'services' && !this._providerDetail) this.showServicesList();
      if (this._page === 'archived') this.loadArchivedSessions();
      if (this._page === 'environment') this.loadEnvironment();
      if (this._page === 'mcp' && (!this._mcpSnapshot || this._mcpSnapshotStale)) {
        this.loadMcpServices({ force: Boolean(this._mcpSnapshotStale) });
      }
      if (this._page === 'cocos') this.loadCocosCapabilities();
    },

    showCocosMessage(message = '', isError = false) {
      this.$.cocosRuntimeMessage.textContent = message;
      this.$.cocosRuntimeMessage.hidden = !message;
      this.$.cocosRuntimeMessage.classList.toggle('is-error', isError);
    },

    async loadCocosCapabilities(options = {}) {
      // Creator extension provenance is separate from global/managed MCP settings.
      // A disabled or unavailable builtin must not block third-party discovery.
      if (!options.builtinOnly) {
        this.renderExternalCocosMcp(this._externalCocosSnapshot);
        this.loadExternalCocosMcp(options);
      }
      const token = this._cocosToken = (this._cocosToken || 0) + 1;
      this.$.cocosRuntimeSummary.textContent = '正在检查…';
      try {
        const snapshot = await this.request('get-cocos-capabilities');
        if (this._closing || token !== this._cocosToken) return;
        this._cocosSnapshot = snapshot;
        this.renderCocosCapabilities(snapshot);
      } catch (error) {
        if (this._closing || token !== this._cocosToken) return;
        this.$.cocosRuntimeSummary.textContent = '暂时无法读取状态';
        this.$.cocosRuntimeDot.className = 'status-dot is-error';
        this.$.cocosSkillsDot.className = 'status-dot is-error';
        this.showCocosMessage(error?.message || '无法读取 Cocos MCP。', true);
      }
    },

    async loadExternalCocosMcp(options = {}) {
      const token = this._externalCocosToken = (this._externalCocosToken || 0) + 1;
      try {
        const snapshot = await this.request('get-external-cocos-services', { refresh: options.refresh === true });
        if (this._closing || token !== this._externalCocosToken) return;
        this._externalCocosSnapshot = snapshot;
        this.renderExternalCocosMcp(snapshot);
      } catch (error) {
        if (!this._closing && token === this._externalCocosToken) this.renderExternalCocosMcp(this._externalCocosSnapshot, error);
      }
    },

    renderExternalCocosMcp(snapshot, error = null) {
      const root = this.$.cocosExternalList;
      const message = this.$.cocosExternalMessage;
      const services = (snapshot?.services || []).filter((service) => service.source?.type === 'creator-extension'
        && service.cocosOperations?.toolNames?.length);
      root.textContent = ''; root.hidden = !services.length;
      const doc = root.ownerDocument;
      for (const service of services) {
        const row = doc.createElement('button'); row.type = 'button'; row.className = 'mcp-row';
        const status = mcpStatus(service);
        const dot = doc.createElement('span'); dot.className = `status-dot ${status.tone}`;
        const copy = doc.createElement('span'); copy.className = 'mcp-row-copy';
        const name = doc.createElement('strong'); name.textContent = service.name;
        const meta = doc.createElement('small');
        meta.textContent = `${service.source.label} · ${status.label} · ${service.cocosOperations.toolNames.length} 项 Cocos 工具`;
        row.title = `依据服务声明的工具识别：${service.cocosOperations.toolNames.join('、')}`;
        copy.appendChild(name); copy.appendChild(meta); row.appendChild(dot); row.appendChild(copy);
        row.addEventListener('click', () => {
          const current = this._externalCocosSnapshot?.services?.find((item) => item.source?.name === service.source.name
            && item.configuration?.url === service.configuration?.url);
          if (!current) return;
          this.showPage('mcp'); this.showMcpDetail(current);
        });
        root.appendChild(row);
      }
      message.textContent = error ? '暂时无法读取外部 MCP，请使用右上角重新检查。'
        : !snapshot ? '正在检查 Cocos 扩展…'
          : snapshot.issues?.length ? snapshot.issues.map((issue) => `${issue.extension}：${issue.message}`).join('\n')
            : services.length ? '' : '尚未识别到其他 Cocos 操作服务。请确认已在对应 Cocos 扩展中完成配置并启动服务。';
      message.hidden = !message.textContent;
      message.classList.toggle('is-error', Boolean(error));
    },

    renderBuiltinDetails(root, rows) {
      root.textContent = '';
      const doc = root.ownerDocument;
      for (const item of rows) {
        const row = doc.createElement('div'); row.className = 'builtin-detail-row';
        const title = doc.createElement('strong'); title.textContent = item.label;
        const value = doc.createElement('small'); value.textContent = item.value;
        row.appendChild(title); row.appendChild(value); root.appendChild(row);
      }
    },

    renderCocosCapabilities(snapshot = {}) {
      const runtime = snapshot.runtime || {};
      const skills = snapshot.skills || runtime.skills || {};
      const skillItems = Array.isArray(skills.skills) ? skills.skills : [];
      const readySkills = skillItems.filter((skill) => skill.installed).length;
      const localTools = snapshot.localTools || {};
      const localToolGroups = Array.isArray(localTools.groups) ? localTools.groups : [];
      const localToolCount = Number.isFinite(localTools.count)
        ? localTools.count : localToolGroups.reduce((sum, group) => sum + Number(group.count || 0), 0);
      const runtimeToolCount = Number.isFinite(runtime.toolCount) ? runtime.toolCount : 0;
      this.$.cocosRuntimeDot.className = `status-dot ${runtime.running ? 'is-connected' : runtime.enabled === false ? '' : 'is-error'}`;
      this.$.cocosSkillsDot.className = `status-dot ${skills.ready ? 'is-connected' : skillItems.length ? 'is-error' : ''}`;
      this.$.cocosRuntimeSummary.textContent = runtime.enabled === false
        ? '未使用'
        : runtime.running ? '已连接'
          : runtime.lastError ? `启动失败 · ${runtime.lastError}` : '未连接';
      this.$.cocosRuntimeTools.textContent = runtimeToolCount || localToolCount
        ? `Cocos ${runtimeToolCount || '—'} · Local ${localToolCount || '—'}` : '—';
      this.$.cocosRuntimeSkills.textContent = skillItems.length ? `${readySkills} / ${skillItems.length} 已就绪` : '—';
      this.$.cocosRuntimeVersion.textContent = snapshot.copilotVersion || '—';
      this.$.cocosRuntimeEndpoint.textContent = runtime.url || '—';
      this.$.cocosRuntimeEndpoint.title = runtime.url || '';
      this.$.cocosRuntimeProject.textContent = runtime.projectName || '—';
      this.$.cocosRuntimeToggle.textContent = runtime.enabled === false ? '使用' : '取消使用';
      this.$.cocosRuntimeToggle.disabled = Boolean(this._cocosAction);
      this.$.cocosRuntimeToggleHint.textContent = runtime.enabled === false
        ? '使用后，Copilot 会重新连接当前项目的内置 Cocos MCP。'
        : '取消使用不会删除或修改任何 MCP 配置。';
      this.renderBuiltinDetails(this.$.cocosToolDetails, [
        { label: 'Cocos MCP Tools', value: runtimeToolCount ? `${runtimeToolCount} 个` : '不可用' },
        ...localToolGroups.map((group) => ({ label: group.label || group.name || group.id, value: `${Number(group.count || 0)} 个` })),
      ]);
      const skillLabels = {
        'funplay-cocos-mcp-workflow': 'Cocos MCP 工作流',
        'funplay-cocos-ui-composition': 'Cocos UI 构建',
        'funplay-cocos-2d-image-toolkit': '2D 图片工具',
        'funplay-cocos-preview-debug': 'Preview 调试',
      };
      this.renderBuiltinDetails(this.$.cocosSkillDetails, skillItems.map((skill) => ({
        label: skillLabels[skill.name] || skill.name,
        value: skill.current ? `Revision ${skill.revision}` : skill.modified ? '已保留用户修改' : skill.installed ? '可更新' : '未安装',
      })));
      if (skills.modified) {
        this.showCocosMessage(`${skills.modified} 个内置 Skill 已由用户修改，已保留原内容；有新版可用。`);
      } else if (skills.updateAvailable) {
        this.showCocosMessage('内置 Skill 有更新可用，将在重新载入扩展时安全更新。');
      } else if (runtime.lastError) {
        this.showCocosMessage(runtime.lastError, true);
      } else {
        this.showCocosMessage();
      }
    },

    async toggleCocosRuntime() {
      if (this._cocosAction) return;
      this._cocosAction = 'toggle';
      this.$.cocosRuntimeToggle.disabled = true;
      const enabled = this._cocosSnapshot?.runtime?.enabled === false;
      try {
        await this.request('set-cocos-runtime-enabled', { enabled });
        await this.loadCocosCapabilities();
      } catch (error) {
        this.showCocosMessage(error?.message || '无法修改 Cocos Runtime 状态。', true);
      } finally {
        this._cocosAction = '';
        if (this._cocosSnapshot) this.renderCocosCapabilities(this._cocosSnapshot);
      }
    },

    async loadEnvironment() {
      const token = this._environmentToken = (this._environmentToken || 0) + 1;
      const root = this.$.environmentStatus;
      root.textContent = '正在检查…';
      try {
        const snapshot = await this.request('get-environment-snapshot', { refresh: true });
        if (this._closing || token !== this._environmentToken) return;
        root.textContent = '';
        const doc = root.ownerDocument;
        const node = (tag, className, text = '') => { const element = doc.createElement(tag); element.className = className; element.textContent = text; return element; };
        const skills = node('details','environment-group environment-skills');
        const heading = node('summary','environment-heading','Skills');
        heading.appendChild(node('span','environment-count',snapshot.status?.skills === 'error' ? '暂时无法读取' : `${snapshot.skills?.length || 0} 个可用`));
        skills.appendChild(heading);
        for (const skill of snapshot.skills || []) { const row = node('div','environment-row environment-skill',skill.name); row.title = skill.description || ''; skills.appendChild(row); }
        root.appendChild(skills);
      } catch (_) { if (!this._closing && token === this._environmentToken) root.textContent = '无法读取 Skills，请重新检查。'; }
    },

    showMcpMessage(message = '', isError = false) {
      this.$.mcpListMessage.textContent = message;
      this.$.mcpListMessage.hidden = !message;
      this.$.mcpListMessage.classList.toggle('is-error', isError);
    },

    showMcpView(view = 'list') {
      if (this._mcpView === 'editor' && view !== 'editor') this._mcpEditorToken = (this._mcpEditorToken || 0) + 1;
      if (view !== this._mcpView) this.$.mcpPage.parentElement?.scrollTo?.({ top: 0 });
      this.$.mcpListView.hidden = view !== 'list';
      this.$.mcpDetailView.hidden = view !== 'detail';
      this.$.mcpEditorView.hidden = view !== 'editor';
      this.$.mcpImportView.hidden = view !== 'import';
      if (view === 'list') this.$.mcpAddChoices.hidden = true;
      this._mcpView = view;
    },

    mcpStatusLabel(service) {
      return mcpStatus(service).label;
    },

    async loadMcpServices(options = {}) {
      const force = options.force === true;
      if (!force && this._mcpSnapshot && !this._mcpSnapshotStale) {
        this.renderMcpList(this._mcpSnapshot.services || []);
        this.showMcpMessage(this._mcpSnapshot.reloadPending ? '已保存，将在当前任务完成后应用。' : '');
        return this._mcpSnapshot;
      }
      if (this._mcpLoadPromise) {
        if (options.refresh === true && !this._mcpLoadRefresh) {
          const pending = this._mcpLoadPromise;
          await pending;
          if (this._closing) return this._mcpSnapshot;
          return this.loadMcpServices({ ...options, force:true });
        }
        return this._mcpLoadPromise;
      }
      const token = this._mcpToken = (this._mcpToken || 0) + 1;
      if (!this._mcpSnapshot && options.silent !== true) this.showMcpMessage('正在读取…');
      const load = (async () => {
        try {
          const snapshot = await this.request('get-mcp-services', {
            refresh: options.refresh === true,
          });
          if (this._closing || token !== this._mcpToken) return this._mcpSnapshot;
          this._mcpSnapshot = snapshot;
          this._mcpSnapshotStale = false;
          this.renderMcpList(snapshot.services || []);
          this.showMcpMessage(snapshot.reloadPending ? '已保存，将在当前任务完成后应用。' : '');
          if (this._mcpView === 'detail' && this._mcpSelectedName && this._mcpDetailOrigin !== 'creator-extension') {
            const service = snapshot.services?.find((item) => item.name === this._mcpSelectedName);
            if (service) this.showMcpDetail(service);
            else this.showMcpView('list');
          }
          return snapshot;
        } catch (error) {
          if (!this._closing && token === this._mcpToken) {
            this.showMcpMessage(error?.message || '无法读取 MCP 服务。', true);
          }
          return this._mcpSnapshot;
        }
      })();
      this._mcpLoadPromise = load;
      this._mcpLoadRefresh = options.refresh === true;
      try { return await load; }
      finally {
        if (this._mcpLoadPromise === load) {
          this._mcpLoadPromise = null;
          this._mcpLoadRefresh = false;
        }
      }
    },

    renderMcpList(services) {
      const root = this.$.mcpList;
      root.textContent = '';
      const doc = root.ownerDocument;
      if (!services.length) {
        const empty = doc.createElement('p'); empty.className = 'muted'; empty.textContent = '暂无 MCP 服务'; root.appendChild(empty);
        return;
      }
      for (const service of services) {
        const row = doc.createElement('button'); row.type = 'button'; row.className = 'mcp-row';
        const dot = doc.createElement('span'); dot.className = `status-dot ${mcpStatus(service).tone}`;
        dot.title = this.mcpStatusLabel(service);
        const copy = doc.createElement('span'); copy.className = 'mcp-row-copy';
        const title = doc.createElement('strong'); title.textContent = service.name;
        const meta = doc.createElement('small');
        meta.textContent = `${service.transport === 'stdio' ? '本地 · stdio' : '远程 · HTTP'} · ${this.mcpStatusLabel(service)}`;
        copy.appendChild(title); copy.appendChild(meta);
        row.appendChild(dot); row.appendChild(copy);
        row.addEventListener('click', () => this.showMcpDetail(service)); root.appendChild(row);
      }
    },

    showMcpDetail(service) {
      if (this._mcpSelectedName !== service.name || this._mcpView !== 'detail') this.$.mcpToolsGroup.open = false;
      this._mcpSelectedName = service.name;
      this._mcpDetailOrigin = service.origin;
      this.$.mcpDetailBack.textContent = service.origin === 'creator-extension' ? '← Cocos MCP' : '← MCP 服务';
      this.$.mcpDetailName.textContent = service.name;
      this.$.mcpDetailMeta.textContent = service.transport === 'stdio' ? '本地 · stdio' : '远程 · Streamable HTTP';
      this.$.mcpDetailStatus.textContent = `状态：${this.mcpStatusLabel(service)}`;
      this.$.mcpDetailDot.className = `status-dot ${mcpStatus(service).tone}`;
      this.$.mcpDetailHint.textContent = service.origin === 'creator-extension'
        ? `来源：Cocos 扩展「${service.source.label}」。连接配置由该扩展管理。${service.toolsError || ''}`
        : service.application?.status === 'missing' ? service.application.message
        : service.statusStale ? '暂时无法更新，当前显示最近一次确认的状态。'
          : service.toolsError || '';
      this.$.mcpDetailHint.hidden = !this.$.mcpDetailHint.textContent;
      this.$.mcpEditButton.hidden = !service.editable;
      this.$.mcpToggleButton.hidden = !service.editable;
      this.$.mcpDeleteButton.hidden = !service.editable;
      this.$.mcpToggleButton.textContent = service.enabled === false ? '启用' : '停用';
      this.$.mcpOauthButton.hidden = service.transport !== 'streamable-http' || !service.editable;
      const tools = this.$.mcpTools; tools.textContent = '';
      this.$.mcpToolsHeading.textContent = `工具 · ${service.tools?.length || 0}`;
      const doc = tools.ownerDocument;
      for (const tool of service.tools || []) {
        const item = doc.createElement('details'); item.className = 'mcp-tool';
        const summary = doc.createElement('summary'); summary.textContent = `${service.name} / ${tool.name}`; item.appendChild(summary);
        if (tool.description) { const description = doc.createElement('p'); description.textContent = tool.description; item.appendChild(description); }
        const schema = doc.createElement('details'); schema.className = 'mcp-tool-schema';
        const schemaSummary = doc.createElement('summary'); schemaSummary.textContent = '参数结构'; schema.appendChild(schemaSummary);
        const pre = doc.createElement('pre'); pre.textContent = JSON.stringify(tool.inputSchema || {}, null, 2); schema.appendChild(pre); item.appendChild(schema);
        tools.appendChild(item);
      }
      if (!(service.tools || []).length) { const empty = doc.createElement('p'); empty.className = 'muted'; empty.textContent = '服务可用后将在这里显示工具。'; tools.appendChild(empty); }
      this.showMcpView('detail');
    },

    mapLines(value) {
      const result = {};
      for (const [lineNumber, line] of String(value || '').split(/\r?\n/u).entries()) {
        if (!line.trim()) continue;
        const index = line.indexOf('=');
        const key = line.slice(0, index).trim();
        if (index < 1) throw new Error(`第 ${lineNumber + 1} 行请按“名称=值”填写。`);
        if (Object.prototype.hasOwnProperty.call(result, key)) throw new Error(`第 ${lineNumber + 1} 行变量名重复，请只保留一行。`);
        Object.defineProperty(result, key, { value: line.slice(index + 1), enumerable: true, configurable: true, writable: true });
      }
      return result;
    },

    mapText(value) { return Object.entries(value || {}).map(([key, item]) => `${key}=${item}`).join('\n'); },

    showMcpEditor(transport, service = null) {
      const configuration = service?.configuration || {};
      const serviceName = service?.name || '';
      this._mcpEditorToken = (this._mcpEditorToken || 0) + 1;
      this._mcpEditorBusy = false;
      this._mcpEditing = service || null;
      this._mcpTransport = transport;
      const form = localFormState(configuration, service?.editor);
      this.$.mcpEditorTitle.textContent = service ? `编辑 ${serviceName}` : transport === 'stdio' ? '添加本地 MCP' : '添加远程 MCP';
      this.$.mcpEditorBack.textContent = service ? `← ${serviceName}` : '← MCP 服务';
      this.$.mcpNameHelp.textContent = service ? '服务标识，添加后不可修改。' : '使用字母、数字、下划线或短横线，最多 64 个字符。';
      this.$.mcpNameHelp.hidden = Boolean(service);
      this.$.mcpName.title = service ? '服务标识，添加后不可修改。' : '';
      this.$.mcpEditorHelp.textContent = '按服务提供方的说明填写。测试连接不会保存配置或调用业务工具。';
      this.$.mcpName.value = serviceName; this.$.mcpName.readOnly = Boolean(service);
      this.$.mcpConnectionMode.value = transport === 'stdio' ? form.mode : 'remote';
      this.$.mcpCommand.value = form.command; this.$.mcpArgs.value = form.args.join('\n');
      this.$.mcpEntryPath.value = form.entryPath; this.$.mcpExtraArgs.value = form.fileArgs.join('\n');
      this.$.mcpRuntimePath.value = form.runtimePath; this.$.mcpRuntimeFallback.hidden = true;
      this.$.mcpCwd.value = configuration.cwd || '';
      this.$.mcpEnv.value = this.mapText(form.env);
      this.$.mcpApplicationPath.value = form.applicationPath;
      this.$.mcpApplicationEnvName.value = form.applicationEnvName;
      this.$.mcpStartupGroup.open = false;
      this.$.mcpEnvironmentGroup.open = false;
      this.$.mcpRemoteAdvanced.open = false;
      for (const id of ['mcpTestButton','mcpSaveButton','mcpCancelButton','mcpEditorBack','mcpEntryBrowse','mcpApplicationBrowse','mcpRuntimeBrowse','mcpCommandBrowse','mcpCwdBrowse']) this.$[id].disabled = false;
      this.$.mcpEnvVars.value = (configuration.envVars || []).join('\n'); this.$.mcpUrl.value = configuration.url || '';
      this.$.mcpBearer.value = configuration.bearerTokenEnvVar || '';
      this.$.mcpAuth.value = configuration.bearerTokenEnvVar ? 'bearer' : 'none'; this.$.mcpBearerRow.hidden = this.$.mcpAuth.value !== 'bearer';
      this.$.mcpHeaders.value = this.mapText(configuration.httpHeaders); this.$.mcpEnvHeaders.value = this.mapText(configuration.envHttpHeaders);
      this.$.mcpEnabled.checked = configuration.enabled !== false; this.$.mcpTestResult.hidden = true; this.$.mcpTestResult.textContent = '';
      this.syncMcpConnectionMode();
      this.showMcpView('editor');
      if (!service) this.$.mcpName.focus?.();
    },

    cancelMcpEditor() {
      if (this._mcpSaving) return;
      const service = this._mcpSnapshot?.services?.find((item) => item.name === this._mcpEditing?.name);
      if (service) this.showMcpDetail(service);
      else this.showMcpView('list');
    },

    syncMcpConnectionMode() {
      const mode = this.$.mcpConnectionMode.value;
      this._mcpTransport = mode === 'remote' ? 'streamable-http' : 'stdio';
      this.$.mcpLocalFields.hidden = mode === 'remote';
      this.$.mcpRemoteFields.hidden = mode !== 'remote';
      this.$.mcpEntryFields.hidden = mode !== 'file';
      this.$.mcpCommandFields.hidden = mode !== 'command';
      this.$.mcpExtraArgsField.hidden = mode !== 'file';
      this.$.mcpTestResult.hidden = true;
      this.syncMcpApplication();
    },

    mcpLocalLaunch() {
      if (this.$.mcpConnectionMode.value === 'file') {
        const launch = entryLaunch(this.$.mcpEntryPath.value, this.$.mcpRuntimePath.value);
        return { ...launch, args: [...launch.args, ...this.$.mcpExtraArgs.value.split(/\r?\n/u).filter((line) => line.length)] };
      }
      return { command: this.$.mcpCommand.value, args: this.$.mcpArgs.value.split(/\r?\n/u).filter((line) => line.length) };
    },

    syncMcpApplication() {
      let known = '';
      try { known = applicationEnvName({ transport: 'stdio', ...this.mcpLocalLaunch() }); } catch (_) { /* An incomplete entry is not an error while typing. */ }
      this.$.mcpApplicationBinding.hidden = !this.$.mcpApplicationPath.value.trim() || Boolean(known);
    },

    async chooseMcpFile(kind) {
      const fields = { entry: ['mcpEntryPath','mcpEntryBrowse'], application: ['mcpApplicationPath','mcpApplicationBrowse'],
        runtime: ['mcpRuntimePath','mcpRuntimeBrowse'], command: ['mcpCommand','mcpCommandBrowse'], directory: ['mcpCwd','mcpCwdBrowse'] };
      const [field, button] = fields[kind] || [];
      if (!field || this._mcpEditorBusy) return;
      const token = this._mcpEditorToken;
      const mode = this.$.mcpConnectionMode.value;
      const valueBefore = this.$[field].value;
      this.$[button].disabled = true;
      try {
        const result = await this.request('browse-mcp-file', { kind });
        if (this._closing || token !== this._mcpEditorToken || mode !== this.$.mcpConnectionMode.value || this.$[field].value !== valueBefore || result.canceled) return;
        if (result.path) this.$[field].value = result.path;
        this.syncMcpApplication();
      } catch (error) {
        if (!this._closing && token === this._mcpEditorToken) this.renderMcpTest(null, error);
      } finally {
        if (!this._closing && token === this._mcpEditorToken) this.$[button].disabled = false;
      }
    },

    mcpDraft() {
      const base = { name: this.$.mcpName.value, transport: this._mcpTransport, enabled: this.$.mcpEnabled.checked };
      if (this._mcpTransport === 'stdio') {
        const result = applyApplication({ ...base, ...this.mcpLocalLaunch(), cwd: this.$.mcpCwd.value,
          env: this.mapLines(this.$.mcpEnv.value),
          envVars: this.$.mcpEnvVars.value.split(/\r?\n/u).map((item) => item.trim()).filter(Boolean) },
        this.$.mcpApplicationPath.value, this.$.mcpApplicationEnvName.value);
        return result.service;
      }
      return { ...base, url: this.$.mcpUrl.value,
        bearerTokenEnvVar: this.$.mcpAuth.value === 'bearer' ? this.$.mcpBearer.value : '',
        httpHeaders: this.mapLines(this.$.mcpHeaders.value), envHttpHeaders: this.mapLines(this.$.mcpEnvHeaders.value) };
    },

    mcpEditorMetadata(draft) {
      if (draft.transport !== 'stdio') return null;
      const result = applyApplication({ ...draft, env: this.mapLines(this.$.mcpEnv.value) },
        this.$.mcpApplicationPath.value, this.$.mcpApplicationEnvName.value);
      return { mode: this.$.mcpConnectionMode.value, ...(result.application ? { application: result.application } : {}) };
    },

    async prepareMcpDraft() {
      const draft = this.validatedMcpDraft();
      const editor = this.mcpEditorMetadata(draft);
      if (this.$.mcpConnectionMode.value !== 'file') return { draft, editor };
      const token = this._mcpEditorToken;
      const original = JSON.stringify({ draft, editor });
      const result = await this.request('resolve-mcp-entry', { entryPath: this.$.mcpEntryPath.value, runtimePath: this.$.mcpRuntimePath.value });
      if (this._closing || token !== this._mcpEditorToken || this._mcpView !== 'editor') throw new Error('配置页面已关闭，本次操作已取消。');
      const current = this.validatedMcpDraft();
      if (original !== JSON.stringify({ draft: current, editor: this.mcpEditorMetadata(current) })) throw new Error('配置已更改，请重新测试或保存。');
      if (!result.ok) {
        this.$.mcpRuntimeFallback.hidden = !result.runtimeRequired;
        const field = result.runtimeRequired ? 'mcpRuntimePath' : 'mcpEntryPath';
        this.$[field].focus?.();
        throw new Error(result.message || '无法读取 MCP 服务入口。');
      }
      return { draft: normalizeService({ ...draft, command: result.command }), editor };
    },

    renderMcpTest(result, error = null) {
      const root = this.$.mcpTestResult; root.textContent = ''; root.hidden = false; root.classList.toggle('is-error', Boolean(error) || !result?.success);
      const doc = root.ownerDocument; const title = doc.createElement('strong');
      title.textContent = error ? /thread not found|app-server (?:was )?stopped/iu.test(error.message || '')
        ? '后台服务已停止或正在重启，本次操作未完成，请重试。' : error.message || '操作未完成，请重试。' : result.summary;
      root.appendChild(title);
      if (result?.application?.status === 'ready') {
        const application = doc.createElement('p'); application.className = 'mcp-check-ok';
        const serviceName = result.name || this._mcpEditing?.name;
        application.textContent = serviceName ? `✓ 已找到 ${serviceName} 使用的应用程序` : '✓ 已找到应用程序';
        root.appendChild(application);
      }
      if (result?.success) { const note = doc.createElement('p'); note.textContent = '已完成连接与工具发现，未调用业务工具。'; root.appendChild(note); }
      if (result?.serverInfo) { const info = doc.createElement('div'); info.textContent = [result.serverInfo.title || result.serverInfo.name, result.serverInfo.version].filter(Boolean).join(' · '); root.appendChild(info); }
      let toolList = root;
      if (result?.tools?.length) {
        toolList = doc.createElement('details'); toolList.className = 'mcp-test-tools';
        const summary = doc.createElement('summary'); summary.textContent = `查看工具（${result.tools.length}）`;
        toolList.appendChild(summary); root.appendChild(toolList);
      }
      for (const tool of result?.tools || []) {
        const item = doc.createElement('details'); item.className = 'mcp-tool';
        const summary = doc.createElement('summary'); summary.textContent = `${result.name || 'MCP'} / ${tool.name}`; item.appendChild(summary);
        if (tool.description) { const description = doc.createElement('p'); description.textContent = tool.description; item.appendChild(description); }
        const schema = doc.createElement('details'); schema.className = 'mcp-tool-schema';
        const schemaSummary = doc.createElement('summary'); schemaSummary.textContent = '参数结构'; schema.appendChild(schemaSummary);
        const pre = doc.createElement('pre'); pre.textContent = JSON.stringify(tool.inputSchema || {}, null, 2); schema.appendChild(pre); item.appendChild(schema);
        toolList.appendChild(item);
      }
      if (error || (!result?.success && (result?.errorDetails || result?.toolsError))) {
        const details = doc.createElement('details'); details.className = 'mcp-error-details';
        const summary = doc.createElement('summary'); summary.textContent = '查看技术详情'; details.appendChild(summary);
        if (result?.errorCode) { const meta = doc.createElement('small'); meta.className = 'mcp-error-code'; meta.textContent = result.errorCode; details.appendChild(meta); }
        const pre = doc.createElement('pre'); pre.textContent = String(error?.message || result?.errorDetails || result?.toolsError || result?.summary || 'Unknown error'); details.appendChild(pre); root.appendChild(details);
      }
      root.scrollIntoView?.({ block: 'nearest' });
    },

    async testMcpDraft() {
      if (this._mcpEditorBusy) return;
      const token = this._mcpEditorToken;
      this._mcpEditorBusy = true;
      this.$.mcpTestButton.disabled = true; this.$.mcpSaveButton.disabled = true;
      this.$.mcpTestResult.hidden = false; this.$.mcpTestResult.textContent = '正在连接服务并读取工具列表…';
      try {
        const { draft } = await this.prepareMcpDraft();
        if (this._closing || token !== this._mcpEditorToken || this._mcpView !== 'editor') return;
        const result = await this.request('test-mcp-service', { service: draft });
        if (!this._closing && token === this._mcpEditorToken) this.renderMcpTest(result);
      } catch (error) {
        if (!this._closing && token === this._mcpEditorToken) this.renderMcpTest(null, error);
      } finally {
        if (!this._closing && token === this._mcpEditorToken) {
          this._mcpEditorBusy = false; this.$.mcpTestButton.disabled = false; this.$.mcpSaveButton.disabled = false;
        }
      }
    },

    validatedMcpDraft() {
      try { return normalizeService(this.mcpDraft()); }
      catch (error) {
        const fields = { name: 'mcpName', entryPath: 'mcpEntryPath', applicationPath: 'mcpApplicationPath', applicationEnvName: 'mcpApplicationEnvName', command: 'mcpCommand', args: this.$.mcpConnectionMode.value === 'file' ? 'mcpExtraArgs' : 'mcpArgs', cwd: 'mcpCwd', env: 'mcpEnv', envVars: 'mcpEnvVars', url: 'mcpUrl', bearerTokenEnvVar: 'mcpBearer', httpHeaders: 'mcpHeaders', envHttpHeaders: 'mcpEnvHeaders' };
        const labels = { command: '命令', args: '参数', cwd: '工作目录', env: '环境变量', envVars: '继承系统变量', url: '服务地址', bearerTokenEnvVar: 'Bearer Token 环境变量' };
        if (['command', 'args', 'cwd'].includes(error.field)) this.$.mcpStartupGroup.open = true;
        if (['env', 'envVars'].includes(error.field) || !error.field) this.$.mcpEnvironmentGroup.open = true;
        if (['httpHeaders', 'envHttpHeaders'].includes(error.field) || (!error.field && this._mcpTransport !== 'stdio')) this.$.mcpRemoteAdvanced.open = true;
        for (const [key, label] of Object.entries(labels)) error.message = error.message.replace(new RegExp(`\\b${key}\\b`, 'gu'), label);
        this.$[fields[error.field] || (this._mcpTransport === 'stdio' ? 'mcpEnv' : 'mcpHeaders')]?.focus?.();
        throw error;
      }
    },

    async saveMcpDraft() {
      if (this._mcpEditorBusy || this._mcpSaving) return;
      const token = this._mcpEditorToken;
      this._mcpEditorBusy = true; this._mcpSaving = true;
      for (const id of ['mcpSaveButton','mcpTestButton','mcpCancelButton','mcpEditorBack']) this.$[id].disabled = true;
      try {
        const { draft, editor } = await this.prepareMcpDraft();
        if (this._closing || token !== this._mcpEditorToken || this._mcpView !== 'editor') return;
        const useOauth = draft.transport === 'streamable-http' && this.$.mcpAuth.value === 'oauth';
        const result = await this.request('save-mcp-service', { service: draft, editor, creating: !this._mcpEditing, expectedVersion: this._mcpSnapshot?.version });
        if (useOauth && !result.reloadPending) await this.request('start-mcp-oauth-login', { name: draft.name });
        if (this._closing || token !== this._mcpEditorToken) return;
        await this.loadMcpServices({ force:true, refresh:true, silent:true });
        if (this._closing || token !== this._mcpEditorToken) return;
        const saved = this._mcpSnapshot?.services?.find((item) => item.name === draft.name);
        if (saved) this.showMcpDetail(saved);
        else this.showMcpView('list');
        if (result.reloadPending) this.showMcpMessage('已保存，将在当前任务完成后应用。');
      } catch (error) { if (!this._closing && token === this._mcpEditorToken) this.renderMcpTest(null, error); }
      finally {
        this._mcpSaving = false;
        if (!this._closing && (token === this._mcpEditorToken || this._mcpView !== 'editor')) {
          this._mcpEditorBusy = false;
          for (const id of ['mcpSaveButton','mcpTestButton','mcpCancelButton','mcpEditorBack']) this.$[id].disabled = false;
        }
      }
    },

    async toggleMcpService() {
      const service = this._mcpSnapshot?.services?.find((item) => item.name === this._mcpSelectedName); if (!service) return;
      try { await this.request('set-mcp-service-enabled', { name: service.name, enabled: service.enabled === false, expectedVersion: this._mcpSnapshot.version }); await this.loadMcpServices({ force:true, refresh:true, silent:true }); }
      catch (error) { this.$.mcpDetailStatus.textContent = error.message || '操作失败。'; }
    },

    async deleteMcpService() {
      const service = this._mcpSnapshot?.services?.find((item) => item.name === this._mcpSelectedName); if (!service) return;
      if (!(typeof window !== 'undefined' && typeof window.confirm === 'function' && window.confirm(`删除 MCP 服务 ${service.name}？`))) return;
      try { await this.request('delete-mcp-service', { name: service.name, expectedVersion: this._mcpSnapshot.version }); this.showMcpView('list'); await this.loadMcpServices({ force:true, refresh:true, silent:true }); }
      catch (error) { this.$.mcpDetailStatus.textContent = error.message || '删除失败。'; }
    },

    async loginMcpOauth() {
      try { await this.request('start-mcp-oauth-login', { name: this._mcpSelectedName }); this.$.mcpDetailStatus.textContent = '已在系统浏览器打开授权页面。'; }
      catch (error) { this.$.mcpDetailStatus.textContent = error.message || '无法开始 OAuth 登录。'; }
    },

    showMcpImport() {
      this._mcpImportServices = []; this.$.mcpImportMessage.hidden = true; this.$.mcpImportPreview.textContent = ''; this.$.mcpImportSaveButton.hidden = true; this.showMcpView('import');
    },

    async previewMcpImport() {
      try {
        const result = await this.request('parse-mcp-configuration', { text: this.$.mcpImportText.value, existingNames: (this._mcpSnapshot?.services || []).map((item) => item.name) });
        this._mcpImportServices = result.services || []; this.$.mcpImportPreview.textContent = '';
        const doc = this.$.mcpImportPreview.ownerDocument;
        for (const service of this._mcpImportServices) { const row = doc.createElement('div'); row.className = 'mcp-import-item'; const name = doc.createElement('strong'); name.textContent = service.name; const type = doc.createElement('span'); type.textContent = service.transport === 'stdio' ? `本地 · ${service.command}` : `远程 · ${service.url}`; row.appendChild(name); row.appendChild(type); this.$.mcpImportPreview.appendChild(row); }
        this.$.mcpImportMessage.hidden = true; this.$.mcpImportSaveButton.hidden = !this._mcpImportServices.length;
      } catch (error) { this.$.mcpImportMessage.textContent = error.message || '配置无效。'; this.$.mcpImportMessage.hidden = false; this.$.mcpImportMessage.classList.add('is-error'); this.$.mcpImportSaveButton.hidden = true; }
    },

    async saveMcpImport() {
      this.$.mcpImportSaveButton.disabled = true;
      try {
        let version = this._mcpSnapshot?.version;
        for (const service of this._mcpImportServices || []) { const result = await this.request('save-mcp-service', { service, creating: true, expectedVersion: version }); version = result.version; }
        this.showMcpView('list'); await this.loadMcpServices({ force:true, refresh:true, silent:true });
      } catch (error) { this.$.mcpImportMessage.textContent = error.message || '导入失败。'; this.$.mcpImportMessage.hidden = false; this.$.mcpImportMessage.classList.add('is-error'); }
      finally { this.$.mcpImportSaveButton.disabled = false; }
    },

    showArchivedMessage(message = '', isError = false) {
      this.$.archivedMessage.textContent = message;
      this.$.archivedMessage.hidden = !message;
      this.$.archivedMessage.classList.toggle('is-error', isError);
    },

    async loadArchivedSessions() {
      const requestId = this._archivedRequestId = (this._archivedRequestId || 0) + 1;
      try {
        const result = await this.request('list-archived-sessions');
        if (this._closing || requestId !== this._archivedRequestId) return;
        if (!Array.isArray(result?.sessions)) throw new Error('Invalid archived list.');
        this.renderArchivedSessions(result.sessions);
        this.showArchivedMessage();
        if (result.warnings?.length) this.showArchivedMessage(result.warnings[0], true);
        return true;
      } catch (_) {
        if (!this._closing && requestId === this._archivedRequestId) this.showArchivedMessage('无法读取已归档的会话，请重新检查。', true);
      }
    },

    renderArchivedSessions(records) {
      const list = this.$.archivedList;
      list.textContent = '';
      const doc = list.ownerDocument;
      if (!records.length) {
        const empty = doc.createElement('p');
        empty.className = 'archived-empty'; empty.textContent = '暂无已归档的会话';
        list.appendChild(empty);
      }
      for (const record of records) {
        const row = doc.createElement('div'); row.className = 'archived-row'; row.dataset.sessionId = record.id;
        const copy = doc.createElement('div'); copy.className = 'archived-copy';
        const title = doc.createElement('strong'); title.className = 'archived-title';
        title.textContent = record.title; title.title = record.title;
        const time = doc.createElement('small'); time.className = 'archived-time';
        time.textContent = `归档于 ${new Date(record.archivedAt).toLocaleDateString()}`;
        copy.appendChild(title); copy.appendChild(time); row.appendChild(copy);
        const restore = doc.createElement('button'); restore.type = 'button'; restore.className = 'text-button'; restore.textContent = '恢复归档';
        const remove = doc.createElement('button'); remove.type = 'button'; remove.className = 'text-button danger'; remove.textContent = '删除';
        let confirming = false;
        const mutate = async (action) => {
          if (this._archivedAction || this._closing) return;
          this._archivedAction = record.id;
          this._archivedRequestId = (this._archivedRequestId || 0) + 1;
          restore.disabled = remove.disabled = true;
          this.showArchivedMessage();
          try {
            const result = await this.request('update-session-lifecycle', { sessionId: record.id, action });
            if (this._closing) return;
            if (!result?.accepted) { this.showArchivedMessage(result?.message || '暂时无法更改会话。', true); return; }
            if (await this.loadArchivedSessions()) {
              this.showArchivedMessage(result.message || (action === 'delete' ? '已删除' : '已恢复归档'), Boolean(result.message));
            }
          } catch (_) {
            if (!this._closing) this.showArchivedMessage('暂时无法更改会话，请检查本地存储。', true);
          } finally {
            this._archivedAction = '';
            if (!this._closing) { restore.disabled = remove.disabled = false; confirming = false; remove.textContent = '删除'; }
          }
        };
        restore.addEventListener('click', () => mutate('unarchive'));
        remove.addEventListener('click', () => {
          if (!confirming) { confirming = true; remove.textContent = '确认删除'; }
          else mutate('delete');
        });
        remove.addEventListener('blur', () => { if (!remove.disabled) { confirming = false; remove.textContent = '删除'; } });
        row.appendChild(restore); row.appendChild(remove); list.appendChild(row);
      }
    },

    showServicesList() {
      this._providerDetail = '';
      this.$.providerListView.hidden = false;
      this.$.openaiDetail.hidden = true;
      this.$.deepseekDetail.hidden = true;
    },

    showProvider(providerId) {
      this.showPage('services');
      this._providerDetail = providerId === 'deepseek' ? 'deepseek' : 'openai';
      this.$.providerListView.hidden = true;
      this.$.openaiDetail.hidden = this._providerDetail !== 'openai';
      this.$.deepseekDetail.hidden = this._providerDetail !== 'deepseek';
    },

    renderOpenAiPane(openai) {
      const pane = this._openAiPane || (['chatgpt','apiKey'].includes(openai.authMethod) ? openai.authMethod : 'chatgpt');
      this._openAiPane = pane;
      this.$.chatgptPane.hidden = pane !== 'chatgpt';
      this.$.openaiKeyPane.hidden = pane !== 'apiKey';
      const hasKey = Boolean(openai.apiKey?.hasKey);
      const editing = !hasKey || this._openAiEditing;
      this.$.openaiSavedKey.hidden = editing;
      this.$.openaiKeyEditor.hidden = !editing;
      this.$.openaiCancelEdit.hidden = !hasKey;
      this.$.openaiVerifyButton.textContent = hasKey ? '验证并更新' : '验证并使用';
      if (!editing) {
        this.$.openaiKeyInput.value = '';
        this.$.openaiKeyInput.type = 'password';
      }
    },

    renderSnapshot(snapshot) {
      if (!snapshot?.providers) return;
      this._snapshot = snapshot;
      const openai = snapshot.providers.openai;
      const deepseek = snapshot.providers.deepseek;
      const chatgptAvailable = Boolean(openai.chatGpt?.connected);
      const keyAvailable = Boolean(openai.apiKey?.hasKey);
      const active = openai.authMethod || 'none';
      const activeLabel = active === 'chatgpt' ? 'ChatGPT' : active === 'apiKey' ? 'API Key' : '未选择';
      this.$.openaiCurrentAuth.textContent = `当前使用：${activeLabel}`;
      this.$.chatgptMethod.classList.toggle('is-active', active === 'chatgpt');
      this.$.openaiKeyMethod.classList.toggle('is-active', active === 'apiKey');
      this.$.chatgptMethodState.textContent = chatgptAvailable ? '已登录' : '未登录';
      this.$.openaiKeyMethodState.textContent = keyAvailable ? '已配置' : '未配置';
      this.$.chatgptState.textContent = chatgptAvailable
        ? `系统 Codex 已登录${openai.chatGpt.planType ? ` · ${openai.chatGpt.planType}` : ''}`
        : '系统 Codex 未登录';
      this.$.chatgptStartButton.hidden = chatgptAvailable;
      this.$.chatgptDisconnectButton.hidden = !(chatgptAvailable && active === 'chatgpt');
      this.$.chatgptLoginButton.hidden = !chatgptAvailable;
      this.$.chatgptMessage.textContent = openai.chatGpt.error || '';
      this.$.chatgptMessage.hidden = !openai.chatGpt.error;
      this.renderOpenAiPane(openai);
      this.$.openaiModelStatus.textContent = modelSummary(openai);
      this.$.deepseekSummary.textContent = deepseek.apiKey?.hasKey ? '当前使用：API Key' : '未配置';
      const deepseekEditing = !deepseek.apiKey?.hasKey || this._deepseekEditing;
      this.$.deepseekSavedKey.hidden = deepseekEditing;
      this.$.deepseekKeyEditor.hidden = !deepseekEditing;
      this.$.deepseekCancelEdit.hidden = !deepseek.apiKey?.hasKey;
      this.$.deepseekVerifyButton.textContent = deepseek.apiKey?.hasKey ? '验证并更新' : '验证并使用';
      if (!deepseekEditing) {
        this.$.deepseekKeyInput.value = '';
        this.$.deepseekKeyInput.type = 'password';
      }
      this.$.deepseekModelStatus.textContent = modelSummary(deepseek);
      const openaiAvailable = chatgptAvailable || keyAvailable;
      const openaiActive = active !== 'none' && openai.status === 'connected';
      this.$.openaiDot.className = `status-dot ${openaiActive ? 'is-connected' : openaiAvailable ? 'is-available' : openai.status === 'error' ? 'is-error' : ''}`;
      this.$.openaiRowSummary.textContent = openaiActive ? `${activeLabel} · 当前使用`
        : openaiAvailable ? '凭据可用 · 尚未选择' : '未配置';
      this.$.deepseekDot.className = `status-dot ${deepseek.apiKey?.hasKey ? 'is-connected' : deepseek.status === 'error' ? 'is-error' : ''}`;
      this.$.deepseekRowSummary.textContent = deepseek.apiKey?.hasKey ? 'API Key · 当前使用' : '未配置';
      this.$.storageNotice.textContent = snapshot.secretStorage?.description || '';
      this.$.runtimeVersion.textContent = snapshot.runtime?.version || '未知';
      this.$.runtimeStatus.textContent = snapshot.runtime?.status === 'running' ? 'Running' : 'Stopped';
      const connection = snapshot.runtime?.connection || {};
      this.$.runtimeManualConnection.hidden = !(connection.message || connection.manualPath);
      this.$.runtimeAutomaticButton.hidden = !connection.manualPath;
      if (!this._runtimePathDirty) this.$.runtimeExecutableInput.value = connection.manualPath || '';
      const connectionMessage = connection.message || this._runtimeFeedback || '';
      this.$.runtimeConnectionMessage.textContent = connectionMessage;
      this.$.runtimeConnectionMessage.hidden = !connectionMessage;
      this.$.runtimeConnectionMessage.classList.toggle('is-error', Boolean(connection.message));
    },

    async checkRuntime(mode = 'check') {
      if (this._runtimeConnecting) return;
      this._runtimeConnecting = true;
      this._runtimeFeedback = '';
      const buttons = [this.$.runtimeCheckButton, this.$.runtimeBrowseButton, this.$.runtimeConnectButton, this.$.runtimeAutomaticButton];
      buttons.forEach((button) => { button.disabled = true; });
      const message = this.$.runtimeConnectionMessage;
      message.hidden = false; message.textContent = '正在检测 Codex 连接…'; message.classList.remove('is-error');
      try {
        const result = await this.request('check-codex-runtime', { mode, executable: this.$.runtimeExecutableInput.value });
        if (this._closing) return;
        if (result.connected) this._runtimePathDirty = false;
        this._runtimeFeedback = result.message || '';
        this.renderSnapshot(result.snapshot);
        message.hidden = false; message.textContent = result.message;
        message.classList.toggle('is-error', !result.connected && !result.deferred);
      } catch (_) {
        if (!this._closing) {
          message.textContent = '暂时无法检查连接，请稍后重试。'; message.classList.add('is-error');
          this.$.runtimeManualConnection.hidden = false;
        }
      } finally {
        this._runtimeConnecting = false;
        if (!this._closing) buttons.forEach((button) => { button.disabled = false; });
      }
    },

    async loadSnapshot(refresh = false) {
      if (this._loadingSnapshot) return this._loadingSnapshot;
      this._loadingSnapshot = this.request(refresh ? 'refresh-model-services' : 'get-model-services')
        .then((snapshot) => { this.renderSnapshot(snapshot); return snapshot; })
        .catch(() => this.showInlineMessage(this._providerDetail || 'openai', '无法连接模型服务，请检查网络后重试。', true))
        .finally(() => {
          this._loadingSnapshot = null;
        });
      return this._loadingSnapshot;
    },

    showInlineMessage(providerId, message, isError = false) {
      const element = providerId === 'deepseek' ? this.$.deepseekKeyMessage : this.$.openaiKeyMessage;
      element.textContent = String(message || '');
      element.hidden = !message;
      element.classList.toggle('is-error', isError);
    },

    async chooseOpenAiMethod(authMethod) {
      const openai = this._snapshot?.providers?.openai;
      this._openAiPane = authMethod;
      if (authMethod === 'apiKey' && !openai?.apiKey?.hasKey) {
        this._openAiEditing = true;
        this.renderSnapshot(this._snapshot);
        return false;
      }
      if (authMethod === 'chatgpt' && !openai?.chatGpt?.connected) {
        this.renderSnapshot(this._snapshot);
        return false;
      }
      if (openai?.authMethod === authMethod) {
        this.renderSnapshot(this._snapshot);
        return false;
      }
      try {
        const snapshot = await this.request('set-openai-auth-method', { authMethod });
        this.renderSnapshot(snapshot);
        return true;
      } catch (_) { this.showInlineMessage('openai', '暂时无法切换连接方式。', true); return false; }
    },

    editKey(providerId) {
      if (providerId === 'deepseek') this._deepseekEditing = true;
      else { this._openAiEditing = true; this._openAiPane = 'apiKey'; }
      this.renderSnapshot(this._snapshot);
      const input = providerId === 'deepseek' ? this.$.deepseekKeyInput : this.$.openaiKeyInput;
      input?.focus?.();
    },

    cancelKeyEdit(providerId) {
      if (providerId === 'deepseek') this._deepseekEditing = false;
      else this._openAiEditing = false;
      this.renderSnapshot(this._snapshot);
    },

    async verifyKey(providerId) {
      const input = providerId === 'deepseek' ? this.$.deepseekKeyInput : this.$.openaiKeyInput;
      const button = providerId === 'deepseek' ? this.$.deepseekVerifyButton : this.$.openaiVerifyButton;
      const key = String(input.value || '').trim();
      if (!key) { this.showInlineMessage(providerId, '请输入 API Key。', true); return; }
      button.disabled = true;
      this.showInlineMessage(providerId, '正在验证…');
      try {
        const result = await this.request('verify-provider-key', { providerId, apiKey: key });
        input.value = '';
        input.type = 'password';
        if (!result?.connected) { this.showInlineMessage(providerId, result?.message || '连接失败。', true); return; }
        if (providerId === 'deepseek') this._deepseekEditing = false;
        else this._openAiEditing = false;
        this.showInlineMessage(providerId, result.persistent ? '已验证并使用。' : '已验证；Key 仅保留到本次 Creator 关闭。');
        this.renderSnapshot(result.snapshot);
      } catch (_) {
        input.value = '';
        input.type = 'password';
        this.showInlineMessage(providerId, '连接失败，API Key 无效或当前服务不可用。', true);
      } finally { button.disabled = false; }
    },

    async removeKey(providerId) {
      const confirmed = typeof window !== 'undefined' && typeof window.confirm === 'function'
        && window.confirm(`删除已保存的 ${providerId === 'deepseek' ? 'DeepSeek' : 'OpenAI'} API Key？`);
      if (!confirmed) return;
      try {
        const snapshot = await this.request('remove-provider-key', { providerId });
        if (providerId === 'deepseek') this._deepseekEditing = true;
        else this._openAiEditing = true;
        this.showInlineMessage(providerId, 'API Key 已删除。');
        this.renderSnapshot(snapshot);
      } catch (_) { this.showInlineMessage(providerId, '暂时无法删除 API Key。', true); }
    },

    toggleSecretVisibility(input, button) {
      const hide = input.type === 'text';
      input.type = hide ? 'password' : 'text';
      button.title = hide ? '暂时显示' : '隐藏';
      button.setAttribute('aria-label', `${button.title}当前输入的 API Key`);
    },

    async disconnectChatGpt() {
      try {
        const snapshot = await this.request('set-openai-auth-method', { authMethod: 'none' });
        this.renderSnapshot(snapshot);
      } catch (_) { this.$.chatgptMessage.textContent = '暂时无法断开 AI Copilot。'; this.$.chatgptMessage.hidden = false; }
    },

    async handleChatGptAction(startLogin = false) {
      if (this._snapshot?.login?.status === 'connecting') {
        await this.request('cancel-chatgpt-login').catch(() => {});
        await this.loadSnapshot();
        return;
      }
      if (!startLogin && this._snapshot?.providers?.openai?.chatGpt?.connected) {
        await this.loadSnapshot(true);
        return;
      }
      const result = await this.request('start-chatgpt-login').catch(() => ({ started:false, message:'无法开始 ChatGPT 登录，请重试。' }));
      if (!result.started && !result.duplicate) {
        this.$.chatgptMessage.textContent = result.message || '无法开始 ChatGPT 登录，请重试。';
        this.$.chatgptMessage.hidden = false;
      }
      await this.loadSnapshot();
    },
  },

  ready() {
    this._closing = false;
    this._listeners = [];
    this._providerDetail = '';
    this._mcpView = 'list';
    this._mcpSnapshot = null;
    this._mcpSnapshotStale = false;
    this._mcpLoadPromise = null;
    this._mcpLoadRefresh = false;
    this._openAiPane = '';
    this._openAiEditing = false;
    this._deepseekEditing = false;
    const on = (element, name, handler) => { element.addEventListener(name, handler); this._listeners.push(() => element.removeEventListener(name, handler)); };
    for (const hint of this.$.mcpPage.querySelectorAll('.mcp-help')) {
      const show = () => {
        hint.removeAttribute('data-dismissed'); hint.classList.remove('is-above');
        const popup = hint.querySelector('.mcp-help-tooltip');
        if (popup.getBoundingClientRect().bottom > hint.ownerDocument.defaultView.innerHeight - 12) hint.classList.add('is-above');
      };
      on(hint, 'mouseenter', show); on(hint, 'focusin', show);
      on(hint, 'keydown', (event) => { if (event.key === 'Escape') { hint.setAttribute('data-dismissed', ''); event.stopPropagation(); } });
      on(hint.querySelector('.mcp-help-trigger'), 'click', (event) => { event.preventDefault(); event.stopPropagation(); });
    }
    on(this.$.servicesNav,'click',() => { this.showPage('services'); this.showServicesList(); });
    on(this.$.cocosNav,'click',() => this.showPage('cocos'));
    on(this.$.mcpNav,'click',() => { this.showPage('mcp'); this.showMcpView('list'); });
    on(this.$.environmentNav,'click',() => this.showPage('environment'));
    on(this.$.runtimeNav,'click',() => this.showPage('runtime'));
    on(this.$.archivedNav,'click',() => { this.showArchivedMessage(); this.showPage('archived'); });
    const check = (button, operation) => on(button, 'click', async () => {
      if (button.disabled) return;
      const label = button.textContent; button.disabled = true; button.textContent = '正在检查…';
      try { await operation(); }
      finally { if (!this._closing) { button.disabled = false; button.textContent = label; } }
    });
    check(this.$.servicesCheckButton, () => this.loadSnapshot(true));
    check(this.$.archivedCheckButton, () => this.loadArchivedSessions());
    check(this.$.cocosBuiltinCheckButton, () => this.loadCocosCapabilities({ builtinOnly:true }));
    check(this.$.mcpCheckButton, () => this.loadMcpServices({ force:true, refresh:true }));
    check(this.$.environmentCheckButton, () => this.loadEnvironment());
    on(this.$.runtimeCheckButton,'click',() => this.checkRuntime());
    on(this.$.runtimeConnectButton,'click',() => this.checkRuntime('manual'));
    on(this.$.runtimeAutomaticButton,'click',() => this.checkRuntime('auto'));
    on(this.$.runtimeExecutableInput,'input',() => { this._runtimePathDirty = true; });
    on(this.$.runtimeBrowseButton,'click',async () => {
      const result = await this.request('browse-codex-runtime').catch(() => null);
      if (!this._closing && result && !result.canceled) {
        this.$.runtimeExecutableInput.value = result.path; this._runtimePathDirty = true;
      }
    });
    on(this.$.openaiRow,'click',() => this.showProvider('openai'));
    on(this.$.deepseekRow,'click',() => this.showProvider('deepseek'));
    on(this.$.openaiBack,'click',() => this.showServicesList());
    on(this.$.deepseekBack,'click',() => this.showServicesList());
    on(this.$.chatgptMethod,'click',() => this.chooseOpenAiMethod('chatgpt'));
    on(this.$.openaiKeyMethod,'click',() => this.chooseOpenAiMethod('apiKey'));
    on(this.$.chatgptLoginButton,'click',() => this.handleChatGptAction(false));
    on(this.$.chatgptStartButton,'click',() => this.handleChatGptAction(true));
    on(this.$.chatgptDisconnectButton,'click',() => this.disconnectChatGpt());
    on(this.$.openaiChangeButton,'click',() => this.editKey('openai'));
    on(this.$.deepseekChangeButton,'click',() => this.editKey('deepseek'));
    on(this.$.openaiCancelEdit,'click',() => this.cancelKeyEdit('openai'));
    on(this.$.deepseekCancelEdit,'click',() => this.cancelKeyEdit('deepseek'));
    on(this.$.openaiVerifyButton,'click',() => this.verifyKey('openai'));
    on(this.$.deepseekVerifyButton,'click',() => this.verifyKey('deepseek'));
    on(this.$.openaiRemoveButton,'click',() => this.removeKey('openai'));
    on(this.$.deepseekRemoveButton,'click',() => this.removeKey('deepseek'));
    on(this.$.openaiRevealButton,'click',() => this.toggleSecretVisibility(this.$.openaiKeyInput,this.$.openaiRevealButton));
    on(this.$.deepseekRevealButton,'click',() => this.toggleSecretVisibility(this.$.deepseekKeyInput,this.$.deepseekRevealButton));
    on(this.$.mcpAddButton,'click',() => { this.$.mcpAddChoices.hidden = !this.$.mcpAddChoices.hidden; });
    on(this.$.mcpAddLocal,'click',() => this.showMcpEditor('stdio'));
    on(this.$.mcpAddRemote,'click',() => this.showMcpEditor('streamable-http'));
    on(this.$.mcpImportOpen,'click',() => this.showMcpImport());
    on(this.$.mcpDetailBack,'click',() => this._mcpDetailOrigin === 'creator-extension' ? this.showPage('cocos') : this.showMcpView('list'));
    on(this.$.mcpEditorBack,'click',() => this.cancelMcpEditor());
    on(this.$.mcpCancelButton,'click',() => this.cancelMcpEditor());
    on(this.$.mcpConnectionMode,'change',() => this.syncMcpConnectionMode());
    for (const [id, kind] of [['mcpEntryBrowse','entry'],['mcpApplicationBrowse','application'],['mcpRuntimeBrowse','runtime'],['mcpCommandBrowse','command'],['mcpCwdBrowse','directory']]) {
      on(this.$[id],'click',() => this.chooseMcpFile(kind));
    }
    for (const id of ['mcpEntryPath','mcpCommand','mcpArgs','mcpApplicationPath']) on(this.$[id],'input',() => this.syncMcpApplication());
    on(this.$.mcpImportBack,'click',() => this.showMcpView('list'));
    on(this.$.mcpImportCancel,'click',() => this.showMcpView('list'));
    on(this.$.mcpAuth,'change',() => { this.$.mcpBearerRow.hidden = this.$.mcpAuth.value !== 'bearer'; });
    on(this.$.mcpTestButton,'click',() => this.testMcpDraft());
    on(this.$.mcpSaveButton,'click',() => this.saveMcpDraft());
    on(this.$.mcpEditButton,'click',() => { const service = this._mcpSnapshot?.services?.find((item) => item.name === this._mcpSelectedName); if (service) this.showMcpEditor(service.transport, service); });
    on(this.$.mcpToggleButton,'click',() => this.toggleMcpService());
    on(this.$.mcpDeleteButton,'click',() => this.deleteMcpService());
    on(this.$.mcpOauthButton,'click',() => this.loginMcpOauth());
    on(this.$.mcpImportPreviewButton,'click',() => this.previewMcpImport());
    on(this.$.mcpImportSaveButton,'click',() => this.saveMcpImport());
    on(this.$.cocosRuntimeToggle,'click',() => this.toggleCocosRuntime());
    check(this.$.cocosMcpManage, () => this.loadExternalCocosMcp({ refresh:true }));
    const settingsWindow = this.$.cocosPage.ownerDocument?.defaultView;
    if (settingsWindow?.addEventListener) on(settingsWindow,'focus',() => {
      if (this._page === 'cocos') this.loadExternalCocosMcp({ refresh:true });
    });
    this._modelServicesChanged = () => this.loadSnapshot();
    this._settingsNavigation = (payload = {}) => {
      if (payload.section === 'runtime') this.showPage('runtime');
      else if (payload.section === 'cocos') this.showPage('cocos');
      else if (payload.section === 'archived') this.showPage('archived');
      else if (payload.section === 'mcp') { this.showPage('mcp'); this.showMcpView('list'); }
      else if (payload.providerId) this.showProvider(payload.providerId);
      else { this.showPage('services'); this.showServicesList(); }
    };
    this._sessionLifecycleChanged = () => { if (this._page === 'archived' && !this._archivedAction) this.loadArchivedSessions(); };
    this._mcpServicesChanged = () => {
      this._mcpSnapshotStale = true;
      if (this._page === 'mcp') this.loadMcpServices({ force:true, silent:true });
    };
    if (Editor.Message?.addBroadcastListener) {
      Editor.Message.addBroadcastListener(MODEL_SERVICES_EVENT_CHANNEL,this._modelServicesChanged);
      Editor.Message.addBroadcastListener(SETTINGS_NAVIGATION_EVENT_CHANNEL,this._settingsNavigation);
      Editor.Message.addBroadcastListener(SESSION_LIFECYCLE_EVENT_CHANNEL,this._sessionLifecycleChanged);
      Editor.Message.addBroadcastListener(MCP_SERVICES_EVENT_CHANNEL,this._mcpServicesChanged);
    }
    this.showServicesList();
    this.loadSnapshot();
    this.loadMcpServices({ silent:true });
  },

  close() {
    this._closing = true;
    (this._listeners || []).forEach((dispose) => dispose());
    this._listeners = [];
    if (Editor.Message?.removeBroadcastListener) {
      Editor.Message.removeBroadcastListener(MODEL_SERVICES_EVENT_CHANNEL,this._modelServicesChanged);
      Editor.Message.removeBroadcastListener(SETTINGS_NAVIGATION_EVENT_CHANNEL,this._settingsNavigation);
      Editor.Message.removeBroadcastListener(SESSION_LIFECYCLE_EVENT_CHANNEL,this._sessionLifecycleChanged);
      Editor.Message.removeBroadcastListener(MCP_SERVICES_EVENT_CHANNEL,this._mcpServicesChanged);
    }
    Editor.Message?.request?.(EXTENSION_NAME,'settings-panel-closed').catch?.(() => {});
    this._modelServicesChanged = null;
    this._settingsNavigation = null;
    this._mcpServicesChanged = null;
    this._mcpLoadPromise = null;
    this._mcpLoadRefresh = false;
    this._cocosSnapshot = null;
    this._snapshot = null;
  },
});
