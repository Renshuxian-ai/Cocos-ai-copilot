'use strict';

const EXTENSION_NAME = 'cocos-ai-copilot';
const DETAIL_EVENT_CHANNEL = `${EXTENSION_NAME}:detail-changed`;

const template = `
  <main class="detail-root">
    <header class="detail-header">
      <svg class="detail-icon" viewBox="0 0 16 16" aria-hidden="true">
        <path d="M4 1.75h5l3 3v9.5H4a1 1 0 0 1-1-1V2.75a1 1 0 0 1 1-1Z"></path>
        <path d="M9 1.75v3h3M5.5 8h4.75M5.5 10.5h4.75"></path>
      </svg>
      <div class="detail-heading">
        <div id="detailTitle" class="detail-title">AI Copilot Detail</div>
        <div id="detailMeta" class="detail-meta"></div>
      </div>
    </header>
    <section class="detail-body">
      <div id="detailEmpty" class="detail-empty">无法加载该内容</div>
      <pre id="detailContent" class="detail-content" tabindex="0" hidden></pre>
    </section>
  </main>
`;

const style = `
  :host {
    display: block;
    width: 100%;
    height: 100%;
    color: var(--color-normal-contrast, #d6d6d6);
    background: var(--color-normal-fill, #242424);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  }

  * { box-sizing: border-box; }

  .detail-root {
    display: flex;
    width: 100%;
    height: 100%;
    min-width: 0;
    min-height: 0;
    flex-direction: column;
  }

  .detail-header {
    display: flex;
    flex: 0 0 auto;
    min-width: 0;
    min-height: 46px;
    padding: 9px 14px;
    align-items: center;
    gap: 9px;
    border-bottom: 1px solid rgba(128, 128, 128, 0.2);
    background: var(--color-normal-fill, #242424);
  }

  .detail-icon {
    width: 16px;
    height: 16px;
    flex: 0 0 auto;
    fill: none;
    stroke: var(--color-normal-contrast-weak, #a7a7a7);
    stroke-width: 1.15;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .detail-heading { min-width: 0; }

  .detail-title {
    overflow: hidden;
    color: var(--color-normal-contrast, #d6d6d6);
    font-size: 13px;
    line-height: 18px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .detail-meta {
    overflow: hidden;
    color: var(--color-normal-contrast-weakest, #747474);
    font-size: 11px;
    line-height: 15px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .detail-body {
    position: relative;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    overflow: auto;
  }

  .detail-content {
    min-width: 100%;
    min-height: 100%;
    margin: 0;
    padding: 16px 18px 28px;
    border: 0;
    outline: 0;
    color: var(--color-normal-contrast, #d6d6d6);
    background: transparent;
    font-family: var(--font-mono, Consolas, "Cascadia Mono", monospace);
    font-size: 13px;
    line-height: 20px;
    overflow-wrap: anywhere;
    white-space: pre-wrap;
    word-break: break-word;
    user-select: text;
    -webkit-user-select: text;
  }

  .detail-content[hidden] { display: none; }

  .detail-empty {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    color: var(--color-normal-contrast-weakest, #747474);
    font-size: 12px;
    text-align: center;
  }

  .detail-empty[hidden] { display: none; }

  .detail-body::-webkit-scrollbar { width: 6px; height: 6px; }
  .detail-body::-webkit-scrollbar-thumb {
    border-radius: 6px;
    background: rgba(128, 128, 128, 0.25);
  }
  .detail-body:hover::-webkit-scrollbar-thumb { background: rgba(128, 128, 128, 0.42); }
`;

module.exports = Editor.Panel.define({
  template,
  style,
  $: {
    detailContent: '#detailContent',
    detailEmpty: '#detailEmpty',
    detailMeta: '#detailMeta',
    detailTitle: '#detailTitle',
  },
  methods: {
    renderDetail(document) {
      const valid = document && document.id && document.type === 'text';
      this._activeDetail = valid ? { ...document } : null;
      this.$.detailTitle.textContent = valid ? document.title : 'AI Copilot Detail';
      this.$.detailMeta.textContent = valid
        ? `${Number(document.charCount || 0).toLocaleString()} 字 · ${Number(document.lineCount || 0).toLocaleString()} 行 · 只读`
        : '';
      this.$.detailContent.textContent = valid ? String(document.content || '') : '';
      this.$.detailContent.hidden = !valid;
      this.$.detailEmpty.hidden = Boolean(valid);
    },

    async loadActiveDetail(detailId = '') {
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        this.renderDetail(null);
        return;
      }
      try {
        const document = await Editor.Message.request(
          EXTENSION_NAME,
          'get-detail',
          { detailId: String(detailId || '') }
        );
        this.renderDetail(document);
      } catch (error) {
        console.warn(`[AI Copilot Detail] Unable to load detail: ${error.message}`);
        this.renderDetail(null);
      }
    },

    detailSelectionText() {
      const content = this.$.detailContent;
      if (!content || content.hidden) return '';
      const ownerDocument = content.ownerDocument || document;
      const ownerWindow = ownerDocument.defaultView || window;
      const root = typeof content.getRootNode === 'function' ? content.getRootNode() : null;
      const candidates = [
        ownerWindow && typeof ownerWindow.getSelection === 'function'
          ? ownerWindow.getSelection()
          : null,
        root && typeof root.getSelection === 'function' ? root.getSelection() : null,
      ];
      const containsNode = (node) => {
        const element = node && node.nodeType === 3 ? node.parentNode : node;
        return Boolean(element && (element === content || content.contains(element)));
      };
      const selection = candidates.find((candidate) => (
        candidate
        && !candidate.isCollapsed
        && String(candidate).trim()
        && containsNode(candidate.anchorNode)
        && containsNode(candidate.focusNode)
      ));
      return selection ? String(selection) : '';
    },

    selectAllDetailContent() {
      const content = this.$.detailContent;
      if (!content || content.hidden) return false;
      const ownerDocument = content.ownerDocument || document;
      const ownerWindow = ownerDocument.defaultView || window;
      const root = typeof content.getRootNode === 'function' ? content.getRootNode() : null;
      const selection = ownerWindow && typeof ownerWindow.getSelection === 'function'
        ? ownerWindow.getSelection()
        : root && typeof root.getSelection === 'function' ? root.getSelection() : null;
      if (!selection) return false;
      const range = ownerDocument.createRange();
      range.selectNodeContents(content);
      selection.removeAllRanges();
      selection.addRange(range);
      return true;
    },

    async showDetailNativeContextMenu(selectedText = '') {
      if (this._nativeContextMenuPending) return false;
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        console.warn('[AI Copilot Detail] Native context menu is unavailable.');
        return false;
      }
      this._nativeContextMenuPending = true;
      try {
        const result = await Editor.Message.request(
          EXTENSION_NAME,
          'show-context-menu',
          { kind: 'detail', selectedText: String(selectedText || '') }
        );
        if (result && result.action === 'select-all') this.selectAllDetailContent();
        return Boolean(result && result.shown);
      } catch (error) {
        console.warn(`[AI Copilot Detail] Unable to show native context menu: ${error.message}`);
        return false;
      } finally {
        this._nativeContextMenuPending = false;
      }
    },

    cancelDetailContextMenuFallback() {
      if (this._detailContextFallbackTimer != null) {
        clearTimeout(this._detailContextFallbackTimer);
        this._detailContextFallbackTimer = null;
      }
    },
  },

  ready() {
    this._nativeContextMenuPending = false;
    this._detailChangedHandler = (payload = {}) => {
      this.loadActiveDetail(payload.detailId);
    };
    if (global.Editor && Editor.Message && typeof Editor.Message.addBroadcastListener === 'function') {
      Editor.Message.addBroadcastListener(DETAIL_EVENT_CHANNEL, this._detailChangedHandler);
    }
    this._selectAllHandler = (event) => {
      if (!(event.ctrlKey || event.metaKey) || String(event.key || '').toLowerCase() !== 'a') return;
      if (this.$.detailContent.hidden) return;
      event.preventDefault();
      event.stopPropagation();
      this.selectAllDetailContent();
    };
    this._detailContextMenuHandler = (event) => {
      const selectedText = this.detailSelectionText();
      this.cancelDetailContextMenuFallback();
      event.preventDefault();
      event.stopPropagation();
      this.showDetailNativeContextMenu(selectedText);
    };
    this._detailRightMouseDownHandler = (event) => {
      if (Number(event.button) !== 2 || this.$.detailContent.hidden) return;
      this.cancelDetailContextMenuFallback();
      const selectedText = this.detailSelectionText();
      this._detailContextFallbackTimer = setTimeout(() => {
        this._detailContextFallbackTimer = null;
        this.showDetailNativeContextMenu(selectedText);
      }, 80);
    };
    this.$.detailContent.addEventListener('keydown', this._selectAllHandler, true);
    this.$.detailContent.addEventListener('contextmenu', this._detailContextMenuHandler, true);
    this.$.detailContent.addEventListener('mousedown', this._detailRightMouseDownHandler, true);
    this.loadActiveDetail();
  },

  close() {
    if (
      this._detailChangedHandler
      && global.Editor
      && Editor.Message
      && typeof Editor.Message.removeBroadcastListener === 'function'
    ) {
      Editor.Message.removeBroadcastListener(DETAIL_EVENT_CHANNEL, this._detailChangedHandler);
    }
    if (this._selectAllHandler && this.$.detailContent) {
      this.$.detailContent.removeEventListener('keydown', this._selectAllHandler, true);
    }
    if (this._detailContextMenuHandler && this.$.detailContent) {
      this.$.detailContent.removeEventListener('contextmenu', this._detailContextMenuHandler, true);
    }
    if (this._detailRightMouseDownHandler && this.$.detailContent) {
      this.$.detailContent.removeEventListener('mousedown', this._detailRightMouseDownHandler, true);
    }
    this.cancelDetailContextMenuFallback();
    this._detailChangedHandler = null;
    this._selectAllHandler = null;
    this._detailContextMenuHandler = null;
    this._detailRightMouseDownHandler = null;
    this._nativeContextMenuPending = false;
    this._activeDetail = null;
  },
});
