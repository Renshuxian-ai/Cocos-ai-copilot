'use strict';

const {
  linkToolActivitiesToGuardTraces,
  reconcileToolRetries,
} = require('../lib/tool-activity-state');
const {
  buildCocosExecutionPrompt,
  createCocosContextSnapshot,
} = require('../lib/cocos-context-snapshot');
const { sessionDocument } = require('../lib/session-store');
const { CoalescedSessionWriter } = require('../lib/coalesced-session-writer');
const { renderTurnPresentation } = require('./turn-presentation');
const createActivityMethods = require('./activity-controller');
const { normalizeProviderError } = require('../lib/model-services');
const {
  projectUndoOutcome,
  projectUndoSummary,
} = require('../lib/review-semantic');
const { createReviewPresentation } = require('../lib/review-presentation');
const { tokenizeInlineMarkdown } = require('./inline-markdown');
const { createArtifactProjectUsageResolver } = require('./artifact-presentation');
const { AUDIO_STATUS_FIELDS, audioStatusPatch, audioStatusView } = require('../lib/audio/status-model');
const { audioBindings, audioVersionLabel, groupAudioArtifacts } = require('../lib/audio/artifact-lineage');

const EXTENSION_NAME = 'cocos-ai-copilot';
const CODEX_EVENT_CHANNEL = `${EXTENSION_NAME}:codex-event`;
const NEW_SESSION_EVENT_CHANNEL = `${EXTENSION_NAME}:new-session-requested`;
const MODEL_SERVICES_EVENT_CHANNEL = `${EXTENSION_NAME}:model-services-changed`;
const SESSION_LIFECYCLE_EVENT_CHANNEL = `${EXTENSION_NAME}:session-lifecycle-changed`;
const PREVIEW_STATE_POLL_INTERVAL_MS = 1000;
const SCROLL_BOTTOM_THRESHOLD_PX = 24;
const LONG_PASTE_CHAR_THRESHOLD = 1500;
const LONG_PASTE_LINE_THRESHOLD = 20;
const TEXT_ATTACHMENT_PREVIEW_CHAR_LIMIT = 72;
const TOOLS_REFRESH_SPIN_MS = 850;

const { template, style, PROMPT_COLLAPSED_LINES } = require('./chat-view');

module.exports = Editor.Panel.define({
  template,
  style,

  listeners: {
    show() {
      if (typeof this.scheduleGlobalContextRegistration === 'function') {
        this.scheduleGlobalContextRegistration();
      }
    },
    hide() {
      if (typeof this.unregisterGlobalContextMenu === 'function') {
        this.unregisterGlobalContextMenu();
      }
    },
  },

  $: {
    agentButton: '#agentButton',
    agentMenu: '#agentMenu',
    attachButton: '#attachButton',
    root: '.copilot-root',
    activityScroller: '#activityScroller',
    activityContent: '#activityContent',
    approvalTray: '#approvalTray',
    composerAttachments: '#composerAttachments',
    composerInput: '#composerInput',
    composerPinPopover: '#composerPinPopover',
    composerSurface: '#composerSurface',
    composerToast: '#composerToast',
    fileDropHint: '#fileDropHint',
    connectionDot: '#connectionDot',
    emptyState: '#emptyState',
    modeLabel: '#modeLabel',
    modelButton: '#modelButton',
    modelMenu: '#modelMenu',
    newSessionButton: '#newSessionButton',
    firstRunOnboarding: '#firstRunOnboarding',
    onboardingChatGpt: '#onboardingChatGpt',
    onboardingOpenAiKey: '#onboardingOpenAiKey',
    onboardingDeepSeekKey: '#onboardingDeepSeekKey',
    onboardingMessage: '#onboardingMessage',
    cancelPinModeButton: '#cancelPinModeButton',
    confirmPinModeButton: '#confirmPinModeButton',
    pendingPinCount: '#pendingPinCount',
    pinCount: '#pinCount',
    pinDropHint: '#pinDropHint',
    pinEntryButton: '#pinEntryButton',
    pinModeBar: '#pinModeBar',
    permissionButton: '#permissionButton',
    permissionMenu: '#permissionMenu',
    renameSessionButton: '#renameSessionButton',
    continueSessionButton: '#continueSessionButton',
    archiveSessionButton: '#archiveSessionButton',
    deleteSessionButton: '#deleteSessionButton',
    deleteSessionLabel: '#deleteSessionLabel',
    renameSessionCancel: '#renameSessionCancel',
    renameSessionDialog: '#renameSessionDialog',
    renameSessionInput: '#renameSessionInput',
    renameSessionSave: '#renameSessionSave',
    queueArea: '#queueArea',
    queueClearButton: '#queueClearButton',
    queueContextMenu: '#queueContextMenu',
    queueEditButton: '#queueEditButton',
    queueItems: '#queueItems',
    queuePausedStatus: '#queuePausedStatus',
    reasoningButton: '#reasoningButton',
    reasoningMenu: '#reasoningMenu',
    scrollToLatestButton: '#scrollToLatestButton',
    sendButton: '#sendButton',
    sessionHistory: '#sessionHistory',
    sessionHistoryButton: '#sessionHistoryButton',
    sessionList: '#sessionList',
    sessionMoreButton: '#sessionMoreButton',
    sessionMoreMenu: '#sessionMoreMenu',
    sessionSearchInput: '#sessionSearchInput',
    sessionStatus: '#sessionStatus',
    sessionNotice: '#sessionNotice',
    sessionTitleButton: '#sessionTitleButton',
    settingsButton: '#settingsButton',
    toolsButton: '#toolsButton',
    toolsPopover: '#toolsPopover',
  },

  methods: {
    clearElement(element) {
      if (!element) return;
      while (element.firstChild) element.removeChild(element.firstChild);
    },

    createElement(ownerDocument, tagName, className, text) {
      const element = ownerDocument.createElement(tagName);
      if (className) element.className = className;
      if (text !== undefined && text !== null) element.textContent = String(text);
      return element;
    },

    providerSnapshot(providerId) {
      return this._modelServicesSnapshot?.providers?.[providerId] || null;
    },

    availableProviderIds() {
      return ['openai', 'deepseek'].filter((providerId) => {
        const provider = this.providerSnapshot(providerId);
        return provider?.status === 'connected' && Array.isArray(provider.models) && provider.models.length;
      });
    },

    modelForSelection(selection = {}) {
      return (this.providerSnapshot(selection.providerId)?.models || [])
        .find((model) => model.id === selection.modelId && !model.hidden) || null;
    },

    normalizedModelSelection(selection = {}, allowProviderFallback = true) {
      const available = this.availableProviderIds();
      let providerId = ['openai', 'deepseek'].includes(selection.providerId)
        ? selection.providerId : this._modelServicesSnapshot?.lastUsedProvider || 'openai';
      if (allowProviderFallback && !available.includes(providerId) && available.length) providerId = available[0];
      const providerModels = (this.providerSnapshot(providerId)?.models || []).filter((model) => !model.hidden);
      if (!providerModels.length) return {
        providerId,
        modelId: String(selection.modelId || ''),
        reasoningEffort: String(selection.reasoningEffort || ''),
      };
      let model = providerModels.find((item) => item.id === selection.modelId);
      if (!model) model = providerModels.find((item) => item.isDefault) || providerModels[0] || null;
      const efforts = model?.supportedReasoningEfforts || [];
      let reasoningEffort = String(selection.reasoningEffort || '');
      if (!efforts.some((item) => item.reasoningEffort === reasoningEffort)) {
        reasoningEffort = efforts.some((item) => item.reasoningEffort === model?.defaultReasoningEffort)
          ? model.defaultReasoningEffort : efforts[0]?.reasoningEffort || '';
      }
      return { providerId, modelId: model?.id || '', reasoningEffort };
    },

    currentModelSelection() {
      const session = this._sessionView === 'conversation' ? this.activeSession() : null;
      return this.normalizedModelSelection(session || this._newSessionModelSelection || {}, !session);
    },

    effortLabel(value) {
      const effort = String(value || '');
      return ({ low: '轻度', medium: '中', high: '高', xhigh: '极高', max: 'Max', ultra: 'Ultra' })[effort]
        || effort.replace(/(^|[-_])(\w)/gu, (_, __, letter) => letter.toUpperCase());
    },

    exposedReasoningEfforts(model, providerId) {
      const efforts = Array.isArray(model?.supportedReasoningEfforts)
        ? model.supportedReasoningEfforts : [];
      if (providerId !== 'openai') return efforts;
      const ids = new Set(efforts.map((entry) => entry.reasoningEffort));
      return ids.has('xhigh') && ids.has('max') && ids.has('ultra')
        ? efforts.filter((entry) => entry.reasoningEffort !== 'max') : efforts;
    },

    prefersReducedMotion() {
      try { return Boolean(globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches); }
      catch (_) { return false; }
    },

    updatePickerControl(control, text, animate = false) {
      if (!control) return;
      const next = String(text || '');
      if (control.textContent === next) return;
      control.textContent = next;
      if (!animate || this.prefersReducedMotion()) return;
      control.classList.add('is-updating');
      setTimeout(() => control.classList.remove('is-updating'), 150);
    },

    updateModelButton(animate = false) {
      if (!this.$.modelButton) return;
      const selection = this.currentModelSelection();
      const model = this.modelForSelection(selection);
      const label = model?.displayName || model?.id || '选择模型';
      this.updatePickerControl(this.$.modelButton, label, animate);
      this.$.modelButton.title = model
        ? `${this.providerSnapshot(selection.providerId)?.displayName || selection.providerId} · ${label}`
        : '连接模型服务';
      this.$.modelButton.classList.toggle('is-unavailable', !model);
      const efforts = this.exposedReasoningEfforts(model, selection.providerId);
      const effortLabel = selection.reasoningEffort ? this.effortLabel(selection.reasoningEffort) : '—';
      this.updatePickerControl(this.$.reasoningButton, effortLabel, animate);
      if (this.$.reasoningButton) {
        this.$.reasoningButton.hidden = !efforts.length;
        this.$.reasoningButton.disabled = !efforts.length;
        this.$.reasoningButton.title = efforts.length ? `思考强度 · ${effortLabel}` : '当前模型没有思考强度选项';
      }
    },

    updateOnboarding() {
      const snapshot = this._modelServicesSnapshot;
      if (!this.$.root || !this.$.firstRunOnboarding || !snapshot) return;
      const onboarding = !snapshot.hasConfiguredProvider;
      this.$.firstRunOnboarding.hidden = !onboarding;
      this.$.root.classList.toggle('is-onboarding', onboarding);
      const connecting = snapshot.login?.status === 'connecting';
      this.$.onboardingChatGpt.textContent = connecting ? '取消 ChatGPT 登录' : '使用 ChatGPT 登录';
      this.$.onboardingChatGpt.disabled = false;
      if (!onboarding && this.$.onboardingMessage) this.$.onboardingMessage.hidden = true;
    },

    applyModelServicesSnapshot(snapshot) {
      if (!snapshot?.providers) return;
      this._modelServicesSnapshot = snapshot;
      this._newSessionModelSelection = this.normalizedModelSelection(
        this._newSessionModelSelection || { providerId: snapshot.lastUsedProvider },
        true
      );
      if (this._sessions) this._sessions.forEach((session) => {
        const normalized = this.normalizedModelSelection(session, false);
        const changed = normalized.modelId && (session.modelId !== normalized.modelId
          || session.reasoningEffort !== normalized.reasoningEffort);
        session.providerId = normalized.providerId;
        session.modelId = normalized.modelId || session.modelId || '';
        session.reasoningEffort = normalized.reasoningEffort;
        if (changed && this._persistenceReady) this.persistSession(session.id, true);
      });
      this.updateOnboarding();
      this.updateModelButton();
      if (this.$.modelMenu && !this.$.modelMenu.hidden) this.renderModelMenu();
      if (this.$.reasoningMenu && !this.$.reasoningMenu.hidden) this.renderReasoningMenu();
    },

    async refreshModelServices(force = false) {
      const requestId = ++this._modelServicesRequestId;
      try {
        const snapshot = await Editor.Message.request(
          EXTENSION_NAME,
          force ? 'refresh-model-services' : 'get-model-services'
        );
        if (this._panelClosing || requestId !== this._modelServicesRequestId) return null;
        this.applyModelServicesSnapshot(snapshot);
        return snapshot;
      } catch (_) {
        if (this.$.onboardingMessage) {
          this.$.onboardingMessage.textContent = '暂时无法检查模型服务，请稍后重试。';
          this.$.onboardingMessage.hidden = false;
        }
        return null;
      }
    },

    async openSettings(providerId = '') {
      this.closeModelMenu();
      try {
        await Editor.Message.request(EXTENSION_NAME, 'open-settings', {
          section: 'services', providerId: String(providerId || ''),
        });
        return true;
      } catch (_) {
        this.showComposerToast('暂时无法打开设置');
        return false;
      }
    },

    async handleOnboardingChatGpt() {
      const connecting = this._modelServicesSnapshot?.login?.status === 'connecting';
      const message = connecting ? 'cancel-chatgpt-login' : 'start-chatgpt-login';
      this.$.onboardingChatGpt.disabled = true;
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, message);
        if (!connecting && result?.started === false && !result?.duplicate) {
          this.$.onboardingMessage.textContent = result?.message || '无法开始 ChatGPT 登录，请重试。';
          this.$.onboardingMessage.hidden = false;
        }
      } catch (_) {
        this.$.onboardingMessage.textContent = '无法开始 ChatGPT 登录，请重试。';
        this.$.onboardingMessage.hidden = false;
      } finally {
        this.$.onboardingChatGpt.disabled = false;
        await this.refreshModelServices();
      }
    },

    closeModelMenu() {
      if (!this.$.modelMenu) return;
      this.$.modelMenu.hidden = true;
      this.$.modelButton?.setAttribute('aria-expanded', 'false');
    },

    closeAgentMenu() {
      if (!this.$.agentMenu) return;
      this.$.agentMenu.hidden = true;
      this.$.agentButton?.setAttribute('aria-expanded', 'false');
    },

    closeReasoningMenu() {
      if (!this.$.reasoningMenu) return;
      this.$.reasoningMenu.hidden = true;
      this.$.reasoningButton?.setAttribute('aria-expanded', 'false');
    },

    dismissComposerPickers(event = {}) {
      const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
      const target = event.target;
      const isInside = (surface, anchor) => path.includes(surface)
        || path.includes(anchor)
        || Boolean(target && (surface?.contains?.(target) || anchor?.contains?.(target)));
      if (this.$.permissionMenu && !this.$.permissionMenu.hidden
        && !isInside(this.$.permissionMenu, this.$.permissionButton)) this.closePermissionMenu();
      if (this.$.toolsPopover && !this.$.toolsPopover.hidden
        && !isInside(this.$.toolsPopover, this.$.toolsButton)) this.closeToolsPopover();
      if (this.$.modelMenu && !this.$.modelMenu.hidden
        && !isInside(this.$.modelMenu, this.$.modelButton)) this.closeModelMenu();
      if (this.$.agentMenu && !this.$.agentMenu.hidden
        && !isInside(this.$.agentMenu, this.$.agentButton)) this.closeAgentMenu();
      if (this.$.reasoningMenu && !this.$.reasoningMenu.hidden
        && !isInside(this.$.reasoningMenu, this.$.reasoningButton)) this.closeReasoningMenu();
      if (this._activePinPopover
        && !isInside(this.$.composerPinPopover, this._activePinPopover.anchor)) this.closePinPopover();
    },

    positionPicker(menu, anchor, minimumTop = 34) {
      if (!menu || menu.hidden || !anchor || !this.$.root) return;
      const root = this.$.root.getBoundingClientRect();
      const rect = anchor.getBoundingClientRect();
      const width = menu.offsetWidth;
      const height = menu.offsetHeight;
      const margin = 8;
      menu.style.left = `${Math.max(margin, Math.min(rect.left - root.left, root.width - width - margin))}px`;
      menu.style.top = `${Math.max(minimumTop, rect.top - root.top - height - 7)}px`;
    },

    positionModelMenu() {
      this.positionPicker(this.$.modelMenu, this.$.modelButton);
    },

    renderModelMenu() {
      const menu = this.$.modelMenu;
      if (!menu || menu.hidden) return;
      this.clearElement(menu);
      const doc = menu.ownerDocument || document;
      const selected = this.currentModelSelection();
      const available = this.availableProviderIds();
      if (!available.length) {
        menu.appendChild(this.createElement(doc, 'div', 'permission-menu-status', '请先连接模型服务'));
        this.positionModelMenu();
        return;
      }
      let providerId = available.includes(this._modelMenuProviderId)
        ? this._modelMenuProviderId
        : available.includes(selected.providerId) ? selected.providerId : available[0];
      this._modelMenuProviderId = providerId;
      menu.appendChild(this.createElement(doc, 'div', 'model-menu-heading', '选择模型'));
      if (available.length > 1) {
        const tabs = this.createElement(doc, 'div', 'provider-tabs');
        tabs.setAttribute('role', 'tablist');
        available.forEach((id) => {
          const tab = this.createElement(doc, 'button', `provider-tab${id === providerId ? ' is-active' : ''}`,
            this.providerSnapshot(id)?.displayName || id);
          tab.type = 'button';
          tab.setAttribute('role', 'tab');
          tab.setAttribute('aria-selected', String(id === providerId));
          tab.addEventListener('click', () => {
            if (id === this._modelMenuProviderId) return;
            this._modelMenuProviderId = id;
            this.renderModelMenu();
          });
          tabs.appendChild(tab);
        });
        menu.appendChild(tabs);
      }
      const list = this.createElement(doc, 'div', 'model-menu-list');
      const provider = this.providerSnapshot(providerId);
      (provider?.models || []).filter((model) => !model.hidden).forEach((model) => {
        const button = this.createElement(doc, 'button', 'model-menu-option');
        button.type = 'button';
        button.setAttribute('role', 'menuitemradio');
        button.setAttribute('aria-checked', String(providerId === selected.providerId && model.id === selected.modelId));
        button.appendChild(this.createElement(doc, 'span', 'model-menu-option-title', model.displayName || model.id));
        button.appendChild(this.createElement(doc, 'span', 'model-menu-check', '✓'));
        button.addEventListener('click', () => this.selectModelFromMenu(button, providerId, model.id));
        list.appendChild(button);
      });
      menu.appendChild(list);
      menu.appendChild(this.createElement(doc, 'div', 'model-menu-separator'));
      const manage = this.createElement(doc, 'button', 'model-menu-manage', '管理模型服务…');
      manage.type = 'button';
      manage.addEventListener('click', () => this.openSettings(providerId));
      menu.appendChild(manage);
      this.positionModelMenu();
    },

    selectModelFromMenu(button, providerId, modelId) {
      const selected = this.currentModelSelection();
      if (selected.providerId === providerId && selected.modelId === modelId) {
        this.closeModelMenu();
        return false;
      }
      button?.classList?.add('is-selecting');
      const apply = () => {
        if (this.chooseModel(providerId, modelId)) this.closeModelMenu();
      };
      if (this.prefersReducedMotion()) apply();
      else setTimeout(apply, 140);
      return true;
    },

    toggleModelMenu() {
      if (!this.$.modelMenu.hidden) { this.closeModelMenu(); return; }
      this.closePermissionMenu();
      this.closeAgentMenu();
      this.closeReasoningMenu();
      this.closeToolsPopover();
      this.closePinPopover();
      this._modelMenuProviderId = this.currentModelSelection().providerId;
      this.$.modelMenu.hidden = false;
      this.$.modelButton.setAttribute('aria-expanded', 'true');
      this.renderModelMenu();
    },

    renderAgentMenu() {
      const menu = this.$.agentMenu;
      if (!menu || menu.hidden) return;
      this.clearElement(menu);
      const doc = menu.ownerDocument || document;
      menu.appendChild(this.createElement(doc, 'div', 'compact-picker-heading', 'Agent'));
      const button = this.createElement(doc, 'button', 'model-menu-option');
      button.type = 'button';
      button.setAttribute('role', 'menuitemradio');
      button.setAttribute('aria-checked', 'true');
      button.appendChild(this.createElement(doc, 'span', 'model-menu-option-title', 'Codex'));
      button.appendChild(this.createElement(doc, 'span', 'model-menu-check', '✓'));
      button.addEventListener('click', () => this.closeAgentMenu());
      menu.appendChild(button);
      this.positionPicker(menu, this.$.agentButton);
    },

    toggleAgentMenu() {
      if (!this.$.agentMenu.hidden) { this.closeAgentMenu(); return; }
      this.closePermissionMenu();
      this.closeModelMenu();
      this.closeReasoningMenu();
      this.closeToolsPopover();
      this.closePinPopover();
      this.$.agentMenu.hidden = false;
      this.$.agentButton.setAttribute('aria-expanded', 'true');
      this.renderAgentMenu();
    },

    renderReasoningMenu() {
      const menu = this.$.reasoningMenu;
      if (!menu || menu.hidden) return;
      this.clearElement(menu);
      const doc = menu.ownerDocument || document;
      const selected = this.currentModelSelection();
      const model = this.modelForSelection(selected);
      const efforts = this.exposedReasoningEfforts(model, selected.providerId);
      menu.appendChild(this.createElement(doc, 'div', 'compact-picker-heading', '思考强度'));
      efforts.forEach((entry) => {
        const button = this.createElement(doc, 'button', 'model-menu-option');
        button.type = 'button';
        button.setAttribute('role', 'menuitemradio');
        button.setAttribute('aria-checked', String(entry.reasoningEffort === selected.reasoningEffort));
        button.appendChild(this.createElement(doc, 'span', 'model-menu-option-title', this.effortLabel(entry.reasoningEffort)));
        button.appendChild(this.createElement(doc, 'span', 'model-menu-check', '✓'));
        button.addEventListener('click', () => {
          if (entry.reasoningEffort === this.currentModelSelection().reasoningEffort) {
            this.closeReasoningMenu();
            return;
          }
          button.classList.add('is-selecting');
          const apply = () => {
            if (this.chooseReasoningEffort(entry.reasoningEffort)) this.closeReasoningMenu();
          };
          if (this.prefersReducedMotion()) apply();
          else setTimeout(apply, 140);
        });
        menu.appendChild(button);
      });
      this.positionPicker(menu, this.$.reasoningButton);
    },

    toggleReasoningMenu() {
      if (!this.$.reasoningMenu.hidden) { this.closeReasoningMenu(); return; }
      this.closePermissionMenu();
      this.closeAgentMenu();
      this.closeModelMenu();
      this.closeToolsPopover();
      this.closePinPopover();
      this.$.reasoningMenu.hidden = false;
      this.$.reasoningButton.setAttribute('aria-expanded', 'true');
      this.renderReasoningMenu();
    },

    applySelectionToTarget(selection) {
      const session = this._sessionView === 'conversation' ? this.activeSession() : null;
      if (!session) {
        this._newSessionModelSelection = selection;
        return;
      }
      session.providerId = selection.providerId;
      session.modelId = selection.modelId;
      session.reasoningEffort = selection.reasoningEffort;
      this.persistSession(session.id, true);
    },

    chooseModel(providerId, modelId) {
      const base = this.normalizedModelSelection({ providerId, modelId }, false);
      if (!base.modelId) return false;
      const current = this.currentModelSelection();
      if (current.providerId === base.providerId && current.modelId === base.modelId) return false;
      const session = this._sessionView === 'conversation' ? this.activeSession() : null;
      if (session && session.providerId && session.providerId !== providerId
        && (session.threadId || session.messages.length
          || this.visibleQueueMessages(this.sessionQueueState(session.id)).length)) {
        const draft = this.composerDraftSnapshot();
        session.draft = { text: '', attachments: [], pins: [] };
        this.persistSession(session.id, true);
        const created = this.createSession({
          providerId: base.providerId,
          modelId: base.modelId,
          reasoningEffort: base.reasoningEffort,
          draft,
        });
        this.activateSession(created.id);
        this.showComposerToast(`已切换到 ${this.providerSnapshot(providerId)?.displayName || providerId}，并新建会话`, 1800);
      } else this.applySelectionToTarget(base);
      Editor.Message.request(EXTENSION_NAME, 'set-last-used-provider', { providerId }).catch(() => {});
      this.updateModelButton(true);
      return true;
    },

    chooseReasoningEffort(reasoningEffort) {
      const selected = this.currentModelSelection();
      const model = this.modelForSelection(selected);
      if (!(model?.supportedReasoningEfforts || []).some((entry) => entry.reasoningEffort === reasoningEffort)) return false;
      if (selected.reasoningEffort === reasoningEffort) return false;
      this.applySelectionToTarget({ ...selected, reasoningEffort });
      this.updateModelButton(true);
      return true;
    },

    async refreshEnvironment(force = false) {
      const requestId = ++this._environmentRequestId;
      const showSpinner = Boolean(this.$.toolsPopover && !this.$.toolsPopover.hidden);
      const startedAt = Date.now();
      this._environmentRefreshState = 'loading';
      if (showSpinner) this.renderToolsPopover();
      try {
        const snapshot = await Editor.Message.request('cocos-ai-copilot', 'get-environment-snapshot', { refresh: force });
        if (this._panelClosing || requestId !== this._environmentRequestId) return;
        if (!snapshot || !Array.isArray(snapshot.mcpServers) || !Array.isArray(snapshot.skills) || !snapshot.status) {
          throw new Error('Invalid environment snapshot.');
        }
        this._environmentSnapshot = snapshot;
      } catch (error) {
        if (this._panelClosing || requestId !== this._environmentRequestId) return;
        this._environmentSnapshot = { mcpServers: [], tools: [], skills: [], status: { mcp: 'error', skills: 'error' } };
      }
      const remainingSpin = TOOLS_REFRESH_SPIN_MS - (Date.now() - startedAt);
      if (showSpinner && remainingSpin > 0) {
        await new Promise((resolve) => setTimeout(resolve, remainingSpin));
        if (this._panelClosing || requestId !== this._environmentRequestId) return;
      }
      this._environmentRefreshState = 'idle';
      if (this.$.toolsPopover && !this.$.toolsPopover.hidden) this.renderToolsPopover();
    },

    closeToolsPopover() {
      if (!this.$.toolsPopover) return;
      this.$.toolsPopover.hidden = true;
      this.$.toolsButton?.setAttribute('aria-expanded', 'false');
      this._toolsView = { type: 'overview' };
    },

    currentPermissionModeId() {
      const selected = this._sessionView === 'conversation'
        ? this.activeSession()?.permissionModeId : this._newSessionPermissionModeId;
      return selected || this._permissionInheritedModeId || '';
    },

    permissionModeIconSvg(iconName) {
      if (iconName === 'ask') return '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5.3 7.4V3.8a1 1 0 0 1 2 0v2.8-3.7a1 1 0 0 1 2 0v3.7-2.8a1 1 0 0 1 2 0v4.3l.7-.8a1.1 1.1 0 0 1 1.7 1.4l-2.1 3a4.2 4.2 0 0 1-3.4 1.8H7.1a4 4 0 0 1-3.7-2.5L2.1 8.1a1 1 0 0 1 1.8-.9l1.4 2.1V7.4Z"/></svg>';
      if (iconName === 'auto-review') return '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.7 13 3.6v3.9c0 3-1.8 5.2-5 6.7-3.2-1.5-5-3.7-5-6.7V3.6L8 1.7Z"/><path d="m6.3 5.6 2.4 2.3-2.4 2.4M8.8 10.3h1.3"/></svg>';
      return '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.7 13 3.6v3.9c0 3-1.8 5.2-5 6.7-3.2-1.5-5-3.7-5-6.7V3.6L8 1.7Z"/><path d="M8 5.1v3.8M8 11.2h.01"/></svg>';
    },

    renderPermissionMenu() {
      const menu = this.$?.permissionMenu;
      if (!menu || menu.hidden) return;
      this.clearElement(menu);
      const doc = menu.ownerDocument || document;
      if (this._permissionModesStatus !== 'ready') {
        menu.appendChild(this.createElement(doc, 'div', 'permission-menu-status',
          this._permissionModesStatus === 'loading' ? '正在读取权限…' : '暂时无法读取 Codex 权限状态'));
        return;
      }
      const selected = this.currentPermissionModeId();
      if (!selected) menu.appendChild(this.createElement(doc, 'div', 'permission-menu-status', '沿用当前 Codex 配置 ✓'));
      if (!this._permissionModes.length) {
        menu.appendChild(this.createElement(doc, 'div', 'permission-menu-status', '当前没有可切换的权限模式'));
      }
      this._permissionModes.forEach((mode) => {
        const button = this.createElement(doc, 'button', 'permission-menu-option');
        button.type = 'button';
        button.setAttribute('role', 'menuitemradio');
        button.setAttribute('aria-checked', String(mode.id === selected));
        button.setAttribute('aria-label', `${mode.label}，${mode.description || ''}`);
        const icon = this.createElement(doc, 'span', 'permission-menu-icon');
        icon.innerHTML = this.permissionModeIconSvg(mode.icon);
        const copy = this.createElement(doc, 'span', 'permission-menu-copy');
        copy.appendChild(this.createElement(doc, 'span', 'permission-menu-title', mode.label));
        copy.appendChild(this.createElement(doc, 'span', 'permission-menu-description', mode.description || ''));
        const check = this.createElement(doc, 'span', 'permission-menu-check', mode.id === selected ? '✓' : '');
        check.setAttribute('aria-hidden', 'true');
        button.appendChild(icon);
        button.appendChild(copy);
        button.appendChild(check);
        button.addEventListener('click', () => this.choosePermissionMode(mode.id));
        menu.appendChild(button);
      });
      if (selected && !this._permissionModes.some((mode) => mode.id === selected)) {
        menu.appendChild(this.createElement(doc, 'div', 'permission-menu-status', '当前模式已受管理限制'));
      }
    },

    async refreshPermissionModes() {
      const requestId = ++this._permissionRequestId;
      this._permissionModesStatus = 'loading';
      this.renderPermissionMenu();
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'get-codex-permission-modes');
        if (this._panelClosing || requestId !== this._permissionRequestId) return;
        if (!result || !Array.isArray(result.modes)) throw new Error('Invalid permission modes.');
        this._permissionModes = result.modes.filter((mode) => ['ask', 'auto_review', 'full'].includes(mode?.id));
        this._permissionInheritedModeId = String(result.inheritedModeId || '');
        this._permissionModesStatus = 'ready';
      } catch (error) {
        if (this._panelClosing || requestId !== this._permissionRequestId) return;
        this._permissionModes = [];
        this._permissionModesStatus = 'error';
      }
      this.renderPermissionMenu();
      this.positionPermissionMenu();
    },

    positionPermissionMenu() {
      const menu = this.$?.permissionMenu;
      if (!menu || menu.hidden || !this.$?.root || !this.$?.permissionButton) return;
      const root = this.$.root.getBoundingClientRect();
      const anchor = this.$.permissionButton.getBoundingClientRect();
      const header = this.$.root.querySelector('.panel-header')?.getBoundingClientRect();
      const width = menu.offsetWidth;
      const height = menu.offsetHeight;
      const margin = 10;
      const topBound = Math.max(margin, (header?.bottom || root.top) - root.top + 4);
      const above = anchor.top - root.top - height - 6;
      menu.style.left = `${Math.max(margin, Math.min(anchor.left - root.left, root.width - width - margin))}px`;
      menu.style.top = `${above >= topBound ? above
        : Math.max(topBound, Math.min(anchor.bottom - root.top + 6, root.height - height - margin))}px`;
    },

    closePermissionMenu() {
      if (!this.$?.permissionMenu) return;
      this.$.permissionMenu.hidden = true;
      this.$.permissionButton?.setAttribute('aria-expanded', 'false');
    },

    togglePermissionMenu() {
      if (!this.$?.permissionMenu?.hidden) {
        this.closePermissionMenu();
        return;
      }
      this.closeAgentMenu();
      this.closeModelMenu();
      this.closeReasoningMenu();
      this.closeToolsPopover();
      this.closePinPopover();
      this.$.permissionMenu.hidden = false;
      this.$.permissionButton.setAttribute('aria-expanded', 'true');
      this.renderPermissionMenu();
      this.positionPermissionMenu();
      this.refreshPermissionModes();
    },

    choosePermissionMode(modeId) {
      if (this._permissionModesStatus !== 'ready'
        || !this._permissionModes.some((mode) => mode.id === modeId)) return false;
      const session = this._sessionView === 'conversation' ? this.activeSession() : null;
      if (session) session.permissionModeId = modeId;
      else this._newSessionPermissionModeId = modeId;
      if (session) this.persistSession(session.id, true);
      this.closePermissionMenu();
      return true;
    },

    toggleToolsPopover() {
      if (!this.$.toolsPopover.hidden) {
        this.closeToolsPopover();
        return;
      }
      this.closePermissionMenu();
      this.closeAgentMenu();
      this.closeModelMenu();
      this.closeReasoningMenu();
      this.closePinPopover();
      this._toolsView = { type: 'overview' };
      this.$.toolsPopover.hidden = false;
      this.$.toolsButton.setAttribute('aria-expanded', 'true');
      this.renderToolsPopover();
    },

    positionToolsPopover() {
      const popover = this.$.toolsPopover;
      if (!popover || popover.hidden) return;
      const rootRect = this.$.root.getBoundingClientRect();
      const anchorRect = this.$.toolsButton.getBoundingClientRect();
      const headerRect = this.$.root.querySelector('.panel-header')?.getBoundingClientRect();
      const margin = 10;
      const topBound = Math.max(rootRect.top + margin, (headerRect?.bottom || rootRect.top) + 4);
      const bottomBound = rootRect.bottom - margin;
      const above = Math.max(0, anchorRect.top - topBound - 6);
      const below = Math.max(0, bottomBound - anchorRect.bottom - 6);
      const useAbove = above >= below;
      const available = useAbove ? above : below;
      const maxHeight = Math.max(40, Math.min(380, Math.floor(rootRect.height * 0.58), available));
      const width = Math.max(0, Math.min(180, rootRect.width - margin * 2));
      popover.style.width = `${width}px`;
      popover.style.maxHeight = `${maxHeight}px`;
      const actualWidth = popover.getBoundingClientRect?.().width || width;
      const left = Math.max(rootRect.left + margin, Math.min(anchorRect.right - actualWidth, rootRect.right - margin - actualWidth));
      popover.style.left = `${left - rootRect.left}px`;
      const naturalTop = useAbove ? anchorRect.top - 6 - popover.offsetHeight : anchorRect.bottom + 6;
      popover.style.top = `${Math.max(topBound, Math.min(naturalTop, bottomBound - popover.offsetHeight)) - rootRect.top}px`;
    },

    async renderToolsPopover() {
      const popover = this.$.toolsPopover;
      if (!popover || popover.hidden) return;
      const token = this._toolsRenderToken = (this._toolsRenderToken || 0) + 1;
      let source = this._contentSource;
      const isAudio=value=>value&&(value.kind==='audio'||/\.(wav|mp3|ogg)$/i.test(value.displayName||value.assetUrl||''));
      let audioSource=isAudio(source)?source:null,imageSource=source&&!isAudio(source)?source:null;
      if (!imageSource) try { imageSource = await Editor.Message.request(EXTENSION_NAME, 'get-attachment-thumbnail', { kind:'asset-preview-selection' }); } catch (_) {}
      if (!audioSource) try { audioSource = await Editor.Message.request(EXTENSION_NAME, 'get-audio-source', { kind:'audio-workbench-selection',sessionId:this._activeSessionId }); } catch (_) {}
      if (popover.hidden || token !== this._toolsRenderToken) return;
      const doc = popover.ownerDocument; this.clearElement(popover);
      const body = this.createElement(doc,'div','tools-popover-body'); popover.appendChild(body);
      const entry = this.createElement(doc,'button','tools-row tools-content-tool');
      entry.type = 'button';
      entry.title = '打开图片';
      const icon = this.createElement(doc,'span','tools-content-icon');
      icon.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.75" y="2.25" width="12.5" height="11.5" rx="1.25"/><circle cx="5" cy="5.5" r="1"/><path d="m2 11 3-3 3 2 3-4 3 5"/></svg>';
      entry.appendChild(icon);
      entry.appendChild(this.createElement(doc,'span','tools-row-name','图片'));
      entry.addEventListener('click',()=>{ this.closeToolsPopover(); this.openAssetPreview(imageSource || {}); });
      body.appendChild(entry);
      const audioEntry=this.createElement(doc,'button','tools-row tools-content-tool');audioEntry.type='button';audioEntry.title='试听或编辑游戏音频';const audioIcon=this.createElement(doc,'span','tools-content-icon');audioIcon.innerHTML='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3v8.5a2 2 0 1 1-1-1.73V5l7-1.5v6a2 2 0 1 1-1-1.73V3.5Z"/></svg>';audioEntry.appendChild(audioIcon);audioEntry.appendChild(this.createElement(doc,'span','tools-row-name','音频'));audioEntry.addEventListener('click',()=>{this.closeToolsPopover();this.openAudioWorkbench(audioSource||{});});body.appendChild(audioEntry);
      this.positionToolsPopover();
    },

    createOpaqueId(prefix = 'detail') {
      let value = '';
      try {
        if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') {
          value = globalThis.crypto.randomUUID();
        }
      } catch (error) {
        // Fall through to Node's crypto implementation.
      }
      if (!value) {
        try {
          const crypto = require('crypto');
          if (crypto && typeof crypto.randomUUID === 'function') value = crypto.randomUUID();
        } catch (error) {
          // The final fallback remains unique enough for this in-memory panel lifetime.
        }
      }
      if (!value) value = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      return `${prefix}:${value}`;
    },

    cloneAttachment(attachment = {}) {
      if (attachment.type === 'file') {
        const displayName = String(attachment.displayName || attachment.title || '文件');
        const kind = ['file', 'image', 'directory'].includes(attachment.kind)
          ? attachment.kind
          : (String(attachment.mimeType || '').startsWith('image/') ? 'image' : 'file');
        return {
          id: String(attachment.id || this.createOpaqueId('attachment')),
          type: 'file',
          kind,
          displayName,
          title: displayName,
          storedPath: String(attachment.storedPath || ''),
          size: kind === 'directory' ? null : (Number.isFinite(attachment.size) ? attachment.size : 0),
          extension: String(attachment.extension || ''),
          mimeType: String(attachment.mimeType || ''),
          createdAt: Number(attachment.createdAt || Date.now()),
          source: String(attachment.source || 'file-picker'),
          sessionId: String(attachment.sessionId || ''),
          messageId: String(attachment.messageId || ''),
          available: attachment.available !== false,
        };
      }
      const content = String(attachment.content == null ? '' : attachment.content);
      return {
        id: String(attachment.id || this.createOpaqueId('attachment')),
        type: 'text',
        title: String(attachment.title || '已粘贴的文本.txt'),
        content,
        charCount: Number.isFinite(attachment.charCount) ? attachment.charCount : content.length,
        lineCount: Number.isFinite(attachment.lineCount)
          ? attachment.lineCount
          : (content ? content.split(/\r\n|\r|\n/).length : 0),
        createdAt: Number(attachment.createdAt || Date.now()),
        language: String(attachment.language || 'text'),
        source: String(attachment.source || 'composer-paste'),
      };
    },

    cloneAttachments(attachments) {
      return Array.isArray(attachments)
        ? attachments.filter((item) => item && ['text', 'file'].includes(item.type))
          .map((item) => this.cloneAttachment(item))
        : [];
    },

    cloneTextAttachment(attachment = {}) { return this.cloneAttachment(attachment); },
    cloneTextAttachments(attachments) { return this.cloneAttachments(attachments); },

    cloneArtifact(artifact = {}) {
      const cloned = {
        id: String(artifact.id || ''),
        ...Object.fromEntries(['kind','source','attachmentId','mimeType','format','duration','sampleRate','channels','width','height','hasTransparentPixels','hasAlphaChannel','contentHash','sourceIdentity','sourceThreadId','sourceItemId','sourceServer','sourceTool','sourceArtifactId','parentArtifactId','sourceHash','outputHash','revision','savedRevision','projectImported','projectAssetUrl','projectAssetUuid','projectSpriteFrameUuid','projectTextureUuid','usedAs',...AUDIO_STATUS_FIELDS].filter(key => artifact[key] !== undefined).map(key => [key, artifact[key]])),
        type: 'artifact',
        displayName: String(artifact.displayName || '文件'),
        storedPath: String(artifact.storedPath || ''),
        size: Number.isFinite(artifact.size) ? artifact.size : 0,
        extension: String(artifact.extension || ''),
        sessionId: String(artifact.sessionId || ''),
        turnId: String(artifact.turnId || ''),
        createdAt: Number(artifact.createdAt || Date.now()),
        available: artifact.available !== false,
      };
      for (const key of ['recipe','lineage','operationSummary']) if (artifact[key] !== undefined) {
        try { cloned[key] = JSON.parse(JSON.stringify(artifact[key])); } catch (_) { /* Ignore invalid transient metadata. */ }
      }
      if(artifact.kind==='audio')cloned.projectAudioBindings=audioBindings(artifact);
      return cloned;
    },

    cloneArtifacts(artifacts) {
      return Array.isArray(artifacts)
        ? artifacts.filter((item) => item && item.id).map((item) => this.cloneArtifact(item))
        : [];
    },

    plainPinMetadata(metadata) {
      if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata)) return undefined;
      const output = {};
      Object.entries(metadata).forEach(([key, value]) => {
        if (value == null || value === '') return;
        if (['string', 'number', 'boolean'].includes(typeof value)) output[key] = value;
      });
      return Object.keys(output).length ? output : undefined;
    },

    clonePinnedContext(pin = {}) {
      if (!pin || typeof pin !== 'object') return null;
      const output = {
        id: String(pin.id || this.createOpaqueId('pin')),
        pinKey: String(pin.pinKey || ''),
        source: String(pin.source || ''),
        kind: String(pin.kind || ''),
        label: String(pin.label || ''),
        createdAt: Number(pin.createdAt || Date.now()),
      };
      ['uuid', 'path', 'dbUrl', 'sceneId', 'sceneName', 'hierarchyPath', 'assetType'].forEach((key) => {
        if (pin[key] != null && String(pin[key]).trim()) output[key] = String(pin[key]);
      });
      const metadata = this.plainPinMetadata(pin.metadata);
      if (metadata) output.metadata = metadata;
      if (!output.pinKey || !output.source || !output.kind || !output.label) return null;
      return output;
    },

    clonePinnedContexts(pins) {
      if (!Array.isArray(pins)) return [];
      return pins.map((pin) => this.clonePinnedContext(pin)).filter(Boolean);
    },

    canonicalPinPath(value) {
      return String(value || '')
        .trim()
        .replace(/\\/g, '/')
        .replace(/\/{2,}/g, '/')
        .replace(/\/$/, '')
        .toLowerCase();
    },

    createPinKey(source, kind, uuid, path) {
      const normalizedSource = String(source || '').trim().toLowerCase();
      const normalizedKind = String(kind || '').trim().toLowerCase();
      const normalizedUuid = String(uuid || '').trim();
      const normalizedPath = this.canonicalPinPath(path);
      if (normalizedSource && normalizedKind === 'folder' && normalizedPath) {
        return `${normalizedSource}:${normalizedKind}:path:${normalizedPath}`;
      }
      if (normalizedSource && normalizedKind && normalizedUuid) {
        return `${normalizedSource}:${normalizedKind}:uuid:${normalizedUuid}`;
      }
      return normalizedSource && normalizedKind && normalizedPath
        ? `${normalizedSource}:${normalizedKind}:path:${normalizedPath}`
        : '';
    },

    dedupePinnedContexts(...pinGroups) {
      const seen = new Set();
      const output = [];
      pinGroups.flat().forEach((rawPin) => {
        const pin = this.clonePinnedContext(rawPin);
        if (!pin || seen.has(pin.pinKey)) return;
        seen.add(pin.pinKey);
        output.push(pin);
      });
      return output;
    },

    pinKindLabel(pin = {}) {
      const labels = {
        node: '节点',
        asset: '资源',
        folder: '文件夹',
        scene: '场景',
        prefab: '预制体',
        script: '脚本',
      };
      return labels[pin.kind] || '资源';
    },

    pinDisplayPath(pin = {}) {
      const value = pin.kind === 'node'
        ? pin.hierarchyPath
        : (pin.path || pin.dbUrl);
      return String(value || '').replace(/^db:\/\//, '').replace(/\\/g, '/');
    },

    dumpValue(value) {
      if (value && typeof value === 'object' && Object.prototype.hasOwnProperty.call(value, 'value')) {
        return value.value;
      }
      return value;
    },

    dumpUuid(value) {
      const unwrapped = this.dumpValue(value);
      if (unwrapped && typeof unwrapped === 'object') {
        return String(unwrapped.uuid || this.dumpValue(unwrapped.value) || '');
      }
      return String(unwrapped || '');
    },

    async queryNodeDump(uuid) {
      if (!uuid || !global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') return null;
      try {
        return await Editor.Message.request('scene', 'query-node', String(uuid));
      } catch (error) {
        console.warn(`[AI Copilot][Pins] Unable to query node ${uuid}: ${error.message}`);
        return null;
      }
    },

    async resolveNodePinnedContext(uuid) {
      const normalizedUuid = String(uuid || '').trim();
      if (!normalizedUuid) return null;
      const chain = [];
      const visited = new Set();
      let currentUuid = normalizedUuid;
      let leafDump = null;
      for (let depth = 0; currentUuid && depth < 128 && !visited.has(currentUuid); depth += 1) {
        visited.add(currentUuid);
        const dump = await this.queryNodeDump(currentUuid);
        if (!dump) break;
        if (!leafDump) leafDump = dump;
        const dumpUuid = this.dumpUuid(dump.uuid) || currentUuid;
        const name = String(this.dumpValue(dump.name) || dumpUuid);
        chain.unshift({ uuid: dumpUuid, name, type: String(this.dumpValue(dump.__type__) || '') });
        currentUuid = this.dumpUuid(dump.parent);
      }
      if (!chain.length) return null;
      const leaf = chain[chain.length - 1];
      const root = chain[0];
      const hierarchyPath = chain.map((item) => item.name).filter(Boolean).join('/');
      const metadata = this.plainPinMetadata({
        cocosType: leafDump && String(this.dumpValue(leafDump.__type__) || ''),
      });
      return this.clonePinnedContext({
        id: this.createOpaqueId('pin'),
        pinKey: this.createPinKey('hierarchy', 'node', normalizedUuid, hierarchyPath),
        source: 'hierarchy',
        kind: 'node',
        label: leaf.name,
        uuid: normalizedUuid,
        hierarchyPath,
        sceneId: root.uuid,
        sceneName: root.name,
        metadata,
        createdAt: Date.now(),
      });
    },

    assetDisplayPath(info = {}) {
      const dbUrl = String(info.url || info.path || info.source || '');
      if (dbUrl.startsWith('db://')) return dbUrl.slice(5).replace(/\\/g, '/');
      const projectPath = String(info.path || info.source || '');
      return projectPath.replace(/\\/g, '/');
    },

    assetKind(info = {}) {
      const type = String(info.type || '');
      const importer = String(info.importer || '');
      const dbUrl = String(info.url || info.path || info.source || '');
      if (info.isDirectory || importer === 'directory' || importer === 'database' || type === 'database' || dbUrl === 'db://assets') {
        return 'folder';
      }
      if (type === 'cc.SceneAsset' || importer === 'scene') return 'scene';
      if (type === 'cc.Prefab' || importer === 'prefab') return 'prefab';
      if (type === 'cc.Script' || ['typescript', 'javascript'].includes(importer)) return 'script';
      return 'asset';
    },

    async queryAssetInfo(candidate = {}) {
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') return null;
      const targets = [candidate.uuid, candidate.dbUrl, candidate.path, candidate.value]
        .map((item) => String(item || '').trim())
        .filter((item, index, list) => item && list.indexOf(item) === index);
      for (const target of targets) {
        try {
          const info = await Editor.Message.request('asset-db', 'query-asset-info', target);
          if (info && typeof info === 'object') return info;
        } catch (error) {
          // Try the next stable identity carried by the native drag/selection payload.
        }
      }
      return null;
    },

    async resolveAssetPinnedContext(candidate = {}) {
      const info = await this.queryAssetInfo(candidate);
      if (!info) return null;
      const kind = this.assetKind(info);
      const uuid = String(info.uuid || candidate.uuid || '').trim();
      const dbUrl = String(info.url || info.source || candidate.dbUrl || '').trim();
      const path = this.assetDisplayPath(info) || String(candidate.path || '');
      const label = String(info.name || path.split('/').pop() || dbUrl || uuid).trim();
      const assetType = String(info.importer || info.type || '').trim();
      const pinKey = this.createPinKey('assets', kind, uuid, kind === 'folder' ? path : (dbUrl || path));
      if (!label || !pinKey) return null;
      return this.clonePinnedContext({
        id: this.createOpaqueId('pin'),
        pinKey,
        source: 'assets',
        kind,
        label,
        uuid,
        path,
        dbUrl,
        assetType,
        metadata: this.plainPinMetadata({ importer: info.importer, cocosType: info.type }),
        createdAt: Date.now(),
      });
    },

    async resolvePinnedCandidate(candidate = {}) {
      const type = String(candidate.type || candidate.selectionType || '').toLowerCase();
      const value = candidate.value && typeof candidate.value === 'object'
        ? candidate.value
        : {};
      const uuid = String(candidate.uuid || value.uuid || (typeof candidate.value === 'string' ? candidate.value : '') || '').trim();
      if (type === 'node' || type === 'cc.node' || type.includes('node')) {
        return this.resolveNodePinnedContext(uuid);
      }
      return this.resolveAssetPinnedContext({
        uuid,
        dbUrl: candidate.dbUrl || value.url || value.dbUrl,
        path: candidate.path || value.path || value.url,
        value: typeof candidate.value === 'string' ? candidate.value : value.value,
      });
    },

    formatMiddleEllipsisPath(path, fits) {
      const full = String(path || '');
      if (!full || fits(full)) return full;
      const segments = full.split('/').filter(Boolean);
      if (segments.length < 3) return full;
      const candidates = [];
      [[2, 2], [2, 1], [1, 2], [1, 1], [0, 1]].forEach(([front, back]) => {
        if (front + back >= segments.length) return;
        const candidate = [...segments.slice(0, front), '...', ...segments.slice(-back)].join('/');
        if (!candidates.includes(candidate)) candidates.push(candidate);
      });
      return candidates.find(fits) || candidates[candidates.length - 1] || full;
    },

    layoutPinPaths(container = this.$.composerPinPopover) {
      if (!container) return;
      container.querySelectorAll('.pin-path').forEach((element) => {
        const full = element.dataset.fullPath || '';
        const fits = (candidate) => {
          element.textContent = candidate;
          return element.scrollWidth <= element.clientWidth + 1;
        };
        element.textContent = this.formatMiddleEllipsisPath(full, fits);
      });
    },

    renderPinItem(ownerDocument, pin, options = {}) {
      const row = this.createElement(ownerDocument, 'div', 'pin-popover-item');
      const main = this.createElement(ownerDocument, 'div', 'pin-item-main');
      main.appendChild(this.createElement(ownerDocument, 'span', 'pin-kind', this.pinKindLabel(pin)));
      main.appendChild(this.createElement(ownerDocument, 'span', 'pin-label', pin.label));
      if (options.editable) {
        const remove = this.createElement(ownerDocument, 'button', 'pin-remove-button', '×');
        remove.type = 'button';
        remove.setAttribute('aria-label', `移除钉子 ${pin.label}`);
        remove.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          if (typeof options.onRemove === 'function') options.onRemove(pin.pinKey);
        });
        main.appendChild(remove);
      }
      row.appendChild(main);
      const displayPath = this.pinDisplayPath(pin);
      if (displayPath) {
        const path = this.createElement(ownerDocument, 'div', 'pin-path', displayPath);
        path.dataset.fullPath = displayPath;
        row.appendChild(path);
      }
      return row;
    },

    renderPinPopover(container, pins, options = {}) {
      if (!container) return;
      const items = this.clonePinnedContexts(pins);
      const scrollTop = container.querySelector('.pin-popover-list')?.scrollTop || 0;
      this._pinPopoverPreservedScrollTop = scrollTop;
      this.clearElement(container);
      if (!items.length) {
        container.hidden = true;
        return;
      }
      const ownerDocument = container.ownerDocument || document;
      const header = this.createElement(ownerDocument, 'div', 'pin-popover-header');
      header.appendChild(this.createElement(ownerDocument, 'span', 'pin-popover-title', '钉子'));
      header.appendChild(this.createElement(ownerDocument, 'span', 'pin-popover-total', String(items.length)));
      const list = this.createElement(ownerDocument, 'div', 'pin-popover-list');
      items.forEach((pin) => list.appendChild(this.renderPinItem(ownerDocument, pin, options)));
      container.appendChild(header);
      container.appendChild(list);
      list.scrollTop = scrollTop;
    },

    positionPinPopover() {
      const active = this._activePinPopover;
      const popover = this.$.composerPinPopover;
      const root = this.$.root;
      if (!active || !popover || !root) return;
      if (!active.anchor.isConnected) {
        this.closePinPopover();
        return;
      }
      const rootRect = root.getBoundingClientRect();
      const anchorRect = active.anchor.getBoundingClientRect();
      const ownerWindow = root.ownerDocument.defaultView;
      const viewportWidth = ownerWindow?.innerWidth || rootRect.right;
      const viewportHeight = ownerWindow?.innerHeight || rootRect.bottom;
      const leftBound = Math.max(rootRect.left, 0) + 10;
      const rightBound = Math.min(rootRect.right, viewportWidth) - 10;
      const width = Math.max(120, Math.min(320, rightBound - leftBound));
      const preferredLeft = active.source === 'composer'
        ? anchorRect.left
        : anchorRect.right - width;
      const left = Math.max(leftBound, Math.min(preferredLeft, rightBound - width));
      const toolbarBottom = this.$.root.querySelector('.panel-header')?.getBoundingClientRect().bottom || rootRect.top;
      const topBound = Math.max(rootRect.top + 8, toolbarBottom + 8, 0);
      const bottomBound = Math.min(rootRect.bottom - 8, viewportHeight - 8);
      const gap = 6;
      const above = Math.max(0, anchorRect.top - gap - topBound);
      const below = Math.max(0, bottomBound - anchorRect.bottom - gap);
      const placement = active.source === 'composer' && above >= 70
        ? 'above'
        : (above >= below ? 'above' : 'below');
      const available = placement === 'above' ? above : below;
      const maxHeight = Math.max(30, Math.min(320, Math.floor(rootRect.height * 0.48), available));
      popover.style.visibility = 'hidden';
      popover.style.width = `${width}px`;
      popover.style.maxHeight = `${maxHeight}px`;
      const header = popover.querySelector('.pin-popover-header');
      const list = popover.querySelector('.pin-popover-list');
      if (list) list.style.maxHeight = `${Math.max(0, maxHeight - (header?.offsetHeight || 30) - 2)}px`;
      if (list && this._pinPopoverPreservedScrollTop != null) {
        list.scrollTop = this._pinPopoverPreservedScrollTop;
        this._pinPopoverPreservedScrollTop = null;
      }
      popover.style.left = `${left - rootRect.left}px`;
      const desiredTop = (
        placement === 'above'
          ? anchorRect.top - gap - popover.offsetHeight
          : anchorRect.bottom + gap
      );
      const top = Math.max(topBound, Math.min(desiredTop, bottomBound - popover.offsetHeight));
      popover.style.top = `${top - rootRect.top}px`;
      this.layoutPinPaths(popover);
      popover.style.visibility = '';
    },

    showPinPopover(anchor, pins, options = {}) {
      const items = this.clonePinnedContexts(pins);
      if (!anchor || !items.length || !this.$.composerPinPopover) return false;
      this.closeToolsPopover();
      this.cancelPinPopoverClose();
      const current = this._activePinPopover;
      if (current?.anchor === anchor && !this.$.composerPinPopover.hidden) {
        if (options.locked) current.locked = true;
        this.positionPinPopover();
        return true;
      }
      this._activePinPopover = {
        anchor,
        source: options.source || 'history',
        editable: Boolean(options.editable),
        locked: Boolean(options.locked),
        getPins: options.getPins || (() => items),
      };
      this.renderPinPopover(this.$.composerPinPopover, items, {
        editable: options.editable,
        onRemove: (pinKey) => this.removeComposerPin(pinKey),
      });
      this.$.composerPinPopover.hidden = false;
      this.positionPinPopover();
      return true;
    },

    refreshPinPopover() {
      const active = this._activePinPopover;
      if (!active) return;
      const pins = this.clonePinnedContexts(active.getPins());
      if (!pins.length) {
        this.closePinPopover();
        return;
      }
      this.renderPinPopover(this.$.composerPinPopover, pins, {
        editable: active.editable,
        onRemove: (pinKey) => this.removeComposerPin(pinKey),
      });
      this.positionPinPopover();
    },

    cancelPinPopoverClose() {
      if (this._pinPopoverCloseTimer) clearTimeout(this._pinPopoverCloseTimer);
      this._pinPopoverCloseTimer = null;
    },

    schedulePinPopoverClose(anchor) {
      const active = this._activePinPopover;
      if (!active || active.locked || (anchor && active.anchor !== anchor)) return;
      this.cancelPinPopoverClose();
      this._pinPopoverCloseTimer = setTimeout(() => {
        this._pinPopoverCloseTimer = null;
        if (this._activePinPopover && !this._activePinPopover.locked) this.closePinPopover();
      }, 140);
    },

    closePinPopover() {
      this.cancelPinPopoverClose();
      if (this.$.composerPinPopover) this.$.composerPinPopover.hidden = true;
      this._activePinPopover = null;
    },

    toggleLockedPinPopover(anchor, pins, options = {}) {
      const active = this._activePinPopover;
      if (active?.anchor === anchor && active.locked) {
        this.closePinPopover();
        return;
      }
      this.showPinPopover(anchor, pins, { ...options, locked: true });
    },

    createPinIndicator(ownerDocument, pins, className = '') {
      const items = this.clonePinnedContexts(pins);
      if (!items.length) return null;
      const wrap = this.createElement(ownerDocument, 'div', `pin-indicator-wrap ${className}`.trim());
      const button = this.createElement(ownerDocument, 'button', 'pin-indicator-button');
      button.type = 'button';
      button.setAttribute('aria-label', `查看 ${items.length} 个钉子`);
      button.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5.1 2.5h5.8M6 2.5l.45 4.1-2.2 2.2v.95h7.5V8.8l-2.2-2.2L10 2.5M8 9.75v3.75"></path></svg>';
      button.appendChild(this.createElement(ownerDocument, 'span', 'pin-count', String(items.length)));
      const options = { source: className === 'queue-pin-indicator' ? 'queue' : 'history' };
      button.addEventListener('mouseenter', () => this.showPinPopover(button, items, options));
      button.addEventListener('mouseleave', () => this.schedulePinPopoverClose(button));
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        this.toggleLockedPinPopover(button, items, options);
      });
      wrap.appendChild(button);
      return wrap;
    },

    renderComposerPins() {
      const pins = this.clonePinnedContexts(this._composerPins);
      this._composerPins = pins;
      if (this.$.pinCount) {
        this.$.pinCount.textContent = String(pins.length);
        this.$.pinCount.hidden = pins.length === 0;
        this.$.pinCount.setAttribute('aria-label', `查看 ${pins.length} 个钉子`);
      }
      if (this.$.pinEntryButton) {
        this.$.pinEntryButton.classList.toggle('has-pins', pins.length > 0);
      }
      if (this._activePinPopover?.source === 'composer') this.refreshPinPopover();
      this.updateComposerActionState();
    },

    removeComposerPin(pinKey) {
      const normalizedKey = String(pinKey || '');
      const before = (this._composerPins || []).length;
      this._composerPins = (this._composerPins || []).filter((pin) => pin.pinKey !== normalizedKey);
      if (this._composerPins.length === before) return false;
      this.renderComposerPins();
      return true;
    },

    renderPinMode() {
      const active = Boolean(this._pinModeActive);
      const pendingCount = (this._pendingPins || []).length;
      if (this.$.pinModeBar) this.$.pinModeBar.hidden = !active;
      if (this.$.pendingPinCount) this.$.pendingPinCount.textContent = String(pendingCount);
      if (this.$.pinEntryButton) this.$.pinEntryButton.classList.toggle('is-active', active);
      if (this.$.composerSurface) this.$.composerSurface.classList.toggle('is-pin-mode', active);
      if (this.$.root) this.$.root.classList.toggle('is-pin-mode', active);
      [this.$.attachButton, this.$.toolsButton, this.$.sendButton, this.$.newSessionButton,
        this.$.sessionHistoryButton, this.$.sessionTitleButton, this.$.sessionMoreButton]
        .filter(Boolean)
        .forEach((control) => {
          control.disabled = active;
          control.toggleAttribute('disabled', active);
          control.setAttribute('aria-disabled', String(active));
        });
      if (this.$.composerInput) {
        this.$.composerInput.readOnly = active;
        this.$.composerInput.toggleAttribute('readonly', active);
      }
      this.updateComposerActionState();
    },

    enterPinMode() {
      if (this._pinModeActive) return true;
      this.hideComposerPinPopover();
      this._pendingPins = [];
      this._pinModeGeneration = Number(this._pinModeGeneration || 0) + 1;
      this._pinModeActive = true;
      this.renderPinMode();
      this.showComposerToast('钉子模式：在层级或资源管理器中选择对象');
      return true;
    },

    cancelPinMode() {
      if (!this._pinModeActive) return false;
      this._pendingPins = [];
      this._pinModeActive = false;
      this._pinModeGeneration = Number(this._pinModeGeneration || 0) + 1;
      this.renderPinMode();
      if (this.$.composerInput) this.$.composerInput.focus();
      return true;
    },

    async confirmPinMode() {
      if (!this._pinModeActive) return false;
      try {
        await Promise.resolve(this._pinSelectionSerial);
      } catch (error) {
        console.warn(`[AI Copilot][Pins] Pending selection could not be resolved: ${error.message}`);
      }
      if (!this._pinModeActive) return false;
      this._composerPins = this.dedupePinnedContexts(this._composerPins || [], this._pendingPins || []);
      this._pendingPins = [];
      this._pinModeActive = false;
      this._pinModeGeneration = Number(this._pinModeGeneration || 0) + 1;
      this.renderComposerPins();
      this.renderPinMode();
      if (this.$.composerInput) this.$.composerInput.focus();
      return true;
    },

    hideComposerPinPopover() {
      if (this._activePinPopover?.source === 'composer') this.closePinPopover();
    },

    async addPinnedCandidates(candidates, options = {}) {
      const sourceItems = Array.isArray(candidates) ? candidates : [];
      const resolved = (await Promise.all(sourceItems.map((item) => this.resolvePinnedCandidate(item))))
        .filter(Boolean);
      if (
        options.pinModeGeneration != null
        && (
          !this._pinModeActive
          || Number(options.pinModeGeneration) !== Number(this._pinModeGeneration)
        )
      ) return [];
      if (!resolved.length) {
        if (!options.silent) this.showComposerToast('未识别到可钉住的 Cocos 对象');
        return [];
      }
      if (options.pending || this._pinModeActive) {
        this._pendingPins = this.dedupePinnedContexts(this._pendingPins || [], resolved);
        this.renderPinMode();
      } else {
        this._composerPins = this.dedupePinnedContexts(this._composerPins || [], resolved);
        this.renderComposerPins();
      }
      return resolved;
    },

    async onSelectionSelect(selectionType, selectionUuid) {
      if (selectionType === 'asset' && !this.$.toolsPopover?.hidden) this.renderToolsPopover();
      if (!this._pinModeActive) return false;
      const type = String(selectionType || (Editor.Selection && Editor.Selection.getLastSelectedType && Editor.Selection.getLastSelectedType()) || '');
      const normalizedType = type.toLowerCase();
      if (!['node', 'asset'].includes(normalizedType)) return false;
      let selected = [];
      try {
        selected = Editor.Selection && typeof Editor.Selection.getSelected === 'function'
          ? Editor.Selection.getSelected(type)
          : [];
      } catch (error) {
        selected = [];
      }
      if (!Array.isArray(selected) || !selected.length) selected = selectionUuid ? [selectionUuid] : [];
      const candidates = selected.map((uuid) => ({ type: normalizedType, uuid }));
      const pinModeGeneration = this._pinModeGeneration;
      this._pinSelectionSerial = Promise.resolve(this._pinSelectionSerial)
        .then(() => this.addPinnedCandidates(candidates, {
          pending: true,
          silent: true,
          pinModeGeneration,
        }))
        .catch((error) => console.warn(`[AI Copilot][Pins] Selection could not be pinned: ${error.message}`));
      await this._pinSelectionSerial;
      return true;
    },

    async readCurrentSelectionSnapshot() {
      if (!global.Editor || !Editor.Selection) return [];
      let type = '';
      let selected = [];
      try {
        type = String(
          typeof Editor.Selection.getLastSelectedType === 'function'
            ? Editor.Selection.getLastSelectedType() || ''
            : ''
        ).toLowerCase();
        if (!['node', 'asset'].includes(type)) return [];
        selected = typeof Editor.Selection.getSelected === 'function'
          ? Editor.Selection.getSelected(type)
          : [];
      } catch (error) {
        return [];
      }
      if (!Array.isArray(selected) || !selected.length) return [];
      return (await Promise.all(
        selected.map((uuid) => this.resolvePinnedCandidate({ type, uuid }))
      )).filter(Boolean);
    },

    currentNativeDragInfo() {
      try {
        return global.Editor && Editor.UI && Editor.UI.DragArea
          ? Editor.UI.DragArea.currentDragInfo || null
          : null;
      } catch (error) {
        return null;
      }
    },

    dragCandidates(event) {
      const transfer = event && event.dataTransfer;
      if (transfer && transfer.files && transfer.files.length) return [];
      const dragInfo = this.currentNativeDragInfo();
      const candidates = [];
      const append = (item, fallbackType = '') => {
        if (item == null || item === '') return;
        if (Array.isArray(item)) {
          item.forEach((value) => append(value, fallbackType));
          return;
        }
        if (typeof item === 'object') {
          candidates.push({ ...item, type: item.type || fallbackType, value: item.value != null ? item.value : item });
          return;
        }
        candidates.push({ type: fallbackType, value: String(item), uuid: String(item) });
      };
      if (dragInfo) {
        append(dragInfo.value, dragInfo.type || '');
        append(dragInfo.additional, dragInfo.type || '');
      }
      if (!candidates.length && transfer && typeof transfer.getData === 'function') {
        try {
          const rawValue = transfer.getData('value');
          if (rawValue && dragInfo) {
            let parsed = rawValue;
            try { parsed = JSON.parse(rawValue); } catch (error) { /* Native UUID strings are valid. */ }
            append(parsed, dragInfo.type || '');
          }
        } catch (error) {
          // Ignore unsupported DataTransfer reads.
        }
      }
      return candidates;
    },

    canAcceptPinDrop(event) {
      const transfer = event && event.dataTransfer;
      if (transfer && transfer.files && transfer.files.length) return false;
      return this.dragCandidates(event).length > 0;
    },

    handlePinDragOver(event) {
      if (!this.canAcceptPinDrop(event)) return false;
      event.preventDefault();
      event.stopPropagation();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
      if (this.$.composerSurface) this.$.composerSurface.classList.add('is-pin-dragover');
      if (this.$.pinDropHint) this.$.pinDropHint.hidden = false;
      return true;
    },

    clearPinDragState() {
      if (this.$.composerSurface) this.$.composerSurface.classList.remove('is-pin-dragover');
      if (this.$.pinDropHint) this.$.pinDropHint.hidden = true;
    },

    hasExternalFileDrag(event) {
      const transfer = event?.dataTransfer;
      if (!transfer) return false;
      if (transfer.files?.length) return true;
      return Array.from(transfer.types || []).includes('Files');
    },

    clearFileDragState() {
      this._fileDragDepth = 0;
      if (this.$.root) this.$.root.classList.remove('is-file-drag-over');
      if (this.$.fileDropHint) this.$.fileDropHint.hidden = true;
    },

    isComposerDragTarget(event) {
      const surface = this.$.composerSurface;
      if (!surface) return false;
      const path = typeof event?.composedPath === 'function' ? event.composedPath() : [];
      return path.includes(surface) || Boolean(event?.target && surface.contains(event.target));
    },

    handleComposerDragEnter(event) {
      if (!this.hasExternalFileDrag(event)) {
        return this.isComposerDragTarget(event) ? this.handlePinDragOver(event) : false;
      }
      event.preventDefault();
      event.stopPropagation();
      this._fileDragDepth = Number(this._fileDragDepth || 0) + 1;
      this.clearPinDragState();
      if (this.$.root) this.$.root.classList.add('is-file-drag-over');
      if (this.$.fileDropHint) this.$.fileDropHint.hidden = false;
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
      return true;
    },

    handleComposerDragOver(event) {
      if (!this.hasExternalFileDrag(event)) {
        return this.isComposerDragTarget(event) ? this.handlePinDragOver(event) : false;
      }
      event.preventDefault();
      event.stopPropagation();
      if (this.$.root) this.$.root.classList.add('is-file-drag-over');
      if (this.$.fileDropHint) this.$.fileDropHint.hidden = false;
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
      return true;
    },

    handleComposerDragLeave(event) {
      if (this.hasExternalFileDrag(event) || this._fileDragDepth) {
        this._fileDragDepth = Math.max(0, Number(this._fileDragDepth || 0) - 1);
        if (!this._fileDragDepth) this.clearFileDragState();
        return;
      }
      if (event.relatedTarget && this.$.root?.contains(event.relatedTarget)) return;
      this.clearPinDragState();
    },

    droppedFilePath(file) {
      try {
        const electron = require('electron');
        if (electron?.webUtils && typeof electron.webUtils.getPathForFile === 'function') {
          const resolved = electron.webUtils.getPathForFile(file);
          if (resolved) return String(resolved);
        }
      } catch (_) { /* Electron 31 still exposes File.path below. */ }
      return typeof file?.path === 'string' ? file.path : '';
    },

    async ingestDroppedFiles(files, options = {}) {
      const context = this.attachmentIngestContext();
      const paths = [];
      let missingPathCount = 0;
      files.forEach((file) => {
        const nativePath = this.droppedFilePath(file);
        if (nativePath) paths.push(nativePath);
        else missingPathCount += 1;
      });
      if (!paths.length) {
        if (missingPathCount) this.showComposerToast('当前 Cocos 环境无法读取拖入文件的本地路径', 3200);
        return 0;
      }
      const inferredName = files.length === 1
        ? String(files[0]?.name || paths[0].split(/[\\/]/u).pop() || '')
        : '';
      const ingestState = this.beginAttachmentIngest(context, {
        kind: options.kind === 'directory' ? 'directory' : 'file',
        displayName: options.kind === 'directory'
          ? `正在添加文件夹${inferredName ? ` ${inferredName}` : ''}…`
          : '正在添加…',
      });
      const operation = (async () => {
        try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'ingest-dropped-attachments', {
          sessionId: context.sessionId,
          filePaths: paths,
          source: String(options.source || 'file-drop'),
        });
        const added = this.commitIngestedAttachments(context, result?.attachments);
        const errors = Array.isArray(result?.errors) ? result.errors : [];
        if (!added && errors.length && (options.kind === 'directory' || errors.some((error) => error.kind === 'directory'))) {
          this.finishAttachmentIngest(ingestState, '文件夹添加失败');
        } else {
          this.finishAttachmentIngest(ingestState);
        }
        if (errors.length || missingPathCount) {
          this.showComposerToast('部分拖入文件未能添加，其他附件已保留', 3000);
        }
        return added;
        } catch (error) {
          console.warn(`[AI Copilot] Dropped attachment ingest failed: ${error.message}`);
          this.finishAttachmentIngest(ingestState, options.kind === 'directory' ? '文件夹添加失败' : '附件添加失败');
          this.showComposerToast('无法添加拖入的附件，请重试', 2800);
          return 0;
        }
      })();
      return this.trackAttachmentIngest(ingestState, operation);
    },

    handleComposerDrop(event) {
      if (!this.hasExternalFileDrag(event)) {
        if (!this.isComposerDragTarget(event)) {
          this.clearPinDragState();
          return false;
        }
        return this.handlePinDrop(event);
      }
      event.preventDefault();
      event.stopPropagation();
      const files = Array.from(event.dataTransfer?.files || []);
      const entries = Array.from(event.dataTransfer?.items || []).map((item) => {
        try { return typeof item.webkitGetAsEntry === 'function' ? item.webkitGetAsEntry() : null; }
        catch (_) { return null; }
      }).filter(Boolean);
      const kind = files.length === 1 && entries.length === 1 && entries[0].isDirectory
        ? 'directory'
        : 'file';
      this.clearFileDragState();
      this.clearPinDragState();
      return this.ingestDroppedFiles(files, { kind, source: 'file-drop' });
    },

    async handlePinDrop(event) {
      const nativeDragInfo = this.currentNativeDragInfo();
      const pinModeGeneration = this._pinModeActive ? this._pinModeGeneration : null;
      const candidates = this.dragCandidates(event);
      this.clearPinDragState();
      if (!candidates.length) {
        if (nativeDragInfo) this.showComposerToast('无法钉住该 Cocos 对象');
        return false;
      }
      event.preventDefault();
      event.stopPropagation();
      console.debug('[AI Copilot][Pins] Native Cocos drag payload', {
        type: nativeDragInfo && nativeDragInfo.type,
        candidateCount: candidates.length,
        transferTypes: event.dataTransfer && Array.from(event.dataTransfer.types || []),
      });
      const pinOperation = this.addPinnedCandidates(candidates, {
        pending: pinModeGeneration != null,
        pinModeGeneration,
      });
      if (pinModeGeneration != null) {
        this._pinSelectionSerial = Promise.all([
          Promise.resolve(this._pinSelectionSerial),
          pinOperation,
        ]).then(() => undefined);
      }
      const pins = await pinOperation;
      if (pins.length) this.showComposerToast(`已钉住 ${pins.length} 个 Cocos 对象`);
      return pins.length > 0;
    },

    nextPastedTextTitle() {
      const existing = new Set(
        (this._composerAttachments || []).map((attachment) => String(attachment.title || ''))
      );
      let index = 1;
      while (true) {
        const title = index === 1 ? '已粘贴的文本.txt' : `已粘贴的文本 ${index}.txt`;
        if (!existing.has(title)) return title;
        index += 1;
      }
    },

    createTextAttachment(content) {
      const value = String(content == null ? '' : content);
      return this.cloneTextAttachment({
        id: this.createOpaqueId('attachment'),
        type: 'text',
        title: this.nextPastedTextTitle(),
        content: value,
        charCount: value.length,
        lineCount: value ? value.split(/\r\n|\r|\n/).length : 0,
        createdAt: Date.now(),
        language: 'text',
        source: 'composer-paste',
      });
    },

    attachmentDocument(attachment) {
      const value = this.cloneAttachment(attachment);
      if (value.type !== 'text') return null;
      return {
        id: value.id,
        type: value.type,
        title: value.title,
        language: value.language,
        content: value.content,
        source: value.source,
        charCount: value.charCount,
        lineCount: value.lineCount,
        createdAt: value.createdAt,
      };
    },

    buildAttachmentDisplayLabel(attachment = {}) {
      if (attachment.type === 'file') {
        const fallback = attachment.kind === 'directory' ? '文件夹' : '文件';
        return String(attachment.displayName || attachment.title || fallback).trim() || fallback;
      }
      const content = String(attachment.content == null ? '' : attachment.content)
        .replace(/^\uFEFF/, '')
        .replace(/^(?:[ \t]*(?:\r\n|\r|\n))+/, '')
        .replace(/(?:[ \t]*(?:\r\n|\r|\n)[ \t]*)+/g, ' ')
        .replace(/[ \t\f\v]+/g, ' ')
        .trim();
      if (!content) return '已粘贴的文本';
      return content.length > TEXT_ATTACHMENT_PREVIEW_CHAR_LIMIT
        ? `${content.slice(0, TEXT_ATTACHMENT_PREVIEW_CHAR_LIMIT).trimEnd()}…`
        : content;
    },

    formatFileSize(size) {
      const bytes = Number(size);
      if (!Number.isFinite(bytes) || bytes < 0) return '';
      if (bytes < 1024) return `${bytes} B`;
      if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
      if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(bytes < 10 * 1024 * 1024 ? 1 : 0)} MB`;
      return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
    },

    async requestNativeContextMenu(payload = {}) {
      if (this._nativeContextMenuPending) return { shown: false, action: '' };
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        console.warn('[AI Copilot] Native context menu is unavailable: Editor.Message.request is missing.');
        return { shown: false, action: '' };
      }
      this._nativeContextMenuPending = true;
      try {
        return await Editor.Message.request(EXTENSION_NAME, 'show-context-menu', {
          ...payload,
          contextId: this._globalContextId || '',
        });
      } catch (error) {
        console.warn(`[AI Copilot] Unable to show native context menu: ${error.message}`);
        return { shown: false, action: '' };
      } finally {
        this._nativeContextMenuPending = false;
      }
    },

    suppressGlobalNativeContextMenu() {
      if (
        !this._globalContextId
        || !global.Editor
        || !Editor.Message
        || typeof Editor.Message.request !== 'function'
      ) return;
      try {
        const request = Editor.Message.request(
          EXTENSION_NAME,
          'suppress-global-context-menu',
          { contextId: this._globalContextId }
        );
        if (request && typeof request.catch === 'function') request.catch(() => {});
      } catch (error) {
        // The attachment-specific contextmenu handler still prevents the renderer default.
      }
    },

    async showAttachmentNativeContextMenu(attachment) {
      if (!attachment || attachment.type !== 'text') return false;
      const result = await this.requestNativeContextMenu({
        kind: 'attachment',
        copyText: String(attachment.content || ''),
      });
      if (result && result.action === 'open-detail') {
        return this.openAttachmentDetail(attachment);
      }
      return Boolean(result && result.shown);
    },

    isImageAttachment(attachment = {}) {
      if (attachment.kind === 'directory') return false;
      if (attachment.kind === 'image') return true;
      if (String(attachment.mimeType || '').toLowerCase().startsWith('image/')) return true;
      return ['.avif', '.bmp', '.gif', '.ico', '.jpeg', '.jpg', '.png', '.svg', '.webp']
        .includes(String(attachment.extension || '').toLowerCase());
    },

    attachmentThumbnailBaseKey(attachment = {}) {
      return [attachment.sessionId, attachment.id, attachment.storedPath].map((value) => String(value || '')).join('\u0000');
    },

    attachmentThumbnailKey(attachment = {}, variant = 'chat') {
      return `${this.attachmentThumbnailBaseKey(attachment)}\u0000${variant}`;
    },

    thumbnailBytes(value) {
      if (value instanceof Uint8Array) return value;
      if (value && value.type === 'Buffer' && Array.isArray(value.data)) return Uint8Array.from(value.data);
      if (Array.isArray(value)) return Uint8Array.from(value);
      if (value instanceof ArrayBuffer) return new Uint8Array(value);
      return new Uint8Array();
    },

    revokeAttachmentThumbnailEntry(key) {
      const cache = this._attachmentThumbnailUrls;
      const entry = cache && cache.get(key);
      if (!entry) return false;
      cache.delete(key);
      if (entry.url?.startsWith('blob:') && globalThis.URL && typeof globalThis.URL.revokeObjectURL === 'function') {
        try { globalThis.URL.revokeObjectURL(entry.url); } catch (_) { /* The URL may already be gone. */ }
      }
      return true;
    },

    revokeAttachmentThumbnail(attachment = {}) {
      const prefix = `${this.attachmentThumbnailBaseKey(attachment)}\u0000`;
      let revoked = false;
      Array.from(this._attachmentThumbnailUrls?.keys() || []).filter((key) => key.startsWith(prefix))
        .forEach((key) => { revoked = this.revokeAttachmentThumbnailEntry(key) || revoked; });
      return revoked;
    },

    resetAttachmentThumbnailUrls() {
      this._thumbnailRenderGeneration = Number(this._thumbnailRenderGeneration || 0) + 1;
      const cache = this._attachmentThumbnailUrls;
      if (!cache) return;
      Array.from(cache.keys()).forEach((key) => this.revokeAttachmentThumbnailEntry(key));
    },

    ensureAttachmentThumbnailUrl(attachment = {}, options = {}) {
      if (!this._attachmentThumbnailUrls) this._attachmentThumbnailUrls = new Map();
      const cache = this._attachmentThumbnailUrls;
      const variant = options.variant === 'original' ? 'original' : 'chat';
      const baseKey = this.attachmentThumbnailBaseKey(attachment);
      const key = this.attachmentThumbnailKey(attachment, variant);
      const identityPrefix = [attachment.sessionId, attachment.id].map((value) => String(value || '')).join('\u0000') + '\u0000';
      Array.from(cache.keys()).filter((cachedKey) => cachedKey.startsWith(identityPrefix) && !cachedKey.startsWith(`${baseKey}\u0000`))
        .forEach((cachedKey) => this.revokeAttachmentThumbnailEntry(cachedKey));
      const existing = cache.get(key);
      if (existing?.url) return Promise.resolve(existing.url);
      if (existing?.promise) return existing.promise;
      if (!attachment.storedPath || attachment.available === false
        || !global.Editor?.Message || typeof Editor.Message.request !== 'function') return Promise.resolve('');
      const generation = Number(this._thumbnailRenderGeneration || 0);
      const promise = Promise.resolve(Editor.Message.request(
        EXTENSION_NAME,
        'get-attachment-thumbnail',
        attachment.type === 'artifact'
          ? { kind:variant === 'original' ? 'asset-preview-source' : 'chat-thumbnail-source', sessionId:attachment.sessionId, artifactId:attachment.id }
          : { ...(variant === 'chat' ? { kind:'chat-thumbnail-source' } : {}), sessionId:attachment.sessionId, attachment:this.cloneAttachment(attachment) }
      )).then((result) => {
        const inlineUrl = typeof result?.dataUrl === 'string'
          && /^data:image\/(?:png|jpeg|webp);base64,[a-z0-9+/=]+$/iu.test(result.dataUrl)
          ? result.dataUrl : '';
        const bytes = this.thumbnailBytes(result?.bytes);
        if (!result?.available || (!inlineUrl && !bytes.length) || generation !== Number(this._thumbnailRenderGeneration || 0)) return '';
        if (!inlineUrl && (typeof Blob !== 'function' || !globalThis.URL || typeof globalThis.URL.createObjectURL !== 'function')) return '';
        const url = inlineUrl || globalThis.URL.createObjectURL(new Blob([bytes], { type:result.mimeType || attachment.mimeType || 'application/octet-stream' }));
        if (generation !== Number(this._thumbnailRenderGeneration || 0) || cache.get(key)?.promise !== promise) {
          if (url.startsWith('blob:')) globalThis.URL.revokeObjectURL(url);
          return '';
        }
        cache.set(key, { url, promise: null });
        return url;
      }).catch((error) => {
        console.warn(`[AI Copilot] Thumbnail load failed: ${error.message}`);
        return '';
      }).finally(() => {
        const current = cache.get(key);
        if (current?.promise === promise) cache.delete(key);
      });
      cache.set(key, { url: '', promise });
      return promise;
    },

    markAttachmentThumbnailUnavailable(container, image, attachment = {}) {
      if (image) image.hidden = true;
      container.classList.remove('is-loading');
      container.classList.add('is-unavailable');
      const fallback = Array.from(container.children || [])
        .find((child) => child.classList?.contains('image-attachment-unavailable'));
      if (fallback) fallback.textContent = this.buildAttachmentDisplayLabel(attachment) || '图片不可用';
    },

    bindAttachmentThumbnail(container, image, attachment = {}) {
      const key = this.attachmentThumbnailKey(attachment);
      const generation = Number(this._thumbnailRenderGeneration || 0);
      container.dataset.thumbnailKey = key;
      const reveal = () => {
        if (container.dataset.thumbnailKey !== key
          || generation !== Number(this._thumbnailRenderGeneration || 0)) return;
        image.hidden = false;
        container.classList.remove('is-loading', 'is-unavailable');
      };
      const finalFail = () => {
        if (container.dataset.thumbnailKey !== key
          || generation !== Number(this._thumbnailRenderGeneration || 0)) return;
        this.revokeAttachmentThumbnail(attachment);
        this.markAttachmentThumbnailUnavailable(container, image, attachment);
      };
      let usingOriginal = false;
      const loadOriginal = () => {
        if (usingOriginal) { finalFail(); return Promise.resolve(false); }
        usingOriginal = true;
        this.revokeAttachmentThumbnailEntry(key);
        image.hidden = true;
        container.classList.add('is-loading');
        return this.ensureAttachmentThumbnailUrl(attachment, { variant:'original' }).then((url) => {
          if (!url || container.dataset.thumbnailKey !== key
            || generation !== Number(this._thumbnailRenderGeneration || 0)) {
            finalFail();
            return false;
          }
          image.onerror = finalFail;
          image.src = url;
          if (image.complete && Number(image.naturalWidth || 0) > 0) reveal();
          return true;
        });
      };
      image.onload = reveal;
      image.onerror = () => { void loadOriginal(); };
      if (!attachment.storedPath || attachment.available === false) {
        this.markAttachmentThumbnailUnavailable(container, image, attachment);
        return Promise.resolve(false);
      }
      const cachedUrl = this._attachmentThumbnailUrls?.get(key)?.url || '';
      if (cachedUrl) {
        // A running Turn redraws its presentation for every status event. Reusing
        // a verified object URL must not hide the replacement <img> until a new
        // load event; rapid redraws can otherwise leave every Artifact as a gray
        // placeholder even though the underlying snapshot is still available.
        image.src = cachedUrl;
        reveal();
        return Promise.resolve(true);
      }
      image.hidden = true;
      container.classList.add('is-loading');
      if (!attachment.storedPath || attachment.available === false) {
        this.markAttachmentThumbnailUnavailable(container, image, attachment);
        return Promise.resolve(false);
      }
      return this.ensureAttachmentThumbnailUrl(attachment).then((url) => {
        if (!url || container.dataset.thumbnailKey !== key
          || generation !== Number(this._thumbnailRenderGeneration || 0)) {
          return loadOriginal();
        }
        image.src = url;
        if (image.complete && Number(image.naturalWidth || 0) > 0) reveal();
        return true;
      });
    },

    createImageAttachmentReference(ownerDocument, attachment, options = {}) {
      const displayLabel = this.buildAttachmentDisplayLabel(attachment);
      const thumbnail = this.createElement(ownerDocument, 'div', 'image-attachment');
      thumbnail.classList.toggle('is-unavailable', attachment.available === false);
      thumbnail.title = `${displayLabel}${attachment.available === false ? '（文件已不可用）' : ''}`;
      const image = this.createElement(ownerDocument, 'img');
      image.alt = displayLabel;
      image.draggable = false;
      if (/\.(png|jpe?g|webp)$/i.test(attachment.displayName || attachment.title || attachment.storedPath || '')) {
        image.style.cursor = 'zoom-in'; image.title = '预览图片';
        image.addEventListener('click', () => this.openAssetPreview(attachment));
      }
      thumbnail.appendChild(image);
      thumbnail.appendChild(this.createElement(
        ownerDocument,
        'span',
        'image-attachment-unavailable',
        attachment.available === false ? '文件已不可用' : displayLabel
      ));
      this.bindAttachmentThumbnail(thumbnail, image, attachment);
      if (options.removable) {
        const remove = this.createElement(ownerDocument, 'button', 'image-attachment-remove', '×');
        remove.type = 'button';
        remove.title = '移除附件';
        remove.setAttribute('aria-label', '移除附件');
        remove.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          this.removeComposerAttachment(attachment.id);
        });
        thumbnail.appendChild(remove);
      }
      return thumbnail;
    },

    createAttachmentReference(ownerDocument, attachment, options = {}) {
      const displayLabel = this.buildAttachmentDisplayLabel(attachment);
      const isDirectory = attachment.type === 'file' && attachment.kind === 'directory';
      const chip = this.createElement(ownerDocument, 'div', 'attachment-chip attachment-reference');
      chip.dataset.detailId = attachment.id;
      chip.classList.toggle('is-text-attachment', attachment.type === 'text');
      chip.classList.toggle('is-unavailable', attachment.type === 'file' && attachment.available === false);
      const openButton = this.createElement(ownerDocument, 'button', 'attachment-open-button');
      openButton.type = 'button';
      openButton.classList.toggle('attachment-file-button', attachment.type === 'file');
      openButton.title = '打开完整文本';
      openButton.setAttribute('aria-label', '打开长文本详情');
      openButton.innerHTML = isDirectory
        ? '<svg class="attachment-document-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M1.75 4.25h4l1.35 1.5h7.15v7.5a1 1 0 0 1-1 1H2.75a1 1 0 0 1-1-1v-9Z"></path><path d="M1.75 5.75V3.5a1 1 0 0 1 1-1h3l1.3 1.5h6.2a1 1 0 0 1 1 1v.75"></path></svg>'
        : [
          '<svg class="attachment-document-icon" viewBox="0 0 16 16" aria-hidden="true">',
          '<path d="M4 1.75h5l3 3v9.5H4a1 1 0 0 1-1-1V2.75a1 1 0 0 1 1-1Z"></path>',
          '<path d="M9 1.75v3h3M5.5 8h4.75M5.5 10.5h4.75"></path>',
          '</svg>',
        ].join('');
      if (attachment.type === 'file') {
        openButton.appendChild(this.createElement(ownerDocument, 'span', 'attachment-title', displayLabel));
        const unavailableLabel = isDirectory ? '文件夹已不可用' : '文件已不可用';
        openButton.title = `${displayLabel}${attachment.available === false ? `（${unavailableLabel}）` : ''}`;
        openButton.setAttribute('aria-label', displayLabel);
        const secondary = attachment.available === false ? '不可用'
          : (isDirectory ? '' : this.formatFileSize(attachment.size));
        if (secondary) openButton.appendChild(this.createElement(ownerDocument, 'span', 'attachment-secondary', secondary));
      } else {
        const copy = this.createElement(ownerDocument, 'span', 'attachment-text-copy');
        copy.appendChild(this.createElement(ownerDocument, 'span', 'attachment-title attachment-text-title', displayLabel));
        const textOrdinal = Number.isInteger(options.textOrdinal) && options.textOrdinal > 0
          ? options.textOrdinal : 1;
        copy.appendChild(this.createElement(ownerDocument, 'span', 'attachment-text-source', `已粘贴的文本 ${textOrdinal}`));
        openButton.appendChild(copy);
        openButton.title = `${displayLabel} · 已粘贴的文本 ${textOrdinal}`;
        openButton.setAttribute('aria-label', `查看已粘贴的文本：${displayLabel}`);
        openButton.addEventListener('click', () => {
          this.openAttachmentDetail(attachment);
        });
      }
      chip.appendChild(openButton);
      if (attachment.type === 'text') {
        chip.addEventListener('mousedown', (event) => {
          if (Number(event.button) === 2) this.suppressGlobalNativeContextMenu();
        }, true);
        chip.addEventListener('contextmenu', (event) => {
          event.preventDefault();
          event.stopPropagation();
          this.showAttachmentNativeContextMenu(attachment);
        });
      }

      if (options.removable) {
        const removeButton = this.createElement(ownerDocument, 'button', 'attachment-remove-button', '×');
        removeButton.type = 'button';
        removeButton.title = `移除 ${displayLabel}`;
        removeButton.setAttribute('aria-label', `移除附件 ${displayLabel}`);
        removeButton.title = `移除 ${attachment.title}`;
        removeButton.setAttribute('aria-label', `移除文本附件 ${attachment.title}`);
        removeButton.title = `移除 ${displayLabel}`;
        removeButton.setAttribute('aria-label', `移除附件 ${displayLabel}`);
        removeButton.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          this.removeComposerAttachment(attachment.id);
        });
        chip.appendChild(removeButton);
      }
      return chip;
    },

    renderAttachmentList(container, attachments, options = {}) {
      if (!container) return;
      const items = this.cloneAttachments(attachments);
      this.clearElement(container);
      container.hidden = items.length === 0;
      const ownerDocument = container.ownerDocument || document;
      let textOrdinal = 0;
      items.forEach((attachment) => {
        if (attachment.type === 'text') textOrdinal += 1;
        const itemOptions = attachment.type === 'text'
          ? { ...options, textOrdinal }
          : options;
        if (!options.removable && attachment.type === 'file'
          && (String(attachment.mimeType || '').startsWith('audio/') || /\.(wav|mp3|ogg)$/iu.test(attachment.displayName || ''))) {
          this.renderAssistantArtifacts(container,[{id:attachment.id,type:'artifact',kind:'audio',source:'attachment',attachmentId:attachment.id,
            displayName:attachment.displayName,storedPath:attachment.storedPath,size:attachment.size,extension:attachment.extension,
            mimeType:attachment.mimeType,format:String(attachment.extension||'').replace(/^\./u,''),sessionId:attachment.sessionId,
            turnId:'attachment',projectImported:false,available:attachment.available!==false}]);
          return;
        }
        container.appendChild(this.isImageAttachment(attachment)
          ? this.createImageAttachmentReference(ownerDocument, attachment, itemOptions)
          : this.createAttachmentReference(ownerDocument, attachment, itemOptions));
      });
    },

    renderComposerAttachments() {
      this.renderAttachmentList(this.$.composerAttachments, this._composerAttachments, { removable: true });
      const container = this.$.composerAttachments;
      if (!container) return;
      const ownerDocument = container.ownerDocument || document;
      this.visibleAttachmentIngestStates().forEach((state) => {
        const chip = this.createElement(ownerDocument, 'div', `attachment-chip attachment-reference is-${state.state}`);
        const body = this.createElement(ownerDocument, 'span', 'attachment-open-button attachment-file-button');
        body.innerHTML = state.kind === 'directory'
          ? '<svg class="attachment-document-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M1.75 4.25h4l1.35 1.5h7.15v7.5a1 1 0 0 1-1 1H2.75a1 1 0 0 1-1-1v-9Z"></path><path d="M1.75 5.75V3.5a1 1 0 0 1 1-1h3l1.3 1.5h6.2a1 1 0 0 1 1 1v.75"></path></svg>'
          : '<svg class="attachment-document-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M4 1.75h5l3 3v9.5H4a1 1 0 0 1-1-1V2.75a1 1 0 0 1 1-1Z"></path><path d="M9 1.75v3h3"></path></svg>';
        body.appendChild(this.createElement(ownerDocument, 'span', 'attachment-title', state.displayName));
        chip.appendChild(body);
        if (state.state === 'failed') {
          const remove = this.createElement(ownerDocument, 'button', 'attachment-remove-button', '×');
          remove.type = 'button';
          remove.title = '移除失败的附件';
          remove.addEventListener('click', () => this.removeAttachmentIngestState(state.id));
          chip.appendChild(remove);
        }
        container.appendChild(chip);
      });
      container.hidden = !(this._composerAttachments?.length || this.visibleAttachmentIngestStates().length);
    },

    visibleAttachmentIngestStates() {
      const sessionId = this._sessionView === 'conversation' ? String(this._activeSessionId || '') : '';
      return (this._attachmentIngestStates || []).filter((state) => (
        this._sessionView === 'home' ? state.home : state.sessionId === sessionId
      ));
    },

    beginAttachmentIngest(context, options = {}) {
      if (!this._attachmentIngestStates) this._attachmentIngestStates = [];
      const state = {
        id: this.createOpaqueId('attachment-ingest'),
        sessionId: String(context?.sessionId || ''),
        home: Boolean(context?.createSession && this._sessionView === 'home'),
        kind: options.kind === 'directory' ? 'directory' : 'file',
        displayName: String(options.displayName || (options.kind === 'directory' ? '正在添加文件夹…' : '正在添加…')),
        state: 'pending',
        promise: null,
      };
      this._attachmentIngestStates.push(state);
      this.renderComposerAttachments();
      this.updateComposerActionState();
      return state;
    },

    finishAttachmentIngest(state, errorMessage = '') {
      if (!state) return;
      if (errorMessage) {
        state.state = 'failed';
        state.displayName = String(errorMessage);
        state.promise = null;
      } else {
        this._attachmentIngestStates = (this._attachmentIngestStates || []).filter((item) => item !== state);
      }
      this.renderComposerAttachments();
      this.updateComposerActionState();
    },

    removeAttachmentIngestState(id) {
      this._attachmentIngestStates = (this._attachmentIngestStates || [])
        .filter((state) => state.id !== String(id || ''));
      this.renderComposerAttachments();
      this.updateComposerActionState();
    },

    trackAttachmentIngest(state, operation) {
      const promise = Promise.resolve(operation);
      state.promise = promise;
      return promise;
    },

    async waitForAttachmentIngests() {
      const pending = this.visibleAttachmentIngestStates()
        .filter((state) => state.state === 'pending' && state.promise)
        .map((state) => state.promise);
      if (pending.length) {
        this.showComposerToast('正在添加附件，完成后将继续发送…', 2600);
        await Promise.allSettled(pending);
      }
      if (this.visibleAttachmentIngestStates().some((state) => state.state === 'failed')) {
        this.showComposerToast('有附件添加失败，请移除后重试', 3000);
        return false;
      }
      return true;
    },

    removeComposerAttachment(detailId) {
      const index = (this._composerAttachments || []).findIndex(
        (attachment) => attachment.id === String(detailId || '')
      );
      if (index === -1) return false;
      this.revokeAttachmentThumbnail(this._composerAttachments[index]);
      this._composerAttachments.splice(index, 1);
      this.renderComposerAttachments();
      this.updateComposerActionState();
      this.saveVisibleDraft(true);
      return true;
    },

    attachmentIngestContext() {
      const session = this._sessionView === 'conversation' ? this.activeSession() : null;
      return {
        sessionId: session?.id || this.createSessionId(),
        createSession: !session,
        draft: this.composerDraftSnapshot(),
      };
    },

    commitIngestedAttachments(context, attachments) {
      const added = this.cloneAttachments(attachments);
      if (!context || !added.length) return 0;
      let session = this._sessions.get(context.sessionId);
      if (!session && context.createSession) {
        session = this.createSession({ id: context.sessionId, draft: context.draft });
        if (this._sessionView === 'home' && !this.activeSession()) this.activateSession(session.id);
      }
      if (!session) return 0;
      if (this._sessionView === 'conversation' && this._activeSessionId === session.id) {
        this._composerAttachments.push(...added);
        this.renderComposerAttachments();
        this.updateComposerActionState();
        this.saveVisibleDraft(true);
      } else {
        session.draft = {
          ...(session.draft || context.draft || {}),
          attachments: [
            ...this.cloneAttachments(session.draft?.attachments || context.draft?.attachments),
            ...added,
          ],
        };
        this.persistSession(session.id, true);
      }
      return added.length;
    },

    async selectComposerAttachments(requestedKind = 'menu') {
      if (this._attachmentSelectPending || this._pinModeActive) return false;
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        this.showComposerToast('当前无法打开文件选择器');
        return false;
      }
      let kind = requestedKind;
      if (!['file', 'directory'].includes(kind)) {
        const choice = await this.requestNativeContextMenu({ kind: 'attachment-picker' });
        if (choice?.action === 'upload-file') kind = 'file';
        else if (choice?.action === 'upload-directory') kind = 'directory';
        else return false;
      }
      const context = this.attachmentIngestContext();
      const ingestState = kind === 'directory'
        ? this.beginAttachmentIngest(context, { kind, displayName: '正在添加文件夹…' })
        : null;
      this._attachmentSelectPending = true;
      if (this.$.attachButton) this.$.attachButton.disabled = true;
      const operation = (async () => {
        try {
        const result = await Editor.Message.request(
          EXTENSION_NAME,
          'select-chat-attachments',
          { sessionId: context.sessionId, kind }
        );
        if (result?.canceled) {
          this.finishAttachmentIngest(ingestState);
          return false;
        }
        const addedCount = this.commitIngestedAttachments(context, result?.attachments);
        const failed = Array.isArray(result?.errors) ? result.errors.length : 0;
        if (failed && !addedCount && kind === 'directory') {
          this.finishAttachmentIngest(ingestState, '文件夹添加失败');
        } else {
          this.finishAttachmentIngest(ingestState);
          if (failed) this.showComposerToast(`${failed} 个附件未能添加，其他已成功附件已保留`, 3200);
        }
        return addedCount > 0;
        } catch (error) {
          console.warn(`[AI Copilot] Unable to select attachments: ${error.message}`);
          this.finishAttachmentIngest(ingestState, kind === 'directory' ? '文件夹添加失败' : '文件添加失败');
          this.showComposerToast(kind === 'directory' ? '无法添加文件夹，请重试' : '无法添加文件，请重试', 2600);
          return false;
        } finally {
          this._attachmentSelectPending = false;
          if (this.$.attachButton) this.$.attachButton.disabled = Boolean(this._pinModeActive);
        }
      })();
      return ingestState ? this.trackAttachmentIngest(ingestState, operation) : operation;
    },

    clipboardFiles(event) {
      const clipboard = event?.clipboardData || event?.originalEvent?.clipboardData;
      if (!clipboard) return [];
      const itemFiles = [];
      const itemSeen = new Set();
      Array.from(clipboard.items || []).forEach((item) => {
        if (item?.kind !== 'file') return;
        const file = typeof item.getAsFile === 'function' ? item.getAsFile() : null;
        if (file && !itemSeen.has(file)) { itemSeen.add(file); itemFiles.push(file); }
      });
      const listedFiles = [];
      const listedSeen = new Set();
      Array.from(clipboard.files || []).forEach((file) => {
        if (!file || listedSeen.has(file)) return;
        listedSeen.add(file);
        listedFiles.push(file);
      });
      if (!itemFiles.length) return listedFiles;
      const itemsExposePaths = itemFiles.some((file) => Boolean(this.droppedFilePath(file)));
      const listExposesPaths = listedFiles.some((file) => Boolean(this.droppedFilePath(file)));
      return listExposesPaths && !itemsExposePaths ? listedFiles : itemFiles;
    },

    claimComposerPasteEvent(event) {
      if (!event || (typeof event !== 'object' && typeof event !== 'function')) return true;
      if (!this._consumedComposerPasteEvents) this._consumedComposerPasteEvents = new WeakSet();
      if (this._consumedComposerPasteEvents.has(event)) return false;
      this._consumedComposerPasteEvents.add(event);
      return true;
    },

    clipboardImageFiles(event) {
      return this.clipboardFiles(event)
        .filter((file) => String(file?.type || '').toLowerCase().startsWith('image/'));
    },

    clipboardFilesystemFiles(event) {
      return this.clipboardFiles(event).filter((file) => Boolean(this.droppedFilePath(file)));
    },

    clipboardFormats() {
      const clipboard = this.resolveComposerClipboard();
      if (!clipboard || typeof clipboard.availableFormats !== 'function') return [];
      try { return Array.from(clipboard.availableFormats() || [], (format) => String(format)); }
      catch (_) { return []; }
    },

    clipboardMayContainFilesystemEntries() {
      return this.clipboardFormats().some((format) => (
        /(?:text\/uri-list|filenamew?|cf_hdrop|shell idlist array)/iu.test(format)
      ));
    },

    async ingestNativeClipboardAttachments(images = []) {
      if (!global.Editor?.Message || typeof Editor.Message.request !== 'function') return 0;
      const context = this.attachmentIngestContext();
      const ingestState = this.beginAttachmentIngest(context, { displayName: '正在添加剪贴板附件…' });
      const operation = (async () => {
        try {
          const result = await Editor.Message.request(EXTENSION_NAME, 'ingest-clipboard-attachments', {
            sessionId: context.sessionId,
          });
          if (result?.handled) {
            const added = this.commitIngestedAttachments(context, result.attachments);
            this.finishAttachmentIngest(ingestState, !added && result.errors?.length ? '附件添加失败' : '');
            if (result.errors?.length) this.showComposerToast('部分剪贴板附件未能添加，其他附件已保留', 3000);
            return added;
          }
          this.finishAttachmentIngest(ingestState);
          if (images.length) return this.ingestClipboardImages(images);
          if (result?.limitation) {
            this.showComposerToast('Electron 31 无法可靠读取这次 Explorer 剪贴板文件列表，请改用 + 或拖入', 4200);
          }
          return 0;
        } catch (error) {
          this.finishAttachmentIngest(ingestState);
          if (images.length) return this.ingestClipboardImages(images);
          console.warn(`[AI Copilot] Clipboard attachment ingest failed: ${error.message}`);
          this.showComposerToast('无法读取剪贴板中的文件或文件夹', 3000);
          return 0;
        }
      })();
      return this.trackAttachmentIngest(ingestState, operation);
    },

    async ingestClipboardImages(files) {
      if (!files.length || !global.Editor?.Message || typeof Editor.Message.request !== 'function') return 0;
      const context = this.attachmentIngestContext();
      const attachments = [];
      let failed = 0;
      for (const file of files) {
        try {
          const bytes = new Uint8Array(await file.arrayBuffer());
          const result = await Editor.Message.request(EXTENSION_NAME, 'ingest-clipboard-image', {
            sessionId: context.sessionId,
            displayName: String(file.name || ''),
            mimeType: String(file.type || ''),
            bytes: Array.from(bytes),
          });
          if (result?.attachment) attachments.push(result.attachment);
          else failed += 1;
        } catch (error) {
          failed += 1;
          console.warn(`[AI Copilot] Clipboard image ingest failed: ${error.message}`);
        }
      }
      const added = this.commitIngestedAttachments(context, attachments);
      if (failed) this.showComposerToast('部分剪贴板图片未能添加，其他附件已保留', 3000);
      return added;
    },

    addPastedTextAttachment(content) {
      const value = String(content == null ? '' : content);
      if (!this.isLongPasteContent(value)) return null;
      const attachment = this.createTextAttachment(value);
      this._composerAttachments.push(attachment);
      this.renderComposerAttachments();
      this.updateComposerActionState();
      this.saveVisibleDraft(true);
      return attachment;
    },

    isLongPasteContent(content) {
      const value = String(content == null ? '' : content);
      if (!value) return false;
      const lineCount = value.split(/\r\n|\r|\n/).length;
      return value.length >= LONG_PASTE_CHAR_THRESHOLD
        || lineCount >= LONG_PASTE_LINE_THRESHOLD;
    },

    readComposerPasteText(event) {
      const clipboard = event && (
        event.clipboardData
        || event.originalEvent && event.originalEvent.clipboardData
      );
      if (clipboard && typeof clipboard.getData === 'function') {
        try {
          const plainText = clipboard.getData('text/plain') || clipboard.getData('text');
          if (plainText) return String(plainText);
        } catch (error) {
          console.warn(`[AI Copilot] ClipboardEvent text was unavailable: ${error.message}`);
        }
      }

      // Cocos Creator's Electron panel can deliver a paste event without
      // ClipboardEvent.clipboardData. Use the trusted local clipboard source
      // before allowing the browser to insert a large paste into the textarea.
      const electronClipboard = this.resolveComposerClipboard();
      if (electronClipboard && typeof electronClipboard.readText === 'function') {
        try {
          return String(electronClipboard.readText() || '');
        } catch (error) {
          console.warn(`[AI Copilot] Unable to read pasted text: ${error.message}`);
        }
      }
      return '';
    },

    handleComposerPaste(event) {
      const filesystemFiles = this.clipboardFilesystemFiles(event);
      const images = this.clipboardImageFiles(event);
      if (filesystemFiles.length) {
        if (!this.claimComposerPasteEvent(event)) return true;
        event.preventDefault?.();
        const clipboard = event?.clipboardData || event?.originalEvent?.clipboardData;
        const entries = Array.from(clipboard?.items || []).map((item) => {
          try { return typeof item.webkitGetAsEntry === 'function' ? item.webkitGetAsEntry() : null; }
          catch (_) { return null; }
        }).filter(Boolean);
        const kind = filesystemFiles.length === 1 && entries.length === 1 && entries[0].isDirectory
          ? 'directory'
          : 'file';
        this.ingestDroppedFiles(filesystemFiles, { kind, source: 'clipboard-file' }).catch((error) => {
          console.warn(`[AI Copilot] Clipboard filesystem ingest failed: ${error.message}`);
        });
        return true;
      }
      if (this.clipboardMayContainFilesystemEntries()) {
        if (!this.claimComposerPasteEvent(event)) return true;
        event.preventDefault?.();
        this.ingestNativeClipboardAttachments(images).catch((error) => {
          console.warn(`[AI Copilot] Clipboard filesystem probe failed: ${error.message}`);
        });
        return true;
      }
      if (!images.length) {
        const pastedText = this.readComposerPasteText(event);
        if (!this.isLongPasteContent(pastedText)) return false;
        if (!this.claimComposerPasteEvent(event)) return true;
        event.preventDefault?.();
        this.addPastedTextAttachment(pastedText);
        return true;
      }
      // Do not preventDefault: if the clipboard also contains text, the textarea
      // keeps its native paste behavior while image snapshots are ingested.
      if (!this.claimComposerPasteEvent(event)) return true;
      this.ingestClipboardImages(images).catch((error) => {
        console.warn(`[AI Copilot] Clipboard image ingest failed: ${error.message}`);
        this.showComposerToast('无法添加剪贴板图片，请重试', 2800);
      });
      return true;
    },

    async openAttachmentDetail(attachment) {
      if (!attachment || attachment.type !== 'text'
        || !global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        this.showComposerToast('无法打开该内容');
        return false;
      }
      try {
        const result = await Editor.Message.request(
          EXTENSION_NAME,
          'open-detail',
          { document: this.attachmentDocument(attachment) }
        );
        return Boolean(result && result.opened);
      } catch (error) {
        console.warn(`[AI Copilot] Unable to open text attachment: ${error.message}`);
        this.showComposerToast('无法打开该内容');
        return false;
      }
    },

    async openAssetPreview(source = {}, mode = 'view') {
      let session = this.activeSession();
      if (!session) { session = this.createSession({}); this.activateSession(session.id); }
      const sessionId = source.sessionId || session.id;
      let descriptor = source.type === 'artifact' ? { artifactId: source.id, projectAssetUuid:source.projectAssetUuid, projectAssetUrl:source.projectAssetUrl, identity: `artifact:${sessionId}:${source.id}` }
        : source.storedPath && source.type === 'file' ? { attachment: this.cloneAttachment(source), identity: `attachment:${sessionId}:${source.id}` }
        : { target: source.assetUrl || source.target, identity: source.identity || `project:${source.assetUrl || source.target}` };
      if (!descriptor.target && !descriptor.artifactId && !descriptor.attachment) {
        descriptor = await Editor.Message.request(EXTENSION_NAME, 'get-attachment-thumbnail', { kind: 'asset-preview-selection' });
        if (!descriptor) descriptor = { empty:true, identity:'empty' };
      }
      this._contentSource = descriptor.empty ? null : { ...source, ...descriptor, sessionId };
      return Editor.Message.request(EXTENSION_NAME, 'open-asset-preview', { ...descriptor, sessionId, mode });
    },

    async openAudioWorkbench(source = {}) {
      let session=this.activeSession();if(!session){session=this.createSession({});this.activateSession(session.id);}
      const sessionId=source.sessionId||session.id;
      let descriptor=source.type==='artifact'?{artifactId:source.id,identity:`artifact:${sessionId}:${source.id}`}
        :source.source==='attachment'||source.storedPath&&source.type==='file'?{attachmentId:source.attachmentId||source.id,identity:`attachment:${sessionId}:${source.attachmentId||source.id}`}
          :{target:source.assetUrl||source.target,identity:source.identity||`project:${source.assetUrl||source.target}`};
      if(!descriptor.target&&!descriptor.artifactId&&!descriptor.attachmentId){descriptor=await Editor.Message.request(EXTENSION_NAME,'get-audio-source',{kind:'audio-workbench-selection',sessionId});if(!descriptor)descriptor={empty:true,identity:'empty'};}
      this._contentSource=descriptor.empty?null:{...source,...descriptor,sessionId};
      return Editor.Message.request(EXTENSION_NAME,'open-audio-workbench',{...descriptor,sessionId});
    },

    async commitAudioWorkbench(params={}) {
      const sessionId=params.source?.sessionId||this._activeSessionId,session=this._sessions.get(sessionId);
      if(!session)return {ok:false,message:'原会话已不可用，请重新打开音频。'};
      const taskId=`audio-workbench:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;
      const title={save:'保存音频新版本',import:'导入 AudioClip',configure:'配置 AudioSource',preview:'保存场景并启动 Preview'}[params.action]||'处理音频';
      const turn=this.createTurn(taskId,title,[],[],title,session);turn.liveState=null;turn.executionStarted=true;
      let result;
      try{result=await Editor.Message.request(EXTENSION_NAME,'audio-workbench-action',{...params,taskId});result={ok:true,...result};}
      catch(error){result={ok:false,message:error.message,technicalError:error.stack||String(error)};}
      turn.status=result.ok?'completed':'failed';turn.executionStatus=turn.status;turn.completedAt=Date.now();turn.changeSet=result.changeSet||turn.changeSet;turn.errorMessage=result.ok?'':result.message;turn.errorDetail=result.technicalError||'';turn.viewState.changeExpanded=true;
      if(session.id===this._activeSessionId&&turn.ui)this.renderTurn(turn);this.persistSession(session.id,true);return result;
    },

    async commitPreviewAssets(params) {
      const sessionId = params.sessionId || this._activeSessionId;
      const session = this._sessions.get(sessionId);
      if (!session) return { ok: false, message: '原会话已不可用，请重新打开图片。' };
      const request = (method, payload) => Editor.Message.request(EXTENSION_NAME, method, payload);
      const taskId = `asset-preview:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;
      const title = { 'import-image': '导入图片', settings:'配置图片资产', 'place-image':'放入图片到当前 Scene', frames: '保存 Sprite 帧', animation: '创建 AnimationClip', place: '放入当前 Scene', preview: '保存场景并启动 Preview' }[params.action] || '处理图片资产';
      const turn = this.createTurn(taskId, title, [], [], title, session);
      turn.liveState = null; turn.executionStarted = true;
      let result;
      try { result = await request('save-artifact', { ...params, kind: 'asset-preview-commit', sessionId, taskId }); }
      catch (error) { result = { ok: false, message: '资产操作失败，请查看技术详情。', technicalError: error.stack || String(error) }; }
      turn.status = result.ok ? 'completed' : 'failed'; turn.executionStatus = turn.status;
      turn.completedAt = Date.now(); turn.changeSet = result.changeSet || turn.changeSet;
      turn.errorMessage = result.ok ? '' : result.message; turn.errorDetail = result.technicalError || '';
      turn.viewState.changeExpanded = true;
      if(result.ok&&params.action==='import-image'&&params.artifactId){for(const prior of session.turnsByTaskId.values())for(const message of prior.assistantMessages||[])for(const artifact of message.artifacts||[])if(artifact.id===params.artifactId)Object.assign(artifact,{projectImported:true,projectAssetUrl:result.result.assetUrl,projectAssetUuid:result.result.assetUuid,projectSpriteFrameUuid:result.result.spriteFrameUuid||'',projectTextureUuid:result.result.textureUuid||''});}
      if (session.id === this._activeSessionId && turn.ui) this.renderTurn(turn);
      this.persistSession(session.id, true);
      return result;
    },

    async refreshImportedArtifacts(session, artifactId = '') {
      if (!session) return;
      for (const turn of session.turnsByTaskId.values()) for (const message of turn.assistantMessages || []) for (const artifact of message.artifacts || []) {
        if (!artifact.id||!['image','audio'].includes(artifact.kind)||(artifactId&&artifact.id!==artifactId)) continue;
        const status = await Editor.Message.request(EXTENSION_NAME,'get-attachment-thumbnail',{kind:'artifact-import-status',mediaKind:artifact.kind,sessionId:session.id,artifactId:artifact.id,displayName:artifact.displayName,target:artifact.projectAssetUuid,assetUrl:artifact.projectAssetUrl,projectFileUrl:artifact.projectFileUrl,projectAssetCandidateUrl:artifact.projectAssetCandidateUrl}).catch(()=>null);
        if(status==null)continue;const imported=status===true||status.imported===true;
        const nextUrl=imported?String(status.assetUrl||artifact.projectAssetUrl||''):'';const nextUuid=imported?String(status.assetUuid||artifact.projectAssetUuid||''):'';
        const patch = artifact.kind === 'audio' ? audioStatusPatch(status, artifact) : {projectImported:imported,projectAssetUrl:nextUrl,projectAssetUuid:nextUuid};
        if(Object.entries(patch).some(([key,value])=>artifact[key]!==value)){Object.assign(artifact,patch);if(this._contentSource?.id===artifact.id)this._contentSource=artifact;if(turn.ui&&this._activeSessionId===session.id)this.renderTurn(turn);this.persistSession(session.id,true);}
      }
    },

    async importImageArtifact(artifact) {
      if (!artifact?.id || artifact.projectImported) return false;
      this.closeToolsPopover();
      const doc = this.$.root.ownerDocument;
      const box = this.createElement(doc, 'div', 'tools-popover');
      box.style.cssText = 'position:absolute;z-index:100;left:12px;right:12px;bottom:90px;padding:12px';
      box.appendChild(this.createElement(doc,'div','tools-section-label','导入图片 · 选择已有 assets 目录及文件名'));
      this._imageImportBox?.remove(); this._imageImportBox = box;
      const folder = await Editor.Message.request(EXTENSION_NAME,'get-attachment-thumbnail',{kind:'image-import-default'}).catch(()=>'assets');
      if (this._panelClosing || this._imageImportBox !== box) return false;
      const input = this.createElement(doc,'input','tools-search'); input.value = `${folder}/${artifact.displayName}`; box.appendChild(input);
      const error = this.createElement(doc,'div','tools-empty'); box.appendChild(error);
      const submit = this.createElement(doc,'button','tools-row','导入项目'), cancel = this.createElement(doc,'button','tools-row','取消');
      const close = () => { box.remove(); if (this._imageImportBox === box) this._imageImportBox = null; };
      cancel.addEventListener('click',close);
      submit.addEventListener('click',async()=>{
        submit.disabled = true;
        const result = await this.commitPreviewAssets({ action:'import-image', artifactId:artifact.id, sessionId:artifact.sessionId, outputPath:input.value });
        if (result.ok) {
          const session = this._sessions.get(artifact.sessionId);
          for (const turn of session.turnsByTaskId.values()) for (const message of turn.assistantMessages || []) for (const item of message.artifacts || []) if (item.id === artifact.id) Object.assign(item, { projectImported:true, projectAssetUrl:result.result.assetUrl, projectAssetUuid:result.result.assetUuid,projectSpriteFrameUuid:result.result.spriteFrameUuid||'',projectTextureUuid:result.result.textureUuid||'' });
          this._contentSource = null; this.persistSession(session.id, true);
          for (const turn of session.turnsByTaskId.values()) if (turn.ui && session.id === this._activeSessionId) this.renderTurn(turn); close();
        } else { error.textContent = result.message; submit.disabled = false; }
      });
      box.appendChild(submit); box.appendChild(cancel); this.$.root.appendChild(box); input.focus();
      return true;
    },

    formatAudioTime(value) {
      value=Math.max(0,Number(value)||0);return `${String(Math.floor(value/60)).padStart(2,'0')}:${String(Math.floor(value%60)).padStart(2,'0')}`;
    },

    audioPlaybackIcon(playing=false) {
      return playing
        ? '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 2.5h3.25v11H3zM9.75 2.5H13v11H9.75z"/></svg>'
        : '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 2.25 13 8l-9 5.75z"/></svg>';
    },

    releaseAudioArtifactPlayers() {
      if(this._activeAudioPlayer){this._activeAudioPlayer.pause();this._activeAudioPlayer=null;}
      for(const item of this._audioArtifactPlayers?.values?.()||[]){try{item.audio.pause();item.audio.removeAttribute('src');item.audio.load();item.win.URL.revokeObjectURL(item.url);}catch(_){}}
      this._audioArtifactPlayers=new Map();
    },

    releaseAudioArtifactPlayer(id) {
      const item=this._audioArtifactPlayers?.get(id);if(!item)return;
      try{item.audio.pause();item.audio.removeAttribute('src');item.audio.load();item.win.URL.revokeObjectURL(item.url);}catch(_){}
      if(this._activeAudioPlayer===item.audio)this._activeAudioPlayer=null;
      this._audioArtifactPlayers.delete(id);
    },

    async bindAudioArtifactCard(card,artifact,play,loop,seek,time,meta) {
      this._audioArtifactPlayers ||= new Map();
      const old=this._audioArtifactPlayers.get(artifact.id);if(old){old.audio.pause();old.win.URL.revokeObjectURL(old.url);this._audioArtifactPlayers.delete(artifact.id);}
      try{
        const source=artifact.source==='attachment'?{attachmentId:artifact.attachmentId||artifact.id}:{artifactId:artifact.id};const loaded=await Editor.Message.request(EXTENSION_NAME,'get-audio-source',{kind:'audio-workbench-source',...source,sessionId:artifact.sessionId});
        if(!loaded?.available||this._panelClosing||card.isConnected===false)return;
        const bytes=Uint8Array.from(atob(loaded.base64),char=>char.charCodeAt(0)),blob=new Blob([bytes],{type:loaded.mimeType});
        const win=card.ownerDocument.defaultView,url=win.URL.createObjectURL(blob),audio=new win.Audio(url);audio.preload='metadata';
        this._audioArtifactPlayers.set(artifact.id,{audio,url,win});seek.max=loaded.duration||1;seek.style.setProperty('--audio-progress','0%');time.textContent=`00:00 / ${this.formatAudioTime(loaded.duration)}`;const state=audioStatusView(artifact).label;meta.textContent=`${String(loaded.format||artifact.format||'audio').toUpperCase()} · ${this.formatAudioTime(loaded.duration)} · ${state}`;
        const sync=()=>{const duration=Number(audio.duration)||Number(loaded.duration)||0,current=audio.currentTime||0;seek.value=current;seek.style.setProperty('--audio-progress',`${duration?Math.max(0,Math.min(100,current/duration*100)):0}%`);time.textContent=`${this.formatAudioTime(current)} / ${this.formatAudioTime(duration)}`;};
        audio.addEventListener('timeupdate',sync);audio.addEventListener('play',()=>{if(this._activeAudioPlayer&&this._activeAudioPlayer!==audio)this._activeAudioPlayer.pause();this._activeAudioPlayer=audio;play.innerHTML=this.audioPlaybackIcon(true);});audio.addEventListener('pause',()=>{play.innerHTML=this.audioPlaybackIcon(false);});audio.addEventListener('ended',()=>{play.innerHTML=this.audioPlaybackIcon(false);});
        play.addEventListener('click',()=>audio.paused?audio.play().catch(()=>{}):audio.pause());loop.addEventListener('click',()=>{audio.loop=!audio.loop;loop.classList.toggle('is-active',audio.loop);loop.setAttribute('aria-pressed',String(audio.loop));});seek.addEventListener('input',()=>{audio.currentTime=Number(seek.value)||0;sync();});
      }catch(error){card.classList.add('is-unavailable');play.disabled=true;loop.disabled=true;seek.disabled=true;console.warn(`[AI Copilot] Audio card failed: ${error.message}`);}
    },

    async importAudioArtifact(artifact) {
      if(!artifact?.id||artifact.projectImported)return false;
      const doc=this.$.root.ownerDocument,box=this.createElement(doc,'div','tools-popover');box.style.cssText='position:absolute;z-index:100;left:12px;right:12px;bottom:90px;padding:12px';box.appendChild(this.createElement(doc,'div','tools-section-label','导入音频 · 新建 AudioClip'));
      this._audioImportBox?.remove();this._audioImportBox=box;const folder=await Editor.Message.request(EXTENSION_NAME,'get-audio-source',{kind:'audio-import-default'}).catch(()=>'assets');const input=this.createElement(doc,'input','tools-search');input.value=`${folder}/${artifact.displayName}`;box.appendChild(input);const error=this.createElement(doc,'div','tools-empty');box.appendChild(error);const submit=this.createElement(doc,'button','tools-row','导入项目'),cancel=this.createElement(doc,'button','tools-row','取消');const close=()=>{box.remove();if(this._audioImportBox===box)this._audioImportBox=null;};cancel.addEventListener('click',close);submit.addEventListener('click',async()=>{submit.disabled=true;const source=artifact.source==='attachment'?{attachmentId:artifact.attachmentId||artifact.id,sessionId:artifact.sessionId,identity:`attachment:${artifact.sessionId}:${artifact.attachmentId||artifact.id}`}:{artifactId:artifact.id,sessionId:artifact.sessionId,identity:`artifact:${artifact.sessionId}:${artifact.id}`};const result=await this.commitAudioWorkbench({action:'import',source,draft:{format:artifact.format||String(artifact.extension).replace('.','')||'wav',channels:'source'},outputPath:input.value});if(result.ok){const session=this._sessions.get(artifact.sessionId);for(const turn of session.turnsByTaskId.values())for(const message of turn.assistantMessages||[])for(const item of message.artifacts||[])if(item.id===artifact.id)Object.assign(item,{projectImported:true,projectAssetUrl:result.assetUrl,projectAssetUuid:result.clipUuid});this.persistSession(session.id,true);for(const turn of session.turnsByTaskId.values())if(turn.ui&&session.id===this._activeSessionId)this.renderTurn(turn);close();}else{error.textContent=result.message;submit.disabled=false;}});box.append(submit,cancel);this.$.root.appendChild(box);input.focus();return true;
    },

    composerDraftSnapshot() {
      return {
        text: String(this.$.composerInput && this.$.composerInput.value || ''),
        attachments: this.cloneTextAttachments(this._composerAttachments),
        pins: this.clonePinnedContexts(this._composerPins),
      };
    },

    saveVisibleDraft(immediate = false) {
      if (this._restoringDraft || !this.$.composerInput) return;
      const draft = this.composerDraftSnapshot();
      const session = this._sessionView === 'conversation' ? this.activeSession() : null;
      if (session) {
        session.draft = draft;
        this.persistSession(session.id, immediate);
      } else this._homeDraft = draft;
    },

    restoreComposerDraft(draft = {}) {
      this._restoringDraft = true;
      if (this.$.composerInput) this.$.composerInput.value = String(draft.text || '');
      this._composerAttachments = this.cloneTextAttachments(draft.attachments);
      this._composerPins = this.clonePinnedContexts(draft.pins);
      this.renderComposerAttachments();
      this.renderComposerPins();
      this.resizeComposer();
      this.updateComposerActionState();
      this._restoringDraft = false;
    },

    persistSession(sessionId, immediate = false) {
      if (!this._persistenceReady || !this._sessions?.has(sessionId)) return Promise.resolve();
      if (!this._sessionWriter) {
        const request = Editor.Message.request.bind(Editor.Message);
        this._sessionWriter = new CoalescedSessionWriter((id, flush) => {
        if (!this._sessions?.has(id)) return;
        const record = sessionDocument(this._sessions.get(id), this.sessionQueueState(id));
        return request(EXTENSION_NAME, 'save-session', { record, immediate: flush });
      }, { onError: () => {
          if (!this._persistenceWarningShown) this.showComposerToast('聊天历史暂时无法保存，请检查本地存储。', 3500);
          this._persistenceWarningShown = true;
        } });
      }
      return this._sessionWriter.schedule(sessionId, immediate);
    },

    async restoreLocalSessions() {
      const sessions = this._sessions;
      this._persistenceReady = false;
      this._persistenceError = '';
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'load-sessions');
        if (this._panelClosing || this._sessions !== sessions) return;
        if (!Array.isArray(result?.sessions)) throw new Error('Invalid local history response.');
        this._localSessionProjectKey = result.projectKey;
        for (const record of result.sessions) {
          const update = this._sessionLifecycleUpdates?.get(record.id);
          const lifecycle = update?.projectKey && result.projectKey && update.projectKey !== result.projectKey ? null : update;
          if (lifecycle?.action === 'delete') continue;
          if (this._sessions.has(record.id)) continue;
          const session = this.createSession({ ...record,
            ...(lifecycle ? { archivedAt: lifecycle.archivedAt } : {}), restored: true });
          session.messages = record.messages.map((saved) => ({
            ...saved, sessionId: session.id, liveState: null, ui: null, guardTraces: [],
            executionStatus: saved.status, historyExpanded: saved.status === 'failed',
            user: {
              text: saved.userMessage,
              attachments: saved.attachments,
              pins: saved.pins,
            },
            viewState: { expanded: new Map(),
              planExpanded: null, planUserToggled: false, changeExpanded: false },
          }));
          session.messages.forEach((turn) => {
            session.turnsByTaskId.set(turn.taskId, turn);
            this._taskSessionIds.set(turn.taskId, session.id);
          });
          const queue = this.sessionQueueState(session.id);
          queue.queuedMessages = (record.queue?.queuedMessages || []).map((item) => ({ ...item, sessionId: session.id }));
          queue.paused = queue.queuedMessages.length > 0;
          queue.pauseReason = queue.paused ? 'restored' : '';
        }
        this._persistenceReady = !result.readOnly;
        this._persistenceError = result.warnings?.[0] || '';
        // A user can create a chat while the local read is in flight.
        this._sessions.forEach((session) => { if (!session.restored) this.persistSession(session.id, true); });
        if (this._sessionView === 'home') this.renderChatsHome();
        if (this._sessionView === 'all') this.renderAllSessionsView();
        if (result.warnings?.length) this.showComposerToast(result.warnings[0], 4000);
        // Start only after the local list is mounted; this request owns no navigation.
        this.refreshRestoredReviews(result.projectKey, result.sessions);
      } catch (_) {
        if (this._panelClosing || this._sessions !== sessions) return;
        this._persistenceReady = false;
        this._persistenceError = '聊天历史暂时无法读取，已有文件不会被覆盖。';
        this.showComposerToast(this._persistenceError, 4000);
        if (this._sessionView === 'home') this.renderChatsHome();
        if (this._sessionView === 'all') this.renderAllSessionsView();
      }
    },

    async refreshRestoredReviews(projectKey, records) {
      if (!projectKey) return;
      const sessions = this._sessions;
      const targets = new Map();
      for (const record of records) {
        const session = sessions.get(record.id);
        for (const saved of record.messages || []) {
          const turn = session?.turnsByTaskId.get(saved.taskId);
          if (!turn?.changeSet || turn.changeSet.expired) continue;
          const turnId = turn.changeSet.turnId || turn.taskId;
          targets.set(`${session.id}\0${turnId}`, { session, turn, turnId, previous: turn.changeSet });
        }
      }
      if (!targets.size) return;
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'revalidate-session-reviews', {
          projectKey, changes: Array.from(targets.values()).map(({ session, turnId }) => ({ sessionId: session.id, turnId })),
        });
        if (this._panelClosing || this._sessions !== sessions || result?.projectKey !== projectKey) return;
        for (const update of result.changes || []) {
          const target = targets.get(`${update.sessionId}\0${update.turnId}`);
          if (!target || !update.changeSet || sessions.get(update.sessionId) !== target.session
            || target.turn.changeSet !== target.previous) continue;
          target.turn.changeSet = update.changeSet;
          if (target.turn.ui) this.renderChangeCard(target.turn);
        }
      } catch (error) {
        if (!this._panelClosing && this._sessions === sessions) {
          console.warn(`[AI Copilot Review] History revalidation unavailable: ${error.message}`);
        }
      }
    },

    async ensureSessionRestored(session) {
      if (!session?.threadId || !session.restored || session.restoreState === 'ready') return true;
      if (session.restorePromise) return session.restorePromise;
      session.restorePromise = (async () => {
        try {
          const result = await Editor.Message.request(EXTENSION_NAME, 'resume-session', {
            sessionId: session.id, threadId: session.threadId, permissionModeId: session.permissionModeId || '',
            providerId: session.providerId || 'openai',
            modelId: session.modelId || '',
            reasoningEffort: session.reasoningEffort || '',
          });
          if (result.deferred) return false;
          session.restoreState = result.restored ? 'ready' : 'failed';
          session.restoreError = result.restored ? '' : '原 Codex 会话不可恢复，请重试或新建聊天。';
          return Boolean(result.restored);
        } catch (_) {
          session.restoreState = 'failed';
          session.restoreError = '原 Codex 会话不可恢复，请重试或新建聊天。';
          return false;
        } finally {
          session.restorePromise = null;
          if (session.id === this._activeSessionId) this.updateSessionHeader();
        }
      })();
      return session.restorePromise;
    },

    normalizeTaskPayload(task) {
      const source = task && typeof task === 'object'
        ? task
        : { text: String(task == null ? '' : task), attachments: [] };
      const text = String(source.text == null ? source.displayText || '' : source.text);
      const attachments = this.cloneTextAttachments(source.attachments);
      const pins = this.dedupePinnedContexts(source.pins || []);
      const modelSelection = this.normalizedModelSelection({
        ...this.currentModelSelection(),
        providerId: source.providerId || this.currentModelSelection().providerId,
        modelId: source.modelId || this.currentModelSelection().modelId,
        reasoningEffort: Object.prototype.hasOwnProperty.call(source, 'reasoningEffort')
          ? source.reasoningEffort : this.currentModelSelection().reasoningEffort,
      }, false);
      return {
        text,
        attachments,
        pins,
        ...modelSelection,
        executionPrompt: this.buildExecutionPrompt(text, attachments, pins),
      };
    },

    buildExecutionPrompt(text, attachments, pins = []) {
      const userText = String(text == null ? '' : text);
      const items = this.cloneTextAttachments(attachments);
      const pinnedItems = this.dedupePinnedContexts(pins);
      return buildCocosExecutionPrompt({
        userRequest: userText,
        attachments: items,
        snapshot: createCocosContextSnapshot({ pins: pinnedItems }),
      });
    },

    createSessionId() {
      return `session:${Date.now()}:${Math.random().toString(36).slice(2)}`;
    },

    createSession(options = {}) {
      const now = Date.now();
      const selection = this.normalizedModelSelection({
        ...(this._newSessionModelSelection || {}),
        providerId: options.providerId || this._newSessionModelSelection?.providerId,
        modelId: options.modelId || this._newSessionModelSelection?.modelId,
        reasoningEffort: Object.prototype.hasOwnProperty.call(options, 'reasoningEffort')
          ? options.reasoningEffort : this._newSessionModelSelection?.reasoningEffort,
      }, !options.restored);
      const session = {
        id: String(options.id || this.createSessionId()),
        title: String(options.title || '新会话'),
        threadId: options.threadId ? String(options.threadId) : null,
        permissionModeId: options.permissionModeId || this._newSessionPermissionModeId || null,
        providerId: selection.providerId || options.providerId || 'openai',
        modelId: selection.modelId || String(options.modelId || ''),
        reasoningEffort: selection.reasoningEffort || String(options.reasoningEffort || ''),
        draft: options.draft || { text: '', attachments: [], pins: [] },
        restored: Boolean(options.restored),
        ...(options.continuation ? { continuation: options.continuation } : {}),
        messages: [],
        turnsByTaskId: new Map(),
        createdAt: Number(options.createdAt || now),
        updatedAt: Number(options.updatedAt || now),
        archivedAt: Number(options.archivedAt || 0),
      };
      this._sessions.set(session.id, session);
      this.sessionQueueState(session.id);
      if (!options.restored) this.persistSession(session.id, true);
      return session;
    },

    activeSession() {
      const session = this._sessions && this._sessions.get(this._activeSessionId);
      return session && !session.archivedAt ? session : null;
    },

    sessionForTask(taskId, eventSessionId = '') {
      const normalizedTaskId = String(taskId || '');
      const boundSessionId = this._taskSessionIds && this._taskSessionIds.get(normalizedTaskId);
      const normalizedEventSessionId = String(eventSessionId || '');
      if (boundSessionId && normalizedEventSessionId && boundSessionId !== normalizedEventSessionId) {
        console.error(
          `[AI Copilot] Ignored event with mismatched session binding: task=${normalizedTaskId} `
          + `expected=${boundSessionId} actual=${normalizedEventSessionId}`
        );
        return null;
      }
      const sessionId = boundSessionId || normalizedEventSessionId;
      return sessionId && this._sessions ? this._sessions.get(sessionId) || null : null;
    },

    getRunningSessionId() {
      if (this._activeExecutionSessionId) return this._activeExecutionSessionId;
      const taskId = String(this._activeCodexTaskId || '');
      if (taskId) {
        const boundSessionId = this._taskSessionIds && this._taskSessionIds.get(taskId);
        if (boundSessionId) return boundSessionId;
        const activeTurn = this._codexTurns && this._codexTurns.get(taskId);
        if (activeTurn && activeTurn.sessionId) return activeTurn.sessionId;
      }

      if (this._codexTaskRunning || this._codexStopPending) {
        const runtimeSessionId = String(this._codexSessionId || '');
        if (runtimeSessionId) return runtimeSessionId;
      }

      if (this._sessions) {
        const runningSession = Array.from(this._sessions.values()).find((session) => (
          session.messages.some((turn) => turn && turn.status === 'running')
        ));
        if (runningSession) return runningSession.id;
      }
      return '';
    },

    isSessionRunning(sessionOrId) {
      const sessionId = typeof sessionOrId === 'string'
        ? sessionOrId
        : sessionOrId && sessionOrId.id;
      return Boolean(sessionId && sessionId === this.getRunningSessionId() && (this._codexTaskRunning || this._activeCodexTaskId));
    },

    isCurrentSessionExecuting() {
      return this._sessionView === 'conversation' && this.isSessionRunning(this._activeSessionId);
    },

    isSessionWaiting(sessionId) {
      const queue = this.sessionQueueState(sessionId);
      return Boolean(queue && !queue.paused && this.pendingQueueMessages(queue).length
        && !this.isSessionRunning(sessionId));
    },

    bindActiveSession(session) {
      if (!session) return;
      if (this._activeSessionId !== session.id) { this._contentSource = null; this._imageImportBox?.remove(); this._imageImportBox = null; }
      this._activeSessionId = session.id;
      // Keep the existing fields as active-session aliases so the Composer and
      // queue code can continue using the already-tested paths.
      this._codexSessionId = session.id;
      this._codexThreadId = session.threadId || '';
      this._codexTurns = session.turnsByTaskId;
    },

    deriveSessionTitle(prompt) {
      const normalized = String(prompt || '').replace(/\s+/g, ' ').trim();
      if (!normalized) return '新会话';
      const maxLength = 36;
      if (normalized.length <= maxLength) return normalized;
      let clipped = normalized.slice(0, maxLength).trimEnd();
      if (/[A-Za-z0-9_]$/.test(clipped) && /^[A-Za-z0-9_]/.test(normalized.slice(maxLength))) {
        const wordBoundary = clipped.lastIndexOf(' ');
        if (wordBoundary >= Math.floor(maxLength * 0.55)) clipped = clipped.slice(0, wordBoundary);
      }
      return `${clipped}…`;
    },

    touchSession(sessionOrId, timestamp = Date.now()) {
      const session = typeof sessionOrId === 'string'
        ? this._sessions.get(sessionOrId)
        : sessionOrId;
      if (!session) return;
      session.updatedAt = Number(timestamp || Date.now());
      this.persistSession(session.id, true);
      if (this.$.sessionHistory && !this.$.sessionHistory.hidden) this.renderSessionList();
      if (this._sessionView === 'home') this.renderChatsHome();
      if (this._sessionView === 'all') this.renderAllSessionsView();
    },

    formatSessionTime(timestamp) {
      const value = Number(timestamp || 0);
      if (!Number.isFinite(value)) return '';
      const elapsedMinutes = Math.max(0, Math.floor((Date.now() - value) / 60000));
      if (elapsedMinutes < 1) return '刚刚';
      if (elapsedMinutes < 60) return `${elapsedMinutes} 分`;
      const hours = Math.floor(elapsedMinutes / 60);
      if (hours < 24) return `${hours} 小时`;
      const days = Math.floor(hours / 24);
      if (days < 7) return `${days} 天`;
      if (days < 30) return `${Math.floor(days / 7)} 周`;
      if (days < 365) return `${Math.floor(days / 30)} 月`;
      return `${Math.floor(days / 365)} 年`;
    },

    sortedSessions() {
      return Array.from(this._sessions ? this._sessions.values() : [])
        .filter((session) => !session.archivedAt)
        .sort((left, right) => right.updatedAt - left.updatedAt || right.createdAt - left.createdAt);
    },

    sessionMatchesQuery(session, query) {
      const normalizedQuery = String(query || '').trim().toLowerCase();
      return !normalizedQuery || String(session && session.title || '').toLowerCase().includes(normalizedQuery);
    },

    updateSessionHeader() {
      const session = this.activeSession();
      const isConversation = this._sessionView === 'conversation' && session;
      if (this.$.sessionNotice) {
        this.$.sessionNotice.textContent = isConversation ? session.restoreError || '' : '';
        this.$.sessionNotice.hidden = !this.$.sessionNotice.textContent;
      }
      const title = this._sessionView === 'all'
        ? '全部会话'
        : isConversation ? session.title : '会话';
      if (this.$.sessionTitleButton) {
        this.$.sessionTitleButton.textContent = title;
        this.$.sessionTitleButton.title = title;
        this.$.sessionTitleButton.classList.toggle('is-static', !isConversation);
        this.$.sessionTitleButton.setAttribute('aria-haspopup', isConversation ? 'dialog' : 'false');
        this.$.sessionTitleButton.disabled = false;
      }
      if (this.$.sessionHistoryButton) this.$.sessionHistoryButton.hidden = this._sessionView === 'home';
      if (this.$.sessionMoreButton) {
        this.$.sessionMoreButton.hidden = !session;
        this.$.sessionMoreButton.disabled = !session;
      }
      if (this.$.activityScroller) {
        this.$.activityScroller.setAttribute(
          'aria-label',
          this._sessionView === 'home' ? 'AI Copilot 会话首页'
            : this._sessionView === 'all' ? '全部 AI Copilot 会话' : 'AI Copilot conversation'
        );
      }
      const root = this.$.activityScroller && this.$.activityScroller.closest('.copilot-root');
      if (root) root.dataset.sessionView = this._sessionView;
      this.updateComposerActionState();
    },

    renderSessionRowState(session, ownerDocument) {
      const pending = this.pendingApprovalsForSession(session);
      if (pending.length) {
        const waiting = this.createElement(ownerDocument, 'span', 'session-row-meta session-row-waiting',
          pending[0].activity.requestKind === 'input' ? '待输入' : '待批准');
        waiting.setAttribute('role', 'status');
        return waiting;
      }
      if (this.isSessionRunning(session)) {
        const spinner = this.createElement(ownerDocument, 'span', 'session-row-meta session-row-spinner');
        spinner.setAttribute('role', 'status');
        spinner.setAttribute('aria-label', '正在运行');
        return spinner;
      }
      if (this.isSessionWaiting(session.id)) {
        const waiting = this.createElement(ownerDocument, 'span', 'session-row-meta session-row-waiting', '等待运行');
        waiting.setAttribute('role', 'status');
        return waiting;
      }
      return this.createElement(
        ownerDocument,
        'span',
        'session-row-meta session-row-time',
        this.formatSessionTime(session.updatedAt)
      );
    },

    refreshRenderedSessionStates() {
      const roots = [this.$.activityContent, this.$.sessionList].filter(Boolean);
      roots.forEach((root) => {
        root.querySelectorAll('.session-row[data-session-id]').forEach((row) => {
          const session = this._sessions && this._sessions.get(row.dataset.sessionId);
          if (!session) return;
          row.classList.toggle('is-running', this.isSessionRunning(session));
          const state = this.renderSessionRowState(session, row.ownerDocument || document);
          const current = row.querySelector('.session-row-meta');
          if (current) current.replaceWith(state);
          else row.appendChild(state);
          const updated = row.querySelector('.session-row-updated');
          if (updated) {
            updated.textContent = this.formatSessionTime(session.updatedAt);
            updated.hidden = state.className.includes('session-row-time');
          }
        });
      });
    },

    createSessionRow(container, session, options = {}) {
      if (!container || !session) return null;
      const ownerDocument = container.ownerDocument || document;
      const row = this.createElement(ownerDocument, 'button', 'session-row');
      const isActive = session.id === this._activeSessionId && this._sessionView !== 'home';
      const isRunning = this.isSessionRunning(session);
      row.type = 'button';
      row.dataset.sessionId = session.id;
      row.classList.toggle('is-active', isActive);
      row.classList.toggle('is-running', isRunning);
      row.setAttribute('role', 'option');
      row.setAttribute('aria-selected', String(isActive));
      if (options.showTitleTooltip !== false) row.title = session.title;
      row.appendChild(this.createElement(ownerDocument, 'span', 'session-row-title', session.title));
      const state = this.renderSessionRowState(session, ownerDocument);
      const updated = this.createElement(ownerDocument, 'span', 'session-row-updated session-row-time', this.formatSessionTime(session.updatedAt));
      updated.hidden = state.className.includes('session-row-time');
      row.appendChild(updated);
      row.appendChild(state);
      row.addEventListener('click', () => this.requestSessionSwitch(session.id));
      if (options.showArchiveAction) {
        const wrapper = this.createElement(ownerDocument, 'div', 'session-row-wrap');
        const archive = this.createElement(ownerDocument, 'button', 'session-row-archive');
        archive.type = 'button';
        archive.title = '归档';
        archive.setAttribute('aria-label', '归档会话');
        archive.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9M5 4h14a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1ZM10 13h4"/></svg>';
        archive.addEventListener('click', () => this.requestSessionLifecycle('archive', session.id));
        wrapper.appendChild(archive);
        wrapper.appendChild(row);
        container.appendChild(wrapper);
      } else container.appendChild(row);
      return row;
    },

    renderSessionRows(container, sessions, emptyLabel = '暂无会话', options = {}) {
      if (!container) return;
      this.clearElement(container);
      const ownerDocument = container.ownerDocument || document;
      if (!sessions.length) {
        const message = this._persistenceError || (!this._persistenceReady ? '正在加载本地聊天…' : emptyLabel);
        container.appendChild(this.createElement(ownerDocument, 'div', 'session-list-empty', message));
        return;
      }
      sessions.forEach((session) => this.createSessionRow(container, session, options));
    },

    renderSessionList(query = this.$.sessionSearchInput && this.$.sessionSearchInput.value || '') {
      const container = this.$.sessionList;
      if (!container || !this._sessions) return;
      const sessions = this.sortedSessions().filter((session) => this.sessionMatchesQuery(session, query));
      this.renderSessionRows(container, sessions, query.trim() ? '未找到会话' : '暂无会话');
    },

    showSessionHistory() {
      if (!this.$.sessionHistory || this._sessionView !== 'conversation' || !this.activeSession()) return;
      this.hideQueueContextMenu();
      this.hideSessionMoreMenu();
      this.renderSessionList();
      this.$.sessionHistory.hidden = false;
      if (this.$.sessionTitleButton) this.$.sessionTitleButton.setAttribute('aria-expanded', 'true');
      const schedule = typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : (callback) => setTimeout(callback, 0);
      schedule(() => this.$.sessionSearchInput && this.$.sessionSearchInput.focus());
    },

    hideSessionHistory() {
      if (this.$.sessionHistory) this.$.sessionHistory.hidden = true;
      if (this.$.sessionTitleButton) this.$.sessionTitleButton.setAttribute('aria-expanded', 'false');
      if (this.$.sessionSearchInput) this.$.sessionSearchInput.value = '';
    },

    toggleSessionHistory() {
      if (!this.$.sessionHistory || this.$.sessionHistory.hidden) this.showSessionHistory();
      else this.hideSessionHistory();
    },

    toggleTitleSessionSwitcher() {
      if (this._sessionView !== 'conversation' || !this.activeSession()) return;
      this.toggleSessionHistory();
    },

    showSessionMoreMenu() {
      if (!this.activeSession() || !this.$.sessionMoreMenu) return;
      this.hideSessionHistory();
      this.$.sessionMoreMenu.hidden = false;
      if (this.$.continueSessionButton) this.$.continueSessionButton.disabled = false;
      if (this.$.sessionMoreButton) this.$.sessionMoreButton.setAttribute('aria-expanded', 'true');
    },

    hideSessionMoreMenu() {
      if (this.$.sessionMoreMenu) this.$.sessionMoreMenu.hidden = true;
      if (this.$.sessionMoreButton) this.$.sessionMoreButton.setAttribute('aria-expanded', 'false');
      this._deleteSessionConfirmId = '';
      if (this.$.deleteSessionLabel) this.$.deleteSessionLabel.textContent = '删除';
    },

    requestDeleteSession() {
      const session = this.activeSession();
      if (!session || this._sessionLifecyclePending) return false;
      if (this._deleteSessionConfirmId !== session.id) {
        this._deleteSessionConfirmId = session.id;
        if (this.$.deleteSessionLabel) this.$.deleteSessionLabel.textContent = '确认删除';
        return false;
      }
      return this.requestSessionLifecycle('delete');
    },

    async requestSessionLifecycle(action, sessionId = this._activeSessionId) {
      const session = this._sessions?.get(sessionId);
      if (!session || session.archivedAt || this._panelClosing || this._sessionLifecyclePending) return false;
      this.hideSessionMoreMenu();
      const queue = this.sessionQueueState(session.id);
      if (this._pinModeActive || this._continuationOperation || this.isSessionRunning(session)
        || queue?.drainInProgress || queue?.steerInProgressId || this._attachmentSelectPending
        || this._attachmentIngestStates?.some((state) => state.sessionId === session.id && state.state === 'pending')) {
        this.showComposerToast('会话正在处理任务，请完成后再操作。');
        return false;
      }
      if (!this._persistenceReady) { this.showComposerToast('聊天历史暂时无法更改，请先重新加载。'); return false; }
      if (this._sessionView === 'conversation') this.saveVisibleDraft(true);
      this._sessionLifecyclePending = session.id;
      try {
        const saved = await Editor.Message.request(EXTENSION_NAME, 'save-session', {
          record: sessionDocument(session, queue), immediate: true,
        });
        if (!saved?.saved) throw new Error('Session save failed.');
        const result = await Editor.Message.request(EXTENSION_NAME, 'update-session-lifecycle', { sessionId: session.id, action });
        if (this._panelClosing) return false;
        if (!result?.accepted) { this.showComposerToast(result?.message || '暂时无法更改会话。'); return false; }
        this.applySessionLifecycle(result);
        this.showComposerToast(result.message || (action === 'archive' ? '已归档' : '已删除'));
        return true;
      } catch (_) {
        if (!this._panelClosing) this.showComposerToast('暂时无法更改会话，请检查本地存储。');
        return false;
      } finally { this._sessionLifecyclePending = ''; }
    },

    applySessionLifecycle(result = {}) {
      if (this._panelClosing || !result.accepted) return;
      if (result.projectKey && this._localSessionProjectKey && result.projectKey !== this._localSessionProjectKey) return;
      if (!this._sessionLifecycleUpdates) this._sessionLifecycleUpdates = new Map();
      this._sessionLifecycleUpdates.set(result.sessionId, result);
      const session = this._sessions?.get(result.sessionId);
      if (!session) return;
      if (result.action === 'delete') {
        const queue = this._sessionQueues?.get(session.id);
        if (queue?.drainTimer != null) clearTimeout(queue.drainTimer);
        this._sessionQueues?.delete(session.id);
        this._taskSessionIds?.forEach((id, taskId) => { if (id === session.id) this._taskSessionIds.delete(taskId); });
        this._sessions.delete(session.id);
      } else session.archivedAt = result.archivedAt || 0;
      const leaveConversation = result.action !== 'unarchive' && this._activeSessionId === session.id && this._sessionView === 'conversation';
      if (result.action !== 'unarchive' && this._activeSessionId === session.id) {
        this._activeSessionId = '';
        this._codexSessionId = '';
        this._codexThreadId = '';
        this._codexTurns = new Map();
        if (leaveConversation) {
          if (this._pinModeActive) this.cancelPinMode();
          this.restoreComposerDraft(this._homeDraft || {});
          this.showChatsHome({ focusComposer: false });
        } else this.updateSessionHeader();
      }
      if (!leaveConversation) {
        if (this._sessionView === 'home') this.renderChatsHome();
        if (this._sessionView === 'all') this.renderAllSessionsView();
      }
      if (this.$.sessionHistory && !this.$.sessionHistory.hidden) this.renderSessionList();
    },

    toggleSessionMoreMenu() {
      if (!this.$.sessionMoreMenu || this.$.sessionMoreMenu.hidden) this.showSessionMoreMenu();
      else this.hideSessionMoreMenu();
    },

    async requestContinueSession() {
      if (this._panelClosing) return false;
      const source = this.activeSession();
      this.hideSessionMoreMenu();
      if (!source) {
        console.debug('[AI Copilot][Continuation] rejected reason=source-missing');
        this.showComposerToast('无法创建新会话，原会话未受影响', { kind: 'error' });
        return false;
      }
      if (this._continuationOperation) {
        console.debug(`[AI Copilot][Continuation] rejected reason=in-flight session=${source.id}`);
        this.showComposerToast('正在整理工作上下文…', { kind: 'progress', operationId: this._continuationOperation });
        return false;
      }
      const liveExecution = Boolean(this._activeExecutionSessionId || this._activeCodexTaskId
        || this._codexTaskRunning || this._codexStopPending);
      if (liveExecution) {
        console.debug(`[AI Copilot][Continuation] rejected reason=running session=${source.id}`);
        this.showComposerToast('当前任务运行中，完成后再继续到新会话');
        return false;
      }
      const queue = this.sessionQueueState(source.id);
      if (queue?.queuedMessages?.length) {
        console.debug(`[AI Copilot][Continuation] rejected reason=queue session=${source.id}`);
        this.showComposerToast('当前会话还有排队消息，请先处理后再继续');
        return false;
      }
      const operationId = this.createSessionId();
      const record = sessionDocument(source, queue);
      this._continuationOperation = operationId;
      console.debug(`[AI Copilot][Continuation] requested session=${source.id}`);
      this.showComposerToast('正在整理工作上下文…', { kind: 'progress', operationId });
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'continue-session', {
          sourceSessionId: source.id, record, snapshotAt: Date.now(), operationId,
        });
        if (this._panelClosing || this._continuationOperation !== operationId) return;
        if (result?.reason === 'busy') {
          this.showComposerToast('当前任务运行中，完成后再继续到新会话', { operationId });
          return false;
        }
        if (result?.reason === 'queue') {
          this.showComposerToast('当前会话还有排队消息，请先处理后再继续', { operationId });
          return false;
        }
        if (!result?.record || result.operationId !== operationId) throw new Error('Continuation failed.');
        const session = this.createSession({ ...result.record, restored: true });
        this.activateSession(session.id);
        console.debug(`[AI Copilot Continuation] navigated session=${session.id} at=${Date.now()}`);
        this.showComposerToast('已在新会话中继续', { kind: 'success', operationId });
        return true;
      } catch (error) {
        console.debug(`[AI Copilot][Continuation] rejected reason=request-failed session=${source.id} error=${error.message}`);
        if (!this._panelClosing && this._continuationOperation === operationId) {
          this.showComposerToast('无法创建新会话，原会话未受影响', { kind: 'error', operationId });
        }
        return false;
      } finally {
        if (this._continuationOperation === operationId) this._continuationOperation = null;
      }
    },

    openRenameSessionDialog() {
      const session = this.activeSession();
      if (!session || !this.$.renameSessionDialog) return;
      this.hideSessionMoreMenu();
      this.$.renameSessionInput.value = session.title;
      this.$.renameSessionSave.disabled = !session.title.trim();
      this.$.renameSessionDialog.hidden = false;
      const schedule = typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : (callback) => setTimeout(callback, 0);
      schedule(() => {
        this.$.renameSessionInput.focus();
        this.$.renameSessionInput.select();
      });
    },

    closeRenameSessionDialog() {
      if (this.$.renameSessionDialog) this.$.renameSessionDialog.hidden = true;
    },

    saveRenamedSession() {
      const session = this.activeSession();
      const title = String(this.$.renameSessionInput && this.$.renameSessionInput.value || '').trim();
      if (!session || !title) {
        if (this.$.renameSessionInput) this.$.renameSessionInput.focus();
        return false;
      }
      session.title = title.slice(0, 80);
      this.touchSession(session);
      this.updateSessionHeader();
      this.closeRenameSessionDialog();
      return true;
    },

    canLeaveActiveSession(action) {
      if (this._pinModeActive) {
        this.showComposerToast('请先确认或取消钉子模式');
        return false;
      }
      return true;
    },

    canNavigateToSession(targetSessionId) {
      if (this._pinModeActive) {
        this.showComposerToast('请先确认或取消钉子模式');
        return false;
      }
      return true;
    },

    requestNewSession() {
      if (!this.canLeaveActiveSession('new')) return null;
      this._newSessionPermissionModeId = null;
      this.closePermissionMenu();
      const session = this.createSession();
      this.activateSession(session.id);
      if (this.$.composerInput) this.$.composerInput.focus();
      return session;
    },

    requestConversationBack() {
      if (!this.canLeaveActiveSession('back')) return false;
      this._newSessionPermissionModeId = null;
      this.closePermissionMenu();
      this.showChatsHome({ focusComposer: false });
      return true;
    },

    requestSessionSwitch(sessionId) {
      const normalizedSessionId = String(sessionId || '');
      if (!this._sessions.has(normalizedSessionId)) return false;
      if (!this.canNavigateToSession(normalizedSessionId)) return false;
      if (!this.canLeaveActiveSession('switch')) return false;
      return this.activateSession(normalizedSessionId);
    },

    disconnectPromptObservers() {
      if (!this._promptObservers) return;
      this._promptObservers.forEach((observer) => observer.disconnect());
      this._promptObservers.clear();
    },

    renderActiveSessionConversation() {
      this.closePinPopover();
      const session = this.activeSession();
      if (!session || !this.$.activityContent) return;
      this.disconnectPromptObservers();
      if (this._sessions) {
        this._sessions.forEach((item) => item.messages.forEach((turn) => { turn.ui = null; }));
      }
      this.clearElement(this.$.activityContent);
      if (!session.messages.length) {
        this.$.emptyState.hidden = false;
        this.$.activityContent.appendChild(this.$.emptyState);
      } else {
        this.$.emptyState.hidden = true;
        session.messages.forEach((turn) => this.mountTurn(turn));
      }
    },

    renderChatsHome() {
      this.closePinPopover();
      this.renderApprovalTray();
      const container = this.$.activityContent;
      if (!container) return;
      this.disconnectPromptObservers();
      if (this._sessions) {
        this._sessions.forEach((item) => item.messages.forEach((turn) => { turn.ui = null; }));
      }
      this.clearElement(container);
      const ownerDocument = container.ownerDocument || document;
      const page = this.createElement(ownerDocument, 'section', 'sessions-page chats-home');
      const sessions = this.sortedSessions();
      const recentList = this.createElement(ownerDocument, 'div', 'home-session-list');
      recentList.setAttribute('role', 'listbox');
      this.renderSessionRows(
        recentList,
        sessions.slice(0, 3),
        '还没有会话',
        { showTitleTooltip: false, showArchiveAction: true }
      );
      page.appendChild(recentList);
      if (sessions.length > 3) {
        const viewAll = this.createElement(ownerDocument, 'button', 'home-view-all', `查看全部（${sessions.length} 个）`);
        viewAll.type = 'button';
        viewAll.addEventListener('click', () => this.showAllSessions());
        page.appendChild(viewAll);
      }
      const ambient = this.createElement(ownerDocument, 'div', 'home-ambient');
      ambient.setAttribute('aria-hidden', 'true');
      ambient.innerHTML = '<svg viewBox="0 0 32 32"><path d="M8 9.5h16a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3h-7l-4.5 3v-3H8a3 3 0 0 1-3-3v-7a3 3 0 0 1 3-3Z"></path><path d="M11 15h10M11 18.5h6"></path></svg>';
      page.appendChild(ambient);
      container.appendChild(page);
    },

    renderAllSessionsView(query = this._allSessionsQuery || '') {
      this.closePinPopover();
      this.renderApprovalTray();
      const container = this.$.activityContent;
      if (!container) return;
      this.disconnectPromptObservers();
      if (this._sessions) {
        this._sessions.forEach((item) => item.messages.forEach((turn) => { turn.ui = null; }));
      }
      this.clearElement(container);
      const ownerDocument = container.ownerDocument || document;
      const page = this.createElement(ownerDocument, 'section', 'sessions-page all-sessions-page');
      const searchWrap = this.createElement(ownerDocument, 'div', 'all-sessions-search-wrap');
      const search = this.createElement(ownerDocument, 'input', 'all-sessions-search');
      search.type = 'search';
      search.placeholder = '搜索最近聊天';
      search.setAttribute('aria-label', '搜索全部会话');
      search.value = query;
      search.addEventListener('input', () => {
        this._allSessionsQuery = search.value;
        const filtered = this.sortedSessions().filter((session) => this.sessionMatchesQuery(session, search.value));
        this.renderSessionRows(list, filtered, search.value.trim() ? '未找到会话' : '暂无会话', { showArchiveAction: true });
      });
      searchWrap.appendChild(search);
      page.appendChild(searchWrap);
      page.appendChild(this.createElement(ownerDocument, 'div', 'all-sessions-label', '本地聊天'));
      const list = this.createElement(ownerDocument, 'div', 'all-sessions-list');
      list.setAttribute('role', 'listbox');
      const filtered = this.sortedSessions().filter((session) => this.sessionMatchesQuery(session, query));
      this.renderSessionRows(list, filtered, query.trim() ? '未找到会话' : '暂无会话', { showArchiveAction: true });
      page.appendChild(list);
      container.appendChild(page);
      const schedule = typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : (callback) => setTimeout(callback, 0);
      schedule(() => search.focus());
    },

    notifyChangesSessionNavigation(sessionId = '') {
      if (!global.Editor?.Message || typeof Editor.Message.request !== 'function') return;
      Promise.resolve(Editor.Message.request(EXTENSION_NAME, 'changes-session-navigated', {
        sessionId: String(sessionId || ''),
      })).catch(() => {});
    },

    showChatsHome(options = {}) {
      if (this._pinModeActive) return false;
      this._contentSource = null; this._imageImportBox?.remove(); this._imageImportBox = null;
      this.saveVisibleDraft(true);
      this.closePermissionMenu();
      this.resetAttachmentThumbnailUrls();
      this._sessionView = 'home';
      this.notifyChangesSessionNavigation('');
      this.restoreComposerDraft(this._homeDraft || {});
      this._allSessionsQuery = '';
      this.hideSessionHistory();
      this.hideSessionMoreMenu();
      this.updateSessionHeader();
      this.updateModelButton();
      this.renderChatsHome();
      if (this.$.queueArea) this.$.queueArea.hidden = true;
      if (this.$.queueItems) this.clearElement(this.$.queueItems);
      this._followLatestOutput = true;
      this.scrollActivityToEnd({ force: true });
      if (options.focusComposer && this.$.composerInput) this.$.composerInput.focus();
      return true;
    },

    showAllSessions() {
      if (!this.canLeaveActiveSession('browse')) return false;
      this.saveVisibleDraft(true);
      this.closePermissionMenu();
      this.resetAttachmentThumbnailUrls();
      this._sessionView = 'all';
      this.notifyChangesSessionNavigation('');
      this._allSessionsQuery = '';
      this.hideSessionHistory();
      this.hideSessionMoreMenu();
      this.updateSessionHeader();
      this.updateModelButton();
      this.renderAllSessionsView();
      return true;
    },

    activateSession(sessionId) {
      const session = this._sessions && this._sessions.get(String(sessionId || ''));
      if (!session || session.archivedAt) return false;
      this.saveVisibleDraft(true);
      this.closePermissionMenu();
      if (this._sessionView !== 'conversation' || this._activeSessionId !== session.id) {
        this.resetAttachmentThumbnailUrls();
      }
      this.bindActiveSession(session);
      this._sessionView = 'conversation';
      this.notifyChangesSessionNavigation(session.id);
      this.updateSessionHeader();
      this.updateModelButton();
      this.renderActiveSessionConversation();
      this.renderApprovalTray();
      this.renderQueueArea(session.id);
      this.restoreComposerDraft(session.draft);
      this.hideSessionHistory();
      this.hideSessionMoreMenu();
      this._followLatestOutput = true;
      this.scrollActivityToEnd({ force: true });
      const queue = this.sessionQueueState(session.id);
      if (
        queue
        && !queue.paused
        && this.pendingQueueMessages(queue).length
        && !this._codexTaskRunning
        && !this._activeCodexTaskId
      ) this.scheduleQueueDrain(session.id);
      this.refreshImportedArtifacts(session);
      if (session.restored) this.ensureSessionRestored(session);
      return true;
    },

    statusPresentation(status) {
      const presentations = {
        'waiting-for-approval': { symbol: '◇', className: 'status-waiting', label: '等待确认' },
        approved: { symbol: '✓', className: 'status-approved', label: '已允许' },
        denied: { symbol: '—', className: 'status-denied', label: '已拒绝' },
        cancelled: { symbol: '—', className: 'status-cancelled', label: '已取消' },
        expired: { symbol: '—', className: 'status-cancelled', label: '已过期' },
        success: { symbol: '✓', className: 'status-success', label: 'Success' },
        completed: { symbol: '✓', className: 'status-success', label: 'Success' },
        running: { symbol: '→', className: 'status-running', label: 'Running' },
        failed: { symbol: '×', className: 'status-failed', label: 'Failed' },
        blocked: { symbol: '×', className: 'status-warning', label: 'Blocked' },
        warning: { symbol: '⚠', className: 'status-warning', label: 'Warning' },
        manual: { symbol: '⚠', className: 'status-manual', label: 'Manual Check' },
        pending: { symbol: '○', className: 'status-pending', label: 'Pending' },
      };
      return presentations[status] || presentations.pending;
    },

    disclosureChevronSvg(expanded) {
      const path = expanded ? 'm3.75 5.75 4.25 4 4.25-4' : 'm5.75 3.75 4 4.25-4 4.25';
      return `<svg viewBox="0 0 16 16" aria-hidden="true"><path d="${path}"></path></svg>`;
    },

    appendInlineMarkdown(container, text) {
      const ownerDocument = container.ownerDocument || document;
      tokenizeInlineMarkdown(text).forEach((token) => {
        if (token.type === 'code') {
          container.appendChild(this.createElement(ownerDocument, 'code', 'inline-code', token.text));
        } else if (token.type === 'strong') {
          container.appendChild(this.createElement(ownerDocument, 'strong', 'inline-strong', token.text));
        } else if (token.type === 'reference') {
          const reference = this.createElement(ownerDocument, 'span', 'inline-reference', token.text);
          reference.title = '相关文件';
          container.appendChild(reference);
        } else container.appendChild(ownerDocument.createTextNode(token.text));
      });
    },

    renderTextSegment(container, text) {
      const ownerDocument = container.ownerDocument || document;
      const lines = String(text || '').split(/\r?\n/);
      let index = 0;
      while (index < lines.length) {
        if (!lines[index].trim()) {
          index += 1;
          continue;
        }
        const unordered = /^\s*[-*]\s+/.test(lines[index]);
        const ordered = /^\s*\d+[.)]\s+/.test(lines[index]);
        if (unordered || ordered) {
          const list = this.createElement(ownerDocument, ordered ? 'ol' : 'ul', 'markdown-list');
          while (index < lines.length) {
            const pattern = ordered ? /^\s*\d+[.)]\s+(.*)$/ : /^\s*[-*]\s+(.*)$/;
            const match = lines[index].match(pattern);
            if (!match) break;
            const item = this.createElement(ownerDocument, 'li');
            this.appendInlineMarkdown(item, match[1]);
            list.appendChild(item);
            index += 1;
          }
          container.appendChild(list);
          continue;
        }

        const paragraphLines = [];
        while (index < lines.length && lines[index].trim()) {
          if (/^\s*[-*]\s+/.test(lines[index]) || /^\s*\d+[.)]\s+/.test(lines[index])) break;
          paragraphLines.push(lines[index]);
          index += 1;
        }
        const paragraph = this.createElement(ownerDocument, 'p', 'markdown-paragraph');
        paragraphLines.forEach((line, lineIndex) => {
          if (lineIndex) paragraph.appendChild(ownerDocument.createElement('br'));
          this.appendInlineMarkdown(paragraph, line.replace(/^#{1,6}\s+/, ''));
        });
        container.appendChild(paragraph);
      }
    },

    renderMarkdown(container, text) {
      this.clearElement(container);
      const ownerDocument = container.ownerDocument || document;
      String(text || '').split(/```/).forEach((part, index) => {
        if (!part) return;
        if (index % 2 === 1) {
          const lines = part.replace(/^\r?\n/, '').split(/\r?\n/);
          if (lines.length > 1 && /^[\w.+-]+$/.test(lines[0].trim())) lines.shift();
          const pre = this.createElement(ownerDocument, 'pre', 'code-block');
          pre.appendChild(this.createElement(ownerDocument, 'code', '', lines.join('\n').replace(/\s+$/, '')));
          container.appendChild(pre);
        } else {
          this.renderTextSegment(container, part);
        }
      });
    },

    hasTextSelectionWithin(element) {
      if (!element) return false;
      const ownerDocument = element.ownerDocument || document;
      const ownerWindow = ownerDocument.defaultView;
      const selection = ownerWindow && typeof ownerWindow.getSelection === 'function'
        ? ownerWindow.getSelection()
        : null;
      if (!selection || selection.isCollapsed || !String(selection).trim()) return false;
      if (element.contains(selection.anchorNode) || element.contains(selection.focusNode)) return true;
      for (let index = 0; index < selection.rangeCount; index += 1) {
        try {
          if (selection.getRangeAt(index).intersectsNode(element)) return true;
        } catch (error) {
          // Ignore stale selection ranges while the Activity DOM is re-rendering.
        }
      }
      return false;
    },

    setAssistantCopyState(button, state) {
      if (!button) return;
      if (button._copyResetTimer) clearTimeout(button._copyResetTimer);
      button.classList.toggle('is-copied', state === 'copied');
      button.classList.toggle('is-failed', state === 'failed');
      const feedback = button.querySelector('.assistant-copy-feedback');
      if (feedback) feedback.textContent = state === 'failed' ? '!' : '✓';
      const idleLabel = button.dataset.copyLabel || '复制回复';
      button.title = state === 'failed' ? '复制失败' : state === 'copied' ? '已复制' : idleLabel;
      button.setAttribute('aria-label', button.title);
      if (state === 'idle') return;
      button._copyResetTimer = setTimeout(() => {
        button._copyResetTimer = null;
        this.setAssistantCopyState(button, 'idle');
      }, 1200);
    },

    async copyAssistantMessage(text, button) {
      const value = String(text || '');
      if (!value) return;
      let copied = await this.writeComposerClipboardText(value);
      try {
        if (!copied) {
          const ownerDocument = (button && button.ownerDocument) || document;
          const helper = ownerDocument.createElement('textarea');
          helper.value = value;
          helper.style.position = 'fixed';
          helper.style.opacity = '0';
          ownerDocument.body.appendChild(helper);
          helper.select();
          copied = Boolean(ownerDocument.execCommand('copy'));
          helper.remove();
        }
      } catch (error) {
        console.warn(`[AI Copilot] Unable to copy text: ${error.message}`);
        copied = false;
      }
      this.setAssistantCopyState(button, copied ? 'copied' : 'failed');
    },

    createAssistantCopyButton(ownerDocument, text, label = '复制回复') {
      const button = this.createElement(ownerDocument, 'button', 'assistant-copy-button');
      button.type = 'button';
      button.dataset.copyLabel = String(label || '复制回复');
      button.title = button.dataset.copyLabel;
      button.setAttribute('aria-label', button.dataset.copyLabel);
      button.innerHTML = [
        '<svg viewBox="0 0 16 16" aria-hidden="true">',
        '<rect x="5.25" y="2.75" width="7.5" height="8.5" rx="1.25"></rect>',
        '<path d="M3.25 5.25H3A1.25 1.25 0 0 0 1.75 6.5V12A1.25 1.25 0 0 0 3 13.25h5.5A1.25 1.25 0 0 0 9.75 12v-.25"></path>',
        '</svg>',
        '<span class="assistant-copy-feedback" aria-hidden="true">✓</span>',
      ].join('');
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        this.copyAssistantMessage(text, button);
      });
      return button;
    },

    appendUserMessageActions(article, text, timestamp) {
      if (!article) return null;
      const ownerDocument = article.ownerDocument || document;
      const value = String(text || '');
      const formattedTime = this.formatTurnTimestamp(timestamp);
      if (!formattedTime && !value.trim()) return null;
      const actions = this.createElement(ownerDocument, 'div', 'user-message-actions');
      if (formattedTime) {
        const time = this.createElement(ownerDocument, 'time', 'user-message-time', formattedTime);
        time.dateTime = new Date(timestamp).toISOString();
        time.title = `消息发送于 ${formattedTime}`;
        actions.appendChild(time);
      }
      if (value.trim()) {
        const copyButton = this.createAssistantCopyButton(ownerDocument, value, '复制消息');
        copyButton.classList.add('user-message-copy-button');
        actions.appendChild(copyButton);
      }
      article.appendChild(actions);
      return actions;
    },

    assistantMessagePresentation(turn, message, finalMessageId = '') {
      const isFinal = Boolean(
        turn
        && turn.status !== 'running'
        && finalMessageId
        && String(message && message.id || '') === String(finalMessageId)
      );
      return {
        role: isFinal ? 'final' : 'progress',
        canCopy: isFinal && !message.synthetic,
      };
    },

    async saveAssistantArtifact(artifact, button) {
      if (!artifact || artifact.available === false || !artifact.id) return false;
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') return false;
      if (button) button.disabled = true;
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'save-artifact', {
          sessionId: artifact.sessionId,
          artifactId: artifact.id,
        });
        if (result?.saved) {
          this.showComposerToast('文件已保存', 1800);
          return true;
        }
        if (!result?.canceled) this.showComposerToast(result?.message || '无法保存文件', 2800);
        return false;
      } catch (error) {
        console.warn(`[AI Copilot] Unable to save artifact: ${error.message}`);
        this.showComposerToast('无法保存文件，请重试', 2800);
        return false;
      } finally {
        if (button) button.disabled = artifact.available === false;
      }
    },

    renderAssistantArtifacts(container, artifacts, options = {}) {
      const items = this.cloneArtifacts(artifacts);
      if (!items.length) return;
      const ownerDocument = container.ownerDocument || document;
      const list = this.createElement(ownerDocument, 'div', 'assistant-artifact-list');
      const relatedArtifacts = items.slice();
      const sessionIds = new Set(items.map(item => String(item.sessionId || '')).filter(Boolean));
      sessionIds.forEach((sessionId) => {
        const session = this._sessions?.get(sessionId);
        for (const turn of session?.turnsByTaskId?.values?.() || []) {
          for (const message of turn.assistantMessages || []) relatedArtifacts.push(...(message.artifacts || []));
        }
      });
      const resolveProjectUsage = createArtifactProjectUsageResolver(relatedArtifacts);
      const visibleItems=options.singleVersion?items:groupAudioArtifacts(items,relatedArtifacts);
      visibleItems.forEach((artifact) => {
        if(artifact.audioVersions?.length>1){
          const group=this.createElement(ownerDocument,'div','assistant-audio-group');
          const current=this.createElement(ownerDocument,'div');
          const picker=this.createElement(ownerDocument,'select','artifact-audio-versions');
          picker.setAttribute('aria-label','音频版本');
          const versions=artifact.audioVersions;
          versions.forEach((version,index)=>{
            const label=audioVersionLabel(version);
            const option=this.createElement(ownerDocument,'option','',`${label} · ${version.displayName} (${index+1}/${versions.length})`);
            option.value=version.id;picker.appendChild(option);
          });
          picker.value=artifact.id;
          let renderedId='';
          const renderVersion=()=>{if(renderedId)this.releaseAudioArtifactPlayer(renderedId);this.clearElement(current);const selected=versions.find(item=>item.id===picker.value)||artifact;renderedId=selected.id;this.renderAssistantArtifacts(current,[selected],{singleVersion:true});};
          picker.addEventListener('change',renderVersion);renderVersion();
          group.append(current,picker);list.appendChild(group);return;
        }
        const projectUsage = resolveProjectUsage(artifact);
        const projectTarget = projectUsage.target;
        const card = this.createElement(ownerDocument, 'div', 'assistant-artifact-card');
        card.classList.toggle('is-unavailable', artifact.available === false);
        card.innerHTML = [
          '<svg class="assistant-artifact-icon" viewBox="0 0 16 16" aria-hidden="true">',
          '<path d="M4 1.75h5l3 3v9.5H4a1 1 0 0 1-1-1V2.75a1 1 0 0 1 1-1Z"/>',
          '<path d="M9 1.75v3h3M5.5 8h4.75M5.5 10.5h4.75"/>',
          '</svg>',
        ].join('');
        const copy = this.createElement(ownerDocument, 'div', 'assistant-artifact-copy');
        const name = this.createElement(ownerDocument, 'div', 'assistant-artifact-name', artifact.source === 'generated' ? '生成的图片' : artifact.displayName);
        name.title = artifact.source === 'generated' ? '生成的图片' : String(artifact.displayName || '');
        copy.appendChild(name);
        const extension = String(artifact.extension || '').replace(/^\./u, '').toUpperCase() || 'FILE';
        const metaText = artifact.available === false
          ? '文件已不可用'
          : artifact.kind === 'image' ? [extension,artifact.width&&artifact.height?`${artifact.width} × ${artifact.height}`:'',Array.isArray(artifact.operationSummary)&&artifact.operationSummary.length?`${artifact.operationSummary.length} 项处理`:'',projectUsage.label].filter(Boolean).join(' · ')
            : artifact.source === 'generated' ? (artifact.projectImported ? '已导入项目' : '尚未导入项目') : [extension, this.formatFileSize(artifact.size)].filter(Boolean).join(' · ');
        copy.appendChild(this.createElement(ownerDocument, 'div', 'assistant-artifact-meta', metaText));
        card.appendChild(copy);
        if(artifact.kind==='audio'||/\.(wav|mp3|ogg)$/i.test(artifact.displayName)){
          card.classList.add('is-audio');card.replaceChildren();const head=this.createElement(ownerDocument,'div','artifact-audio-head');head.innerHTML='<svg class="assistant-artifact-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3v8.5a2 2 0 1 1-1-1.73V5l7-1.5v6a2 2 0 1 1-1-1.73V3.5Z"/></svg>';const title=this.createElement(ownerDocument,'div','assistant-artifact-name',artifact.displayName);head.append(title);card.append(head);const status=audioStatusView(artifact).label;const knownDuration=Number(artifact.duration)>0?this.formatAudioTime(artifact.duration):'--:--';const meta=this.createElement(ownerDocument,'div','artifact-audio-meta',`${String(artifact.format||artifact.extension||'audio').replace(/^\./,'').toUpperCase()} · ${knownDuration} · ${status}`);card.append(meta);const controls=this.createElement(ownerDocument,'div','artifact-audio-controls'),play=this.createElement(ownerDocument,'button'),loop=this.createElement(ownerDocument,'button','', '↻'),seek=this.createElement(ownerDocument,'input');play.innerHTML=this.audioPlaybackIcon(false);play.title='播放 / 暂停';play.setAttribute('aria-label','播放 / 暂停');loop.title='循环试听';loop.setAttribute('aria-label','循环试听');loop.setAttribute('aria-pressed','false');seek.type='range';seek.setAttribute('aria-label','播放进度');seek.min='0';seek.max='1';seek.step='.01';seek.value='0';const time=this.createElement(ownerDocument,'span','artifact-audio-time','00:00 / --:--');controls.append(play,loop,seek,time);card.append(controls);const actions=this.createElement(ownerDocument,'div','artifact-audio-actions'),edit=this.createElement(ownerDocument,'button','', '编辑'),importButton=this.createElement(ownerDocument,'button','',audioStatusView(artifact).action);edit.addEventListener('click',()=>this.openAudioWorkbench(artifact));importButton.disabled=artifact.projectImported&&!artifact.projectAssetUrl&&!artifact.projectAssetUuid;importButton.addEventListener('click',()=>artifact.projectImported?Editor.Message.request(EXTENSION_NAME,'locate-change-target',{assetUuid:artifact.projectAssetUuid,assetUrl:artifact.projectAssetUrl}):artifact.projectFileExists?this.refreshImportedArtifacts(this._sessions.get(artifact.sessionId),artifact.id):this.importAudioArtifact(artifact));actions.append(edit,importButton);card.append(actions);this.bindAudioArtifactCard(card,artifact,play,loop,seek,time,meta);list.appendChild(card);return;
        }
        if (/\.(png|jpe?g|webp)$/i.test(artifact.displayName)) {
          const thumbnail = this.createElement(ownerDocument, 'img', 'artifact-thumbnail');
          card.classList.add('is-image');
          thumbnail.alt = '图片预览'; thumbnail.title = projectUsage.label; thumbnail.addEventListener('click', () => this.openAssetPreview(artifact));
          card.insertBefore(thumbnail, card.firstChild); this.bindAttachmentThumbnail(card, thumbnail, artifact);
          const action = this.createElement(ownerDocument,'button','assistant-artifact-save',projectTarget ? '定位' : '导入');
          action.addEventListener('click',()=>projectTarget ? Editor.Message.request(EXTENSION_NAME,'locate-change-target',{assetUuid:projectTarget.projectAssetUuid,assetUrl:projectTarget.projectAssetUrl}) : this.importImageArtifact(artifact));
          card.appendChild(action);
          const edit = this.createElement(ownerDocument, 'button', 'assistant-artifact-save', '编辑');
          edit.disabled = artifact.available === false;
          edit.addEventListener('click', () => this.openAssetPreview(artifact));
          card.appendChild(edit);
        }
        const save = this.createElement(ownerDocument, 'button', 'assistant-artifact-save');
        save.type = 'button';
        save.title = artifact.available === false ? '文件已不可用' : `另存为 ${artifact.displayName}`;
        save.setAttribute('aria-label', save.title);
        save.disabled = artifact.available === false;
        save.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2v8m0 0 3-3m-3 3L5 7M3 13.25h10"/></svg>';
        save.addEventListener('click', () => this.saveAssistantArtifact(artifact, save));
        card.appendChild(save);
        if (card.classList.contains('is-image')) {
          const actions = this.createElement(ownerDocument,'div','artifact-image-actions');
          for (const child of Array.from(card.children)) if (String(child.tagName).toLowerCase() === 'button') actions.appendChild(child);
          card.appendChild(actions);
        }
        list.appendChild(card);
      });
      container.appendChild(list);
    },

    renderAssistantMessages(container, messages, completedAt, options = {}) {
      if (!options.append) this.clearElement(container);
      const ownerDocument = container.ownerDocument || document;
      const completedTime = this.formatTurnTimestamp(completedAt);
      messages.forEach((message) => {
        const presentation = options.turn
          ? this.assistantMessagePresentation(options.turn, message, options.finalMessageId)
          : { role: 'final', canCopy: !message.synthetic };
        const article = this.createElement(
          ownerDocument,
          'div',
          `assistant-message is-${presentation.role}`
        );
        article.dataset.messageRole = presentation.role;
        article.dataset.messageId = String(message.id || '');
        article.dataset.sessionId = String(options.turn?.sessionId || this._activeSessionId || '');
        const content = this.createElement(ownerDocument, 'div', 'assistant-message-content');
        this.renderMarkdown(content, message.text);
        article.appendChild(content);
        this.renderAssistantArtifacts(article, message.artifacts);
        if (presentation.canCopy) {
          const actions = this.createElement(ownerDocument, 'div', 'assistant-message-actions');
          actions.appendChild(this.createAssistantCopyButton(ownerDocument, message.text));
          if (completedTime) {
            const timestamp = this.createElement(
              ownerDocument,
              'time',
              'assistant-message-time',
              completedTime
            );
            timestamp.dateTime = new Date(completedAt).toISOString();
            timestamp.title = `消息完成于 ${completedTime}`;
            actions.appendChild(timestamp);
          }
          article.appendChild(actions);
        }
        container.appendChild(article);
      });
    },

    createUserMessage(turn, container) {
      const ownerDocument = container.ownerDocument || document;
      const article = this.createElement(ownerDocument, 'article', 'turn-user-message');
      const surface = this.createElement(ownerDocument, 'div', 'user-message-surface');
      const userText = String(turn.user && turn.user.text != null ? turn.user.text : turn.userMessage || '');
      const attachments = this.cloneTextAttachments(
        turn.user && turn.user.attachments || turn.attachments
      );
      const pins = this.clonePinnedContexts(turn.user && turn.user.pins || turn.pins);
      surface.classList.toggle('is-attachment-only', !userText.trim()
        && attachments.length > 0 && !pins.length);
      surface.classList.toggle('is-pin-only', !userText.trim() && !attachments.length && pins.length > 0);
      surface.classList.toggle('has-pins', pins.length > 0);
      surface.classList.toggle('has-text-pins', !!userText.trim() && pins.length > 0);
      let content = null;
      let toggle = null;
      let updatePromptToggle = null;
      if (userText.trim()) {
        content = this.createElement(ownerDocument, 'div', 'user-message-text', userText);
        toggle = this.createElement(ownerDocument, 'button', 'prompt-toggle');
        toggle.type = 'button';
        toggle.hidden = true;
        const toggleLabel = this.createElement(ownerDocument, 'span', 'prompt-toggle-label', '显示更多');
        const toggleIcon = this.createElement(ownerDocument, 'span', 'prompt-toggle-icon');
        toggleIcon.innerHTML = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5 6 7.5 9 4.5"/></svg>';
        toggle.appendChild(toggleLabel);
        toggle.appendChild(toggleIcon);
        updatePromptToggle = (expanded) => {
          toggleLabel.textContent = expanded ? '收起' : '显示更多';
          toggleIcon.classList.toggle('is-expanded', expanded);
          toggle.setAttribute('aria-expanded', String(expanded));
        };
        updatePromptToggle(false);
        article.dataset.expanded = 'false';
        article.dataset.hasOverflow = 'false';
        toggle.addEventListener('click', () => {
          if (article.dataset.hasOverflow !== 'true') return;
          const expanded = article.dataset.expanded !== 'true';
          article.dataset.expanded = String(expanded);
          content.classList.toggle('is-collapsed', !expanded);
          updatePromptToggle(expanded);
        });
        surface.appendChild(content);
        surface.appendChild(toggle);
      }
      if (attachments.length) {
        const attachmentList = this.createElement(ownerDocument, 'div', 'attachment-list turn-attachment-list');
        this.renderAttachmentList(attachmentList, attachments);
        surface.appendChild(attachmentList);
      }
      if (pins.length) {
        const indicator = this.createPinIndicator(ownerDocument, pins, 'turn-pin-indicator');
        if (indicator) surface.appendChild(indicator);
      }
      article.appendChild(surface);
      this.appendUserMessageActions(article, userText, turn.startedAt);
      container.appendChild(article);

      if (!content || !toggle) return;

      const refreshOverflow = () => {
        const expanded = article.dataset.expanded === 'true';
        content.classList.add('is-collapsed');
        const collapsedHeight = content.clientHeight;
        const fullHeight = content.scrollHeight;
        const hasOverflow = collapsedHeight > 0 && fullHeight > collapsedHeight + 1;

        article.dataset.hasOverflow = String(hasOverflow);
        toggle.hidden = !hasOverflow;
        if (!hasOverflow) {
          article.dataset.expanded = 'false';
          content.classList.remove('is-collapsed');
          updatePromptToggle(false);
          return;
        }

        content.classList.toggle('is-collapsed', !expanded);
        updatePromptToggle(expanded);
      };
      const schedule = typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : (callback) => setTimeout(callback, 0);
      schedule(refreshOverflow);
      if (typeof ResizeObserver === 'function') {
        let lastWidth = -1;
        const observer = new ResizeObserver((entries) => {
          const width = entries[0] && entries[0].contentRect ? entries[0].contentRect.width : 0;
          if (Math.abs(width - lastWidth) < 0.5) return;
          lastWidth = width;
          refreshOverflow();
        });
        observer.observe(surface);
        this._promptObservers.add(observer);
      }
      if (typeof MutationObserver === 'function') {
        const observer = new MutationObserver(() => schedule(refreshOverflow));
        observer.observe(content, { childList: true, characterData: true, subtree: true });
        this._promptObservers.add(observer);
      }
    },

    renderSteerFollowUp(container, followUp) {
      if (!followUp) return null;
      const ownerDocument = container.ownerDocument || document;
      const article = this.createElement(ownerDocument, 'article', 'turn-user-message steer-follow-up');
      const surface = this.createElement(ownerDocument, 'div', 'user-message-surface');
      const text = String(followUp.text || '');
      const attachments = this.cloneTextAttachments(followUp.attachments);
      const pins = this.clonePinnedContexts(followUp.pins);
      if (text.trim()) surface.appendChild(this.createElement(ownerDocument, 'div', 'user-message-text', text));
      if (attachments.length) {
        const list = this.createElement(ownerDocument, 'div', 'attachment-list turn-attachment-list');
        this.renderAttachmentList(list, attachments);
        surface.appendChild(list);
      }
      if (pins.length) {
        const indicator = this.createPinIndicator(ownerDocument, pins, 'turn-pin-indicator');
        if (indicator) surface.appendChild(indicator);
      }
      article.appendChild(surface);
      this.appendUserMessageActions(article, text, followUp.createdAt || followUp.steeredAt);
      container.appendChild(article);
      return article;
    },

    mountTurn(turn) {
      const ownerDocument = this.$.activityContent.ownerDocument || document;
      const root = this.createElement(ownerDocument, 'section', 'conversation-turn');
      root.dataset.taskId = turn.taskId;
      this.createUserMessage(turn, root);

      const assistant = this.createElement(ownerDocument, 'article', 'turn-assistant');
      const before = this.createElement(ownerDocument, 'div', 'assistant-block assistant-presentation turn-activity-history');
      const live = this.createElement(ownerDocument, 'div', 'live-state');
      const after = this.createElement(ownerDocument, 'div', 'assistant-block turn-final-answer');
      const changeCard = this.createElement(ownerDocument, 'section', 'turn-change-card');
      changeCard.hidden = true;
      const error = this.createElement(ownerDocument, 'div', 'turn-error');
      const duration = this.createElement(ownerDocument, 'button', 'duration-disclosure');
      duration.type = 'button';
      duration.hidden = true;
      assistant.appendChild(duration);
      assistant.appendChild(before);
      assistant.appendChild(after);
      assistant.appendChild(changeCard);
      assistant.appendChild(live);
      assistant.appendChild(error);
      root.appendChild(assistant);
      this.$.activityContent.appendChild(root);

      const viewState = turn.viewState || {
        expanded: new Map(),
        planExpanded: null,
        planUserToggled: false,
        changeExpanded: Boolean(turn.changeSet && !turn.restored),
      };
      turn.viewState = viewState;
      turn.ui = {
        root,
        before,
        live,
        after,
        changeCard,
        error,
        duration,
        expanded: viewState.expanded,
      };
      Object.defineProperties(turn.ui, {
        planExpanded: {
          get: () => viewState.planExpanded,
          set: (value) => { viewState.planExpanded = value == null ? null : Boolean(value); },
        },
        planUserToggled: {
          get: () => viewState.planUserToggled,
          set: (value) => { viewState.planUserToggled = Boolean(value); },
        },
        changeExpanded: {
          get: () => Boolean(viewState.changeExpanded),
          set: (value) => { viewState.changeExpanded = Boolean(value); },
        },
      });
      duration.addEventListener('click', () => {
        if (this.hasTextSelectionWithin(duration)) return;
        if (!this.hasTurnPresentationHistory(turn)) return;
        turn.historyExpanded = !turn.historyExpanded;
        this.updateTurnPresentationVisibility(turn);
        this.renderTurnMeta(turn);
      });
      this.renderTurn(turn);
      return root;
    },

    createTurn(taskId, userMessage, attachments = [], pins = [], executionPrompt = '', session = this.activeSession()) {
      if (!session) throw new Error('No active AI Copilot session.');
      session.messages.forEach((existing) => {
        if (!existing?.viewState) return;
        existing.viewState.changeExpanded = false;
        if (existing.ui) this.renderChangeCard(existing);
      });
      const userAttachments = this.cloneTextAttachments(attachments);
      const userPins = this.dedupePinnedContexts(pins);
      const turn = {
        turnId: taskId,
        taskId,
        sessionId: session.id,
        userMessage,
        attachments: userAttachments,
        pins: userPins,
        user: {
          text: String(userMessage || ''),
          attachments: this.cloneTextAttachments(userAttachments),
          pins: this.clonePinnedContexts(userPins),
        },
        executionPrompt: String(executionPrompt || userMessage || ''),
        assistantMessages: [],
        followUps: [],
        presentationSequence: 0,
        plan: null,
        liveState: { id: 'codex-connection', state: 'thinking', title: '正在连接 Codex', status: 'running' },
        activities: [],
        guardTraces: [],
        validation: [],
        startedAt: Date.now(),
        completedAt: null,
        status: 'running',
        historyExpanded: true,
        errorMessage: '',
        errorDetail: '',
        executionStarted: false,
        executionStatus: 'running',
        hasAgentText: false,
        viewState: {
          expanded: new Map(),
          planExpanded: null,
          planUserToggled: false,
          changeExpanded: false,
        },
        ui: null,
      };
      session.messages.push(turn);
      session.turnsByTaskId.set(taskId, turn);
      if (this._sessionView === 'conversation' && session.id === this._activeSessionId) {
        this.mountTurn(turn);
      }
      return turn;
    },

    upsertById(list, event) {
      const id = String(event.id || `${event.type}:${list.length}`);
      const index = list.findIndex((item) => String(item.id) === id);
      if (index === -1) list.push({ ...event, id });
      else list[index] = { ...list[index], ...event, id };
    },

    nextPresentationOrder(turn) {
      const existingCount = (turn.assistantMessages || []).length
        + (turn.followUps || []).length
        + (turn.activities || []).length
        + (turn.validation || []).length;
      const next = Number.isInteger(turn.presentationSequence) ? turn.presentationSequence : existingCount;
      turn.presentationSequence = next + 1;
      return next;
    },

    upsertTurnPresentationItem(turn, list, event) {
      const id = String(event.id || `${event.type}:${list.length}`);
      const existing = list.find((item) => String(item.id) === id);
      const presentationOrder = existing && Number.isFinite(existing.presentationOrder)
        ? existing.presentationOrder
        : this.nextPresentationOrder(turn);
      const activityPlanStep = existing ? existing.activityPlanStep || '' : (turn.plan?.steps || [])
        .find((step) => ['running', 'in_progress'].includes(step.status))?.title || '';
      this.upsertById(list, { ...event, id, presentationOrder,
        ...(['tool', 'command'].includes(event.type) ? { activityPlanStep } : {}),
      });
    },

    turnPresentationEntries(turn) {
      const messages = (turn.assistantMessages || []).map((item, index) => ({
        kind: 'message',
        item,
        index,
        order: Number(item.presentationOrder),
      }));
      const activities = (turn.activities || []).map((item, index) => ({
        kind: 'activity',
        item,
        index,
        order: Number(item.presentationOrder),
      }));
      const validations = (turn.validation || []).map((item, index) => ({
        kind: 'validation',
        item,
        index,
        order: Number(item.presentationOrder),
      }));
      const anchors = (turn.followUps || []).map((item, index) => ({
        kind: 'anchor',
        item,
        index,
        order: Number(item.presentationOrder),
      }));
      const entries = messages.concat(activities, validations, anchors);
      if (entries.some((entry) => Number.isFinite(entry.order))) {
        const largest = entries.reduce((value, entry) => (
          Number.isFinite(entry.order) ? Math.max(value, entry.order) : value
        ), -1);
        let fallback = largest + 1;
        entries.forEach((entry) => {
          if (!Number.isFinite(entry.order)) entry.order = fallback++;
        });
        return entries.sort((left, right) => left.order - right.order);
      }

      // Compatibility for turns created before presentation ordering existed.
      const before = messages.filter((entry) => entry.item.phase !== 'after-work');
      const after = messages.filter((entry) => entry.item.phase === 'after-work');
      return before.concat(activities, validations, anchors, after).map((entry, index) => ({
        ...entry,
        order: index,
      }));
    },

    groupTurnActivities(turn) {
      const groups = [];
      let current = null;
      const finish = () => {
        if (!current) return;
        if (current.message || current.activities.length || current.validations.length) groups.push(current);
        current = null;
      };
      this.turnPresentationEntries(turn).forEach((entry) => {
        if (entry.item.type === 'runtime-status') {
          finish();
          groups.push({ key: `runtime:${entry.item.id}`, runtimeStatus: entry.item,
            message: null, activities: [], validations: [], order: entry.order });
          return;
        }
        if (entry.kind === 'anchor') {
          finish();
          groups.push({
            key: `anchor:${entry.item.id}`,
            anchor: entry.item,
            message: null,
            activities: [],
            validations: [],
            order: entry.order,
          });
          return;
        }
        if (entry.kind === 'message') {
          finish();
          current = {
            key: `message:${entry.item.id}`,
            message: entry.item,
            activities: [],
            validations: [],
            order: entry.order,
          };
          return;
        }
        if (!current) {
          current = {
            key: `activity:${entry.order}`,
            message: null,
            activities: [],
            validations: [],
            order: entry.order,
          };
        }
        if (entry.kind === 'validation') current.validations.push(entry.item);
        else current.activities.push(entry.item);
      });
      finish();
      return groups;
    },

    finalAssistantMessageId(turn) {
      if (!turn || turn.status === 'running') return '';
      const messages = this.turnPresentationEntries(turn)
        .filter((entry) => entry.kind === 'message')
        .map((entry) => entry.item);
      return messages.length ? String(messages[messages.length - 1].id || '') : '';
    },

    renderTurnMessages(turn) {
      this.renderTurnPresentation(turn);
    },

    hasRunningSpecificActivity(turn) {
      return turn.activities.some((activity) => (
        ((activity.type === 'tool' || activity.type === 'command') && activity.status === 'running')
        || (activity.type === 'approval' && activity.approvalState === 'pending')
      ));
    },

    renderLiveState(turn) {
      const container = turn.ui.live;
      this.clearElement(container);
      const state = turn.liveState;
      const hidden = turn.status !== 'running' || !state || this.hasRunningSpecificActivity(turn);
      container.hidden = hidden;
      if (hidden) return;
      const ownerDocument = container.ownerDocument || document;
      const labels = { thinking: '正在思考', typing: '正在回复', planning: '正在制定计划', exploring: '正在查找资料' };
      const label = state.id === 'stopping' ? '正在停止' : labels[state.state] || '正在处理当前任务';
      container.appendChild(this.createElement(ownerDocument, 'span', 'live-state-label', label));
      container.appendChild(this.createElement(ownerDocument, 'span', 'live-dots', '···'));
      container.title = state.state === 'warning' && state.title ? state.title : '';
    },

    ...createActivityMethods(EXTENSION_NAME),

    renderTurnPresentation,

    hasTurnPresentationHistory(turn) {
      const finalMessageId = this.finalAssistantMessageId(turn);
      if (turn.plan) return true;
      return this.groupTurnActivities(turn).some((group) => (
        Boolean(group.message && String(group.message.id || '') !== finalMessageId)
        || Boolean(group.runtimeStatus)
        || Boolean(this.activityGroupSummary(group))
      ));
    },

    updateTurnPresentationVisibility(turn) {
      const hasHistory = this.hasTurnPresentationHistory(turn);
      turn.ui.before.hidden = !hasHistory || !turn.historyExpanded;
      const hideCompletedProgress = turn.status !== 'running' && !turn.historyExpanded;
      (turn.ui.steerHistoryEntries || []).forEach((entry) => {
        entry.hidden = hideCompletedProgress;
      });
    },

    hasRealFileChange(activity) {
      return activity.type === 'file_change'
        && Array.isArray(activity.files)
        && activity.files.some((file) => file && file.path);
    },

    formatDuration(durationMs) {
      const totalSeconds = Math.max(0, Math.round(Number(durationMs || 0) / 1000));
      if (totalSeconds < 60) return `${totalSeconds} 秒`;
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      return seconds ? `${minutes} 分 ${seconds} 秒` : `${minutes} 分`;
    },

    formatTurnTimestamp(timestamp) {
      const value = Number(timestamp);
      if (!Number.isFinite(value) || value <= 0) return '';
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return '';
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${hours}:${minutes}`;
    },

    changeItemUndoAvailable(item) {
      return Boolean(item?.reversible && item.undoStatus !== 'restored'
        && (!item.availability || item.availability === 'afterStillPresent'));
    },

    unavailableChangeSetTitle(items) {
      if ((items || []).length && (items || []).every((item) => !item.reversible)) {
        return '仅查看 · 无法安全撤销';
      }
      const states = new Set((items || []).map((item) => item.availability).filter(Boolean));
      if (states.has('conflict')) return '存在冲突 · 无法安全撤销';
      if (states.has('unavailable')) return '当前状态暂时无法判断';
      if (states.has('expired')) return '撤销记录已过期';
      if (states.has('discarded')) return '已丢弃 · 无需撤销';
      if (states.has('alreadyReverted')) return '已恢复 · 无需撤销';
      return '';
    },

    changeCardNavigationTarget(domain, group, view) {
      if (!domain || !group || !view) return null;
      return {
        domain: String(domain.id || view.domain || ''),
        changeId: String(view.id || ''),
        anchorId: String(view.anchorId || ''),
        groupKey: String(group.key || ''),
        groupAnchorId: String(group.anchorId || ''),
      };
    },

    appendChangeCardTextStats(parent, additions, deletions) {
      parent.appendChild(this.createElement(parent.ownerDocument || document, 'span', 'diff-add', `+${Number(additions || 0)}`));
      parent.appendChild(this.createElement(parent.ownerDocument || document, 'span', 'diff-remove', `-${Number(deletions || 0)}`));
    },

    async openTurnChanges(turn, navigationTarget = null) {
      const changeSet = turn?.changeSet;
      if (!changeSet) return;
      try {
        const payload = {
          sessionId: turn.sessionId, taskId: turn.taskId, turnId: changeSet.turnId || turn.taskId,
        };
        if (navigationTarget) payload.navigationTarget = navigationTarget;
        const result = await Editor.Message.request(EXTENSION_NAME, 'open-changes', payload);
        if (result?.changeSet) {
          turn.changeSet = result.changeSet;
          if (turn.ui) this.renderChangeCard(turn);
          this.persistSession(turn.sessionId, true);
        }
      } catch (error) {
        this.showComposerToast('无法打开 Cocos Changes。');
      }
    },

    async undoTurnChanges(turn) {
      const changeSet = turn?.changeSet;
      if (!changeSet || turn.undoPending) return;
      turn.undoPending = true;
      if (turn.ui) this.renderChangeCard(turn);
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'undo-turn-changes', {
          sessionId: turn.sessionId, taskId: turn.taskId, turnId: changeSet.turnId || turn.taskId,
        });
        if (result?.changeSet) turn.changeSet = result.changeSet;
        if (!result?.accepted) this.showComposerToast(result?.message || '暂时无法撤销本轮更改。');
        else {
          const items = ['files', 'assets', 'scene', 'components']
            .flatMap((key) => turn.changeSet?.[key] || []);
          const outcomes = items.map((item) => projectUndoOutcome(item)).filter(Boolean);
          if (outcomes.length === 1) {
            this.showComposerToast([outcomes[0].title, ...outcomes[0].details].join(' · '), 4200);
          } else if (result.undo?.conflicts || result.undo?.irreversible || result.undo?.unavailable) {
            const unresolved = Number(result.undo.conflicts || 0) + Number(result.undo.irreversible || 0)
              + Number(result.undo.unavailable || 0);
            this.showComposerToast(`已撤销 ${result.undo.restored} 项，另有 ${unresolved} 项未撤销。`, 3600);
          } else if (result.undo?.restored) this.showComposerToast(`已撤销 ${result.undo.restored} 项。`);
        }
      } catch (_) {
        this.showComposerToast('撤销失败；项目内容没有被盲目覆盖。', 3600);
      } finally {
        turn.undoPending = false;
        if (turn.ui) this.renderChangeCard(turn);
        this.persistSession(turn.sessionId, true);
      }
    },

    renderChangeCard(turn) {
      const card = turn?.ui?.changeCard;
      const changeSet = turn?.changeSet;
      if (!card) return;
      this.clearElement(card);
      if (!changeSet) { card.hidden = true; return; }
      const ownerDocument = card.ownerDocument || document;
      const review = createReviewPresentation(changeSet, { includeDiffLines: false });
      const all = review.visibleDomains.flatMap(domain => domain.items.map(view => view.item));
      if (!all.length && !review.warnings.length) { card.hidden = true; return; }
      card.hidden = false;
      const head = this.createElement(ownerDocument, 'div', 'change-card-head');
      const toggle = this.createElement(ownerDocument, 'button', 'change-card-toggle');
      toggle.type = 'button';
      toggle.setAttribute('aria-expanded', String(Boolean(turn.ui.changeExpanded)));
      const icon = this.createElement(ownerDocument, 'span', 'change-card-icon');
      icon.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="2" width="19" height="20" rx="3.5"/><path d="M9 8.5h6M12 5.5v6M9.5 16.5h5"/></svg>';
      toggle.appendChild(icon);
      const copy = this.createElement(ownerDocument, 'span', 'change-card-copy');
      const pending = all.some((item) => this.changeItemUndoAvailable(item));
      const availabilityTitle = pending ? '' : this.unavailableChangeSetTitle(all);
      const title = !all.length ? '改动核对不完整' : projectUndoSummary(changeSet) || availabilityTitle || `${all.length} 项改动`;
      copy.appendChild(this.createElement(ownerDocument, 'span', 'change-card-title', title));
      if (review.hasTextDiff) {
        const stats = this.createElement(ownerDocument, 'span', 'change-card-stats');
        this.appendChangeCardTextStats(stats, review.textAdditions, review.textDeletions);
        copy.appendChild(stats);
      }
      toggle.appendChild(copy);
      const chevron = this.createElement(ownerDocument, 'span', 'change-card-chevron');
      chevron.innerHTML = this.disclosureChevronSvg(Boolean(turn.ui.changeExpanded));
      toggle.appendChild(chevron);
      toggle.addEventListener('click', () => {
        turn.ui.changeExpanded = !turn.ui.changeExpanded;
        this.renderChangeCard(turn);
      });
      head.appendChild(toggle);
      const undo = this.createElement(ownerDocument, 'button', 'change-card-undo', turn.undoPending ? '撤销中…' : '撤销');
      undo.type = 'button';
      undo.disabled = turn.undoPending || !pending || this._codexTaskRunning || Boolean(this._activeCodexTaskId);
      undo.title = pending ? '只撤销这一轮仍满足安全条件的更改' : '没有可安全撤销的更改';
      undo.addEventListener('click', () => this.undoTurnChanges(turn));
      head.appendChild(undo);
      card.appendChild(head);
      const body = this.createElement(ownerDocument, 'div', 'change-card-body');
      body.hidden = !turn.ui.changeExpanded;
      const details = this.createElement(ownerDocument, 'div', 'change-card-details change-details-surface');
      for (const warning of review.warnings) details.appendChild(this.createElement(ownerDocument, 'div', 'change-card-row-detail', warning));
      if (review.persistence) details.appendChild(this.createElement(ownerDocument, 'div', 'change-card-row-detail', review.persistence));
      review.compactDomains.forEach((domain) => {
        const group = this.createElement(ownerDocument, 'div', 'change-card-group');
        group.appendChild(this.createElement(ownerDocument, 'div', 'change-card-group-title', `${domain.label} · ${domain.changeCount}`));
        domain.groups.slice(0, review.maxCardGroups).forEach((presentationGroup) => {
          const presentationView = presentationGroup.items[0];
          const presentation = presentationGroup.compact;
          const canOpenViewer = Boolean(turn.sessionId && (changeSet.turnId || turn.taskId));
          const navigationTarget = this.changeCardNavigationTarget(domain, presentationGroup, presentationView);
          if (presentationGroup.items.length > 1) navigationTarget.anchorId = '';
          const row = this.createElement(ownerDocument, canOpenViewer ? 'button' : 'div',
            `change-card-row${canOpenViewer ? ' is-clickable' : ''}`);
          if (canOpenViewer) {
            row.type = 'button';
            row.title = '在 Cocos Changes 中查看';
            row.addEventListener('click', () => this.openTurnChanges(turn, navigationTarget));
          }
          const hasFileStats = presentation.textDiff === true;
          const undoStatus = presentation.status;
          if (undoStatus) row.classList.add('has-status');
          const rowCopy = this.createElement(ownerDocument, 'span', 'change-card-row-copy');
          const label = this.createElement(ownerDocument, 'span', 'change-card-row-label', presentation.label);
          label.title = presentationGroup.fullLabel;
          rowCopy.appendChild(label);
          for (const text of presentation.details) rowCopy.appendChild(this.createElement(ownerDocument, 'span', 'change-card-row-detail', text));
          if (hasFileStats) {
            const stats = this.createElement(ownerDocument, 'span', 'change-card-row-detail');
            this.appendChangeCardTextStats(stats, presentation.additions, presentation.deletions);
            rowCopy.appendChild(stats);
          }
          row.appendChild(rowCopy);
          if (undoStatus) row.appendChild(this.createElement(ownerDocument, 'span', 'change-card-row-state', undoStatus));
          group.appendChild(row);
        });
        if (domain.groups.length > review.maxCardGroups) {
          const remaining = domain.groups.slice(review.maxCardGroups);
          group.appendChild(this.createElement(ownerDocument, 'div', 'change-card-more', `另有 ${remaining.length} 个分组 · ${remaining.reduce((count, group) => count + group.changeCount, 0)} 项改动`));
        }
        details.appendChild(group);
      });
      body.appendChild(details);
      const footer = this.createElement(ownerDocument, 'div', 'change-card-footer');
      const view = this.createElement(ownerDocument, 'button', 'change-card-view', '查看更改 ↗');
      view.type = 'button';
      view.addEventListener('click', () => this.openTurnChanges(turn));
      footer.appendChild(view);
      body.appendChild(footer);
      card.appendChild(body);
    },

    renderTurnMeta(turn) {
      const button = turn && turn.ui && turn.ui.duration;
      if (!button) return;
      const end = turn.completedAt || Date.now();
      const duration = this.formatDuration(end - turn.startedAt);
      const waitingApprovalLabel = `等待确认 · ${duration}`;
      const stopping = turn.status === 'running'
        && turn.liveState
        && turn.liveState.id === 'stopping';
      const labels = {
        running: `工作中 · ${duration}`,
        completed: `已完成 · ${duration}`,
        failed: `执行失败 · ${duration}`,
        cancelled: `已停止 · ${duration}`,
      };
      const presentationStatus = stopping ? 'stopping' : (turn.executionStatus || turn.status);
      if (presentationStatus === 'waiting-for-approval') {
        labels.running = waitingApprovalLabel;
      }
      const expandable = this.hasTurnPresentationHistory(turn);
      button.hidden = false;
      button.disabled = !expandable;
      ['running', 'stopping', 'completed', 'failed', 'cancelled'].forEach((status) => {
        button.classList.toggle(`is-${status}`, presentationStatus === status);
      });
      button.classList.toggle('is-static', !expandable);
      button.setAttribute('aria-disabled', String(!expandable));
      button.setAttribute('aria-expanded', expandable ? String(turn.historyExpanded) : 'false');
      this.clearElement(button);
      button.appendChild(this.createElement(
        button.ownerDocument || document,
        'span',
        'turn-meta-label',
        stopping ? `正在停止 · ${duration}` : labels[presentationStatus] || `任务已结束 · ${duration}`
      ));
      const chevron = this.createElement(button.ownerDocument || document, 'span', 'turn-meta-chevron');
      if (expandable) chevron.innerHTML = this.disclosureChevronSvg(turn.historyExpanded);
      button.appendChild(chevron);
    },

    renderTurn(turn) {
      if (!turn || !turn.ui) return;
      this.renderTurnMessages(turn);
      this.renderLiveState(turn);
      this.renderChangeCard(turn);
      this.clearElement(turn.ui.error);
      if (turn.errorMessage) {
        turn.ui.error.appendChild(this.createElement(
          turn.ui.error.ownerDocument || document,
          'div',
          'turn-error-summary',
          turn.errorMessage
        ));
        if (turn.errorDetail && turn.errorDetail !== turn.errorMessage) {
          const details = this.createElement(turn.ui.error.ownerDocument || document, 'details');
          details.appendChild(this.createElement(turn.ui.error.ownerDocument || document, 'summary', '', '查看详情'));
          details.appendChild(this.createElement(turn.ui.error.ownerDocument || document, 'pre', '', turn.errorDetail));
          turn.ui.error.appendChild(details);
        }
      }
      this.renderTurnMeta(turn);
      this.updateTurnPresentationVisibility(turn);
      if (turn.sessionId === this._activeSessionId) this.renderApprovalTray();
    },

    activityDistanceFromBottom() {
      const scroller = this.$.activityScroller;
      if (!scroller) return 0;
      return Math.max(0, scroller.scrollHeight - scroller.clientHeight - scroller.scrollTop);
    },

    isActivityNearBottom() {
      return this.activityDistanceFromBottom() <= SCROLL_BOTTOM_THRESHOLD_PX;
    },

    updateScrollToLatestButton() {
      if (!this.$.scrollToLatestButton) return;
      const nearBottom = this.isActivityNearBottom();
      if (nearBottom) this._followLatestOutput = true;
      this.$.scrollToLatestButton.classList.toggle('is-running', this.isCurrentSessionExecuting());
      this.$.scrollToLatestButton.hidden = Boolean(
        nearBottom || this._followLatestOutput || this._scrollToLatestInProgress
      );
    },

    handleActivityScroll() {
      if (this._activePinPopover && this._activePinPopover.source !== 'composer') this.closePinPopover();
      if (this._scrollToLatestInProgress) {
        this.updateScrollToLatestButton();
        return;
      }
      this._followLatestOutput = this.isActivityNearBottom();
      this.updateScrollToLatestButton();
    },

    cancelScrollToLatestAnimation() {
      if (this._scrollToLatestAnimationFrame == null) return;
      if (typeof cancelAnimationFrame === 'function') {
        cancelAnimationFrame(this._scrollToLatestAnimationFrame);
      } else {
        clearTimeout(this._scrollToLatestAnimationFrame);
      }
      this._scrollToLatestAnimationFrame = null;
      this._scrollToLatestInProgress = false;
    },

    animateActivityToEnd() {
      const scroller = this.$.activityScroller;
      if (!scroller) return;
      this.cancelScrollToLatestAnimation();
      const startTop = scroller.scrollTop;
      const firstTarget = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
      if (Math.abs(firstTarget - startTop) <= 1) {
        scroller.scrollTop = firstTarget;
        this._followLatestOutput = true;
        this.updateScrollToLatestButton();
        return;
      }

      const schedule = typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : (callback) => setTimeout(() => callback(Date.now()), 16);
      const durationMs = 280;
      let startedAt = null;
      this._scrollToLatestInProgress = true;
      this._followLatestOutput = true;
      this.updateScrollToLatestButton();

      const step = (timestamp) => {
        if (startedAt == null) startedAt = timestamp;
        const progress = Math.min(1, Math.max(0, (timestamp - startedAt) / durationMs));
        const eased = 1 - ((1 - progress) ** 3);
        const targetTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
        scroller.scrollTop = startTop + ((targetTop - startTop) * eased);
        if (progress < 1) {
          this._scrollToLatestAnimationFrame = schedule(step);
          return;
        }
        scroller.scrollTop = targetTop;
        this._scrollToLatestAnimationFrame = null;
        this._scrollToLatestInProgress = false;
        this._followLatestOutput = true;
        this.updateScrollToLatestButton();
      };
      this._scrollToLatestAnimationFrame = schedule(step);
    },

    scrollActivityToEnd(options = {}) {
      const scroller = this.$.activityScroller;
      if (!scroller) return;
      const normalized = options === true ? { force: true } : options;
      const force = Boolean(normalized.force);
      const smooth = normalized.behavior === 'smooth';
      if (force) this._followLatestOutput = true;
      if (!this._followLatestOutput && !force) {
        this.updateScrollToLatestButton();
        return;
      }

      const targetTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
      if (smooth) {
        this.animateActivityToEnd();
      } else {
        this.cancelScrollToLatestAnimation();
        scroller.scrollTop = targetTop;
        this._followLatestOutput = true;
        this.updateScrollToLatestButton();
      }
    },

    hasComposerDraft() {
      return Boolean(
        String(this.$.composerInput && this.$.composerInput.value || '').trim()
        || (this._composerAttachments && this._composerAttachments.length)
        || (this._composerPins && this._composerPins.length)
      );
    },

    updateComposerActionState() {
      this.saveVisibleDraft();
      const hasDraft = this.hasComposerDraft();
      const executing = this.isCurrentSessionExecuting();
      const isPinMode = Boolean(this._pinModeActive);
      const queue = this.sessionQueueState();
      const editingQueuedMessage = Boolean(queue && queue.editingMessageId);
      if (this.$.composerInput) {
        this.$.composerInput.placeholder = editingQueuedMessage
          ? '编辑排队消息'
          : executing ? '提出后续变更要求' : '提出开发任务...';
      }
      const isStopAction = this._sessionView === 'conversation'
        && !isPinMode
        && executing && (this._codexStopPending || !hasDraft);
      const button = this.$.sendButton;
      if (!button) return;
      button.textContent = isStopAction ? '■' : '↑';
      button.classList.toggle('is-stop', isStopAction);
      button.classList.toggle('is-send-empty', !isStopAction && !hasDraft);
      button.classList.toggle('is-send-active', !isStopAction && hasDraft);
      const disabled = Boolean((executing && this._codexStopPending) || isPinMode);
      button.disabled = disabled;
      button.toggleAttribute('disabled', disabled);
      button.setAttribute('aria-disabled', String(disabled));
      const label = isPinMode ? '请先确认或取消钉子模式' : (isStopAction ? '停止' : '发送');
      button.setAttribute('title', label);
      button.setAttribute('aria-label', label);
    },

    hideComposerToast() {
      if (this._composerToastTimer) {
        clearTimeout(this._composerToastTimer);
        this._composerToastTimer = null;
      }
      if (this.$.composerToast) {
        this.$.composerToast.hidden = true;
        delete this.$.composerToast.dataset.kind;
        delete this.$.composerToast.dataset.operationId;
      }
    },

    showComposerToast(message, options = {}) {
      if (this._panelClosing) return;
      const toast = this.$.composerToast;
      if (!toast) return;
      const { kind = 'info', operationId = '', durationMs = 1800 } = typeof options === 'number'
        ? { durationMs: options } : options;
      if (toast.dataset.kind === 'progress' && toast.dataset.operationId !== operationId) return;
      if (this._composerToastTimer) clearTimeout(this._composerToastTimer);
      this._composerToastTimer = null;
      toast.dataset.kind = kind;
      toast.dataset.operationId = operationId;
      toast.textContent = String(message || '');
      toast.hidden = false;
      if (kind !== 'progress') this._composerToastTimer = setTimeout(() => {
        this._composerToastTimer = null;
        toast.hidden = true;
      }, durationMs);
    },

    showEmptySendToast() {
      this.showComposerToast('没有可发送的内容');
      return false;
    },

    handleComposerSubmit() {
      if (!this.hasComposerDraft()) return this.showEmptySendToast();
      return this.sendCurrentDraft();
    },

    async sendCurrentDraft() {
      if (this._pinModeActive) {
        this.showComposerToast('请先确认或取消钉子模式');
        return false;
      }
      if (!await this.waitForAttachmentIngests()) return false;
      const draft = this.composerDraftSnapshot();
      if (!draft.text.trim() && !draft.attachments.length && !draft.pins.length) {
        return this.showEmptySendToast();
      }
      if (this.isCurrentSessionExecuting() && this._codexStopPending) return false;
      const queue = this._sessionView === 'conversation' ? this.sessionQueueState() : null;
      if (queue && queue.editingMessageId) return this.commitQueuedMessageEdit(draft, queue);
      if (this.isCurrentSessionExecuting()) {
        try {
          const queuedMessage = this.enqueueMessage(draft.text, draft.attachments, draft.pins);
          if (!queuedMessage) {
            this.showComposerToast('发送失败，请重试');
            return false;
          }
          this.clearComposerDraft();
          return true;
        } catch (error) {
          console.warn(`[AI Copilot] Unable to enqueue message: ${error.message}`);
          this.showComposerToast('发送失败，请重试');
          return false;
        }
      }
      return this.submitComposerPrompt();
    },

    async handleComposerAction() {
      if (this._pinModeActive) return false;
      if (this.isCurrentSessionExecuting() && this._codexStopPending) return false;
      const hasDraft = this.hasComposerDraft();
      if (this.isCurrentSessionExecuting() && !hasDraft) {
        await this.stopCurrentTask();
        return true;
      }
      return this.handleComposerSubmit();
    },

    setComposerBusy(isBusy, isStopping = false) {
      const wasBusy = this._codexTaskRunning;
      const wasStopping = this._codexStopPending;
      this._codexTaskRunning = Boolean(isBusy);
      this._codexStopPending = Boolean(isStopping);
      if (this.$.composerInput) {
        this.$.composerInput.disabled = false;
        this.$.composerInput.removeAttribute('disabled');
        this.$.composerInput.readOnly = Boolean(this._pinModeActive);
        this.$.composerInput.toggleAttribute('readonly', Boolean(this._pinModeActive));
      }
      this.updateComposerActionState();
      this.updateScrollToLatestButton();
      if (wasBusy !== this._codexTaskRunning || wasStopping !== this._codexStopPending) {
        this.refreshRenderedSessionStates();
        const visible = this.activeSession();
        (visible?.messages || []).forEach((turn) => { if (turn.ui?.changeCard) this.renderChangeCard(turn); });
      }
    },

    sessionQueueState(sessionId = this._codexSessionId) {
      const normalizedSessionId = String(sessionId || '').trim();
      if (!normalizedSessionId) return null;
      if (!this._sessionQueues) this._sessionQueues = new Map();
      if (!this._sessionQueues.has(normalizedSessionId)) {
        this._sessionQueues.set(normalizedSessionId, {
          sessionId: normalizedSessionId,
          queuedMessages: [],
          paused: false,
          pauseReason: '',
          drainInProgress: false,
          drainTimer: null,
          activeMessageId: '',
          steerInProgressId: '',
          editingMessageId: '',
          draggingMessageId: '',
        });
      }
      return this._sessionQueues.get(normalizedSessionId);
    },

    pendingQueueMessages(queue = this.sessionQueueState()) {
      return queue
        ? queue.queuedMessages.filter((message) => message.status === 'queued')
        : [];
    },

    visibleQueueMessages(queue = this.sessionQueueState()) {
      return queue
        ? queue.queuedMessages.filter((message) => ['queued', 'steering', 'unconfirmed'].includes(message.status))
        : [];
    },

    queueMessagePreview(message) {
      const text = String(message && message.text || '').trim();
      if (text) return text;
      const attachment = message && Array.isArray(message.attachments) && message.attachments[0];
      if (attachment) return String(attachment.title || '已粘贴的文本.txt');
      const pin = message && Array.isArray(message.pins) && message.pins[0];
      if (pin) return String(pin.label || '已固定的 Cocos 对象');
      return '排队消息';
    },

    queueMessageById(messageId, queue = this.sessionQueueState()) {
      if (!queue) return null;
      return queue.queuedMessages.find((message) => message.id === messageId) || null;
    },

    createQueueAttachmentSummary(ownerDocument, attachments) {
      const items = this.cloneAttachments(attachments);
      if (!items.length) return null;
      const list = this.createElement(ownerDocument, 'span', 'queue-attachment-list');
      items.slice(0, 3).forEach((attachment) => {
        if (this.isImageAttachment(attachment)) {
          const thumb = this.createElement(ownerDocument, 'span', 'queue-attachment-thumb');
          const image = this.createElement(ownerDocument, 'img');
          image.alt = attachment.displayName || attachment.title || '图片附件';
          image.draggable = false;
          thumb.appendChild(image);
          thumb.appendChild(this.createElement(ownerDocument, 'span', 'image-attachment-unavailable', '图片不可用'));
          this.bindAttachmentThumbnail(thumb, image, attachment);
          thumb.title = attachment.displayName || attachment.title || '图片附件';
          list.appendChild(thumb);
        } else {
          const file = this.createElement(ownerDocument, 'span', 'queue-attachment-file');
          file.innerHTML = attachment.kind === 'directory'
            ? '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path fill="none" stroke="currentColor" d="M1.75 4.25h4l1.35 1.5h7.15v7.5a1 1 0 0 1-1 1H2.75a1 1 0 0 1-1-1v-9Z"/></svg>'
            : '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path fill="none" stroke="currentColor" d="M4 1.75h5l3 3v9.5H4a1 1 0 0 1-1-1V2.75a1 1 0 0 1 1-1Z"/></svg>';
          const name = attachment.displayName || attachment.title || '文件';
          file.appendChild(this.createElement(ownerDocument, 'span', '', name));
          file.title = name;
          list.appendChild(file);
        }
      });
      if (items.length > 3) list.appendChild(this.createElement(ownerDocument, 'span', 'queue-attachment-file', `+${items.length - 3}`));
      return list;
    },

    renderQueueItem(container, queue, message, messages, waiting = false) {
      const ownerDocument = container.ownerDocument || document;
      const steering = message.status === 'steering';
      const unconfirmed = message.status === 'unconfirmed';
      const reorderable = !waiting && !steering
        && !queue.editingMessageId
        && messages.filter((item) => item.status === 'queued').length > 1;
      const item = this.createElement(ownerDocument, 'article', `queue-item${waiting ? ' is-waiting' : ''}`);
      item.dataset.queueMessageId = message.id;
      item.classList.toggle('is-steering', steering);
      item.classList.toggle('is-reorderable', reorderable);

      if (reorderable) {
        const dragHandle = this.createElement(ownerDocument, 'button', 'queue-drag-handle');
        dragHandle.type = 'button';
        dragHandle.draggable = true;
        dragHandle.title = '拖动调整排队顺序';
        dragHandle.setAttribute('aria-label', '拖动调整排队顺序；也可使用 Alt+上/下方向键');
        dragHandle.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 4h.01M5 8h.01M5 12h.01M11 4h.01M11 8h.01M11 12h.01"></path></svg>';
        dragHandle.addEventListener('dragstart', (event) => {
          queue.draggingMessageId = message.id;
          item.classList.add('is-dragging');
          if (event.dataTransfer) {
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/plain', message.id);
          }
        });
        dragHandle.addEventListener('dragend', () => {
          queue.draggingMessageId = '';
          item.classList.remove('is-dragging');
        });
        dragHandle.addEventListener('keydown', (event) => {
          if (!event.altKey || !['ArrowUp', 'ArrowDown'].includes(event.key)) return;
          event.preventDefault();
          this.moveQueuedMessage(message.id, event.key === 'ArrowUp' ? -1 : 1, queue);
        });
        item.appendChild(dragHandle);
        item.addEventListener('dragover', (event) => {
          if (!queue.draggingMessageId || queue.draggingMessageId === message.id) return;
          event.preventDefault();
          if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
        });
        item.addEventListener('drop', (event) => {
          if (!queue.draggingMessageId || queue.draggingMessageId === message.id) return;
          event.preventDefault();
          const rect = item.getBoundingClientRect();
          const placeAfter = Number(event.clientY) > rect.top + rect.height / 2;
          this.reorderQueuedMessage(queue.draggingMessageId, message.id, placeAfter, queue);
          queue.draggingMessageId = '';
        });
      }

      const previewText = this.queueMessagePreview(message);
      const preview = this.createElement(ownerDocument, 'span', 'queue-preview');
      if (!waiting) preview.innerHTML = [
          '<svg class="queue-toggle-icon" viewBox="0 0 20 20" aria-hidden="true">',
          '<path d="M2.66797 11V3.33301C2.66797 2.96574 2.96574 2.66797 3.33301 2.66797C3.70028 2.66797 3.99805 2.96574 3.99805 3.33301V11C3.99805 11.7109 3.99894 12.2044 4.03027 12.5879C4.06098 12.9634 4.11776 13.175 4.19824 13.333L4.26856 13.459C4.44487 13.7465 4.69781 13.9808 5 14.1348L5.12988 14.1904C5.27366 14.2419 5.46311 14.2797 5.74512 14.3027C6.12864 14.3341 6.62197 14.335 7.33301 14.335H15L15.0674 14.3418L14.1123 13.3867L14.0273 13.2822C13.8571 13.0242 13.8854 12.6735 14.1123 12.4463C14.3397 12.2189 14.6911 12.1906 14.9492 12.3613L15.0537 12.4463L17.1367 14.5293C17.3964 14.7889 17.3963 15.21 17.1367 15.4697L15.0537 17.5537C14.794 17.8134 14.372 17.8134 14.1123 17.5537C13.8526 17.294 13.8526 16.872 14.1123 16.6123L15.0664 15.6582L15 15.665H7.33301C6.64392 15.665 6.08696 15.6647 5.63672 15.6279C5.23614 15.5952 4.87531 15.5309 4.53906 15.3867L4.39649 15.3193C3.87528 15.0538 3.43887 14.6502 3.13477 14.1543L3.0127 13.9365C2.82084 13.5599 2.74153 13.1541 2.7041 12.6963C2.66732 12.2461 2.66797 11.6889 2.66797 11ZM15.665 15C15.665 15.0226 15.6594 15.0444 15.6572 15.0664L15.7256 14.999L15.6572 14.9316C15.6595 14.9541 15.665 14.9769 15.665 15ZM11.666 8.91797L11.8008 8.93164C12.1036 8.99381 12.3311 9.2618 12.3311 9.58301C12.3311 9.90422 12.1036 10.1722 11.8008 10.2344L11.666 10.248H7.5C7.13273 10.248 6.83496 9.95028 6.83496 9.58301C6.83496 9.21574 7.13273 8.91797 7.5 8.91797H11.666ZM14.166 4.33496L14.3008 4.34863C14.6036 4.41083 14.8311 4.67881 14.8311 5C14.8309 5.32109 14.6035 5.58924 14.3008 5.65137L14.166 5.66504H7.5C7.13284 5.66504 6.83514 5.36712 6.83496 5C6.83496 4.63273 7.13273 4.33496 7.5 4.33496H14.166Z"></path>',
          '</svg>',
        ].join('');
      const attachmentSummary = this.createQueueAttachmentSummary(ownerDocument, message.attachments);
      if (attachmentSummary) preview.appendChild(attachmentSummary);
      preview.appendChild(this.createElement(ownerDocument, 'span', 'queue-preview-text', previewText));
      preview.title = previewText;
      if (unconfirmed) preview.title += '（上次调整方向是否送达尚未确认，请核对历史后编辑并重新发送）';
      item.appendChild(preview);

      const actions = this.createElement(ownerDocument, 'div', 'queue-item-actions');
      if (waiting) {
        const editButton = this.createElement(ownerDocument, 'button', 'queue-item-action queue-waiting-action', '编辑');
        editButton.type = 'button';
        editButton.title = '编辑待运行任务';
        editButton.setAttribute('aria-label', '编辑待运行任务');
        editButton.disabled = Boolean(queue.editingMessageId);
        editButton.addEventListener('click', (event) => {
          event.stopPropagation();
          this.editQueuedMessage(message.id);
        });
        actions.appendChild(editButton);

        const cancelButton = this.createElement(ownerDocument, 'button', 'queue-item-action queue-waiting-action', '取消');
        cancelButton.type = 'button';
        cancelButton.title = '取消待运行任务';
        cancelButton.setAttribute('aria-label', '取消待运行任务');
        cancelButton.disabled = Boolean(queue.editingMessageId);
        cancelButton.addEventListener('click', (event) => {
          event.stopPropagation();
          this.removeQueuedMessage(message.id);
        });
        actions.appendChild(cancelButton);
        item.appendChild(actions);
        container.appendChild(item);
        return;
      }

      const steerButton = this.createElement(ownerDocument, 'button', 'queue-item-action queue-steer-action');
      steerButton.type = 'button';
      steerButton.title = '提交，但不中断模型运行';
      steerButton.setAttribute('aria-label', '调整方向：提交这条消息，但不中断模型运行');
      steerButton.disabled = steering || Boolean(queue.editingMessageId)
        || !this.isCurrentSessionExecuting() || this._codexStopPending || unconfirmed;
      steerButton.hidden = !this.isCurrentSessionExecuting();
      steerButton.classList.toggle('is-pending', steering);
      steerButton.innerHTML = [
        '<svg viewBox="0 0 16 16" aria-hidden="true">',
        '<path d="M3 3.5v5.25a2 2 0 0 0 2 2h7"></path>',
        '<path d="m9.5 8.25 2.5 2.5-2.5 2.5"></path>',
        '</svg>',
        `<span class="queue-steer-label">${steering ? '正在调整' : '调整方向'}</span>`,
      ].join('');
      steerButton.addEventListener('click', (event) => {
        event.stopPropagation();
        this.steerQueuedMessage(message.id);
      });
      actions.appendChild(steerButton);

      const removeButton = this.createElement(ownerDocument, 'button', 'queue-item-action');
      removeButton.type = 'button';
      removeButton.title = '删除下一条排队消息';
      removeButton.setAttribute('aria-label', '删除下一条排队消息');
      removeButton.disabled = steering || Boolean(queue.editingMessageId);
      removeButton.innerHTML = [
        '<svg viewBox="0 0 16 16" aria-hidden="true">',
        '<path d="M3.25 4.5h9.5M6 2.75h4M5 6.25v5.25M8 6.25v5.25M11 6.25v5.25"></path>',
        '<path d="M4.25 4.5l.5 8.1a.75.75 0 0 0 .75.65h5a.75.75 0 0 0 .75-.65l.5-8.1"></path>',
        '</svg>',
      ].join('');
      removeButton.addEventListener('click', (event) => {
        event.stopPropagation();
        this.removeQueuedMessage(message.id);
      });
      actions.appendChild(removeButton);

      const moreButton = this.createElement(ownerDocument, 'button', 'queue-item-action', '⋯');
      moreButton.type = 'button';
      moreButton.title = '排队消息操作';
      moreButton.setAttribute('aria-label', '排队消息操作');
      moreButton.disabled = steering || Boolean(queue.editingMessageId);
      moreButton.addEventListener('click', (event) => {
        event.stopPropagation();
        this.showQueueContextMenu(message.id, moreButton);
      });
      actions.appendChild(moreButton);
      item.appendChild(actions);
      container.appendChild(item);
    },

    renderQueueArea(sessionId = this._codexSessionId) {
      const area = this.$.queueArea;
      const itemsContainer = this.$.queueItems;
      if (!area || !itemsContainer) return;
      if (this._sessionView !== 'conversation') {
        area.hidden = true;
        this.clearElement(itemsContainer);
        this.$.queuePausedStatus.hidden = true;
        return;
      }
      const normalizedSessionId = String(sessionId || '');
      if (normalizedSessionId && normalizedSessionId !== this._activeSessionId) return;
      const queue = this.sessionQueueState(normalizedSessionId || this._activeSessionId);
      if (!queue) {
        area.hidden = true;
        area.classList.remove('is-waiting');
        this.clearElement(itemsContainer);
        this.$.queuePausedStatus.hidden = true;
        return;
      }
      const queuedMessages = this.visibleQueueMessages(queue);
      const waiting = this.isSessionWaiting(queue.sessionId);
      area.classList.toggle('is-waiting', waiting);
      if (
        this._queueContextMessageId
        && !queuedMessages.some((message) => message.id === this._queueContextMessageId)
      ) this.hideQueueContextMenu();
      area.hidden = queuedMessages.length === 0;
      this.clearElement(itemsContainer);
      if (!queuedMessages.length) {
        this.$.queuePausedStatus.hidden = true;
        return;
      }
      queuedMessages.forEach((message) => (
        this.renderQueueItem(itemsContainer, queue, message, queuedMessages, waiting)
      ));

      const pausedLabel = this.$.queuePausedStatus;
      pausedLabel.hidden = !queue.paused && !waiting;
      pausedLabel.textContent = '';
      if (waiting) {
        const ownerDocument = pausedLabel.ownerDocument || document;
        const icon = this.createElement(ownerDocument, 'span', 'waiting-status-icon');
        icon.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="5.25"></circle><path d="M8 4.75V8l2.25 1.5"></path></svg>';
        pausedLabel.appendChild(icon);
        pausedLabel.appendChild(this.createElement(
          ownerDocument,
          'span',
          'waiting-status-text',
          '等待运行 · 另一个会话正在运行'
        ));
      } else {
        pausedLabel.textContent = queue.pauseReason === 'failed'
          ? '任务失败，排队已暂停'
          : queue.pauseReason === 'restored' ? '已恢复待发送内容，尚未执行'
            : queue.paused ? '排队已暂停' : '';
      }
      if (queue.queuedMessages.some((item) => item.status === 'unconfirmed')) {
        pausedLabel.hidden = false;
        pausedLabel.textContent += ' · 上次调整方向未确认，请先核对';
      }
      if (queue.paused && this.pendingQueueMessages(queue).length) {
        const resume = this.createElement(pausedLabel.ownerDocument || document, 'button', 'queue-resume', '继续执行');
        resume.type = 'button';
        resume.addEventListener('click', () => this.resumeQueue());
        pausedLabel.appendChild(resume);
      }
    },

    removeQueuedMessage(messageId) {
      const queue = this.sessionQueueState();
      const message = this.queueMessageById(messageId, queue);
      if (!message || !['queued', 'unconfirmed'].includes(message.status)) return false;
      message.status = 'cancelled';
      if (queue.editingMessageId === message.id) queue.editingMessageId = '';
      this.hideQueueContextMenu();
      this.renderQueueArea();
      this.refreshRenderedSessionStates();
      this.persistSession(queue.sessionId, true);
      this.scheduleQueueDrain(queue.sessionId);
      return true;
    },

    clearQueue(options = {}) {
      const queue = this.sessionQueueState();
      if (!queue) return 0;
      let cancelled = 0;
      queue.queuedMessages.forEach((message) => {
        if (!['queued', 'unconfirmed'].includes(message.status)) return;
        message.status = 'cancelled';
        cancelled += 1;
      });
      queue.paused = Boolean(options.pause);
      queue.pauseReason = queue.paused ? String(options.reason || '') : '';
      queue.editingMessageId = '';
      queue.draggingMessageId = '';
      this.hideQueueContextMenu();
      this.renderQueueArea();
      this.refreshRenderedSessionStates();
      this.persistSession(queue.sessionId, true);
      this.scheduleQueueDrain(queue.sessionId);
      return cancelled;
    },

    editQueuedMessage(messageId) {
      const queue = this.sessionQueueState();
      const message = this.queueMessageById(messageId, queue);
      if (
        !message
        || !['queued', 'unconfirmed'].includes(message.status)
        || !this.$.composerInput
        || (queue.editingMessageId && queue.editingMessageId !== message.id)
      ) return false;
      const text = message.text;
      const attachments = this.cloneTextAttachments(message.attachments);
      const pins = this.clonePinnedContexts(message.pins);
      queue.editingMessageId = message.id;
      this.hideQueueContextMenu();
      this.$.composerInput.value = text;
      this._composerAttachments = attachments;
      this._composerPins = pins;
      this.renderComposerAttachments();
      this.renderComposerPins();
      this.resizeComposer();
      this.updateComposerActionState();
      this.$.composerInput.focus();
      const caret = text.length;
      if (typeof this.$.composerInput.setSelectionRange === 'function') {
        this.$.composerInput.setSelectionRange(caret, caret);
      }
      this.renderQueueArea(queue.sessionId);
      return true;
    },

    commitQueuedMessageEdit(draft, queue = this.sessionQueueState()) {
      const message = queue && this.queueMessageById(queue.editingMessageId, queue);
      if (!message || !['queued', 'unconfirmed'].includes(message.status)) {
        if (queue) queue.editingMessageId = '';
        return false;
      }
      const text = String(draft && draft.text || '');
      const attachments = this.cloneTextAttachments(draft && draft.attachments);
      const pins = this.dedupePinnedContexts(draft && draft.pins || []);
      if (!text.trim() && !attachments.length && !pins.length) return this.showEmptySendToast();
      message.text = text;
      message.status = 'queued';
      message.attachments = attachments;
      message.pins = pins;
      const selection = this.currentModelSelection();
      message.providerId = selection.providerId;
      message.modelId = selection.modelId;
      message.reasoningEffort = selection.reasoningEffort;
      message.updatedAt = Date.now();
      message.error = '';
      queue.editingMessageId = '';
      this.clearComposerDraft();
      this.renderQueueArea(queue.sessionId);
      this.refreshRenderedSessionStates();
      this.persistSession(queue.sessionId, true);
      if (!this._codexTaskRunning && !queue.paused) this.scheduleQueueDrain(queue.sessionId);
      return true;
    },

    reorderQueuedMessage(sourceId, targetId, placeAfter = false, queue = this.sessionQueueState()) {
      if (!queue || queue.editingMessageId || queue.steerInProgressId) return false;
      const queued = queue.queuedMessages.filter((message) => message.status === 'queued');
      const sourceIndex = queued.findIndex((message) => message.id === sourceId);
      const targetIndex = queued.findIndex((message) => message.id === targetId);
      if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return false;
      const [source] = queued.splice(sourceIndex, 1);
      const adjustedTargetIndex = queued.findIndex((message) => message.id === targetId);
      queued.splice(adjustedTargetIndex + (placeAfter ? 1 : 0), 0, source);
      let cursor = 0;
      queue.queuedMessages = queue.queuedMessages.map((message) => (
        message.status === 'queued' ? queued[cursor++] : message
      ));
      if (queue.sessionId === this._activeSessionId) this.renderQueueArea(queue.sessionId);
      this.refreshRenderedSessionStates();
      this.persistSession(queue.sessionId, true);
      return true;
    },

    moveQueuedMessage(messageId, offset, queue = this.sessionQueueState()) {
      if (!queue || !Number.isInteger(offset) || offset === 0) return false;
      const queued = queue.queuedMessages.filter((message) => message.status === 'queued');
      const index = queued.findIndex((message) => message.id === messageId);
      const targetIndex = Math.max(0, Math.min(queued.length - 1, index + offset));
      if (index < 0 || targetIndex === index) return false;
      return this.reorderQueuedMessage(
        messageId,
        queued[targetIndex].id,
        targetIndex > index,
        queue
      );
    },

    async steerQueuedMessage(messageId) {
      const queue = this.sessionQueueState();
      const message = this.queueMessageById(messageId, queue);
      const session = this.activeSession();
      const taskId = String(this._activeCodexTaskId || '');
      if (
        !queue
        || !message
        || message.status !== 'queued'
        || !session
        || !taskId
        || queue.steerInProgressId
        || !this._codexTaskRunning
        || (this._activeExecutionSessionId && queue.sessionId !== this._activeExecutionSessionId)
        || this._codexStopPending
      ) return false;
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        this.showComposerToast('当前无法提交调整方向，这条消息仍在队列中。');
        return false;
      }
      message.status = 'steering';
      queue.steerInProgressId = message.id;
      message.error = '';
      this.hideQueueContextMenu();
      this.renderQueueArea(queue.sessionId);
      this.refreshRenderedSessionStates();
      this.persistSession(queue.sessionId, true);
      try {
        const task = this.normalizeTaskPayload({
          text: message.text,
          attachments: message.attachments,
          pins: message.pins,
        });
        const selection = await this.readCurrentSelectionSnapshot();
        const response = await Editor.Message.request(
          EXTENSION_NAME,
          'steer-codex-task',
          {
            prompt: task.executionPrompt,
            userRequest: task.text,
            attachments: this.cloneTextAttachments(task.attachments),
            pins: this.clonePinnedContexts(task.pins),
            selection,
            sessionId: session.id,
            threadId: session.threadId || '',
            taskId,
            clientUserMessageId: message.id,
          }
        );
        if (!response || response.accepted !== true) {
          message.status = queue.pauseReason === 'user-stop' ? 'cancelled' : 'queued';
          message.error = String(response && response.message || '当前 Turn 暂时无法接收调整。');
          if (message.status === 'queued') this.showComposerToast(message.error, 2400);
          if (!this._codexTaskRunning && !queue.paused) this.scheduleQueueDrain(queue.sessionId);
          return false;
        }
        message.status = 'steered';
        message.steeredAt = Date.now();
        message.turnId = String(response.turnId || '');
        const turn = session.turnsByTaskId && session.turnsByTaskId.get(taskId);
        if (turn && turn.sessionId === session.id) {
          this.upsertTurnPresentationItem(turn, turn.followUps || (turn.followUps = []), {
            id: message.id,
            type: 'user-follow-up',
            text: message.text,
            attachments: this.cloneTextAttachments(message.attachments),
            pins: this.clonePinnedContexts(message.pins),
            status: 'steered',
            turnId: message.turnId,
            createdAt: message.steeredAt,
          });
          if (turn.ui) this.renderTurn(turn);
        }
        return true;
      } catch (error) {
        message.status = queue.pauseReason === 'user-stop' ? 'cancelled' : 'queued';
        message.error = String(error && error.message || '当前 Turn 暂时无法接收调整。');
        if (message.status === 'queued') this.showComposerToast(`无法调整方向：${message.error}`, 2400);
        if (!this._codexTaskRunning && !queue.paused) this.scheduleQueueDrain(queue.sessionId);
        return false;
      } finally {
        if (message.status === 'steering') {
          message.status = queue.pauseReason === 'user-stop' ? 'cancelled' : 'queued';
        }
        if (queue.steerInProgressId === message.id) queue.steerInProgressId = '';
        if (queue.sessionId === this._activeSessionId) this.renderQueueArea(queue.sessionId);
        this.refreshRenderedSessionStates();
        this.persistSession(queue.sessionId, true);
        if (!this._codexTaskRunning) {
          this.scheduleQueueDrain(queue.sessionId);
        }
      }
    },

    hideQueueContextMenu() {
      if (this.$.queueContextMenu) this.$.queueContextMenu.hidden = true;
      this._queueContextMessageId = '';
    },

    showQueueContextMenu(messageId, anchor) {
      const menu = this.$.queueContextMenu;
      const message = this.queueMessageById(messageId);
      if (!menu || !anchor || !message || !['queued', 'unconfirmed'].includes(message.status)) return;
      this._queueContextMessageId = message.id;
      const anchorRect = anchor.getBoundingClientRect();
      menu.style.left = `${Math.max(4, anchorRect.right - 120)}px`;
      menu.style.top = `${Math.max(4, anchorRect.bottom + 3)}px`;
      menu.hidden = false;

      const schedule = typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : (callback) => setTimeout(callback, 0);
      schedule(() => {
        if (menu.hidden) return;
        const ownerDocument = anchor.ownerDocument || document;
        const ownerWindow = ownerDocument.defaultView
          || (typeof window !== 'undefined' ? window : null);
        const viewportWidth = ownerWindow && ownerWindow.innerWidth
          || ownerDocument.documentElement.clientWidth;
        const viewportHeight = ownerWindow && ownerWindow.innerHeight
          || ownerDocument.documentElement.clientHeight;
        const rect = menu.getBoundingClientRect();
        menu.style.left = `${Math.max(4, Math.min(anchorRect.right - rect.width, viewportWidth - rect.width - 4))}px`;
        menu.style.top = `${Math.max(4, Math.min(anchorRect.bottom + 3, viewportHeight - rect.height - 4))}px`;
      });
    },

    clearComposerDraft() {
      if (!this.$.composerInput) return;
      const visibleIngestStates = new Set(this.visibleAttachmentIngestStates());
      this.$.composerInput.value = '';
      this._composerAttachments = [];
      this._composerPins = [];
      this._attachmentIngestStates = (this._attachmentIngestStates || [])
        .filter((state) => !visibleIngestStates.has(state));
      this.renderComposerAttachments();
      this.renderComposerPins();
      this.resizeComposer();
      this.updateComposerActionState();
      this.saveVisibleDraft(true);
    },

    enqueueMessage(text, attachments = [], pins = [], modelSelection = this.currentModelSelection()) {
      const value = String(text || '');
      const attachmentItems = this.cloneTextAttachments(attachments);
      const pinItems = this.dedupePinnedContexts(pins);
      const queue = this.sessionQueueState();
      if (!queue) return null;
      if (!value.trim() && !attachmentItems.length && !pinItems.length) return null;
      const selection = this.normalizedModelSelection(modelSelection, false);
      const message = {
        id: `queue:${Date.now()}:${Math.random().toString(36).slice(2)}`,
        sessionId: queue.sessionId,
        text: value,
        attachments: attachmentItems,
        pins: pinItems,
        providerId: selection.providerId,
        modelId: selection.modelId,
        reasoningEffort: selection.reasoningEffort,
        createdAt: Date.now(),
        status: 'queued',
        error: '',
      };
      queue.queuedMessages.push(message);
      const session = this._sessions?.get(queue.sessionId);
      if (session && session.title === '新会话') session.title = this.deriveSessionTitle(this.queueMessagePreview(message));
      if (session) session.updatedAt = message.createdAt;
      try {
        this.renderQueueArea();
        this.refreshRenderedSessionStates();
      } catch (error) {
        const index = queue.queuedMessages.indexOf(message);
        if (index !== -1) queue.queuedMessages.splice(index, 1);
        throw error;
      }
      this.persistSession(queue.sessionId, true);
      return message;
    },

    pauseQueue(reason = '', sessionId = this._codexSessionId) {
      const queue = this.sessionQueueState(sessionId);
      if (!queue) return;
      queue.paused = true;
      queue.pauseReason = String(reason || '');
      this.renderQueueArea(sessionId);
      this.refreshRenderedSessionStates();
      this.persistSession(queue.sessionId, true);
    },

    async resumeQueue() {
      const queue = this.sessionQueueState();
      if (!queue || !this.pendingQueueMessages(queue).length) return false;
      const session = this._sessions?.get(queue.sessionId);
      if (session?.restored && !this.getRunningSessionId() && !await this.ensureSessionRestored(session)) return false;
      queue.paused = false;
      queue.pauseReason = '';
      this.renderQueueArea();
      this.refreshRenderedSessionStates();
      this.persistSession(queue.sessionId, true);
      this.scheduleQueueDrain(queue.sessionId);
      return true;
    },

    scheduleQueueDrain(sessionId = this._codexSessionId) {
      const queue = this.sessionQueueState(sessionId);
      if (!queue || queue.drainTimer != null || this._panelClosing) return;
      queue.drainTimer = setTimeout(() => {
        queue.drainTimer = null;
        if (this._panelClosing) return;
        this.drainQueue(queue.sessionId).catch((error) => {
          console.warn(`[AI Copilot] Unable to continue queued task: ${error.message}`);
          this.pauseQueue('drain-error', queue.sessionId);
        });
      }, 0);
    },

    finalizeQueuedMessage(turn, status, message = '') {
      if (!turn || !turn.queueMessageId) return;
      const queue = this.sessionQueueState(turn.sessionId || this._codexSessionId);
      if (!queue) return;
      const queuedMessage = queue.queuedMessages.find((item) => item.id === turn.queueMessageId);
      if (queuedMessage) {
        queuedMessage.status = ['completed', 'cancelled'].includes(status) ? status : 'error';
        queuedMessage.error = status === 'failed' ? String(message || '') : '';
      }
      if (queue.activeMessageId === turn.queueMessageId) queue.activeMessageId = '';
      if (queue.sessionId === this._activeSessionId) this.renderQueueArea(queue.sessionId);
      this.refreshRenderedSessionStates();
    },

    async drainQueue(sessionId = this._codexSessionId) {
      if (this._codexTaskRunning || this._activeCodexTaskId || this._codexStopPending || this._panelClosing) return false;
      let queue = this._sessionQueues?.get(this._activeExecutionSessionId);
      // The owner keeps its follow-ups (including an in-flight steer/edit) ahead of other chats.
      if (queue?.drainInProgress || queue?.steerInProgressId || (queue?.editingMessageId && !queue.paused)) return false;
      if (!queue || queue.paused || !this.pendingQueueMessages(queue).length) {
        this._activeExecutionSessionId = '';
        queue = Array.from(this._sessionQueues?.values() || [])
          .filter((item) => !item.paused && !item.editingMessageId && !item.steerInProgressId
            && !item.drainInProgress && !item.activeMessageId && this.pendingQueueMessages(item).length)
          .sort((a, b) => Math.min(...this.pendingQueueMessages(a).map((item) => item.createdAt))
            - Math.min(...this.pendingQueueMessages(b).map((item) => item.createdAt)))[0];
      }
      this.refreshRenderedSessionStates();
      if (!queue) return false;
      const next = this.pendingQueueMessages(queue)[0];
      const session = this._sessions?.get(queue.sessionId);
      if (!session) return false;
      this._activeExecutionSessionId = session.id;
      queue.drainInProgress = true;
      try {
        return await this.startCodexTask(
          {
            text: next.text,
            attachments: next.attachments,
            pins: next.pins,
            providerId: next.providerId,
            modelId: next.modelId,
            reasoningEffort: next.reasoningEffort,
          },
          { queuedMessage: next, session }
        );
      } finally {
        queue.drainInProgress = false;
        if (!this._codexTaskRunning && !this._activeCodexTaskId) {
          this.scheduleQueueDrain(queue.sessionId);
        }
      }
    },

    normalizeCodexEvent(event) {
      if (!event || typeof event !== 'object') return null;
      const aliases = {
        'thread.started': 'thread',
        'agent.message': 'message',
        'turn.completed': 'completed',
        'turn.failed': 'failed',
        error: 'failed',
      };
      const normalizedType = aliases[event.type] || event.type;
      return normalizedType === event.type ? event : { ...event, type: normalizedType };
    },

    hasStructuredWork(turn) {
      return Boolean(turn.plan || turn.executionStarted || turn.activities.length || turn.validation.length);
    },

    returnToThinking(turn, title = '正在思考') {
      if (turn.status !== 'running') return;
      turn.liveState = { id: 'turn-working', state: 'thinking', title, status: 'running' };
    },

    endTask(turn, options = {}) {
      const taskId = String(options.taskId || (turn && turn.taskId) || '');
      const requestedStatus = ['completed', 'failed', 'cancelled'].includes(options.status)
        ? options.status
        : 'cancelled';
      const releaseRuntime = Boolean(options.releaseRuntime);
      if (turn && turn.status === 'running') {
        turn.activities = (turn.activities || []).filter((activity) => activity.type !== 'runtime-status'
          || (activity.kind === 'context-compaction' && activity.status === 'success'));
        (turn.activities || []).filter((activity) => activity.type === 'approval' && activity.approvalState === 'pending')
          .forEach((activity) => { activity.approvalState = 'expired'; activity.status = 'expired'; });
        turn.status = requestedStatus;
        turn.executionStatus = requestedStatus;
        if (!turn.completedAt) turn.completedAt = Date.now();
        turn.liveState = null;
        turn.errorMessage = requestedStatus === 'failed'
          ? String(options.message || '未知错误').trim()
          : '';
        turn.errorDetail = requestedStatus === 'failed'
          ? String(options.detail || '').trim()
          : '';
        if (requestedStatus === 'completed' && !turn.hasAgentText) {
          turn.assistantMessages.push({
            id: `empty:${turn.taskId}`,
            text: 'Codex 已完成，但没有返回文本。',
            phase: 'after-work',
            synthetic: true,
            presentationOrder: this.nextPresentationOrder(turn),
          });
        }
        turn.historyExpanded = requestedStatus === 'failed';
        this.touchSession(turn.sessionId, turn.completedAt);
        if (turn.ui) this.renderTurn(turn);
        this.renderApprovalTray();
      } else if (turn && releaseRuntime && turn.status !== requestedStatus) {
        // task-ended is authoritative because it is emitted only after Runner cleanup.
        turn.status = requestedStatus;
        turn.executionStatus = requestedStatus;
        turn.completedAt = turn.completedAt || Date.now();
        turn.liveState = null;
        turn.errorMessage = requestedStatus === 'failed'
          ? String(options.message || turn.errorMessage || '未知错误').trim()
          : '';
        turn.errorDetail = requestedStatus === 'failed'
          ? String(options.detail || turn.errorDetail || '').trim()
          : '';
        turn.historyExpanded = requestedStatus === 'failed';
        this.touchSession(turn.sessionId, turn.completedAt);
        if (turn.ui) this.renderTurn(turn);
      }
      let released = false;
      if (releaseRuntime && taskId && taskId === this._activeCodexTaskId) {
        this._activeCodexTaskId = '';
        this.setComposerBusy(false);
        released = true;
      }
      if (
        turn
        && turn.sessionId === this._activeSessionId
        && this._sessionView === 'conversation'
      ) this.scrollActivityToEnd();
      return {
        released,
        status: turn ? turn.status : requestedStatus,
      };
    },

    finishCodexTurn(turn, state, message, detail = '') {
      this.endTask(turn, { taskId: turn && turn.taskId, status: state, message, detail });
    },

    handleCodexEvent(event) {
      if (!event) return;
      if (event.type === 'session-store-error') {
        this.showComposerToast(event.message, 3500);
        return;
      }
      const normalizedEvent = this.normalizeCodexEvent(event);
      if (!normalizedEvent) return;
      const session = this.sessionForTask(normalizedEvent.taskId, normalizedEvent.sessionId);
      if (!session) return;
      const turn = session.turnsByTaskId.get(normalizedEvent.taskId);
      if (normalizedEvent.threadId && session.threadId && normalizedEvent.threadId !== session.threadId) return;
      if (normalizedEvent.turnId && turn?.codexTurnId && normalizedEvent.turnId !== turn.codexTurnId) return;
      if (normalizedEvent.turnId && turn) turn.codexTurnId = normalizedEvent.turnId;
      const isActiveSession = session.id === this._activeSessionId;
      const isVisibleConversation = isActiveSession && this._sessionView === 'conversation';
      try {
        if (normalizedEvent.type === 'artifact-error') {
          if (isActiveSession) this.showComposerToast(normalizedEvent.message || '生成的文件无法加入聊天附件', 3200);
          return;
        }
        if (normalizedEvent.type === 'artifact-updated' && normalizedEvent.artifact) {
          const update = this.cloneArtifacts([normalizedEvent.artifact])[0];
          if (!update || update.sessionId !== session.id) return;
          let changed = false;
          for (const prior of session.turnsByTaskId.values()) for (const message of prior.assistantMessages || []) {
            const artifact = (message.artifacts || []).find(item => item.id === update.id);
            if (artifact) { Object.assign(artifact, update); changed = true; }
          }
          if (changed) {
            if (this._contentSource?.id === update.id) Object.assign(this._contentSource, update);
            for (const prior of session.turnsByTaskId.values()) if (prior.ui && isActiveSession) this.renderTurn(prior);
          } else { this._pendingArtifactUpdates ||= new Map(); this._pendingArtifactUpdates.set(update.id, update); }
          return;
        }
        if (normalizedEvent.type === 'assistant-artifacts' && turn) {
          const artifacts = this.cloneArtifacts(normalizedEvent.artifacts).map(artifact=>{
            const pending=this._pendingArtifactUpdates?.get(artifact.id);if(pending){this._pendingArtifactUpdates.delete(artifact.id);return {...artifact,...pending};}return artifact;
          }).filter((artifact) => (
            artifact.sessionId === session.id && artifact.turnId === turn.taskId
          ));
          if (!artifacts.length) return;
          let target = (turn.assistantMessages || []).slice().sort((left, right) => (
            Number(left.presentationOrder || 0) - Number(right.presentationOrder || 0)
          )).pop();
          if (!target) {
            target = {
              id: `artifact:${turn.taskId}`,
              text: '',
              phase: 'after-work',
              synthetic: true,
              presentationOrder: this.nextPresentationOrder(turn),
            };
            turn.assistantMessages.push(target);
          }
          const existing = this.cloneArtifacts(target.artifacts),byId=new Map(existing.map(artifact=>[artifact.id,artifact]));
          for(const artifact of artifacts){const current=byId.get(artifact.id);if(current)Object.assign(current,artifact);else{existing.push(artifact);byId.set(artifact.id,artifact);}}
          target.artifacts = existing;
          if (isActiveSession && artifacts.some(artifact=>artifact.kind==='audio')) {
            for(const prior of session.turnsByTaskId.values())if(prior.ui)this.renderTurn(prior);
          } else if (turn.ui) this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }
        if (normalizedEvent.type === 'turn-change-set' && turn && normalizedEvent.changeSet) {
          const firstDelivery = !turn.changeSet;
          turn.changeSet = normalizedEvent.changeSet;
          this.refreshImportedArtifacts(session);
          if (firstDelivery) {
            turn.viewState = turn.viewState || {};
            turn.viewState.changeExpanded = true;
          }
          if (turn.ui) this.renderChangeCard(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }
        if (normalizedEvent.type === 'task-ended') {
          const terminalStatus = normalizedEvent.terminalStatus === 'completed'
            ? 'completed'
            : normalizedEvent.terminalStatus === 'cancelled' ? 'cancelled' : 'failed';
          const result = this.endTask(turn, {
            taskId: normalizedEvent.taskId,
            status: terminalStatus,
            message: normalizedEvent.message,
            releaseRuntime: true,
          });
          if (!result.released) return;
          this.finalizeQueuedMessage(turn, terminalStatus, normalizedEvent.message);
          const queue = this.sessionQueueState(session.id);
          if (terminalStatus === 'completed') {
            if (!queue.paused) this.scheduleQueueDrain(queue.sessionId);
          } else {
            queue.paused = true;
            queue.pauseReason = terminalStatus;
            if (isActiveSession) this.renderQueueArea(queue.sessionId);
            this.refreshRenderedSessionStates();
          }
          this.persistSession(session.id, true);
          this.scheduleQueueDrain(session.id);
          return;
        }
        if (!turn) return;

        if (normalizedEvent.type === 'runtime-status') {
          if (turn.status !== 'running' || !normalizedEvent.threadId || !normalizedEvent.turnId
            || normalizedEvent.threadId !== session.threadId
            || !['context-compaction', 'reconnecting'].includes(normalizedEvent.kind)) return;
          if (normalizedEvent.status === 'cleared') {
            turn.activities = turn.activities.filter((activity) => activity.id !== normalizedEvent.id);
          } else {
            this.upsertTurnPresentationItem(turn, turn.activities, normalizedEvent);
          }
          if (turn.ui) this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if (normalizedEvent.type === 'approval-request' && turn.status === 'running') {
          turn.executionStarted = true;
          turn.executionStatus = 'waiting-for-approval';
          turn.liveState = null;
          this.upsertTurnPresentationItem(turn, turn.activities, {
            ...normalizedEvent,
            id: `approval:${String(normalizedEvent.requestId)}`,
            type: 'approval',
            status: 'waiting-for-approval',
            approvalState: 'pending',
            persistent: true,
          });
          if (turn.ui) this.renderTurn(turn);
          this.renderApprovalTray();
          this.refreshRenderedSessionStates();
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if (normalizedEvent.type === 'approval-updated') {
          const existing = turn.activities.find((activity) => (
            activity.type === 'approval' && activity.requestId === normalizedEvent.requestId
          ));
          if (!existing) return;
          const state = String(normalizedEvent.approvalState || 'expired');
          Object.assign(existing, normalizedEvent, {
            type: 'approval',
            approvalState: state,
            status: state === 'pending' ? 'waiting-for-approval' : state,
            submitting: false,
          });
          const stillPending = turn.activities.some((activity) => activity.type === 'approval' && activity.approvalState === 'pending');
          turn.executionStatus = stillPending ? 'waiting-for-approval' : 'running';
          if (!stillPending && !(this._codexStopPending && session.id === this.getRunningSessionId())) this.returnToThinking(turn, '正在继续执行');
          if (turn.ui) this.renderTurn(turn);
          this.renderApprovalTray();
          this.refreshRenderedSessionStates();
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if (normalizedEvent.type === 'tool_guard_outcome') {
          if (!Array.isArray(turn.guardTraces)) turn.guardTraces = [];
          this.upsertById(turn.guardTraces, normalizedEvent);
          linkToolActivitiesToGuardTraces(turn.activities, turn.guardTraces);
          reconcileToolRetries(turn.activities);
          if (turn.ui) this.renderTurn(turn);
          return;
        }

        if (normalizedEvent.type === 'thread') {
          const incomingThreadId = String(normalizedEvent.threadId || '').trim();
          if (!incomingThreadId) return;
          if (session.threadId && session.threadId !== incomingThreadId) {
            console.error(
              `[AI Copilot] Refused inconsistent thread binding for session ${session.id}: `
              + `expected=${session.threadId} actual=${incomingThreadId}`
            );
            return;
          }
          session.threadId = incomingThreadId;
          if (isActiveSession) this._codexThreadId = incomingThreadId;
          return;
        }

        if (normalizedEvent.type === 'message' && turn.status === 'running') {
          const text = String(normalizedEvent.text || '').trim();
          if (!text) return;
          const id = String(normalizedEvent.id || `message:${turn.assistantMessages.length}`);
          const existing = turn.assistantMessages.find((message) => message.id === id);
          const phase = existing ? existing.phase : this.hasStructuredWork(turn) ? 'after-work' : 'before-work';
          this.upsertTurnPresentationItem(turn, turn.assistantMessages, {
            id, text, phase, createdAt: existing?.createdAt || normalizedEvent.timestamp || Date.now(), updatedAt: Date.now(),
          });
          turn.hasAgentText = true;
          turn.liveState = normalizedEvent.status === 'running'
            ? { id: 'typing', state: 'typing', title: '正在回复', status: 'running' }
            : turn.liveState;
          this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if (normalizedEvent.type === 'working' && turn.status === 'running') {
          turn.liveState = {
            ...normalizedEvent,
            state: normalizedEvent.state || 'thinking',
            status: 'running',
          };
          this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if (normalizedEvent.type === 'plan' && turn.status === 'running') {
          turn.plan = normalizedEvent;
          turn.liveState = normalizedEvent.status === 'running'
            ? { id: 'planning', state: 'planning', title: '正在制定计划', status: 'running' }
            : { id: 'thinking', state: 'thinking', title: '正在思考', status: 'running' };
          this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if ((normalizedEvent.type === 'tool' || normalizedEvent.type === 'command') && turn.status === 'running') {
          turn.executionStarted = true;
          this.upsertTurnPresentationItem(turn, turn.activities, normalizedEvent);
          if (normalizedEvent.type === 'tool') {
            linkToolActivitiesToGuardTraces(turn.activities, turn.guardTraces || []);
            reconcileToolRetries(turn.activities);
          }
          turn.liveState = normalizedEvent.status === 'running'
            || normalizedEvent.status === 'failed'
            || normalizedEvent.status === 'blocked'
            ? null
            : { id: 'thinking', state: 'thinking', title: '正在思考', status: 'running' };
          this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if ((normalizedEvent.type === 'file_change' || normalizedEvent.type === 'cocos_change' || normalizedEvent.type === 'state_guard') && turn.status === 'running') {
          turn.executionStarted = true;
          this.upsertTurnPresentationItem(turn, turn.activities, normalizedEvent);
          if (normalizedEvent.type === 'state_guard') {
            reconcileToolRetries(turn.activities);
            turn.liveState = null;
          }
          else this.returnToThinking(turn);
          this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if (normalizedEvent.type === 'validation' && turn.status === 'running') {
          turn.executionStarted = true;
          this.upsertTurnPresentationItem(turn, turn.validation, normalizedEvent);
          if (normalizedEvent.status === 'running') {
            turn.liveState = { id: 'validating', state: 'working', title: '正在验证', status: 'running' };
          } else {
            this.returnToThinking(turn);
          }
          this.renderTurn(turn);
          if (isVisibleConversation) this.scrollActivityToEnd();
          return;
        }

        if (normalizedEvent.type === 'completed') {
          this.finishCodexTurn(turn, 'completed');
          return;
        }
        if (normalizedEvent.type === 'failed') {
          const providerError = normalizedEvent.detail
            ? { message: normalizedEvent.message, detail: normalizedEvent.detail }
            : normalizeProviderError(normalizedEvent.message, turn?.providerId || session.providerId);
          this.finishCodexTurn(turn, 'failed', providerError.message, providerError.detail);
        }
      } finally {
        session.updatedAt = Date.now();
        this.persistSession(session.id, [
          'thread', 'completed', 'failed', 'task-ended', 'turn-change-set', 'approval-updated', 'assistant-artifacts', 'artifact-updated',
        ].includes(normalizedEvent.type));
      }
    },

    globalContextDescriptor() {
      const root = this.$.root;
      if (!root || typeof root.getBoundingClientRect !== 'function') return null;
      const rect = root.getBoundingClientRect();
      if (!rect || rect.width <= 0 || rect.height <= 0) return null;
      let webFrame = null;
      try {
        const electron = require('electron');
        webFrame = electron && electron.webFrame;
      } catch (error) {
        return null;
      }
      const frameRoutingId = webFrame && Number(webFrame.routingId);
      const rendererPid = typeof process !== 'undefined' ? Number(process.pid) : 0;
      if (
        !Number.isInteger(frameRoutingId)
        || !Number.isInteger(rendererPid)
        || rendererPid <= 0
      ) return null;
      const ownerDocument = root.ownerDocument || document;
      const ownerWindow = ownerDocument.defaultView || (typeof window !== 'undefined' ? window : null);
      return {
        contextId: this._globalContextId,
        panelName: `${EXTENSION_NAME}.default`,
        rendererPid,
        frameRoutingId,
        pageURL: ownerWindow && ownerWindow.location ? String(ownerWindow.location.href || '') : '',
        visible: true,
        bounds: {
          x: rect.x,
          y: rect.y,
          width: rect.width,
          height: rect.height,
        },
      };
    },

    async registerGlobalContextMenu() {
      if (this._panelClosing || !this._globalContextId) return false;
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') return false;
      const descriptor = this.globalContextDescriptor();
      if (!descriptor) return false;
      try {
        const result = await Editor.Message.request(
          EXTENSION_NAME,
          'register-global-context-menu',
          descriptor
        );
        this._globalContextRegistered = Boolean(result && result.registered);
        return this._globalContextRegistered;
      } catch (error) {
        this._globalContextRegistered = false;
        console.warn(`[AI Copilot] Unable to register the scoped native context menu: ${error.message}`);
        return false;
      }
    },

    scheduleGlobalContextRegistration() {
      if (this._panelClosing || this._globalContextRegistrationFrame != null) return;
      const schedule = typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : (callback) => setTimeout(callback, 0);
      this._globalContextRegistrationFrame = schedule(() => {
        this._globalContextRegistrationFrame = null;
        this.registerGlobalContextMenu();
      });
    },

    cancelGlobalContextRegistration() {
      if (this._globalContextRegistrationFrame == null) return;
      if (typeof cancelAnimationFrame === 'function') {
        cancelAnimationFrame(this._globalContextRegistrationFrame);
      } else {
        clearTimeout(this._globalContextRegistrationFrame);
      }
      this._globalContextRegistrationFrame = null;
    },

    unregisterGlobalContextMenu() {
      this.cancelGlobalContextRegistration();
      this._globalContextRegistered = false;
      if (
        !this._globalContextId
        || !global.Editor
        || !Editor.Message
        || typeof Editor.Message.request !== 'function'
      ) return;
      try {
        const request = Editor.Message.request(
          EXTENSION_NAME,
          'unregister-global-context-menu',
          { contextId: this._globalContextId }
        );
        if (request && typeof request.catch === 'function') request.catch(() => {});
      } catch (error) {
        // Extension reload can tear down the main process before the panel closes.
      }
    },

    resolveComposerClipboard() {
      if (this._composerClipboardResolved) return this._composerClipboard;
      this._composerClipboardResolved = true;
      this._composerClipboard = null;
      try {
        const electron = require('electron');
        if (
          electron
          && electron.clipboard
          && typeof electron.clipboard.readText === 'function'
          && typeof electron.clipboard.writeText === 'function'
        ) {
          this._composerClipboard = electron.clipboard;
        }
      } catch (error) {
        // Browser Clipboard is used below when Electron's renderer API is unavailable.
      }
      return this._composerClipboard;
    },

    browserClipboard() {
      return typeof navigator !== 'undefined' && navigator.clipboard
        ? navigator.clipboard
        : null;
    },

    async writeComposerClipboardText(text) {
      const value = String(text || '');
      const electronClipboard = this.resolveComposerClipboard();
      try {
        if (electronClipboard) {
          electronClipboard.writeText(value);
          return true;
        }
        const clipboard = this.browserClipboard();
        if (clipboard && typeof clipboard.writeText === 'function') {
          await clipboard.writeText(value);
          return true;
        }
      } catch (error) {
        console.warn(`[AI Copilot] Clipboard write failed: ${error.message}`);
      }
      return false;
    },

    composerSelection() {
      const input = this.$.composerInput;
      const length = String(input && input.value || '').length;
      const rawStart = input && input.selectionStart;
      const rawEnd = input && input.selectionEnd;
      const start = Math.max(0, Math.min(length, Number.isInteger(rawStart) ? rawStart : length));
      const end = Math.max(start, Math.min(length, Number.isInteger(rawEnd) ? rawEnd : start));
      return { start, end };
    },

    replaceComposerSelection(text, selection = this.composerSelection()) {
      const input = this.$.composerInput;
      if (!input) return;
      const value = String(text || '');
      input.focus();
      if (typeof input.setRangeText === 'function') {
        input.setRangeText(value, selection.start, selection.end, 'end');
      } else {
        input.value = `${input.value.slice(0, selection.start)}${value}${input.value.slice(selection.end)}`;
        const caret = selection.start + value.length;
        if (typeof input.setSelectionRange === 'function') input.setSelectionRange(caret, caret);
      }
      const ownerWindow = input.ownerDocument && input.ownerDocument.defaultView;
      const EventConstructor = ownerWindow && ownerWindow.Event
        ? ownerWindow.Event
        : typeof Event === 'function' ? Event : null;
      if (EventConstructor && typeof input.dispatchEvent === 'function') {
        input.dispatchEvent(new EventConstructor('input', { bubbles: true, composed: true }));
      }
      this.resizeComposer();
      this.updateComposerActionState();
    },

    handleComposerKeydown(event) {
      const key = String(event.key || '').toLowerCase();
      if ((event.ctrlKey || event.metaKey) && (key === 'x' || key === 'c' || key === 'v')) {
        event.stopPropagation();
        return;
      }

      const keyCode = Number(event.keyCode || event.which || 0);
      const isEnter = event.key === 'Enter'
        || event.code === 'Enter'
        || event.code === 'NumpadEnter'
        || keyCode === 13;
      const isComposing = Boolean(event.isComposing) || keyCode === 229;
      if (isComposing) {
        event.stopPropagation();
        return;
      }
      if (!isEnter) return;

      if (event.shiftKey) {
        event.stopPropagation();
        if (event.defaultPrevented) this.replaceComposerSelection('\n');
        return;
      }

      event.preventDefault();
      event.stopPropagation();
      this.handleComposerSubmit();
    },

    resizeComposer() {
      const input = this.$.composerInput;
      if (!input) return;
      input.style.height = 'auto';
      input.style.height = `${Math.min(126, Math.max(42, input.scrollHeight))}px`;
      if (this._activePinPopover?.source === 'composer') this.positionPinPopover();
      if (this.$.permissionMenu && !this.$.permissionMenu.hidden) this.positionPermissionMenu();
    },

    async stopCurrentTask() {
      if (!this.isCurrentSessionExecuting() || this._codexStopPending) return;
      this.clearQueue({ pause: true, reason: 'user-stop' });
      const taskId = this._activeCodexTaskId;
      const turn = taskId ? this._codexTurns.get(taskId) : null;
      if (turn && turn.status === 'running') {
        turn.liveState = { id: 'stopping', state: 'working', title: '正在停止', status: 'running' };
        this.renderTurn(turn);
      }
      this.setComposerBusy(true, true);
      try {
        const stopped = await Editor.Message.request(
          EXTENSION_NAME,
          'cancel-codex-session',
          { sessionId: this._codexSessionId, dispose: false }
        );
        if (!stopped && turn) this.finishCodexTurn(turn, 'failed', '无法停止当前 Codex 任务。');
      } catch (error) {
        if (turn) this.finishCodexTurn(turn, 'failed', error.message);
      }
    },

    async startCodexTask(task, options = {}) {
      const taskPayload = this.normalizeTaskPayload(task);
      const displayText = taskPayload.text;
      const attachments = taskPayload.attachments;
      const pins = taskPayload.pins;
      const prompt = taskPayload.executionPrompt;
      if ((!displayText.trim() && !attachments.length && !pins.length)
        || this._codexTaskRunning || this._activeCodexTaskId) {
        return false;
      }
      const session = options.session || this.activeSession();
      if (!session) return false;
      if (this._activeExecutionSessionId && this._activeExecutionSessionId !== session.id) return false;
      this._activeExecutionSessionId = session.id;
      const queuedMessage = options.queuedMessage || null;
      const selectedModel = this.modelForSelection(taskPayload);
      const supportsImageInput = !selectedModel
        || (selectedModel.inputModalities || []).includes('image');
      if (!supportsImageInput && attachments.some((attachment) => this.isImageAttachment(attachment))) {
        this.showComposerToast('当前模型不支持直接图像输入；图片仍作为文件附件提供', 3200);
      }
      if (queuedMessage && queuedMessage.sessionId !== session.id) {
        queuedMessage.status = 'error';
        queuedMessage.error = 'Queue session mismatch.';
        this.pauseQueue('session-mismatch', session.id);
        return false;
      }

      console.log(
        `[AI Copilot] Task submitted: text=${displayText.length} chars, attachments=${attachments.length}, pins=${pins.length}`
      );
      if (this.$.emptyState && this._sessionView === 'conversation') this.$.emptyState.hidden = true;
      if (!session.messages.length && session.title === '新会话') {
        session.title = this.deriveSessionTitle(
          displayText || attachments[0] && attachments[0].title || pins[0] && `钉住 ${pins[0].label}`
        );
        this.updateSessionHeader();
      }
      this.touchSession(session);
      const taskId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const turn = this.createTurn(taskId, displayText, attachments, pins, prompt, session);
      turn.providerId = taskPayload.providerId;
      turn.modelId = taskPayload.modelId;
      turn.reasoningEffort = taskPayload.reasoningEffort;
      turn.queueMessageId = queuedMessage ? queuedMessage.id : '';
      if (queuedMessage) {
        queuedMessage.status = 'running';
        this.sessionQueueState(session.id).activeMessageId = queuedMessage.id;
        this.renderQueueArea(session.id);
      }
      this._taskSessionIds.set(taskId, session.id);
      this._activeCodexTaskId = taskId;
      this.setComposerBusy(true);
      this.persistSession(session.id, true);
      if (this._sessionView === 'conversation' && session.id === this._activeSessionId) this.scrollActivityToEnd({ force: true });

      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        const message = 'Editor.Message.request 不可用。';
        this.endTask(turn, { taskId, status: 'failed', message, releaseRuntime: true });
        this.finalizeQueuedMessage(turn, 'failed', message);
        this.pauseQueue('failed', session.id);
        this.scheduleQueueDrain(session.id);
        return false;
      }
      try {
        if (session.restored && !await this.ensureSessionRestored(session)) {
          throw new Error(session.restoreError || '原 Codex 会话暂时无法恢复，请稍后重试。');
        }
        const selection = await this.readCurrentSelectionSnapshot();
        if (this._codexStopPending || this._panelClosing) {
          this.endTask(turn, { taskId, status: 'cancelled', releaseRuntime: true });
          this.finalizeQueuedMessage(turn, 'cancelled');
          this.scheduleQueueDrain(session.id);
          return false;
        }
        const response = await Editor.Message.request(
          EXTENSION_NAME,
          'run-codex-task',
          {
            prompt,
            userRequest: displayText,
            attachments: this.cloneTextAttachments(attachments),
            pins: this.clonePinnedContexts(pins),
            selection,
            sessionId: session.id,
            threadId: session.threadId || '',
            permissionModeId: session.permissionModeId || '',
            providerId: taskPayload.providerId,
            modelId: taskPayload.modelId,
            reasoningEffort: taskPayload.reasoningEffort,
            supportsImageInput,
            taskId,
          }
        );
        if (!response || response.accepted !== true) {
          const message = response && response.message
            ? response.message
            : 'Codex 任务没有被接受。';
          this.endTask(turn, { taskId, status: 'failed', message, releaseRuntime: true });
          this.finalizeQueuedMessage(turn, 'failed', message);
          this.pauseQueue('failed', session.id);
          this.scheduleQueueDrain(session.id);
          return false;
        }
        const responseThreadId = String(response.threadId || '').trim();
        if (responseThreadId) {
          if (session.threadId && session.threadId !== responseThreadId) {
            console.error(
              `[AI Copilot] Refused inconsistent thread response for session ${session.id}: `
              + `expected=${session.threadId} actual=${responseThreadId}`
            );
          } else {
            session.threadId = responseThreadId;
            if (session.id === this._activeSessionId) this._codexThreadId = responseThreadId;
            this.persistSession(session.id, true);
          }
        }
        return true;
      } catch (error) {
        const providerError = normalizeProviderError(error, taskPayload.providerId);
        this.endTask(turn, {
          taskId,
          status: 'failed',
          message: providerError.message,
          detail: providerError.detail,
          releaseRuntime: true,
        });
        this.finalizeQueuedMessage(turn, 'failed', providerError.message);
        this.pauseQueue('failed', session.id);
        if (queuedMessage && session.restoreState === 'failed') queuedMessage.status = 'queued';
        this.persistSession(session.id, true);
        this.scheduleQueueDrain(session.id);
        return false;
      }
    },

    async submitComposerPrompt(draftInput = null) {
      const draft = draftInput && typeof draftInput === 'object'
        ? {
          text: String(draftInput.text || ''),
          attachments: this.cloneTextAttachments(draftInput.attachments),
          pins: this.dedupePinnedContexts(draftInput.pins || []),
        }
        : this.composerDraftSnapshot();
      if (!draft.text.trim() && !draft.attachments.length && !draft.pins.length) return false;

      if (this._sessionView === 'home' || !this.activeSession()) {
        const session = this.createSession();
        this.activateSession(session.id);
        this.clearComposerDraft();
        this._homeDraft = { text: '', attachments: [], pins: [] };
      }

      const queue = this.sessionQueueState();
      const hasPendingQueue = this.pendingQueueMessages(queue).length > 0;

      if (hasPendingQueue || this.getRunningSessionId()) {
        const queuedMessage = this.enqueueMessage(draft.text, draft.attachments, draft.pins);
        if (!queuedMessage) return false;
        this.clearComposerDraft();
        // Sending new text must not implicitly replay a restored/failed queue.
        if (!queue.paused) this.scheduleQueueDrain(queue.sessionId);
        return true;
      }

      if (queue) {
        queue.paused = false;
        queue.pauseReason = '';
      }
      const started = await this.startCodexTask(draft);
      if (started) this.clearComposerDraft();
      else {
        this.restoreComposerDraft(draft);
        this.saveVisibleDraft(true);
      }
      return started;
    },

    async sendTask() {
      return this.handleComposerAction();
    },

    updateSessionTooltip() {
      if (!this.$.sessionStatus) return;
      const mode = this._editorMode === 'Preview' ? 'Preview' : 'Editor';
      this.$.sessionStatus.setAttribute('title', `${mode} mode · Main.scene`);
    },

    updateEditorMode(mode) {
      const nextMode = mode === 'Preview' ? 'Preview' : 'Editor';
      if (this.$.modeLabel) this.$.modeLabel.textContent = nextMode;
      this._editorMode = nextMode;
      this.updateSessionTooltip();
    },

    updateMcpServerStatus(status) {
      const nextStatus = status === 'started' || status === 'stopped' ? status : 'unknown';
      const label = nextStatus === 'started'
        ? 'MCP Server Started'
        : nextStatus === 'stopped' ? 'MCP Server Stopped' : 'MCP Unknown';
      this._mcpServerStatus = nextStatus;
      if (this.$.connectionDot) {
        this.$.connectionDot.classList.toggle('is-started', nextStatus === 'started');
        this.$.connectionDot.classList.toggle('is-stopped', nextStatus === 'stopped');
        this.$.connectionDot.classList.toggle('is-unknown', nextStatus === 'unknown');
        this.$.connectionDot.setAttribute('title', label);
        this.$.connectionDot.setAttribute('aria-label', label);
      }
      this.updateSessionTooltip();
    },

    async refreshEditorMode() {
      if (this._previewStateRequestInFlight || this._previewStateSyncStopped) return;
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') return;
      this._previewStateRequestInFlight = true;
      try {
        const snapshot = await Editor.Message.request(EXTENSION_NAME, 'get-environment-snapshot', { includePreviewToolbar:true });
        if (this._previewStateSyncStopped) return;
        this.updateEditorMode(snapshot?.previewToolbar?.running === true ? 'Preview' : 'Editor');
        this._previewStateReadFailed = false;
      } catch (error) {
        if (this._previewStateSyncStopped) return;
        if (!this._previewStateReadFailed) {
          console.warn(`[AI Copilot] Unable to read Preview state: ${error.message}`);
        }
        this._previewStateReadFailed = true;
      } finally {
        this._previewStateRequestInFlight = false;
      }
    },

    async refreshMcpServerStatus() {
      if (this._mcpStatusRequestInFlight || this._previewStateSyncStopped) return;
      if (!global.Editor || !Editor.Message || typeof Editor.Message.request !== 'function') {
        this.updateMcpServerStatus('unknown');
        return;
      }
      this._mcpStatusRequestInFlight = true;
      try {
        const snapshot = await Editor.Message.request('cocos-ai-copilot', 'get-environment-snapshot');
        if (this._previewStateSyncStopped) return;
        if (!snapshot || !Array.isArray(snapshot.mcpServers)) {
          throw new Error('Cocos runtime discovery returned an unsupported MCP server status.');
        }
        const connected = snapshot.mcpServers.some((server) => server?.status === 'connected');
        this.updateMcpServerStatus(connected ? 'started' : 'stopped');
        this._mcpStatusReadFailed = false;
      } catch (error) {
        if (this._previewStateSyncStopped) return;
        this.updateMcpServerStatus('unknown');
        if (!this._mcpStatusReadFailed) {
          console.warn(`[AI Copilot] Unable to read Cocos MCP server status: ${error.message}`);
        }
        this._mcpStatusReadFailed = true;
      } finally {
        this._mcpStatusRequestInFlight = false;
      }
    },

    refreshToolbarStatus() {
      return Promise.allSettled([this.refreshEditorMode(), this.refreshMcpServerStatus()]);
    },

    startEditorModeSync() {
      this.stopEditorModeSync();
      this._previewStateSyncStopped = false;
      this.refreshToolbarStatus();
      this._previewStatePollTimer = setInterval(
        () => this.refreshToolbarStatus(),
        PREVIEW_STATE_POLL_INTERVAL_MS
      );
    },

    stopEditorModeSync() {
      this._previewStateSyncStopped = true;
      if (this._previewStatePollTimer) {
        clearInterval(this._previewStatePollTimer);
        this._previewStatePollTimer = null;
      }
    },
  },

  ready() {
    this._environmentRefreshState = 'idle';
    this._environmentRequestId = 0;
    this._environmentSnapshot = null;
    this._toolsView = { type: 'overview' };
    this._permissionModes = [];
    this._permissionModesStatus = 'loading';
    this._permissionInheritedModeId = '';
    this._permissionRequestId = 0;
    this._newSessionPermissionModeId = null;
    this._modelServicesSnapshot = null;
    this._modelServicesRequestId = 0;
    this._agentId = 'codex';
    this._modelMenuProviderId = '';
    this._newSessionModelSelection = { providerId: 'openai', modelId: '', reasoningEffort: '' };
    this._persistenceReady = false;
    this._persistenceError = '';
    this._activeExecutionSessionId = '';
    this._homeDraft = { text: '', attachments: [], pins: [] };
    this._sessions = new Map();
    this._taskSessionIds = new Map();
    this._activeSessionId = '';
    this._sessionQueues = new Map();
    this._codexSessionId = '';
    this._codexThreadId = '';
    this._codexTurns = new Map();
    this._sessionView = 'home';
    this._allSessionsQuery = '';
    this._panelClosing = false;
    this._activeCodexTaskId = '';
    this._codexTaskRunning = false;
    this._codexStopPending = false;
    this._promptObservers = new Set();
    this._queueContextMessageId = '';
    this._followLatestOutput = true;
    this._scrollToLatestInProgress = false;
    this._scrollToLatestAnimationFrame = null;
    this._composerClipboard = null;
    this._composerClipboardResolved = false;
    this._attachmentSelectPending = false;
    this._attachmentThumbnailUrls = new Map();
    this._thumbnailRenderGeneration = 0;
    this._attachmentIngestStates = [];
    this._consumedComposerPasteEvents = new WeakSet();
    this._composerAttachments = [];
    this._composerPins = [];
    this._activePinPopover = null;
    this._pinPopoverCloseTimer = null;
    this._pinPopoverPreservedScrollTop = null;
    this._pendingPins = [];
    this._pinModeActive = false;
    this._pinModeGeneration = 0;
    this._fileDragDepth = 0;
    this._pinSelectionSerial = Promise.resolve();
    this._composerToastTimer = null;
    this._nativeContextMenuPending = false;
    this._globalContextId = this.createOpaqueId('panel-context');
    this._globalContextRegistered = false;
    this._globalContextRegistrationFrame = null;
    this._globalContextResizeObserver = null;
    this._globalContextWindow = null;
    this._codexEventHandler = (event) => this.handleCodexEvent(event);
    this._newSessionContextHandler = () => this.requestNewSession();
    this._modelServicesChangedHandler = () => this.refreshModelServices();
    this._sessionLifecycleUpdates = new Map();
    this._localSessionProjectKey = '';
    this._sessionLifecyclePending = '';
    this._sessionLifecycleHandler = (result) => this.applySessionLifecycle(result);
    if (global.Editor && Editor.Message && typeof Editor.Message.addBroadcastListener === 'function') {
      Editor.Message.addBroadcastListener(CODEX_EVENT_CHANNEL, this._codexEventHandler);
      Editor.Message.addBroadcastListener(NEW_SESSION_EVENT_CHANNEL, this._newSessionContextHandler);
      Editor.Message.addBroadcastListener(MODEL_SERVICES_EVENT_CHANNEL, this._modelServicesChangedHandler);
      Editor.Message.addBroadcastListener(SESSION_LIFECYCLE_EVENT_CHANNEL, this._sessionLifecycleHandler);
    }

    this._sendClickHandler = () => this.sendTask();
    this._attachClickHandler = () => this.selectComposerAttachments();
    this._agentClickHandler = () => this.toggleAgentMenu();
    this._toolsClickHandler = () => this.toggleToolsPopover();
    this._modelClickHandler = () => this.toggleModelMenu();
    this._reasoningClickHandler = () => this.toggleReasoningMenu();
    this._settingsClickHandler = () => this.openSettings();
    this._onboardingChatGptHandler = () => this.handleOnboardingChatGpt();
    this._onboardingOpenAiKeyHandler = () => this.openSettings('openai');
    this._onboardingDeepSeekKeyHandler = () => this.openSettings('deepseek');
    this._permissionClickHandler = () => this.togglePermissionMenu();
    this._sendMouseDownHandler = (event) => event.preventDefault();
    this._composerInputHandler = () => {
      this.resizeComposer();
      this.updateComposerActionState();
    };
    this._composerPasteHandler = (event) => this.handleComposerPaste(event);
    this._composerKeydownHandler = (event) => this.handleComposerKeydown(event);
    this._queueContextMenuMouseDownHandler = (event) => event.preventDefault();
    this._queueEditClickHandler = () => this.editQueuedMessage(this._queueContextMessageId);
    this._queueClearClickHandler = () => this.clearQueue();
    this._pinEntryClickHandler = () => {
      if (this._pinModeActive) {
        const pins = this.dedupePinnedContexts(this._composerPins || [], this._pendingPins || []);
        this.toggleLockedPinPopover(this.$.pinEntryButton, pins, {
          source: 'composer',
          getPins: () => this.dedupePinnedContexts(this._composerPins || [], this._pendingPins || []),
        });
      } else this.enterPinMode();
    };
    this._pinEntryMouseEnterHandler = () => {
      if ((this._composerPins || []).length && !this._pinModeActive) {
        this.showPinPopover(this.$.pinCount, this._composerPins, {
          source: 'composer',
          editable: true,
          getPins: () => this._composerPins || [],
        });
      }
    };
    this._pinEntryMouseLeaveHandler = () => this.schedulePinPopoverClose(this.$.pinCount);
    this._pinCountClickHandler = (event) => {
      event.stopPropagation();
      this.toggleLockedPinPopover(this.$.pinCount, this._composerPins || [], {
        source: 'composer',
        editable: true,
        getPins: () => this._composerPins || [],
      });
    };
    this._pinPopoverMouseEnterHandler = () => this.cancelPinPopoverClose();
    this._pinPopoverMouseLeaveHandler = () => this.schedulePinPopoverClose();
    this._cancelPinModeClickHandler = () => this.cancelPinMode();
    this._confirmPinModeClickHandler = () => {
      this.confirmPinMode().catch((error) => {
        console.warn(`[AI Copilot][Pins] Unable to confirm pin mode: ${error.message}`);
      });
    };
    this._pinDragEnterHandler = (event) => this.handleComposerDragEnter(event);
    this._pinDragOverHandler = (event) => this.handleComposerDragOver(event);
    this._pinDragLeaveHandler = (event) => this.handleComposerDragLeave(event);
    this._pinDropHandler = (event) => {
      Promise.resolve(this.handleComposerDrop(event)).catch((error) => {
        this.clearFileDragState();
        this.clearPinDragState();
        console.warn(`[AI Copilot] Composer drop failed: ${error.message}`);
        this.showComposerToast('无法处理拖入内容');
      });
    };
    this._composerEventRoot = typeof this.$.composerInput.getRootNode === 'function'
      ? this.$.composerInput.getRootNode()
      : this.$.composerInput.ownerDocument;
    this._composerDismissRoot = this.$.composerInput.ownerDocument || this._composerEventRoot;
    this._composerEventWindow = this.$.composerInput.ownerDocument?.defaultView
      || (typeof window !== 'undefined' ? window : null);
    this._composerContextDismissHandler = (event) => {
      this.dismissComposerPickers(event);
      const sessionMenu = this.$.sessionMoreMenu;
      if (!this.$.queueContextMenu.hidden && (
        typeof event.composedPath === 'function'
          ? event.composedPath().includes(this.$.queueContextMenu)
          : this.$.queueContextMenu.contains(event.target)
      )) return;
      if (sessionMenu && !sessionMenu.hidden && (
        typeof event.composedPath === 'function'
          ? event.composedPath().includes(sessionMenu)
          : sessionMenu.contains(event.target)
      )) return;
      if (this.$.renameSessionDialog && !this.$.renameSessionDialog.hidden) return;
      if (
        this.$.sessionHistory
        && !this.$.sessionHistory.hidden
        && !this.$.sessionHistory.contains(event.target)
        && event.target !== this.$.sessionHistoryButton
        && event.target !== this.$.sessionTitleButton
      ) this.hideSessionHistory();
      if (
        this.$.sessionMoreMenu
        && !this.$.sessionMoreMenu.hidden
        && event.target !== this.$.sessionMoreButton
      ) this.hideSessionMoreMenu();
      if (!this.$.queueContextMenu.hidden) this.hideQueueContextMenu();
    };
    this._composerWindowBlurHandler = () => this.dismissComposerPickers();
    this._composerContextEscapeHandler = (event) => {
      if (event.key === 'Escape' && this.$.permissionMenu && !this.$.permissionMenu.hidden) {
        event.preventDefault();
        event.stopPropagation();
        this.closePermissionMenu();
        this.$.permissionButton.focus();
        return;
      }
      if (event.key === 'Escape' && this.$.toolsPopover && !this.$.toolsPopover.hidden) {
        event.preventDefault();
        event.stopPropagation();
        this.closeToolsPopover();
        return;
      }
      if (event.key === 'Escape' && this.$.modelMenu && !this.$.modelMenu.hidden) {
        event.preventDefault();
        event.stopPropagation();
        this.closeModelMenu();
        this.$.modelButton.focus();
        return;
      }
      if (event.key === 'Escape' && this.$.agentMenu && !this.$.agentMenu.hidden) {
        event.preventDefault();
        event.stopPropagation();
        this.closeAgentMenu();
        this.$.agentButton.focus();
        return;
      }
      if (event.key === 'Escape' && this.$.reasoningMenu && !this.$.reasoningMenu.hidden) {
        event.preventDefault();
        event.stopPropagation();
        this.closeReasoningMenu();
        this.$.reasoningButton.focus();
        return;
      }
      if (event.key === 'Escape' && this._pinModeActive) {
        event.preventDefault();
        event.stopPropagation();
        this.cancelPinMode();
        return;
      }
      if (event.key === 'Escape' && this._activePinPopover) {
        event.preventDefault();
        event.stopPropagation();
        this.closePinPopover();
        return;
      }
      if (
        event.key !== 'Escape'
        || (
          this.$.queueContextMenu.hidden
          && (!this.$.sessionHistory || this.$.sessionHistory.hidden)
          && (!this.$.sessionMoreMenu || this.$.sessionMoreMenu.hidden)
          && (!this.$.renameSessionDialog || this.$.renameSessionDialog.hidden)
        )
      ) return;
      event.preventDefault();
      event.stopPropagation();
      if (this.$.renameSessionDialog && !this.$.renameSessionDialog.hidden) {
        this.closeRenameSessionDialog();
        return;
      }
      if (!this.$.queueContextMenu.hidden) this.hideQueueContextMenu();
      if (this.$.sessionHistory && !this.$.sessionHistory.hidden) this.hideSessionHistory();
      if (this.$.sessionMoreMenu && !this.$.sessionMoreMenu.hidden) this.hideSessionMoreMenu();
    };
    this._sessionHistoryClickHandler = () => this.requestConversationBack();
    this._sessionTitleClickHandler = () => this.toggleTitleSessionSwitcher();
    this._newSessionClickHandler = () => this.requestNewSession();
    this._sessionSearchInputHandler = () => this.renderSessionList(this.$.sessionSearchInput.value);
    this._sessionMoreClickHandler = () => this.toggleSessionMoreMenu();
    this._renameSessionClickHandler = () => this.openRenameSessionDialog();
    this._renameSessionCancelHandler = () => this.closeRenameSessionDialog();
    this._renameSessionSaveHandler = () => this.saveRenamedSession();
    this._renameSessionInputHandler = () => {
      this.$.renameSessionSave.disabled = !String(this.$.renameSessionInput.value || '').trim();
    };
    this._renameSessionKeydownHandler = (event) => {
      if (event.key === 'Enter' && !event.isComposing && event.keyCode !== 229) {
        event.preventDefault();
        this.saveRenamedSession();
      } else if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        this.closeRenameSessionDialog();
      }
    };
    this._renameDialogPointerHandler = (event) => {
      if (event.target === this.$.renameSessionDialog) this.closeRenameSessionDialog();
    };
    this._activityScrollHandler = () => this.handleActivityScroll();
    this._scrollToLatestClickHandler = () => this.scrollActivityToEnd({ force: true, behavior: 'smooth' });
    this.$.sendButton.addEventListener('click', this._sendClickHandler);
    this.$.attachButton.addEventListener('click', this._attachClickHandler);
    this.$.agentButton.addEventListener('click', this._agentClickHandler);
    this.$.toolsButton.addEventListener('click', this._toolsClickHandler);
    this.$.modelButton.addEventListener('click', this._modelClickHandler);
    this.$.reasoningButton.addEventListener('click', this._reasoningClickHandler);
    this.$.settingsButton.addEventListener('click', this._settingsClickHandler);
    this.$.onboardingChatGpt.addEventListener('click', this._onboardingChatGptHandler);
    this.$.onboardingOpenAiKey.addEventListener('click', this._onboardingOpenAiKeyHandler);
    this.$.onboardingDeepSeekKey.addEventListener('click', this._onboardingDeepSeekKeyHandler);
    this.$.permissionButton.addEventListener('click', this._permissionClickHandler);
    this.$.sendButton.addEventListener('mousedown', this._sendMouseDownHandler);
    this.$.composerInput.addEventListener('input', this._composerInputHandler);
    this.$.composerInput.addEventListener('paste', this._composerPasteHandler, true);
    this.$.composerInput.addEventListener('keydown', this._composerKeydownHandler, true);
    this.$.queueContextMenu.addEventListener('mousedown', this._queueContextMenuMouseDownHandler);
    this.$.queueEditButton.addEventListener('click', this._queueEditClickHandler);
    this.$.queueClearButton.addEventListener('click', this._queueClearClickHandler);
    this.$.pinEntryButton.addEventListener('click', this._pinEntryClickHandler);
    this.$.pinCount.addEventListener('click', this._pinCountClickHandler);
    this.$.pinEntryButton.parentElement.addEventListener('mouseenter', this._pinEntryMouseEnterHandler);
    this.$.pinEntryButton.parentElement.addEventListener('mouseleave', this._pinEntryMouseLeaveHandler);
    this.$.composerPinPopover.addEventListener('mouseenter', this._pinPopoverMouseEnterHandler);
    this.$.composerPinPopover.addEventListener('mouseleave', this._pinPopoverMouseLeaveHandler);
    this.$.cancelPinModeButton.addEventListener('click', this._cancelPinModeClickHandler);
    this.$.confirmPinModeButton.addEventListener('click', this._confirmPinModeClickHandler);
    this.$.root.addEventListener('dragenter', this._pinDragEnterHandler);
    this.$.root.addEventListener('dragover', this._pinDragOverHandler);
    this.$.root.addEventListener('dragleave', this._pinDragLeaveHandler);
    this.$.root.addEventListener('drop', this._pinDropHandler);
    if (this._composerDismissRoot && typeof this._composerDismissRoot.addEventListener === 'function') {
      this._composerDismissRoot.addEventListener('pointerdown', this._composerContextDismissHandler, true);
    }
    if (this._composerEventRoot && typeof this._composerEventRoot.addEventListener === 'function') {
      this._composerEventRoot.addEventListener('keydown', this._composerContextEscapeHandler, true);
    }
    if (this._composerEventWindow && typeof this._composerEventWindow.addEventListener === 'function') {
      this._composerEventWindow.addEventListener('blur', this._composerWindowBlurHandler);
    }
    this.$.sessionHistoryButton.addEventListener('click', this._sessionHistoryClickHandler);
    this.$.sessionTitleButton.addEventListener('click', this._sessionTitleClickHandler);
    this.$.newSessionButton.addEventListener('click', this._newSessionClickHandler);
    this.$.sessionSearchInput.addEventListener('input', this._sessionSearchInputHandler);
    this.$.sessionMoreButton.addEventListener('click', this._sessionMoreClickHandler);
    this.$.renameSessionButton.addEventListener('click', this._renameSessionClickHandler);
    this._continueSessionClickHandler = () => this.requestContinueSession();
    this.$.continueSessionButton.addEventListener('click', this._continueSessionClickHandler);
    this._archiveSessionClickHandler = () => this.requestSessionLifecycle('archive');
    this._deleteSessionClickHandler = () => this.requestDeleteSession();
    this.$.archiveSessionButton.addEventListener('click', this._archiveSessionClickHandler);
    this.$.deleteSessionButton.addEventListener('click', this._deleteSessionClickHandler);
    this.$.renameSessionCancel.addEventListener('click', this._renameSessionCancelHandler);
    this.$.renameSessionSave.addEventListener('click', this._renameSessionSaveHandler);
    this.$.renameSessionInput.addEventListener('input', this._renameSessionInputHandler);
    this.$.renameSessionInput.addEventListener('keydown', this._renameSessionKeydownHandler);
    this.$.renameSessionDialog.addEventListener('pointerdown', this._renameDialogPointerHandler);
    this.$.activityScroller.addEventListener('scroll', this._activityScrollHandler, { passive: true });
    this.$.scrollToLatestButton.addEventListener('click', this._scrollToLatestClickHandler);
    if (typeof ResizeObserver === 'function') {
      this._threadResizeObserver = new ResizeObserver(() => {
        if (this._followLatestOutput) this.scrollActivityToEnd();
        else this.updateScrollToLatestButton();
      });
      this._threadResizeObserver.observe(this.$.activityScroller);
      this._threadResizeObserver.observe(this.$.activityContent);
      this._globalContextResizeObserver = new ResizeObserver(() => {
        this.scheduleGlobalContextRegistration();
      });
      this._globalContextResizeObserver.observe(this.$.root);
      this._pinPopoverResizeObserver = new ResizeObserver(() => {
        if (this._activePinPopover) this.positionPinPopover();
        if (this.$.permissionMenu && !this.$.permissionMenu.hidden) this.positionPermissionMenu();
        if (this.$.modelMenu && !this.$.modelMenu.hidden) this.positionModelMenu();
        if (this.$.agentMenu && !this.$.agentMenu.hidden) this.positionPicker(this.$.agentMenu, this.$.agentButton);
        if (this.$.reasoningMenu && !this.$.reasoningMenu.hidden) this.positionPicker(this.$.reasoningMenu, this.$.reasoningButton);
        if (this.$.toolsPopover && !this.$.toolsPopover.hidden) {
          this.positionToolsPopover();
        }
      });
      this._pinPopoverResizeObserver.observe(this.$.root);
      this._pinPopoverResizeObserver.observe(this.$.composerSurface);
    }
    this._globalContextWindow = this.$.root
      && this.$.root.ownerDocument
      && this.$.root.ownerDocument.defaultView;
    this._globalContextWindowResizeHandler = () => this.scheduleGlobalContextRegistration();
    this._globalContextPointerUpHandler = () => this.scheduleGlobalContextRegistration();
    if (this._globalContextWindow && typeof this._globalContextWindow.addEventListener === 'function') {
      this._globalContextWindow.addEventListener('resize', this._globalContextWindowResizeHandler);
      this._globalContextWindow.addEventListener('pointerup', this._globalContextPointerUpHandler, true);
    }
    this.showChatsHome({ focusComposer: false });
    this._sessionsLoaded = this.restoreLocalSessions();
    this.refreshEnvironment();
    this.refreshPermissionModes();
    this.refreshModelServices(true);
    this.renderComposerAttachments();
    this.renderComposerPins();
    this.setComposerBusy(false);
    this.renderPinMode();
    this.resizeComposer();
    this.scrollActivityToEnd({ force: true });
    this._durationTimer = setInterval(() => {
      if (!this._activeCodexTaskId) return;
      const turn = this._codexTurns.get(this._activeCodexTaskId);
      if (turn && turn.status === 'running') this.renderTurnMeta(turn);
    }, 1000);
    this.scheduleGlobalContextRegistration();
    this.startEditorModeSync();
  },

  async close() {
    this._panelClosing = true;
    this._contentSource = null; this._imageImportBox?.remove(); this._imageImportBox = null;this._audioImportBox?.remove();this._audioImportBox=null;this.releaseAudioArtifactPlayers();
    this._continuationOperation = null;
    if (this._continueSessionClickHandler) this.$.continueSessionButton?.removeEventListener('click', this._continueSessionClickHandler);
    if (this._archiveSessionClickHandler) this.$.archiveSessionButton?.removeEventListener('click', this._archiveSessionClickHandler);
    if (this._deleteSessionClickHandler) this.$.deleteSessionButton?.removeEventListener('click', this._deleteSessionClickHandler);
    Editor.Message?.removeBroadcastListener?.(SESSION_LIFECYCLE_EVENT_CHANNEL, this._sessionLifecycleHandler);
    this.resetAttachmentThumbnailUrls();
    this.saveVisibleDraft(true);
    if (this._persistenceReady) {
      await Promise.all(Array.from(this._sessions.keys()).map((id) => this.persistSession(id, true)));
      await Editor.Message.request(EXTENSION_NAME, 'flush-sessions').catch(() => {});
    }
    this._environmentRequestId += 1;
    this._permissionRequestId += 1;
    this._modelServicesRequestId += 1;
    this.closeToolsPopover();
    this.closePermissionMenu();
    this.closeAgentMenu();
    this.closeModelMenu();
    this.closeReasoningMenu();
    this.closePinPopover();
    this.unregisterGlobalContextMenu();
    this.hideComposerToast();
    this.stopEditorModeSync();
    if (this._durationTimer) {
      clearInterval(this._durationTimer);
      this._durationTimer = null;
    }
    this.cancelScrollToLatestAnimation();
    if (this._threadResizeObserver) {
      this._threadResizeObserver.disconnect();
      this._threadResizeObserver = null;
    }
    if (this._globalContextResizeObserver) {
      this._globalContextResizeObserver.disconnect();
      this._globalContextResizeObserver = null;
    }
    if (this._pinPopoverResizeObserver) {
      this._pinPopoverResizeObserver.disconnect();
      this._pinPopoverResizeObserver = null;
    }
    if (
      this._globalContextWindow
      && this._globalContextWindowResizeHandler
      && typeof this._globalContextWindow.removeEventListener === 'function'
    ) {
      this._globalContextWindow.removeEventListener('resize', this._globalContextWindowResizeHandler);
      this._globalContextWindow.removeEventListener('pointerup', this._globalContextPointerUpHandler, true);
    }
    if (this._promptObservers) {
      this._promptObservers.forEach((observer) => observer.disconnect());
      this._promptObservers.clear();
    }
    if (
      this._codexEventHandler
      && global.Editor
      && Editor.Message
      && typeof Editor.Message.removeBroadcastListener === 'function'
    ) {
      Editor.Message.removeBroadcastListener(CODEX_EVENT_CHANNEL, this._codexEventHandler);
    }
    if (
      this._newSessionContextHandler
      && global.Editor
      && Editor.Message
      && typeof Editor.Message.removeBroadcastListener === 'function'
    ) {
      Editor.Message.removeBroadcastListener(NEW_SESSION_EVENT_CHANNEL, this._newSessionContextHandler);
    }
    if (
      this._modelServicesChangedHandler
      && global.Editor
      && Editor.Message
      && typeof Editor.Message.removeBroadcastListener === 'function'
    ) {
      Editor.Message.removeBroadcastListener(MODEL_SERVICES_EVENT_CHANNEL, this._modelServicesChangedHandler);
    }
    if (this._sessions && global.Editor && Editor.Message && typeof Editor.Message.request === 'function') {
      this._sessions.forEach((session) => {
        try {
          const cancellation = Editor.Message.request(
            EXTENSION_NAME,
            'cancel-codex-session',
            { sessionId: session.id, dispose: true }
          );
          if (cancellation && typeof cancellation.catch === 'function') {
            cancellation.catch((error) => {
              console.warn(`[AI Copilot] Unable to cancel Codex session ${session.id}: ${error.message}`);
            });
          }
        } catch (error) {
          console.warn(`[AI Copilot] Unable to cancel Codex session ${session.id}: ${error.message}`);
        }
      });
    }
    if (this._sendClickHandler && this.$.sendButton) {
      this.$.sendButton.removeEventListener('click', this._sendClickHandler);
    }
    if (this._attachClickHandler && this.$.attachButton) {
      this.$.attachButton.removeEventListener('click', this._attachClickHandler);
    }
    if (this._agentClickHandler && this.$.agentButton) {
      this.$.agentButton.removeEventListener('click', this._agentClickHandler);
    }
    if (this._sendMouseDownHandler && this.$.sendButton) {
      this.$.sendButton.removeEventListener('mousedown', this._sendMouseDownHandler);
    }
    if (this._composerInputHandler && this.$.composerInput) {
      this.$.composerInput.removeEventListener('input', this._composerInputHandler);
    }
    if (this._composerPasteHandler && this.$.composerInput) {
      this.$.composerInput.removeEventListener('paste', this._composerPasteHandler, true);
    }
    if (this._composerKeydownHandler && this.$.composerInput) {
      this.$.composerInput.removeEventListener('keydown', this._composerKeydownHandler, true);
    }
    if (this._queueContextMenuMouseDownHandler && this.$.queueContextMenu) {
      this.$.queueContextMenu.removeEventListener('mousedown', this._queueContextMenuMouseDownHandler);
    }
    if (this._queueEditClickHandler && this.$.queueEditButton) {
      this.$.queueEditButton.removeEventListener('click', this._queueEditClickHandler);
    }
    if (this._queueClearClickHandler && this.$.queueClearButton) {
      this.$.queueClearButton.removeEventListener('click', this._queueClearClickHandler);
    }
    if (this._pinEntryClickHandler && this.$.pinEntryButton) {
      this.$.pinEntryButton.removeEventListener('click', this._pinEntryClickHandler);
    }
    if (this._toolsClickHandler && this.$.toolsButton) this.$.toolsButton.removeEventListener('click', this._toolsClickHandler);
    if (this._modelClickHandler && this.$.modelButton) this.$.modelButton.removeEventListener('click', this._modelClickHandler);
    if (this._reasoningClickHandler && this.$.reasoningButton) this.$.reasoningButton.removeEventListener('click', this._reasoningClickHandler);
    if (this._settingsClickHandler && this.$.settingsButton) this.$.settingsButton.removeEventListener('click', this._settingsClickHandler);
    if (this._onboardingChatGptHandler && this.$.onboardingChatGpt) this.$.onboardingChatGpt.removeEventListener('click', this._onboardingChatGptHandler);
    if (this._onboardingOpenAiKeyHandler && this.$.onboardingOpenAiKey) this.$.onboardingOpenAiKey.removeEventListener('click', this._onboardingOpenAiKeyHandler);
    if (this._onboardingDeepSeekKeyHandler && this.$.onboardingDeepSeekKey) this.$.onboardingDeepSeekKey.removeEventListener('click', this._onboardingDeepSeekKeyHandler);
    if (this._permissionClickHandler && this.$.permissionButton) this.$.permissionButton.removeEventListener('click', this._permissionClickHandler);
    if (this._pinCountClickHandler && this.$.pinCount) {
      this.$.pinCount.removeEventListener('click', this._pinCountClickHandler);
    }
    if (this._pinEntryMouseEnterHandler && this.$.pinEntryButton?.parentElement) {
      this.$.pinEntryButton.parentElement.removeEventListener('mouseenter', this._pinEntryMouseEnterHandler);
      this.$.pinEntryButton.parentElement.removeEventListener('mouseleave', this._pinEntryMouseLeaveHandler);
    }
    if (this.$.composerPinPopover) {
      this.$.composerPinPopover.removeEventListener('mouseenter', this._pinPopoverMouseEnterHandler);
      this.$.composerPinPopover.removeEventListener('mouseleave', this._pinPopoverMouseLeaveHandler);
    }
    if (this._cancelPinModeClickHandler && this.$.cancelPinModeButton) {
      this.$.cancelPinModeButton.removeEventListener('click', this._cancelPinModeClickHandler);
    }
    if (this._confirmPinModeClickHandler && this.$.confirmPinModeButton) {
      this.$.confirmPinModeButton.removeEventListener('click', this._confirmPinModeClickHandler);
    }
    if (this.$.root) {
      this.$.root.removeEventListener('dragenter', this._pinDragEnterHandler);
      this.$.root.removeEventListener('dragover', this._pinDragOverHandler);
      this.$.root.removeEventListener('dragleave', this._pinDragLeaveHandler);
      this.$.root.removeEventListener('drop', this._pinDropHandler);
    }
    if (this._composerDismissRoot && this._composerContextDismissHandler) {
      this._composerDismissRoot.removeEventListener('pointerdown', this._composerContextDismissHandler, true);
    }
    if (this._composerEventRoot && this._composerContextEscapeHandler) {
      this._composerEventRoot.removeEventListener('keydown', this._composerContextEscapeHandler, true);
    }
    if (this._composerEventWindow && this._composerWindowBlurHandler) {
      this._composerEventWindow.removeEventListener('blur', this._composerWindowBlurHandler);
    }
    if (this._sessionHistoryClickHandler && this.$.sessionHistoryButton) {
      this.$.sessionHistoryButton.removeEventListener('click', this._sessionHistoryClickHandler);
    }
    if (this._sessionTitleClickHandler && this.$.sessionTitleButton) {
      this.$.sessionTitleButton.removeEventListener('click', this._sessionTitleClickHandler);
    }
    if (this._newSessionClickHandler && this.$.newSessionButton) {
      this.$.newSessionButton.removeEventListener('click', this._newSessionClickHandler);
    }
    if (this._sessionSearchInputHandler && this.$.sessionSearchInput) {
      this.$.sessionSearchInput.removeEventListener('input', this._sessionSearchInputHandler);
    }
    if (this._sessionMoreClickHandler && this.$.sessionMoreButton) {
      this.$.sessionMoreButton.removeEventListener('click', this._sessionMoreClickHandler);
    }
    if (this._renameSessionClickHandler && this.$.renameSessionButton) {
      this.$.renameSessionButton.removeEventListener('click', this._renameSessionClickHandler);
    }
    if (this._renameSessionCancelHandler && this.$.renameSessionCancel) {
      this.$.renameSessionCancel.removeEventListener('click', this._renameSessionCancelHandler);
    }
    if (this._renameSessionSaveHandler && this.$.renameSessionSave) {
      this.$.renameSessionSave.removeEventListener('click', this._renameSessionSaveHandler);
    }
    if (this._renameSessionInputHandler && this.$.renameSessionInput) {
      this.$.renameSessionInput.removeEventListener('input', this._renameSessionInputHandler);
    }
    if (this._renameSessionKeydownHandler && this.$.renameSessionInput) {
      this.$.renameSessionInput.removeEventListener('keydown', this._renameSessionKeydownHandler);
    }
    if (this._renameDialogPointerHandler && this.$.renameSessionDialog) {
      this.$.renameSessionDialog.removeEventListener('pointerdown', this._renameDialogPointerHandler);
    }
    if (this._activityScrollHandler && this.$.activityScroller) {
      this.$.activityScroller.removeEventListener('scroll', this._activityScrollHandler);
    }
    if (this._scrollToLatestClickHandler && this.$.scrollToLatestButton) {
      this.$.scrollToLatestButton.removeEventListener('click', this._scrollToLatestClickHandler);
    }
    this._sendClickHandler = null;
    this._attachClickHandler = null;
    this._agentClickHandler = null;
    this._toolsClickHandler = null;
    this._modelClickHandler = null;
    this._reasoningClickHandler = null;
    this._settingsClickHandler = null;
    this._onboardingChatGptHandler = null;
    this._onboardingOpenAiKeyHandler = null;
    this._onboardingDeepSeekKeyHandler = null;
    this._permissionClickHandler = null;
    this._sendMouseDownHandler = null;
    this._composerInputHandler = null;
    this._composerPasteHandler = null;
    this._composerKeydownHandler = null;
    this._queueContextMenuMouseDownHandler = null;
    this._queueEditClickHandler = null;
    this._queueClearClickHandler = null;
    this._pinEntryClickHandler = null;
    this._pinCountClickHandler = null;
    this._pinEntryMouseEnterHandler = null;
    this._pinEntryMouseLeaveHandler = null;
    this._pinPopoverMouseEnterHandler = null;
    this._pinPopoverMouseLeaveHandler = null;
    this._cancelPinModeClickHandler = null;
    this._confirmPinModeClickHandler = null;
    this._pinDragOverHandler = null;
    this._pinDragEnterHandler = null;
    this._pinDragLeaveHandler = null;
    this._pinDropHandler = null;
    this._composerContextDismissHandler = null;
    this._composerContextEscapeHandler = null;
    this._sessionHistoryClickHandler = null;
    this._sessionTitleClickHandler = null;
    this._sessionSearchInputHandler = null;
    this._sessionMoreClickHandler = null;
    this._renameSessionClickHandler = null;
    this._continueSessionClickHandler = null;
    this._archiveSessionClickHandler = null;
    this._deleteSessionClickHandler = null;
    this._sessionLifecycleHandler = null;
    this._sessionLifecycleUpdates = null;
    this._renameSessionCancelHandler = null;
    this._renameSessionSaveHandler = null;
    this._renameSessionInputHandler = null;
    this._renameSessionKeydownHandler = null;
    this._renameDialogPointerHandler = null;
    this._composerAttachments = null;
    this._consumedComposerPasteEvents = null;
    this._attachmentSelectPending = false;
    this._composerPins = null;
    this._activePinPopover = null;
    this._pinPopoverPreservedScrollTop = null;
    this._pendingPins = null;
    this._pinModeActive = false;
    this._pinModeGeneration = 0;
    this._fileDragDepth = 0;
    this._pinSelectionSerial = null;
    this._composerToastTimer = null;
    this._nativeContextMenuPending = false;
    this._globalContextId = '';
    this._globalContextRegistered = false;
    this._globalContextRegistrationFrame = null;
    this._globalContextWindow = null;
    this._globalContextWindowResizeHandler = null;
    this._globalContextPointerUpHandler = null;
    this._queueContextMessageId = '';
    this._composerEventRoot = null;
    this._composerClipboard = null;
    this._composerClipboardResolved = false;
    this._newSessionClickHandler = null;
    this._activityScrollHandler = null;
    this._scrollToLatestClickHandler = null;
    this._codexEventHandler = null;
    this._newSessionContextHandler = null;
    this._modelServicesChangedHandler = null;
    this._modelServicesSnapshot = null;
    this._agentId = '';
    this._modelMenuProviderId = '';
    this._activeCodexTaskId = '';
    if (this._sessionQueues) {
      this._sessionQueues.forEach((queue) => {
        if (queue.drainTimer != null) clearTimeout(queue.drainTimer);
        queue.drainTimer = null;
        queue.drainInProgress = false;
      });
      this._sessionQueues.clear();
    }
    this._sessionQueues = null;
    if (this._sessions) {
      this._sessions.forEach((session) => {
        session.turnsByTaskId.clear();
        session.messages.length = 0;
      });
      this._sessions.clear();
    }
    if (this._taskSessionIds) this._taskSessionIds.clear();
    this._sessions = null;
    this._taskSessionIds = null;
    this._codexTurns = null;
  },
});
