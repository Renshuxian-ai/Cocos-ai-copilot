'use strict';

const NONE = Object.freeze({ kind: 'none', label: '尚未导入项目', target: null });

function createArtifactProjectUsageResolver(artifacts = []) {
  const byId = new Map();
  const children = new Map();
  for (const artifact of Array.isArray(artifacts) ? artifacts : []) {
    if (!artifact?.id) continue;
    byId.set(artifact.id, artifact);
    for (const parentId of new Set([artifact.sourceArtifactId, artifact.parentArtifactId].filter(Boolean))) {
      if (!children.has(parentId)) children.set(parentId, []);
      children.get(parentId).push(artifact.id);
    }
  }
  const memo = new Map();
  const visiting = new Set();
  const resolveId = (id) => {
    if (!id || !byId.has(id)) return NONE;
    if (memo.has(id)) return memo.get(id);
    const artifact = byId.get(id);
    if (artifact.projectImported === true) {
      const direct = { kind: 'direct', label: '已导入项目', target: artifact };
      memo.set(id, direct);
      return direct;
    }
    if (visiting.has(id)) return NONE;
    visiting.add(id);
    let result = NONE;
    for (const childId of children.get(id) || []) {
      const child = resolveId(childId);
      if (child.target) {
        result = { kind: 'derived', label: '已用于项目', target: child.target };
        break;
      }
    }
    visiting.delete(id);
    memo.set(id, result);
    return result;
  };
  return (artifact) => {
    if (!artifact?.id) return NONE;
    if (artifact.projectImported === true) return { kind: 'direct', label: '已导入项目', target: artifact };
    return resolveId(artifact.id);
  };
}

function resolveArtifactProjectUsage(artifact, artifacts = []) {
  return createArtifactProjectUsageResolver([artifact, ...(Array.isArray(artifacts) ? artifacts : [])])(artifact);
}

module.exports = { createArtifactProjectUsageResolver, resolveArtifactProjectUsage };
