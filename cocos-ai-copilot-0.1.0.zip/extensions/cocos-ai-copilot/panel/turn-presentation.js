'use strict';

const { reconcile } = require('./keyed-presentation');
const { groupAudioArtifacts } = require('../lib/audio/artifact-lineage');

function renderTurnPresentation(turn) {
  const groups = this.groupTurnActivities(turn);
  const session=this._sessions?.get(turn.sessionId);
  const audioContext=[...(session?.turnsByTaskId?.values()||[turn])].flatMap(prior=>
    (prior.assistantMessages||[]).flatMap(item=>(item.artifacts||[]).filter(artifact=>artifact.kind==='audio')));
  const finalMessageId = this.finalAssistantMessageId(turn);
  // Keep delivered media visible when completed progress is collapsed. This is
  // presentation only: retain original message ownership and chronology on disk.
  const deliveredArtifacts=new Map();
  if(finalMessageId)for(const item of turn.assistantMessages||[])for(const artifact of item.artifacts||[])deliveredArtifacts.set(artifact.id,artifact);
  const failedGroups = groups.filter((group) => this.activityGroupHasFailure(group));
  const failedGroupKey = failedGroups.length ? failedGroups[failedGroups.length - 1].key : '';
  const before = [], after = [];
  let destination = before;
  let planRendered = false;
  const add = (key, value, render, progress = destination === after) => {
    destination.push({ key, value: [value, progress], render: (stage) => {
      render(stage);
      if (progress) for (const node of stage.children) node.classList.add('steer-progress-entry');
    }, progress });
  };
  const message = (item, final = false) => {
    const projected=finalMessageId?{...item,artifacts:final?[...deliveredArtifacts.values()]:[]}:item;
    add(`message:${item.id}`,
    [projected, final, turn.completedAt, turn.sessionId,
      groupAudioArtifacts((projected.artifacts||[]).filter(artifact=>artifact.kind==='audio'),audioContext)],
    (stage) => this.renderAssistantMessages(stage, [projected], turn.completedAt, {
      append: true, turn, finalMessageId,
    }), !final && destination === after);
  };
  const plan = () => {
    add('plan', [turn.plan, turn.executionStarted, turn.ui.planExpanded, turn.ui.planUserToggled],
      (stage) => this.renderPlan(turn, stage));
    planRendered = true;
  };
  for (const group of groups) {
    if (group.anchor) {
      destination = after;
      add(group.key, group.anchor, (stage) => this.renderSteerFollowUp(stage, group.anchor), false);
      continue;
    }
    if (group.runtimeStatus) {
      add(group.key, group.runtimeStatus, (stage) => this.renderRuntimeStatus(stage, group.runtimeStatus));
      continue;
    }
    if (group.message && String(group.message.id || '') !== finalMessageId) message(group.message);
    if (!planRendered && turn.plan) plan();
    const rawKeys = new Set(group.activities.map((activity) => `raw:${activity.id}`));
    const expanded = Array.from(turn.ui.expanded || []).filter(([key]) =>
      key.startsWith(`presentation:${group.key}:`) || rawKeys.has(key));
    add(`activities:${group.key}`, [group.activities, group.validations, turn.status, group.key === failedGroupKey, expanded],
      (stage) => this.renderActivityGroup(stage, turn, group, failedGroupKey));
  }
  if (!planRendered && turn.plan) plan();
  if (finalMessageId) {
    const finalMessage = (turn.assistantMessages || []).find((item) => String(item.id || '') === finalMessageId);
    destination = after;
    if (finalMessage) message(finalMessage, true);
  }
  turn.ui.before.classList.add('assistant-presentation');
  const previous = turn.ui.presentationCache || {};
  const cache = {
    before: reconcile(turn.ui.before, before, previous.before),
    after: reconcile(turn.ui.after, after, previous.after),
  };
  turn.ui.presentationCache = cache;
  turn.ui.steerHistoryEntries = after.filter((item) => item.progress)
    .flatMap((item) => cache.after.get(item.key).nodes);
}

module.exports = { renderTurnPresentation };
