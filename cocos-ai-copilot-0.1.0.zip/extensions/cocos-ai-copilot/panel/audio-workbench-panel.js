'use strict';

const {createAudioWorkbench}=require('./audio-workbench');
const NAME='cocos-ai-copilot';
const request=(method,payload)=>Editor.Message.request(NAME,method,payload);
module.exports=Editor.Panel.define({
  template:'<div id="root"><div id="viewer"></div><div id="confirm" hidden><p>当前 Audio Draft 尚未保存，切换会放弃这些修改。</p><button id="discard">放弃并切换</button><button id="keep">继续编辑</button></div></div>',
  style:':host,#root,#viewer{display:block;height:100%;min-height:0;color-scheme:dark}#root{position:relative;overflow:hidden;background:#0b0c0e}#confirm{position:absolute;z-index:100;left:50%;bottom:18px;width:min(420px,calc(100% - 28px));transform:translateX(-50%);padding:14px;border:0;border-radius:11px;background:linear-gradient(145deg,rgba(54,55,59,.94),rgba(27,28,31,.96));box-shadow:0 16px 46px rgba(0,0,0,.48),inset 0 1px rgba(255,255,255,.06);backdrop-filter:blur(18px);color:#dedfe1;font:12px/1.45 Inter,"Segoe UI",system-ui,sans-serif}#confirm[hidden]{display:none}#confirm p{margin:0 0 12px;line-height:1.5;color:#dadadd}#confirm button{height:30px;margin-right:7px;padding:4px 11px;border:0;border-radius:7px;background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.055));color:#e5e5e6;box-shadow:inset 0 1px rgba(255,255,255,.04);cursor:pointer}#confirm button:hover{background:linear-gradient(180deg,rgba(255,255,255,.15),rgba(255,255,255,.08))}#confirm #discard{color:#efb4b0}#confirm #keep{background:rgba(255,255,255,.13);color:#fff}',
  $:{viewer:'#viewer',confirm:'#confirm',discard:'#discard',keep:'#keep'},
  listeners:{hide(){this._viewer?.pause();}},
  methods:{
    async setSource(source){if(this._closing)return false;this._sessionId=source?.sessionId||this._sessionId;return this._viewer.setSource(source);},
    async snapshot(){return this._viewer?.snapshot();},
    async requestClose(){if(this._viewer?.state.dirty&&!await this.confirmDiscard())return false;await Editor.Panel.close(`${NAME}.audio-workbench`);return true;},
    confirmDiscard(){this.$.confirm.hidden=false;return new Promise(resolve=>{this._resolve=value=>{this.$.confirm.hidden=true;this._resolve=null;resolve(value);};});},
  },
  ready(){this._closing=false;this._selectionToken=0;this._viewer=createAudioWorkbench(this.$.viewer,{
    read:source=>request('get-audio-source',{...source,kind:'audio-workbench-source'}),
    action:(action,payload)=>request(action==='render'||action==='runtime'?'audio-workbench-action':'commit-audio-workbench',{action,...payload}),
    confirmDiscard:()=>this.confirmDiscard(),requestClose:()=>this.requestClose(),
    locate:source=>(source?.assetUrl||source?.assetUuid)&&request('locate-change-target',{assetUuid:source.assetUuid||source.target,assetUrl:source.assetUrl}),
    review:turnId=>request('open-changes',{sessionId:this._viewer?.state.source?.sessionId,turnId}),
  });this._discard=()=>this._resolve?.(true);this._keep=()=>this._resolve?.(false);this.$.discard.addEventListener('click',this._discard);this.$.keep.addEventListener('click',this._keep);
    this._selection=async type=>{if(this._closing||type!=='asset')return;const token=++this._selectionToken;try{const source=await request('get-audio-source',{kind:'audio-workbench-selection',sessionId:this._sessionId});if(this._closing||token!==this._selectionToken||!source)return;if(source.identity&&source.identity===this._viewer?.state.source?.identity)return;await this.setSource({...source,sessionId:this._sessionId});}catch(_){/* A disappeared or non-audio selection preserves the current source. */}};
    Editor.Message.addBroadcastListener('selection:select',this._selection);
  },
  close(){this._closing=true;this._selectionToken++;Editor.Message.removeBroadcastListener('selection:select',this._selection);this._resolve?.(false);this._viewer?.destroy();this._viewer=null;this.$.discard.removeEventListener('click',this._discard);this.$.keep.removeEventListener('click',this._keep);},
});
