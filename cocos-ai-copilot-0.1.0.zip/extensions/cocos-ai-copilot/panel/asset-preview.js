'use strict';

const Panzoom = require('../third_party/panzoom/4.6.2/panzoom.cjs');
const model = require('../lib/asset-preview/frame-model');
const imageDraft = require('../lib/asset-preview/image-draft');

const style = `
.asset-preview{position:absolute;inset:0;z-index:2000;background:#15171bf5;color:#d9dde5;display:flex;flex-direction:column;font:12px/1.4 system-ui;container-type:inline-size;min-width:260px;overflow:hidden}
.asset-preview *{box-sizing:border-box}.asset-preview[data-mode=view] .ap-stage{flex:1;height:auto}.asset-preview button,.asset-preview input,.asset-preview select{font:inherit;color:inherit;background:#252931;border:1px solid #414650;border-radius:3px;padding:4px 6px;min-width:0}
.asset-preview button{cursor:pointer}.asset-preview button:hover{background:#343b47}.asset-preview button:disabled{opacity:.45;cursor:default}
.ap-workflow-hint{color:#9299a3;font-size:11px;margin:6px 0;line-height:1.5}
.asset-preview [hidden]{display:none!important}.asset-preview header,.ap-toolbar{display:flex;gap:5px;align-items:center;flex-wrap:wrap;padding:7px;border-bottom:1px solid #333842}.ap-title{flex:1;min-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ap-mode-tabs,.ap-view-tools{display:flex;gap:5px;align-items:center;min-width:0}.ap-mode-tabs{flex:0 0 auto}.ap-view-tools{margin-left:auto;flex:0 1 auto}
.ap-body{display:flex;flex:1;min-height:0}.ap-stage{position:relative;overflow:hidden;flex:1;min-width:120px;min-height:150px;background-color:#16181c;background-image:linear-gradient(45deg,#252830 25%,transparent 25%),linear-gradient(-45deg,#252830 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#252830 75%),linear-gradient(-45deg,transparent 75%,#252830 75%);background-size:20px 20px;background-position:0 0,0 10px,10px -10px,-10px 0;touch-action:none}
.ap-image-plane{position:absolute;left:50%;top:50%;transform-origin:center;user-select:none}.ap-image-plane img{display:block;max-width:none;max-height:none;pointer-events:none}.ap-overlay{position:absolute;inset:0;overflow:visible;touch-action:none}.ap-overlay rect{fill:#6ca9ef18;stroke:#a7c8ef;stroke-width:1;vector-effect:non-scaling-stroke}.ap-overlay rect[data-selected=true]{fill:#70adeb33;stroke:#fcce6d;stroke-width:2}.ap-overlay [data-handle]{fill:#fcce6d;cursor:nwse-resize}
.ap-tools{width:235px;max-width:48%;padding:8px;overflow:auto;border-left:1px solid #353a43}.ap-tools label{display:flex;align-items:center;gap:5px;margin:5px 0}.ap-tools input[type=number]{width:70px;margin-left:auto}.ap-tools input[type=text]{width:100%}.ap-pair{display:flex;gap:6px}.ap-pair label{flex:1}.ap-pair input[type=number]{width:48px}.ap-section{border-bottom:1px solid #343842;padding-bottom:8px;margin-bottom:8px}.ap-section-title{color:#a9b7cc;margin-bottom:5px}.ap-frame-list{display:flex;gap:4px;flex-wrap:wrap;max-height:175px;overflow:auto}.ap-frame{width:61px;padding:3px!important;display:flex;flex-direction:column;align-items:center}.ap-frame[data-selected=true]{border-color:#eac06d}.ap-frame canvas{width:48px;height:48px;object-fit:contain}.ap-frame span{max-width:54px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px}.ap-animation{width:100%;height:120px;object-fit:contain;background:#111319}.ap-status{padding:6px 9px;min-height:28px;color:#b4c2d6;max-height:90px;overflow:auto}.ap-status[data-error=true]{color:#f1a7a0}.ap-details{padding:0 9px;max-height:90px;overflow:auto;white-space:pre-wrap;font-size:10px}.ap-mode-active{border-color:#87adde!important}.ap-inline{display:flex;gap:5px;align-items:center}.ap-inline input[type=range]{width:100%;padding:0}.ap-list-title{margin:5px 0}.ap-rect{display:grid;grid-template-columns:1fr 1fr;gap:3px}.ap-rect label{margin:0}.ap-rect input[type=number]{width:56px}.ap-commit{display:flex;gap:4px;flex-wrap:wrap;margin-top:7px}.ap-commit button{flex:1;white-space:nowrap}
@container(max-width:520px){.ap-body{flex-direction:column}.ap-stage{flex:none;height:40%;min-height:150px}.ap-tools{width:100%;max-width:none;border-left:0;border-top:1px solid #353a43;flex:1}.ap-section{padding-bottom:6px;margin-bottom:6px}.ap-frame-list{max-height:120px}.ap-animation{height:90px}}
.ap-tools{width:clamp(260px,30%,340px);flex:0 0 clamp(260px,30%,340px);max-width:none;padding:10px;scrollbar-gutter:stable}
.ap-tools label{display:grid;grid-template-columns:76px minmax(0,1fr);gap:8px;margin:7px 0;white-space:nowrap}
.ap-tools input[type=number],.ap-tools input[type=text]{width:100%;margin:0}
.ap-pair{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:10px}
.ap-pair label{grid-template-columns:54px minmax(0,1fr)}
.ap-pair input[type=number],.ap-rect input[type=number]{width:100%}
.ap-rect{gap:8px 16px}
.ap-rect label{grid-template-columns:24px minmax(0,1fr);gap:8px}
.ap-slice-actions,.ap-commit{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:6px}
.ap-tools button,.ap-tools select{height:28px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ap-frame-list{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px}
.ap-tools .ap-frame{width:100%;height:auto;min-height:70px}
.ap-frame canvas{width:100%;max-width:48px;flex-shrink:0}
.ap-frame span{width:100%}
.ap-tools button[data-action=auto]{width:100%;margin-top:6px}
.ap-commit button:last-child:nth-child(odd){grid-column:1 / -1}
.ap-scene-actions{grid-template-columns:minmax(0,1fr)}
.ap-tools label.ap-check{display:flex;align-items:center;white-space:normal;gap:7px}
.ap-check input[type=checkbox]{flex:0 0 auto;margin:0}
.ap-target{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#929eaf;font-size:11px}
.ap-index{flex:0 0 auto;min-width:40px;text-align:right}
@container(max-width:620px){.ap-view-tools{margin-left:0;flex-wrap:wrap}}
@container(max-width:520px){.ap-toolbar{align-content:flex-start}.ap-mode-tabs,.ap-view-tools{max-width:100%}.ap-tools{width:100%;max-width:none;flex:1}.ap-tools label{grid-template-columns:76px minmax(0,1fr)}.ap-pair label{grid-template-columns:54px minmax(0,1fr)}.ap-rect label{grid-template-columns:24px minmax(0,1fr)}}

.asset-preview{color-scheme:dark}
.asset-preview button{background:transparent;border-color:rgba(255,255,255,.10);border-radius:2px;box-shadow:none}
.asset-preview button:hover{background:rgba(255,255,255,.045);border-color:rgba(255,255,255,.18)}
.ap-tools input,.ap-tools select{height:26px;padding:3px 6px;background:rgba(0,0,0,.12);border:1px solid rgba(255,255,255,.20);border-radius:2px;box-shadow:none}
.ap-tools input:hover,.ap-tools select:hover{border-color:rgba(255,255,255,.30)}
.ap-tools input:focus,.ap-tools select:focus{outline:none;border-color:#607c9b;background:rgba(0,0,0,.16)}
.ap-tools input[type=checkbox]{width:13px;height:13px;padding:0;accent-color:#829bb7}
.ap-tools input[type=number]::-webkit-inner-spin-button{opacity:0}
.ap-tools input[type=number]:hover::-webkit-inner-spin-button,.ap-tools input[type=number]:focus::-webkit-inner-spin-button{opacity:.5}
.ap-animation-surface{position:relative;border:1px solid rgba(255,255,255,.09);border-radius:2px;overflow:hidden}
.ap-animation-surface .ap-animation{display:block;background:rgba(0,0,0,.12)}
.ap-animation-empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;color:#9b9fa6;pointer-events:none}
.ap-animation-empty small{font-size:10px;color:#717780}
.asset-preview .ap-play-toggle{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;align-items:center;justify-content:center;width:32px;height:32px;padding:8px;border-radius:50%;border-color:rgba(255,255,255,.18);background:rgba(20,22,26,.35);color:#ddd}
.ap-play-toggle svg{width:14px;height:14px;fill:currentColor}
.ap-play-toggle .ap-pause-icon,.ap-play-toggle[data-playing=true] .ap-play-icon{display:none}
.ap-play-toggle[data-playing=true] .ap-pause-icon{display:block}
.ap-play-toggle[data-playing=true]{opacity:0}
.ap-animation-surface:hover .ap-play-toggle,.ap-play-toggle:focus-visible{opacity:1}
.ap-stage-empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;color:#777d86;font-size:12px;text-align:center;pointer-events:none}
.asset-preview[data-empty=true] .ap-stage{background:#17191d}
.ap-process-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}.ap-process-actions .ap-wide{grid-column:1/-1}.ap-operation-list{display:flex;flex-direction:column;gap:4px;max-height:210px;overflow:auto;overscroll-behavior:contain}.ap-operation{display:grid;grid-template-columns:18px minmax(0,1fr) 24px;gap:5px;align-items:center;padding:4px 5px;border:1px solid rgba(255,255,255,.08);cursor:grab}.ap-operation:active{cursor:grabbing}.ap-operation[data-dragging=true]{opacity:.45}.ap-operation[data-drop-target=true]{border-color:#9ca2ab;box-shadow:0 0 0 1px #ffffff12}.ap-drag-handle{color:#777d86;text-align:center;font-size:13px;line-height:1;user-select:none}.ap-operation-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ap-operation-delete{height:22px!important;width:22px;padding:0!important;opacity:0;pointer-events:none;color:#adb1b8!important;transition:opacity .12s ease,background-color .12s ease!important}.ap-operation:hover .ap-operation-delete,.ap-operation:focus-within .ap-operation-delete{opacity:1;pointer-events:auto}.ap-operation-delete:hover{color:#f0f1f3!important;background:rgba(255,255,255,.09)!important}.ap-operation-more{flex:0 0 auto;width:100%;height:25px!important;padding:2px 7px!important;background:rgba(255,255,255,.035)!important;color:#aaaeb5!important;box-shadow:none!important;text-align:left}.ap-operation-more:hover{background:rgba(255,255,255,.075)!important;color:#ededee!important}.ap-operation-count{color:#999ba0;font-weight:500}.ap-note{font-size:10px;color:#8f98a6;line-height:1.45}.ap-stale{padding:6px;border:1px solid #806b3e;background:#5a481f33;color:#d7bd7b}.ap-tools details{border-bottom:1px solid #343842;padding:0 0 7px;margin:0 0 8px}.ap-tools summary{cursor:pointer;color:#a9b7cc;padding:2px 0 5px}.ap-subsection{border-top:1px solid rgba(255,255,255,.08);margin-top:9px;padding-top:8px}.ap-tools details>.ap-subsection:first-of-type{border-top:0;margin-top:0;padding-top:0}.ap-subsection-title{display:flex;align-items:center;gap:5px;margin:0 0 6px;color:#8f9bad;font-size:11px}.ap-semantic-icon{width:13px;height:13px;flex:0 0 13px;color:#829bb7;stroke:currentColor;fill:none;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}.ap-subsection>button{width:100%}.ap-tools .ap-color{display:grid;grid-template-columns:76px minmax(0,1fr)}.ap-tools input[type=color]{width:100%;padding:1px}.ap-original-toggle{display:grid;grid-template-columns:1fr 1fr;gap:5px}.ap-result-meta{font-size:10px;color:#98a4b6;white-space:pre-wrap}.ap-settings-target{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#9ba7b8;margin-bottom:6px}

/* Modern docked workbench: the image stays visible while a compact tool rail swaps details. */
.asset-preview{background:rgba(11,13,16,.96);color:#d9dde3;font:12px/1.45 Inter,"Segoe UI",system-ui,sans-serif;backdrop-filter:blur(18px) saturate(105%);-webkit-backdrop-filter:blur(18px) saturate(105%)}
.asset-preview>header{min-height:42px;padding:8px 11px;background:rgba(24,27,32,.78);border:0;box-shadow:0 5px 18px #0003}
.ap-title{font-weight:600;letter-spacing:.01em;color:#eef3f9}
.ap-toolbar{padding:7px 10px;background:rgba(16,18,22,.82);border:0}
.ap-mode-tabs{gap:2px;padding:3px;background:rgba(0,0,0,.32);border:0;border-radius:8px}
.ap-mode-tabs button{height:28px;padding:4px 10px;border:0;border-radius:5px;color:#929cab}
.ap-mode-tabs button:hover{background:rgba(255,255,255,.055);color:#e7e9ed}
.ap-mode-tabs .ap-mode-active{background:rgba(255,255,255,.105)!important;color:#f5f6f8;border:0!important;box-shadow:inset 0 1px #ffffff0a}
.ap-view-tools{gap:4px;color:#8590a0}
.ap-view-tools button{height:28px;border-color:transparent;color:#aeb8c6}
.ap-view-tools button:hover{background:rgba(255,255,255,.055)}
.ap-stage{background-color:#101216;background-image:linear-gradient(45deg,#191c21 25%,transparent 25%),linear-gradient(-45deg,#191c21 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#191c21 75%),linear-gradient(-45deg,transparent 75%,#191c21 75%);background-size:18px 18px;background-position:0 0,0 9px,9px -9px,-9px 0;box-shadow:inset 1px 0 rgba(255,255,255,.035)}
.ap-tools{order:-1;width:clamp(340px,32%,400px);flex:0 0 clamp(340px,32%,400px);padding:0;background:rgba(18,20,24,.88);border:0;box-shadow:8px 0 28px #0003;scrollbar-gutter:stable;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}
.asset-preview button,.asset-preview input,.asset-preview select{border-radius:6px;transition:background-color .14s ease,border-color .14s ease,color .14s ease,box-shadow .14s ease}
.asset-preview button{border:0;background:rgba(255,255,255,.025);color:#cbd0d7;font-weight:400;box-shadow:inset 0 1px #ffffff05}
.asset-preview button:hover{background:rgba(255,255,255,.065);color:#f0f1f3}
.asset-preview button:focus-visible,.asset-preview input:focus-visible,.asset-preview select:focus-visible{outline:2px solid #a7adb7;outline-offset:1px}
.ap-tools input,.ap-tools select{height:30px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.28);color:#dedfe2;border-radius:6px}
.ap-tools input:hover,.ap-tools select:hover{border-color:rgba(255,255,255,.20)}
.ap-tools input:focus,.ap-tools select:focus{border-color:#8f96a0;background:rgba(0,0,0,.34);box-shadow:0 0 0 2px #ffffff12}
.ap-section,.ap-process-pane{border:0;background:linear-gradient(145deg,rgba(47,50,56,.48),rgba(26,28,33,.58));border-radius:9px;box-shadow:0 7px 22px #0004,inset 0 1px #ffffff08;backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}
.ap-section{padding:10px;margin:0 0 10px}
.ap-section-title,.ap-process-pane-title{font-weight:600;color:#c8d2df;letter-spacing:.01em}.ap-section-title{display:flex;align-items:center;gap:6px;margin-bottom:8px}
.ap-info-button{margin-left:auto!important;width:18px!important;min-width:18px!important;height:18px!important;padding:0!important;border-radius:50%!important;color:#989da5!important;font-size:11px!important;line-height:16px!important;cursor:help!important}
.ap-process-tools{display:grid;grid-template-columns:72px minmax(0,1fr);min-height:100%;align-items:start}
.ap-process-content{min-width:0;padding:12px}
.ap-process-nav{display:flex;flex-direction:column;gap:3px;min-height:100%;padding:8px 5px;position:sticky;top:0;background:rgba(8,10,12,.40);border:0}
.ap-process-nav button{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;min-height:50px;height:auto;padding:5px 2px;border:0;background:transparent;color:#8995a6;font-size:10px;line-height:1.15}
.ap-process-nav button:hover{background:rgba(255,255,255,.055);color:#e0e2e6}
.ap-process-nav button[aria-selected=true]{background:linear-gradient(180deg,rgba(255,255,255,.13),rgba(255,255,255,.07));color:#f4f5f7;box-shadow:none}
.ap-process-nav button .ap-semantic-icon{width:17px;height:17px;flex-basis:17px;color:currentColor}
.ap-process-detail{min-width:0}
.ap-process-pane{padding:11px;margin-bottom:10px}
.ap-process-pane-title{display:flex;align-items:center;gap:7px;margin:0 0 10px;padding-bottom:2px;border:0}
.ap-process-pane-title .ap-semantic-icon{width:15px;height:15px;flex-basis:15px;color:#b7bdc6}
.ap-process-pane>button{width:100%}
.ap-process-pane .ap-note{margin-top:8px}
.ap-tools .ap-section button[data-action^=add-],.ap-process-pane button[data-action^=add-],.ap-process-pane button[data-action=flip-h],.ap-tools button[data-action=save-version],.ap-tools button[data-action=apply-settings]{background:rgba(255,255,255,.072);color:#e8e9eb;font-weight:500;box-shadow:inset 0 1px #ffffff08,0 1px 2px #0003}
.ap-tools .ap-section button[data-action^=add-]:hover,.ap-process-pane button[data-action^=add-]:hover,.ap-process-pane button[data-action=flip-h]:hover,.ap-tools button[data-action=save-version]:hover,.ap-tools button[data-action=apply-settings]:hover{background:rgba(255,255,255,.115)}
.ap-operation{padding:5px;border:0;background:rgba(0,0,0,.22);border-radius:6px}
.ap-operation b{color:#c4c8ce;text-align:center}
.ap-original-toggle{padding:3px;background:rgba(0,0,0,.27);border-radius:7px}
.ap-original-toggle button{border:0;background:transparent}
.ap-original-toggle .ap-mode-active{background:rgba(255,255,255,.105)!important;border:0!important;color:#f2f3f5;box-shadow:inset 0 1px #ffffff08}
.ap-status{background:rgba(10,12,15,.90);border:0;color:#a4a9b1;padding:7px 11px}
.ap-status[data-error=true]{color:#ffaea8;background:#241719}
.ap-stale{border:0;background:#5a481f24;color:#e0c57f;border-radius:6px;margin-top:8px}
.ap-frame{border-radius:7px!important;background:#12171e!important}
.ap-frame[data-selected=true]{background:rgba(255,255,255,.09)!important;box-shadow:none}
.ap-animation-surface{border-radius:7px;border:0}
.ap-sheet-tools,.ap-settings-tools{padding:12px}
.ap-tools::-webkit-scrollbar,.ap-process-nav::-webkit-scrollbar{width:8px;height:8px}.ap-tools::-webkit-scrollbar-thumb,.ap-process-nav::-webkit-scrollbar-thumb{background:#3a3d43;border:2px solid #17191d;border-radius:8px}.ap-tools::-webkit-scrollbar-track,.ap-process-nav::-webkit-scrollbar-track{background:transparent}
@container(max-width:700px){.ap-body{flex-direction:column}.ap-stage{order:-1;flex:none;height:48%;min-height:180px}.ap-tools{order:0;width:100%;max-width:none;flex:1;border:0;box-shadow:0 -8px 28px #0003}.ap-process-tools{grid-template-columns:1fr}.ap-process-nav{position:static;min-height:0;flex-direction:row;overflow-x:auto;border:0}.ap-process-nav button{flex:0 0 64px;min-height:48px}.ap-process-content{padding:10px}}

/* Final monochrome glass skin. Only editable fields retain a visible outline. */
.asset-preview{background:rgba(10,11,13,.97);color:#d8d9dc;backdrop-filter:blur(20px) saturate(105%);-webkit-backdrop-filter:blur(20px) saturate(105%)}
.asset-preview>header{background:rgba(27,28,31,.80);box-shadow:0 7px 24px rgba(0,0,0,.24)}
.ap-toolbar{background:rgba(15,16,18,.84)}
.ap-title{color:#f0f0f1}.ap-mode-tabs button{color:#9d9fa5}.ap-mode-tabs .ap-mode-active{color:#f5f5f6}.ap-view-tools,.ap-view-tools button{color:#b3b5ba}
.ap-stage{background-color:#0e0f11;background-image:linear-gradient(45deg,#191a1d 25%,transparent 25%),linear-gradient(-45deg,#191a1d 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#191a1d 75%),linear-gradient(-45deg,transparent 75%,#191a1d 75%);box-shadow:none}
.ap-tools{background:rgba(18,19,22,.90);box-shadow:9px 0 30px rgba(0,0,0,.30);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)}
.asset-preview button{border:0!important;border-radius:7px;background:linear-gradient(180deg,rgba(255,255,255,.065),rgba(255,255,255,.035));color:#d2d3d6;box-shadow:inset 0 1px rgba(255,255,255,.045),0 1px 2px rgba(0,0,0,.22)}
.asset-preview button:hover:not(:disabled){border:0!important;background:linear-gradient(180deg,rgba(255,255,255,.105),rgba(255,255,255,.06));color:#f2f2f3}.asset-preview button:focus-visible{outline:0;background:rgba(255,255,255,.11);box-shadow:0 0 0 2px rgba(255,255,255,.09)}
.ap-mode-tabs button,.ap-view-tools button,.ap-process-nav button,.ap-original-toggle button,.ap-operation-delete{background:transparent;box-shadow:none}
.ap-tools input,.ap-tools select{border:1px solid rgba(255,255,255,.13);border-radius:7px;background:rgba(0,0,0,.28);color:#e0e1e3;box-shadow:inset 0 1px 2px rgba(0,0,0,.28)}.ap-tools select{color-scheme:dark}.ap-tools select option{outline:0;background:#202124;color:#e3e3e5}.ap-tools select option:checked,.ap-tools select option:focus{outline:0!important;background:linear-gradient(#45464a,#45464a)!important;background-color:#45464a!important;color:#fff!important}.ap-tools select option:hover{background:linear-gradient(#38393d,#38393d)!important;background-color:#38393d!important;color:#fff!important}
.ap-tools input:hover,.ap-tools select:hover{border-color:rgba(255,255,255,.22)}.ap-tools input:focus,.ap-tools select:focus{outline:0;border-color:rgba(255,255,255,.39);background:rgba(0,0,0,.36);box-shadow:0 0 0 2px rgba(255,255,255,.075)}
.ap-tools input[type=checkbox]{accent-color:#aeb0b4}.ap-inline input[type=range]{border:0;box-shadow:none;accent-color:#aeb0b4}
.ap-section,.ap-process-pane{border:0;background:linear-gradient(145deg,rgba(48,49,53,.43),rgba(27,28,31,.58));border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.25),inset 0 1px rgba(255,255,255,.035)}
.ap-section-title,.ap-process-pane-title{color:#d0d1d4}.ap-process-pane-title .ap-semantic-icon,.ap-semantic-icon{color:#b1b2b5}
.ap-process-nav{border:0;background:rgba(7,8,10,.44)}.ap-process-nav button{color:#8f9298}.ap-process-nav button[aria-selected=true]{background:linear-gradient(180deg,rgba(255,255,255,.13),rgba(255,255,255,.07));color:#f4f4f5;box-shadow:none}
.ap-tools .ap-section button[data-action^=add-],.ap-process-pane button[data-action^=add-],.ap-process-pane button[data-action=flip-h],.ap-tools button[data-action=save-version],.ap-tools button[data-action=apply-settings]{background:linear-gradient(180deg,rgba(255,255,255,.105),rgba(255,255,255,.06));color:#eeeeef;box-shadow:inset 0 1px rgba(255,255,255,.045),0 1px 2px rgba(0,0,0,.22)}
.ap-tools .ap-section button[data-action^=add-]:hover,.ap-process-pane button[data-action^=add-]:hover,.ap-process-pane button[data-action=flip-h]:hover,.ap-tools button[data-action=save-version]:hover,.ap-tools button[data-action=apply-settings]:hover{background:linear-gradient(180deg,rgba(255,255,255,.15),rgba(255,255,255,.085))}
.ap-operation{border:0;background:rgba(0,0,0,.23);border-radius:7px}.ap-operation:hover{background:rgba(255,255,255,.045)}.ap-operation[data-drop-target=true]{border:0;background:rgba(255,255,255,.09);box-shadow:inset 0 0 0 1px rgba(255,255,255,.10)}
.ap-tools details,.ap-subsection{border:0}.ap-subsection-title,.ap-result-meta,.ap-target,.ap-settings-target,.ap-note,.ap-workflow-hint{color:#989a9f}
.ap-original-toggle{background:rgba(0,0,0,.28)}.ap-original-toggle .ap-mode-active{background:rgba(255,255,255,.105)!important;color:#f2f2f3;box-shadow:inset 0 1px rgba(255,255,255,.035)}
.ap-animation-surface,.ap-frame{border:0!important}.ap-frame{background:rgba(0,0,0,.24)!important}.ap-frame[data-selected=true]{background:rgba(255,255,255,.10)!important}.ap-status{border:0;background:rgba(9,10,12,.92);color:#a5a6aa}.ap-stale{border:0;background:rgba(104,78,29,.25)}

`;
const semanticIcon = body => `<svg class="ap-semantic-icon" viewBox="0 0 20 20" aria-hidden="true">${body}</svg>`;
const semanticIcons = {
  crop:semanticIcon('<path d="M5 2v9a4 4 0 0 0 4 4h9"/><path d="M2 5h9a4 4 0 0 1 4 4v9"/>'),
  resize:semanticIcon('<path d="M3 8V3h5M12 3h5v5M3 12v5h5M17 12v5h-5"/><path d="m7 7 6 6M13 7l-6 6"/>'),
  canvas:semanticIcon('<rect x="2.5" y="2.5" width="15" height="15" rx="1"/><rect x="6.5" y="6.5" width="7" height="7" rx=".5"/>'),
  transform:semanticIcon('<path d="M16.5 8A7 7 0 1 0 17 12"/><path d="M12.5 4H17v4.5"/>'),
  alpha:semanticIcon('<path d="M10 2.5S5.5 8 5.5 11.5a4.5 4.5 0 0 0 9 0C14.5 8 10 2.5 10 2.5Z"/><path d="m6 16 8-8"/>'),
  color:semanticIcon('<circle cx="10" cy="10" r="3"/><path d="M10 1.5v2M10 16.5v2M1.5 10h2M16.5 10h2M4 4l1.5 1.5M14.5 14.5 16 16M16 4l-1.5 1.5M5.5 14.5 4 16"/>'),
  tint:semanticIcon('<path d="M4 14.5 13.5 5l1.5 1.5L5.5 16H4v-1.5Z"/><path d="m12 6.5 1.5 1.5M3 3h5v5H3z"/>'),
  composite:semanticIcon('<rect x="2.5" y="5.5" width="10" height="10" rx="1"/><rect x="7.5" y="2.5" width="10" height="10" rx="1"/>'),
};
const template = `
<header><span class="ap-title"></span><button data-action="locate">定位</button><button data-action="close" aria-label="关闭图片预览">×</button></header>
<div class="ap-toolbar"><div class="ap-mode-tabs"><button data-action="view" class="ap-mode-active">查看</button><button data-action="process-mode">图片处理</button><button data-action="sheet">Sprite Sheet</button><button data-action="settings-mode">资产设置</button></div><div class="ap-view-tools"><button data-action="fit">适应窗口</button><button data-action="minus">−</button><span class="ap-zoom">100%</span><button data-action="plus">+</button><button data-action="reset">重置视图</button><span class="ap-size"></span></div></div>
<div class="ap-body"><div class="ap-stage"><div class="ap-stage-empty" hidden>从资源管理器选择图片，或从聊天打开图片</div><div class="ap-image-plane"><img alt="2D Asset Preview" draggable="false"><svg class="ap-overlay" xmlns="http://www.w3.org/2000/svg" hidden></svg></div></div>
<aside class="ap-tools" hidden>
<div class="ap-process-tools" hidden>
<nav class="ap-process-nav" aria-label="图片处理工具">
<button data-action="process-tool" data-process-tool="crop" aria-selected="true">${semanticIcons.crop}<span>裁剪</span></button>
<button data-action="process-tool" data-process-tool="resize" aria-selected="false">${semanticIcons.resize}<span>缩放</span></button>
<button data-action="process-tool" data-process-tool="canvas" aria-selected="false">${semanticIcons.canvas}<span>画布</span></button>
<button data-action="process-tool" data-process-tool="transform" aria-selected="false">${semanticIcons.transform}<span>变换</span></button>
<button data-action="process-tool" data-process-tool="alpha" aria-selected="false">${semanticIcons.alpha}<span>透明</span></button>
<button data-action="process-tool" data-process-tool="color" aria-selected="false">${semanticIcons.color}<span>色彩</span></button>
<button data-action="process-tool" data-process-tool="tint" aria-selected="false">${semanticIcons.tint}<span>着色</span></button>
<button data-action="process-tool" data-process-tool="composite" aria-selected="false">${semanticIcons.composite}<span>合成</span></button>
</nav>
<div class="ap-process-content">
<div class="ap-section"><div class="ap-section-title">处理预览 · 固定源图重放</div><div class="ap-original-toggle"><button data-action="show-original">原图</button><button data-action="show-current" class="ap-mode-active">当前版本</button></div><div class="ap-result-meta"></div><div class="ap-stale" hidden>图片几何已变化。当前 Sprite Sheet 坐标仍属于原始源图；如需切新版本，请先保存并打开新版本后重新切片。</div></div>
<div class="ap-process-detail">
<section class="ap-process-pane" data-process-pane="crop"><div class="ap-process-pane-title">${semanticIcons.crop}<span>裁剪</span></div><div class="ap-pair"><label>X<input name="cropX" type="number" value="0" min="0"></label><label>Y<input name="cropY" type="number" value="0" min="0"></label></div><div class="ap-pair"><label>宽<input name="cropWidth" type="number" min="1"></label><label>高<input name="cropHeight" type="number" min="1"></label></div><div class="ap-process-actions"><button data-action="add-crop">添加裁剪</button><button data-action="add-trim">透明边裁剪</button></div><label>透明阈值<input name="processTrimThreshold" type="number" value="1" min="0" max="255"></label></section>
<section class="ap-process-pane" data-process-pane="resize" hidden><div class="ap-process-pane-title">${semanticIcons.resize}<span>缩放</span></div><div class="ap-pair"><label>目标宽<input name="resizeWidth" type="number" min="1"></label><label>目标高<input name="resizeHeight" type="number" min="1"></label></div><label>百分比<input name="resizePercentage" type="number" min="0.01" max="1600" placeholder="可选"></label><label>适配<select name="resizeFit"><option value="inside">保持比例</option><option value="stretch">拉伸</option><option value="contain">Contain</option></select></label><label>插值<select name="interpolation"><option value="nearest">Nearest · 像素画</option><option value="bilinear">Bilinear · 平滑</option><option value="bicubic">Bicubic</option></select></label><button data-action="add-resize">添加缩放</button></section>
<section class="ap-process-pane" data-process-pane="canvas" hidden><div class="ap-process-pane-title">${semanticIcons.canvas}<span>画布与留白</span></div><div class="ap-pair"><label>上<input name="padTop" type="number" value="0" min="0"></label><label>下<input name="padBottom" type="number" value="0" min="0"></label></div><div class="ap-pair"><label>左<input name="padLeft" type="number" value="0" min="0"></label><label>右<input name="padRight" type="number" value="0" min="0"></label></div><button data-action="add-padding">添加四边留白</button><div class="ap-pair"><label>画布宽<input name="canvasWidth" type="number" min="1"></label><label>画布高<input name="canvasHeight" type="number" min="1"></label></div><label>锚点<select name="canvasAnchor"><option value="center">中心</option><option value="top">上</option><option value="bottom">下</option><option value="left">左</option><option value="right">右</option><option value="top-left">左上</option><option value="top-right">右上</option><option value="bottom-left">左下</option><option value="bottom-right">右下</option></select></label><button data-action="add-canvas">添加目标画布</button></section>
<section class="ap-process-pane" data-process-pane="transform" hidden><div class="ap-process-pane-title">${semanticIcons.transform}<span>翻转与旋转</span></div><div class="ap-process-actions"><button data-action="flip-h">水平翻转</button><select name="transformAction" aria-label="其他翻转与旋转"><option value="">其他变换…</option><option value="flip-v">垂直翻转</option><option value="rotate-90">顺时针 90°</option><option value="rotate-180">旋转 180°</option><option value="rotate-270">顺时针 270°</option></select></div></section>
<section class="ap-process-pane" data-process-pane="alpha" hidden><div class="ap-process-pane-title">${semanticIcons.alpha}<span>抠色与透明度</span></div><label class="ap-color">抠色<input name="keyColor" type="color" value="#ffffff"></label><div class="ap-pair"><label>容差<input name="keyTolerance" type="number" value="0" min="0" max="255"></label><label>Alpha<input name="keyAlpha" type="number" value="0" min="0" max="255"></label></div><button data-action="add-color-key">颜色转透明</button><label>整体透明度<input name="opacity" type="number" value="1" min="0" max="1" step="0.05"></label><button data-action="add-opacity">添加透明度</button></section>
<section class="ap-process-pane" data-process-pane="color" hidden><div class="ap-process-pane-title">${semanticIcons.color}<span>明暗与色彩</span></div><label>亮度<input name="brightness" type="number" value="0" min="-1" max="1" step="0.05"></label><button data-action="add-brightness">添加亮度</button><label>对比度<input name="contrast" type="number" value="0" min="-0.99" max="0.99" step="0.05"></label><button data-action="add-contrast">添加对比度</button><label>色相 °<input name="hue" type="number" value="0" min="-180" max="180"></label><button data-action="add-hue">添加色相</button><label>饱和度<input name="saturation" type="number" value="0" min="-1" max="1" step="0.05"></label><button data-action="add-saturation">添加饱和度</button></section>
<section class="ap-process-pane" data-process-pane="tint" hidden><div class="ap-process-pane-title">${semanticIcons.tint}<span>游戏着色</span></div><label class="ap-color">着色<input name="tintColor" type="color" value="#ff0000"></label><label>强度<input name="tintStrength" type="number" value="0.5" min="0" max="1" step="0.05"></label><label>模式<select name="tintMode"><option value="multiply">RGB Multiply</option><option value="mix">Mix</option></select></label><button data-action="add-tint">添加游戏着色</button></section>
<section class="ap-process-pane" data-process-pane="composite" hidden><div class="ap-process-pane-title">${semanticIcons.composite}<span>轻量合成与蒙版</span></div><label>Artifact ID<input name="auxArtifactId" type="text" placeholder="同一会话图片 ID"></label><label>方式<select name="auxKind"><option value="composite">合成</option><option value="mask-alpha">Alpha 蒙版</option><option value="mask-grayscale">灰度蒙版</option></select></label><div class="ap-pair"><label>X<input name="auxX" type="number" value="0"></label><label>Y<input name="auxY" type="number" value="0"></label></div><label>合成透明度<input name="auxOpacity" type="number" value="1" min="0" max="1" step="0.05"></label><button data-action="add-aux">添加操作</button><div class="ap-note">仅做单层合成或蒙版，不建立图层系统。</div></section>
</div>
<div class="ap-section"><div class="ap-section-title">处理步骤 <span class="ap-operation-count">0</span></div><div class="ap-operation-list"></div><div class="ap-process-actions"><button data-action="draft-reset">重置草稿</button><button data-action="render-draft">重新预览</button></div></div>
<div class="ap-section"><div class="ap-section-title">保存新版本</div><label>格式<select name="outputFormat"><option value="png">PNG</option><option value="jpeg">JPEG</option></select></label><label class="ap-jpeg-field" hidden>JPEG 质量<input name="jpegQuality" type="number" value="90" min="1" max="100"></label><label class="ap-jpeg-field" hidden>铺底颜色<input name="jpegMatte" type="color" value="#ffffff"></label><label>文件名<input name="versionName" type="text"></label><button data-action="save-version">保存新版本</button><label>导入位置<input name="imageOutputPath" type="text"></label><div class="ap-process-actions"><button data-action="import-version">导入项目</button><button data-action="review-process">查看改动</button></div></div>
</div></div>
<div class="ap-sheet-tools" hidden>
<div class="ap-section"><div class="ap-section-title">切片 · 源图坐标</div><div class="ap-slice-actions"><select name="gridMode"><option value="count">行列</option><option value="size">帧尺寸</option></select><button data-action="grid">生成切片</button><button data-action="manual">画框</button><button data-action="pan">平移</button></div>
<div class="ap-pair"><label>列<input name="columns" type="number" value="4" min="1"></label><label>行<input name="rows" type="number" value="2" min="1"></label></div>
<div class="ap-pair"><label>宽<input name="frameWidth" type="number" value="64" min="1"></label><label>高<input name="frameHeight" type="number" value="64" min="1"></label></div>
<div class="ap-pair"><label>间距 X<input name="spacingX" type="number" value="0" min="0"></label><label>Y<input name="spacingY" type="number" value="0" min="0"></label></div>
<div class="ap-pair"><label>偏移 X<input name="offsetX" type="number" value="0" min="0"></label><label>Y<input name="offsetY" type="number" value="0" min="0"></label></div>
<label>透明阈值<input name="threshold" type="number" value="1" min="1" max="255"></label><label>最小面积<input name="minArea" type="number" value="4" min="1"></label><label>合并间距<input name="gutter" type="number" value="0" min="0" max="128"></label><button data-action="auto">透明区域自动切片</button></div>
<div class="ap-section"><div class="ap-list-title">帧 <span class="ap-count">0</span> · 拖动排序</div><div class="ap-frame-list"></div><label>帧名称<input name="frameName" type="text" placeholder="帧名称"></label><div class="ap-rect">${[['x','X'],['y','Y'],['width','宽'],['height','高']].map(([key,label]) => `<label>${label}<input type="number" name="rect-${key}"></label>`).join('')}</div><div class="ap-commit"><button data-action="rect">应用坐标</button><button data-action="delete">删除帧</button><button data-action="clear">清空切片</button></div></div>
<div class="ap-section ap-player"><div class="ap-section-title">动画预览</div><div class="ap-animation-surface"><canvas class="ap-animation"></canvas><div class="ap-animation-empty"><span>暂无动画</span><small>切片后可预览</small></div><button class="ap-play-toggle" data-action="toggle-play" aria-label="播放" title="播放" hidden><svg class="ap-play-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M4 2 14 8 4 14Z"/></svg><svg class="ap-pause-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 2H6V14H3ZM10 2H13V14H10Z"/></svg></button></div><label>FPS<input name="fps" type="number" value="12" min="1" max="60"></label><label class="ap-check"><input name="loop" type="checkbox" checked>循环播放</label><div class="ap-inline"><input name="seek" type="range" min="0" max="0" value="0" disabled><span class="ap-index">0 / 0</span></div></div>
<div class="ap-section"><div class="ap-section-title">保存资源</div><label>输出目录<input name="outputFolder" type="text"></label><label>动画名称<input name="animationName" type="text" value="Run"></label><div class="ap-commit"><button data-action="save">保存帧</button><button data-action="animation">创建动画</button></div>
</div><div class="ap-section"><div class="ap-section-title">场景</div><label>节点名称<input name="nodeName" type="text" value="Sprite"></label><label>父节点<input name="parentPath" type="text" placeholder="例如 Canvas"></label><label class="ap-check"><input name="useSelected" type="checkbox">使用所选节点</label><span class="ap-target"></span><label class="ap-check"><input name="playOnLoad" type="checkbox" checked>放入场景并播放</label><div class="ap-commit ap-scene-actions"><button data-action="place">放入当前场景</button><button data-action="preview">保存场景并预览</button><button data-action="review">查看改动</button></div></div></div>
<div class="ap-settings-tools" hidden><div class="ap-section"><div class="ap-section-title">Cocos 图片资产设置<button type="button" class="ap-info-button" aria-label="查看资产设置说明" title="Pivot 属于 SpriteFrame，Anchor 属于场景节点 UITransform；纹理压缩沿用项目 Builder 配置，因为 Creator 3.8.8 没有稳定的逐图片公开写入接口。">i</button></div><div class="ap-settings-target"></div><label>过滤<select name="assetFilter"><option value="linear">Linear</option><option value="nearest">Nearest · Pixel Art</option></select></label><label>环绕<select name="assetWrap"><option value="clamp">Clamp</option><option value="repeat">Repeat</option></select></label><div class="ap-pair"><label>Pivot X<input name="pivotX" type="number" value="0.5" min="0" max="1" step="0.05"></label><label>Y<input name="pivotY" type="number" value="0.5" min="0" max="1" step="0.05"></label></div><div class="ap-pair"><label>Border 左<input name="borderLeft" type="number" value="0" min="0"></label><label>右<input name="borderRight" type="number" value="0" min="0"></label></div><div class="ap-pair"><label>上<input name="borderTop" type="number" value="0" min="0"></label><label>下<input name="borderBottom" type="number" value="0" min="0"></label></div><label class="ap-check"><input name="mipmap" type="checkbox">启用 Mipmap Filter</label><button data-action="apply-settings">保存、重新导入并回读</button></div><div class="ap-section"><div class="ap-section-title">放入场景</div><label>节点名称<input name="imageNodeName" type="text" value="Sprite"></label><label>父节点<input name="imageParentPath" type="text" placeholder="例如 Canvas"></label><div class="ap-pair"><label>显示宽<input name="imageNodeWidth" type="number" min="1"></label><label>显示高<input name="imageNodeHeight" type="number" min="1"></label></div><div class="ap-pair"><label>Anchor X<input name="anchorX" type="number" value="0.5" min="0" max="1" step="0.05"></label><label>Y<input name="anchorY" type="number" value="0.5" min="0" max="1" step="0.05"></label></div><label class="ap-check"><input name="spriteSliced" type="checkbox">Sprite Type = SLICED</label><div class="ap-process-actions"><button data-action="place-image">放入当前场景</button><button data-action="preview-image">保存并预览</button></div></div></div>
</aside></div><div class="ap-status" role="status">正在加载图片…</div><details class="ap-details" hidden><summary>技术详情</summary><pre></pre></details>`;

function createAssetPreview(parent, options) {
  const doc = parent.ownerDocument, win = doc.defaultView;
  const root = doc.createElement('section'); root.className = 'asset-preview'; root.dataset.mode = 'view'; root.tabIndex = -1;
  const css = doc.createElement('style'); css.textContent = style; root.append(css);
  const content = doc.createElement('div'); content.style.cssText = 'display:contents'; content.innerHTML = template; root.append(content); parent.append(root);
  const q = selector => root.querySelector(selector), field = name => q(`[name="${name}"]`);
  const image = q('img'), plane = q('.ap-image-plane'), stage = q('.ap-stage'), svg = q('svg'), list = q('.ap-frame-list'), animation = q('.ap-animation');
  const listeners = [], canvases = new Set([animation]);
  const state = { revision: 0, frames: [], width: 0, height: 0, sourceWidth:0, sourceHeight:0, sheet: false, mode:'view', draw: false, selected: '', currentIndex: 0, playing: false, elapsed: 0,
    fps: 12, loop: true, dirty: false, sheetDirty:false, processDirty:false, disposed: false, busy: false, processing:false, ready: false, saved: null, clip: null, raf: 0,
    blobUrl: '', previewBlobUrl:'', previewMetadata:null, processDraft:null, savedVersion:null, importedImage:null, drag: null, sequence: 0, renderSequence:0, renderingToken:0, operationListExpanded:false };
  let panzoom, observer, lastTime = 0, source, context = {}, dragIndex = -1, operationDragIndex = -1, cancelLoad;
  const on = (node, event, handler, flags) => { node.addEventListener(event, handler, flags); listeners.push(() => node.removeEventListener(event, handler, flags)); };
  function status(message, error) {
    if (state.disposed) return;
    q('.ap-status').textContent = message; q('.ap-status').dataset.error = String(Boolean(error));
    q('.ap-details').hidden = !error; q('.ap-details pre').textContent = error ? String(error.stack || error) : '';
    updateControls();
  }
  function updateControls() {
    const reason = !state.ready ? '请先打开图片。' : !state.frames.length ? '先生成切片；整张图片可设为 1 列 × 1 行。'
      : !state.saved ? '请先保存帧。' : !state.clip ? '请先创建动画。' : '';
    const placeReason = reason || (!context.sceneUuid ? '请先打开场景。'
      : field('useSelected').checked && !context.selectedNodeUuid ? '请在层级管理器中选择节点，或取消“使用所选节点”。' : '');
    const reasons = { save: !state.ready || !state.frames.length ? reason : '',
      animation: !state.saved ? reason : '', place: placeReason,
      preview: reason || (!state.placed ? '请先放入当前场景。' : ''), review: !state.lastReview ? '保存或放入场景后可查看改动。' : '' };
    for (const [action, hint] of Object.entries(reasons)) {
      const button = q(`[data-action=${action}]`);
      button.disabled = state.busy || state.preparing || Boolean(hint); button.title = state.busy || state.preparing ? '正在处理…' : hint;
    }
    for (const [selector, text] of [['.ap-save-hint', !state.saved ? reason : !state.clip ? '帧已保存，可以创建动画。' : '动画已创建。'],
      ['.ap-scene-hint', placeReason || (!state.placed ? '可放入当前场景。' : '已放入场景，可以保存并预览。')]]) {
      let hint = q(selector);
      if (!hint) { hint = doc.createElement('div'); hint.className = `ap-workflow-hint ${selector.slice(1)}`; hint.setAttribute('role', 'status');
        q(selector === '.ap-save-hint' ? '[data-action=save]' : '[data-action=place]').parentElement.before(hint); }
      hint.textContent = text;
    }
    const processing=state.busy||state.processing||state.preparing;
    for(const action of ['save-version','render-draft']){const button=q(`[data-action=${action}]`);if(button)button.disabled=processing||!state.ready||!state.processDraft;}
    const importButton=q('[data-action=import-version]');if(importButton){importButton.disabled=processing||!state.savedVersion;importButton.title=!state.savedVersion?'请先保存新版本。':'';}
    const settingsButton=q('[data-action=apply-settings]');if(settingsButton){const target=state.importedImage?.assetUuid||state.sourceAssetUuid;settingsButton.disabled=processing||!target;settingsButton.title=target?'':'请先选择项目图片，或保存并导入新版本。';}
    const spriteFrame=state.importedImage?.spriteFrameUuid||state.assetSettings?.spriteFrameUuid;
    const staticParent=field('imageParentPath')?.value?.trim();
    const placeImage=q('[data-action=place-image]'),previewImage=q('[data-action=preview-image]');
    if(placeImage){placeImage.disabled=processing||!spriteFrame||!context.sceneUuid||!staticParent;placeImage.title=!spriteFrame?'请先导入图片并读取 SpriteFrame。':!context.sceneUuid?'请先打开场景。':!staticParent?'请明确选择唯一父节点。':'';}
    if(previewImage){previewImage.disabled=processing||!state.imagePlaced;previewImage.title=state.imagePlaced?'':'请先放入当前场景。';}
  }
  async function refreshContext() {
    const token = state.contextToken = (state.contextToken || 0) + 1;
    const fresh = await options.context?.() || {};
    if (state.disposed || token !== state.contextToken) return;
    if (context.sceneUuid && fresh.sceneUuid !== context.sceneUuid) { state.placed = null; state.imagePlaced = null; }
    context = fresh;
    q('.ap-target').textContent = context.selectedNodeName || (context.selectedNodeUuid ? '已选择节点' : '未选择节点');
    q('.ap-target').title = context.selectedNodeUuid || '';
    q('.ap-target').hidden = !field('useSelected').checked;
    updateControls();
  }
  async function commitFromUI(action) {
    if (state.busy || state.preparing) return;
    state.preparing = true; updateControls();
    try {
      const sceneUuid = context.sceneUuid;
      await refreshContext();
      if (sceneUuid && sceneUuid !== context.sceneUuid) throw Error('当前场景已切换，请确认父节点后重新操作。');
      return await commit(action);
    } finally { state.preparing = false; updateControls(); }
  }
  function safe(fn) { return async event => { try { await fn(event); } catch (error) { status(error.message || '操作失败，请重试。', error); } }; }
  function releaseCanvases(exceptAnimation = false) {
    for (const canvas of canvases) if (!exceptAnimation || canvas !== animation) { canvas.width = canvas.height = 0; canvases.delete(canvas); }
  }
  function syncDirty(){state.dirty=state.sheetDirty||state.processDirty;}
  function invalidate() { state.revision++; state.sheetDirty = true; syncDirty(); state.saved = null; state.clip = null; state.placed = null; pause(); }
  function selected() { return state.frames.find(frame => frame.id === state.selected); }
  function renderRects() {
    svg.replaceChildren();
    for (const frame of state.frames) {
      const node = doc.createElementNS('http://www.w3.org/2000/svg', 'rect');
      for (const key of ['x','y','width','height']) node.setAttribute(key, frame[key]);
      node.dataset.frame = frame.id; node.dataset.selected = String(frame.id === state.selected); svg.append(node);
      if (frame.id === state.selected) {
        const handle = doc.createElementNS('http://www.w3.org/2000/svg', 'rect'), size = 8 / (panzoom?.getScale() || 1);
        handle.setAttribute('x', frame.x + frame.width - size / 2); handle.setAttribute('y', frame.y + frame.height - size / 2);
        handle.setAttribute('width', size); handle.setAttribute('height', size); handle.dataset.handle = frame.id; svg.append(handle);
      }
    }
    const topHandle = svg.querySelector('[data-handle]');
    if (topHandle) svg.append(topHandle);
    const frame = selected();
    field('frameName').value = frame?.name || '';
    for (const key of ['x','y','width','height']) field(`rect-${key}`).value = frame?.[key] ?? '';
  }
  function drawFrame(canvas, frame, thumbnail = false) {
    if (!frame) { canvas.width = canvas.height = 0; return; }
    const scale = thumbnail ? Math.min(1, 48 / Math.max(frame.width, frame.height)) : Math.min(1, 512 / Math.max(frame.width, frame.height));
    canvas.width = Math.max(1, Math.round(frame.width * scale)); canvas.height = Math.max(1, Math.round(frame.height * scale));
    const ctx = canvas.getContext('2d'); ctx.imageSmoothingEnabled = false;
    ctx.drawImage(image, frame.x, frame.y, frame.width, frame.height, 0, 0, canvas.width, canvas.height);
  }
  function drawAnimation() {
    q('.ap-animation-empty').hidden = Boolean(state.frames.length);
    const toggle = q('.ap-play-toggle'); toggle.hidden = !state.frames.length; toggle.disabled = state.busy;
    field('seek').disabled = state.busy || !state.frames.length;
    state.currentIndex = Math.min(Math.max(0, state.currentIndex), Math.max(0, state.frames.length - 1));
    drawFrame(animation, state.frames[state.currentIndex]);
    field('seek').max = Math.max(0, state.frames.length - 1); field('seek').value = state.currentIndex;
    q('.ap-index').textContent = `${state.frames.length ? state.currentIndex + 1 : 0} / ${state.frames.length}`;
  }
  function renderFrames() {
    releaseCanvases(true); list.replaceChildren();
    state.frames.forEach((frame, index) => {
      const button = doc.createElement('button'); button.className = 'ap-frame'; button.draggable = true;
      button.dataset.index = index; button.dataset.selected = String(frame.id === state.selected);
      button.title = `${index + 1}. ${frame.name} (${frame.x}, ${frame.y}, ${frame.width} × ${frame.height})`;
      const canvas = doc.createElement('canvas'); canvases.add(canvas); drawFrame(canvas, frame, true); button.append(canvas);
      const label = doc.createElement('span'); label.textContent = `${index + 1} ${frame.name}`; button.append(label); list.append(button);
    });
    q('.ap-count').textContent = state.frames.length; renderRects(); drawAnimation(); updateControls();
  }
  function setFrames(frames) {
    invalidate(); state.frames = frames; state.selected = frames[0]?.id || ''; state.currentIndex = 0; state.elapsed = 0;
    renderFrames(); status(frames.length ? `${frames.length} 帧 · 尚未保存` : '没有检测到 Sprite。请调整参数或手动画框。');
  }
  function updatePlaybackButton() {
    const button = q('.ap-play-toggle'); button.dataset.playing = String(state.playing);
    button.title = state.playing ? '暂停' : '播放'; button.setAttribute('aria-label', button.title);
  }
  function pause() { state.playing = false; if (state.raf) win.cancelAnimationFrame(state.raf); state.raf = 0; updatePlaybackButton(); }
  function tick(time) {
    state.raf = 0; if (state.disposed || !state.playing) return;
    state.elapsed += Math.max(0, time - lastTime); lastTime = time;
    const frame = model.playback(state.elapsed, state.fps, state.frames.length, state.loop);
    state.currentIndex = frame.index; drawAnimation();
    if (frame.ended) pause(); else state.raf = win.requestAnimationFrame(tick);
  }
  function play() {
    if (!state.frames.length) throw new Error('请先切片。');
    pause(); if (model.playback(state.elapsed, state.fps, state.frames.length, false).ended) state.elapsed = 0;
    state.playing = true; updatePlaybackButton(); lastTime = win.performance.now(); state.raf = win.requestAnimationFrame(tick);
  }
  function fit(reset = false) {
    if (!panzoom || !state.ready) return;
    const scale = reset ? 1 : Math.min(stage.clientWidth / state.width, stage.clientHeight / state.height) * .92;
    panzoom.zoom(scale, { animate: false, force: true }); panzoom.pan(0, 0, { animate: false, force: true });
  }
  function applyDimensions(width,height) {
    state.width=width;state.height=height;image.width=width;image.height=height;
    plane.style.width=`${width}px`;plane.style.height=`${height}px`;plane.style.marginLeft=`${-width/2}px`;plane.style.marginTop=`${-height/2}px`;
    svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('width',width);svg.setAttribute('height',height);q('.ap-size').textContent=`${width} × ${height}`;
  }
  async function switchImage(url,width,height) {
    if(!url)return;
    const token=state.displayToken=(state.displayToken||0)+1;
    if(image.src!==url)await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('处理后的图片无法预览。'));image.src=url;});
    image.onload=image.onerror=null;if(state.disposed||token!==state.displayToken)return;applyDimensions(width,height);fit();
  }
  async function setMode(value) {
    const mode=typeof value==='boolean'?(value?'sheet':'view'):value;
    state.mode=mode;state.sheet=mode==='sheet';root.dataset.mode=mode;q('.ap-tools').hidden=mode==='view';svg.toggleAttribute('hidden',!state.sheet);state.draw=state.sheet;
    q('.ap-process-tools').hidden=mode!=='process';q('.ap-sheet-tools').hidden=mode!=='sheet';q('.ap-settings-tools').hidden=mode!=='settings';
    for(const [action,active] of [['view',mode==='view'],['process-mode',mode==='process'],['sheet',mode==='sheet'],['settings-mode',mode==='settings']])q(`[data-action=${action}]`)?.classList.toggle('ap-mode-active',active);
    panzoom?.setOptions({disablePan:state.sheet});
    if(state.ready){if(state.sheet||!state.previewBlobUrl)await switchImage(state.blobUrl,state.sourceWidth,state.sourceHeight);else await switchImage(state.previewBlobUrl,state.previewMetadata.width,state.previewMetadata.height);}
    if(mode==='settings'){updateSettingsTarget();await loadAssetSettings();}fit();
  }
  function setProcessTool(tool) {
    const target=q(`[data-process-pane="${tool}"]`);if(!target)return;
    root.querySelectorAll('[data-process-tool]').forEach(button=>button.setAttribute('aria-selected',String(button.dataset.processTool===tool)));
    root.querySelectorAll('[data-process-pane]').forEach(pane=>{pane.hidden=pane!==target;});
  }
  function fieldNumber(name,{required=false,integer=false}={}) {
    const text=String(field(name).value||'').trim();if(!text){if(required)throw new Error(`${name} 不能为空。`);return undefined;}
    const value=Number(text);if(!Number.isFinite(value)||(integer&&!Number.isInteger(value)))throw new Error(`${name} 数值无效。`);return value;
  }
  function processOutput() {
    const format=field('outputFormat').value,name=field('versionName').value.trim();
    return {format,name,...(format==='jpeg'?{quality:fieldNumber('jpegQuality',{required:true,integer:true}),matte:field('jpegMatte').value}:{})};
  }
  function invalidateProcessedVersion() {
    state.savedVersion=null;state.importedImage=null;state.assetSettings=null;state.assetSettingsTarget='';state.imagePlaced=null;
    updateSettingsTarget();
  }
  function syncProcessOutput() {
    const output=processOutput();
    if(JSON.stringify(output)!==JSON.stringify(state.processDraft.output)){imageDraft.setOutput(state.processDraft,output);state.processDirty=imageDraft.dirty(state.processDraft);syncDirty();state.previewMetadata=null;invalidateProcessedVersion();}
    return output;
  }
  function operationName(operation) {
    const names={crop:'裁剪',trimTransparent:'透明边裁剪',resize:'缩放',padding:'画布 / 留白',flip:'翻转',rotate:'旋转',colorKey:'颜色转透明',opacity:'透明度',brightness:'亮度',contrast:'对比度',hue:'色相',saturation:'饱和度',tint:'游戏着色',composite:'合成',mask:'蒙版'};
    const detail=operation.type==='resize'?(operation.percentage?`${operation.percentage}%`:`${operation.width||'auto'}×${operation.height||'auto'} ${operation.interpolation||''}`):operation.type==='rotate'?`${operation.direction==='counterclockwise'?'逆':'顺'}时针 ${operation.degrees}°`:operation.type==='tint'?`${operation.color} ${Math.round(operation.strength*100)}%`:'';
    return `${names[operation.type]||operation.type}${detail?` · ${detail}`:''}`;
  }
  function renderOperations() {
    const container=q('.ap-operation-list'),operations=state.processDraft.operations;container.replaceChildren();
    q('.ap-operation-count').textContent=String(operations.length);
    const hiddenCount=Math.max(0,operations.length-5);if(!hiddenCount)state.operationListExpanded=false;
    if(hiddenCount){const more=doc.createElement('button');more.className='ap-operation-more';more.dataset.action='operation-toggle';more.textContent=state.operationListExpanded?'收起较早步骤':`还有 ${hiddenCount} 个步骤`;more.setAttribute('aria-expanded',String(state.operationListExpanded));container.append(more);}
    const firstVisible=state.operationListExpanded?0:hiddenCount;
    operations.forEach((operation,index)=>{if(index<firstVisible)return;const row=doc.createElement('div');row.className='ap-operation';row.draggable=true;row.dataset.index=String(index);
      const handle=doc.createElement('span');handle.className='ap-drag-handle';handle.textContent='⠿';handle.title='拖动调整顺序';row.append(handle);
      const label=doc.createElement('span');label.className='ap-operation-label';label.textContent=`${index+1}. ${operationName(operation)}`;label.title=JSON.stringify(operation);row.append(label);
      const button=doc.createElement('button');button.className='ap-operation-delete';button.dataset.action='op-delete';button.dataset.index=String(index);button.textContent='×';button.title='删除此步骤';button.setAttribute('aria-label','删除此步骤');row.append(button);container.append(row);});
    if(!operations.length){const empty=doc.createElement('div');empty.className='ap-note';empty.textContent='添加图片处理后将在这里显示执行顺序';container.append(empty);}
    q('.ap-stale').hidden=!state.processDraft.geometryChanged;updateControls();
  }
  async function processChanged() {
    if(state.processDraft.geometryChanged&&state.frames.length){state.frames=[];state.selected='';state.saved=null;state.clip=null;state.placed=null;state.sheetDirty=false;renderFrames();}
    state.processDirty=imageDraft.dirty(state.processDraft);invalidateProcessedVersion();syncDirty();renderOperations();return renderProcessDraft();
  }
  async function addProcessOperation(operation) {if(state.busy)throw new Error('正在保存图片，请稍候。');imageDraft.addOperation(state.processDraft,operation);return processChanged();}
  async function renderProcessDraft() {
    if(!state.ready||!state.processDraft||!options.process)throw new Error('图片处理服务不可用。');
    syncProcessOutput();const revision=state.processDraft.revision,recipe=imageDraft.recipe(state.processDraft),renderToken=++state.renderSequence;state.processing=true;state.renderingToken=renderToken;updateControls();status('正在后台处理图片…');
    try{
      const result=await options.process({action:'render',recipe,revision});
      if(result?.cancelled||result?.stale){if(state.renderingToken===renderToken)status('图片预览已由更新的草稿取代。');return null;}
      if(state.disposed||!imageDraft.acceptPreview(state.processDraft,result))return null;
      const blob=new win.Blob([Buffer.from(result.base64,'base64')],{type:result.mimeType}),url=win.URL.createObjectURL(blob),previous=state.previewBlobUrl;
      state.previewBlobUrl=url;state.previewMetadata=result.metadata;await switchImage(url,result.metadata.width,result.metadata.height);if(previous)win.URL.revokeObjectURL(previous);
      q('.ap-result-meta').textContent=`${result.metadata.width} × ${result.metadata.height} · ${String(result.metadata.format).toUpperCase()} · ${(result.metadata.byteLength/1024).toFixed(1)} KiB${result.metadata.hasTransparentPixels?' · 含透明像素':''}`;
      q('[data-action=show-original]').classList.remove('ap-mode-active');q('[data-action=show-current]').classList.add('ap-mode-active');status(`当前版本预览完成 · revision ${revision}`);return result;
    }finally{if(state.renderingToken===renderToken){state.processing=false;updateControls();}}
  }
  async function showOriginal() {await switchImage(state.blobUrl,state.sourceWidth,state.sourceHeight);q('[data-action=show-original]').classList.add('ap-mode-active');q('[data-action=show-current]').classList.remove('ap-mode-active');status('正在查看固定源图；处理配方不会覆盖它。');}
  async function showCurrent() {if(!state.previewBlobUrl||state.processDraft.previewRevision!==state.processDraft.revision)await renderProcessDraft();else await switchImage(state.previewBlobUrl,state.previewMetadata.width,state.previewMetadata.height);q('[data-action=show-original]').classList.remove('ap-mode-active');q('[data-action=show-current]').classList.add('ap-mode-active');}
  async function saveImageVersion() {
    if(state.busy)return;syncProcessOutput();if(state.processDraft.previewRevision!==state.processDraft.revision)await renderProcessDraft();
    const revision=state.processDraft.revision,recipe=imageDraft.recipe(state.processDraft);state.busy=true;updateControls();status('正在暂存、校验并发布新的 Image Artifact…');
    try{const result=await options.process({action:'save',recipe,revision});if(state.processDraft.revision!==revision)throw new Error('图片草稿已变化；旧保存结果未设为当前版本。');
      state.savedVersion=result.artifact;imageDraft.markSaved(state.processDraft,revision,result.artifact.id);state.processDirty=imageDraft.dirty(state.processDraft);syncDirty();
      field('imageOutputPath').value=`assets/art/${result.artifact.displayName}`;status('已保存新版本 · 原图未修改 · 可导入项目');return result;
    }finally{state.busy=false;updateControls();}
  }
  async function importImageVersion() {
    if(!state.savedVersion)throw new Error('请先保存新版本。');state.busy=true;updateControls();status('正在通过 AssetDB 导入图片并验证 SpriteFrame…');
    try{const result=await options.commit({action:'import-image',artifactId:state.savedVersion.id,outputPath:field('imageOutputPath').value});if(!result.ok){const error=new Error(result.message||'图片导入失败。');error.stack=result.technicalError||error.stack;throw error;}
      state.importedImage=result.result;state.lastReview=result;updateSettingsTarget();status('图片已导入 · ImageAsset 与 SpriteFrame 验证通过');return result;
    }finally{state.busy=false;updateControls();}
  }
  function updateSettingsTarget(){const target=state.importedImage?.assetUrl||source?.assetUrl||'';q('.ap-settings-target').textContent=target||'当前版本尚未导入项目';q('.ap-settings-target').title=target;updateControls();}
  async function loadAssetSettings(force=false) {
    const target=state.importedImage?.assetUuid||source?.assetUuid;if(!target||!options.process)return null;if(!force&&state.assetSettingsTarget===target)return state.assetSettings;
    const result=await options.process({action:'query-settings',target});state.assetSettings=result;state.assetSettingsTarget=target;
    field('assetFilter').value=result.filter;field('assetWrap').value=result.wrapS==='repeat'&&result.wrapT==='repeat'?'repeat':'clamp';field('pivotX').value=result.pivot.x;field('pivotY').value=result.pivot.y;
    for(const key of ['Left','Right','Top','Bottom'])field(`border${key}`).value=result.borders[key.toLowerCase()];field('mipmap').checked=result.mipmap.enabled;
    field('imageNodeWidth').value=result.size.width;field('imageNodeHeight').value=result.size.height;if(!field('imageParentPath').value)field('imageParentPath').value=context.canvasPaths?.[0]||'';
    status('已读取 Cocos ImageAsset metadata。');return result;
  }
  async function applyAssetSettings() {
    const target=state.importedImage?.assetUuid||source?.assetUuid;if(!target)throw new Error('请先选择项目图片，或保存并导入新版本。');
    const settings={filter:field('assetFilter').value,wrap:field('assetWrap').value,pivot:{x:fieldNumber('pivotX',{required:true}),y:fieldNumber('pivotY',{required:true})},
      borders:{left:fieldNumber('borderLeft',{required:true,integer:true}),right:fieldNumber('borderRight',{required:true,integer:true}),top:fieldNumber('borderTop',{required:true,integer:true}),bottom:fieldNumber('borderBottom',{required:true,integer:true})},mipmap:field('mipmap').checked};
    state.busy=true;updateControls();status('正在保存 metadata、重新导入并回读…');
    try{const result=await options.commit({action:'settings',target,settings});if(!result.ok){const error=new Error(result.message||'图片资产设置失败。');error.stack=result.technicalError||error.stack;throw error;}state.assetSettings=result.result;state.assetSettingsTarget=target;state.lastReview=result;status('图片资产设置已保存 · reimport 与 readback 验证通过');return result;}
    finally{state.busy=false;updateControls();}
  }
  async function placeStaticImage() {
    const spriteFrameUuid=state.importedImage?.spriteFrameUuid||state.assetSettings?.spriteFrameUuid;if(!spriteFrameUuid)throw new Error('请先导入图片并读取 SpriteFrame。');
    const sceneUuid=context.sceneUuid;await refreshContext();if(!sceneUuid||sceneUuid!==context.sceneUuid)throw new Error('当前 Scene 已变化，请重新确认。');
    state.busy=true;updateControls();status('正在创建 Sprite 并回读场景状态…');
    try{const result=await options.commit({action:'place-image',sceneUuid,spriteFrameUuid,name:field('imageNodeName').value.trim()||'Sprite',parentPath:field('imageParentPath').value,
      width:fieldNumber('imageNodeWidth',{required:true}),height:fieldNumber('imageNodeHeight',{required:true}),sliced:field('spriteSliced').checked,anchorX:fieldNumber('anchorX',{required:true}),anchorY:fieldNumber('anchorY',{required:true})});
      if(!result.ok){const error=new Error(result.message||'Sprite 放置失败。');error.stack=result.technicalError||error.stack;throw error;}state.imagePlaced=result.result;state.lastReview=result;status(`Sprite 已放入场景${result.result.sliced?' · SLICED':''} · 回读验证通过`);return result;}
    finally{state.busy=false;updateControls();}
  }
  async function previewStaticImage() {
    if(!state.imagePlaced)throw new Error('请先放入当前场景。');const sceneUuid=context.sceneUuid;await refreshContext();if(!sceneUuid||sceneUuid!==context.sceneUuid||state.imagePlaced.sceneUuid!==sceneUuid)throw new Error('当前 Scene 已变化，请重新放置图片。');
    await options.showPreview?.();state.busy=true;updateControls();
    try{const result=await options.commit({action:'preview',sceneUuid});if(!result.ok){const error=new Error(result.message||'Preview 启动失败。');error.stack=result.technicalError||error.stack;throw error;}state.lastReview=result;status('Scene 已保存 · Game View 已启动');return result;}
    finally{state.busy=false;updateControls();}
  }
  async function exportFrames() {
    if (!state.frames.length) throw new Error('请先创建切片。');
    const canvas = doc.createElement('canvas'); canvases.add(canvas); const output = [];
    try {
      for (const frame of state.frames) {
        const checked = model.rect(frame, state.width, state.height);
        if (['x','y','width','height'].some(key => checked[key] !== frame[key])) throw new Error('Frame 越界，请调整坐标。');
        canvas.width = frame.width; canvas.height = frame.height;
        canvas.getContext('2d').drawImage(image, frame.x, frame.y, frame.width, frame.height, 0, 0, frame.width, frame.height);
        output.push({ name: frame.name, width: frame.width, height: frame.height, png: canvas.toDataURL('image/png').split(',')[1] });
      }
      return output;
    } finally { canvas.width = canvas.height = 0; canvases.delete(canvas); }
  }
  async function commit(action) {
    if (state.busy) return;
    if (action !== 'frames' && !state.saved) throw new Error('切片已改变或尚未保存，请先保存帧。');
    if (['place', 'preview'].includes(action) && !state.clip) throw new Error('请先创建动画。');
    if (action === 'preview' && !state.placed) throw new Error('请先放入当前 Scene。');
    pause(); state.busy = true; root.dataset.busy = 'true';
    root.querySelectorAll('.ap-tools button, .ap-tools input, .ap-tools select').forEach(node => { node.disabled = true; });
    try {
      const params = { action, outputFolder: action === 'frames' ? field('outputFolder').value : state.saved.folder,
        name: action === 'place' ? field('nodeName').value : field('animationName').value,
        fps: state.fps, loop: state.loop, sceneUuid: context.sceneUuid };
      if (action === 'frames') params.frames = await exportFrames();
      if (action === 'animation') params.spriteFrameUuids = state.saved.spriteFrameUuids;
      if (action === 'place') {
        if (field('useSelected').checked && !context.selectedNodeUuid) throw new Error('没有明确选中的 Node，请重新打开图片。');
        Object.assign(params, { clipUuid: state.clip.clipUuid, spriteFrameUuid: state.saved.spriteFrameUuids[0],
          width: state.frames[0].width, height: state.frames[0].height, parentPath: field('parentPath').value,
          targetUuid: field('useSelected').checked ? context.selectedNodeUuid : '', playOnLoad: field('playOnLoad').checked });
      }
      status('正在保存并核对项目改动…');
      if (action === 'preview') await options.showPreview?.();
      const result = await options.commit(params);
      if (state.disposed) return;
      if (result.taskId || result.turnId || result.changeSet) state.lastReview = result;
      if (!result.ok) { const error = new Error(result.message || '资产保存失败。'); error.stack = result.technicalError || error.stack; throw error; }
      if (action === 'frames') state.saved = result.result;
      if (action === 'animation') { state.clip = result.result; state.sheetDirty = false; syncDirty(); }
      if (action === 'place') state.placed = result.result;
      state.lastReview = result; state.revision++;
      status(action === 'frames' ? '帧已保存 · SpriteFrame 导入成功' : action === 'animation' ? '动画已创建 · 重新加载验证通过' : action === 'preview' ? 'Scene 已保存 · Game View 已启动' : '已放入当前 Scene · 可保存并启动 Preview');
      return result;
    } finally {
      state.busy = false; root.dataset.busy = 'false';
      root.querySelectorAll('.ap-tools button, .ap-tools input, .ap-tools select').forEach(node => { node.disabled = false; });
      drawAnimation();
      updateControls();
    }
  }
  const actions = {
    'toggle-play': () => state.playing ? pause() : play(),
    close: () => options.requestClose ? options.requestClose() : destroy(), view: () => setMode('view'), 'process-mode': () => setMode('process'), sheet: () => setMode('sheet'), 'settings-mode': () => setMode('settings'), fit: () => fit(), reset: () => fit(true),
    'process-tool':event=>setProcessTool(event.target.closest('[data-process-tool]')?.dataset.processTool),
    plus: () => panzoom?.zoomIn(), minus: () => panzoom?.zoomOut(),
    'show-original':showOriginal,'show-current':showCurrent,
    'add-crop':()=>addProcessOperation({type:'crop',x:fieldNumber('cropX',{required:true,integer:true}),y:fieldNumber('cropY',{required:true,integer:true}),width:fieldNumber('cropWidth',{required:true,integer:true}),height:fieldNumber('cropHeight',{required:true,integer:true})}),
    'add-trim':()=>addProcessOperation({type:'trimTransparent',alphaThreshold:fieldNumber('processTrimThreshold',{required:true,integer:true}),empty:'noop'}),
    'add-resize':()=>{const percentage=fieldNumber('resizePercentage'),width=fieldNumber('resizeWidth',{integer:true}),height=fieldNumber('resizeHeight',{integer:true}),fitMode=field('resizeFit').value;return addProcessOperation({type:'resize',...(percentage!==undefined?{percentage}:{...(width!==undefined?{width}:{}),...(height!==undefined?{height}:{})}),maintainAspectRatio:fitMode!=='stretch',fit:fitMode,interpolation:field('interpolation').value});},
    'add-padding':()=>addProcessOperation({type:'padding',top:fieldNumber('padTop',{required:true,integer:true}),bottom:fieldNumber('padBottom',{required:true,integer:true}),left:fieldNumber('padLeft',{required:true,integer:true}),right:fieldNumber('padRight',{required:true,integer:true}),anchor:'center',background:'#00000000'}),
    'add-canvas':()=>addProcessOperation({type:'padding',targetWidth:fieldNumber('canvasWidth',{required:true,integer:true}),targetHeight:fieldNumber('canvasHeight',{required:true,integer:true}),anchor:field('canvasAnchor').value,background:'#00000000'}),
    'flip-h':()=>addProcessOperation({type:'flip',horizontal:true,vertical:false}),'flip-v':()=>addProcessOperation({type:'flip',horizontal:false,vertical:true}),
    'rotate-90':()=>addProcessOperation({type:'rotate',degrees:90,direction:'clockwise'}),'rotate-180':()=>addProcessOperation({type:'rotate',degrees:180,direction:'clockwise'}),'rotate-270':()=>addProcessOperation({type:'rotate',degrees:270,direction:'clockwise'}),
    'add-color-key':()=>addProcessOperation({type:'colorKey',color:field('keyColor').value,tolerance:fieldNumber('keyTolerance',{required:true,integer:true}),resultAlpha:fieldNumber('keyAlpha',{required:true,integer:true})}),
    'add-opacity':()=>addProcessOperation({type:'opacity',value:fieldNumber('opacity',{required:true})}),'add-brightness':()=>addProcessOperation({type:'brightness',amount:fieldNumber('brightness',{required:true})}),
    'add-contrast':()=>addProcessOperation({type:'contrast',amount:fieldNumber('contrast',{required:true})}),'add-hue':()=>addProcessOperation({type:'hue',degrees:fieldNumber('hue',{required:true})}),
    'add-saturation':()=>addProcessOperation({type:'saturation',amount:fieldNumber('saturation',{required:true})}),'add-tint':()=>addProcessOperation({type:'tint',color:field('tintColor').value,strength:fieldNumber('tintStrength',{required:true}),mode:field('tintMode').value}),
    'add-aux':()=>{const id=field('auxArtifactId').value.trim(),kind=field('auxKind').value;if(!id)throw new Error('请输入同一会话中的辅助图片 Artifact ID。');return addProcessOperation(kind==='composite'?{type:'composite',source:{artifactId:id},x:fieldNumber('auxX',{required:true,integer:true}),y:fieldNumber('auxY',{required:true,integer:true}),opacity:fieldNumber('auxOpacity',{required:true})}:{type:'mask',source:{artifactId:id},mode:kind==='mask-alpha'?'alpha':'grayscale',x:fieldNumber('auxX',{required:true,integer:true}),y:fieldNumber('auxY',{required:true,integer:true})});},
    'operation-toggle':()=>{state.operationListExpanded=!state.operationListExpanded;renderOperations();},
    'op-delete':event=>{const index=Number(event.target.closest('[data-index]').dataset.index);imageDraft.removeOperation(state.processDraft,index);return processChanged();},
    'draft-reset':async()=>{imageDraft.resetDraft(state.processDraft);state.operationListExpanded=false;state.processDirty=false;syncDirty();invalidateProcessedVersion();state.previewMetadata=null;if(state.previewBlobUrl){win.URL.revokeObjectURL(state.previewBlobUrl);state.previewBlobUrl='';}renderOperations();await showOriginal();status('图片处理草稿已重置；源图未改变。');},
    'render-draft':renderProcessDraft,'save-version':saveImageVersion,'import-version':importImageVersion,'apply-settings':applyAssetSettings,
    'place-image':placeStaticImage,'preview-image':previewStaticImage,
    'review-process':()=>{if(!state.lastReview)throw new Error('还没有项目改动记录；保存 Artifact 本身不会改项目，请先导入或设置资产。');return options.review?.(state.lastReview);},
    pan: () => { state.draw = false; panzoom?.setOptions({ disablePan: false }); },
    manual: () => { state.draw = true; panzoom?.setOptions({ disablePan: true }); },
    grid: () => setFrames(model.grid(state.width, state.height, Object.fromEntries(['columns','rows','frameWidth','frameHeight','spacingX','spacingY','offsetX','offsetY'].map(key => [key, field(key).value]).concat([['mode',field('gridMode').value],['base',source.displayName]])))),
    auto: () => {
      model.dimensions(state.width, state.height, model.MAX_AUTO_PIXELS);
      const canvas = doc.createElement('canvas'); canvases.add(canvas);
      try { canvas.width = state.width; canvas.height = state.height; const ctx = canvas.getContext('2d', { willReadFrequently: true }); ctx.drawImage(image, 0, 0);
        setFrames(model.autoSlice(ctx.getImageData(0, 0, state.width, state.height).data, state.width, state.height,
          { threshold: field('threshold').value, minArea: field('minArea').value, gutter: field('gutter').value, base: source.displayName }));
      } finally { canvas.width = canvas.height = 0; canvases.delete(canvas); }
    },
    rect: () => { const frame = selected(); if (!frame) return; const checked = model.rect(Object.fromEntries(['x','y','width','height'].map(key => [key, field(`rect-${key}`).value])), state.width, state.height); invalidate(); Object.assign(frame, checked); frame.name = field('frameName').value.trim() || frame.name; renderFrames(); },
    delete: () => setFrames(state.frames.filter(frame => frame.id !== state.selected).map((frame, order) => ({ ...frame, order }))),
    clear: () => setFrames([]), play, pause, stop: () => { pause(); state.elapsed = 0; state.currentIndex = 0; drawAnimation(); },
    save: () => commit('frames'), animation: () => commit('animation'), place: () => commitFromUI('place'), preview: () => commitFromUI('preview'),
    locate: () => options.locate?.(source), review: () => {
      if (!state.lastReview) throw Error('还没有改动记录，请先保存资源或放入场景。');
      return options.review?.(state.lastReview);
    },
  };
  on(root, 'click', safe(event => { const action = event.target.closest('[data-action]')?.dataset.action; if (action && actions[action]) return actions[action](event); }));
  on(list, 'click', event => { const button = event.target.closest('[data-index]'); if (!button || state.busy) return; state.selected = state.frames[Number(button.dataset.index)]?.id; renderFrames(); });
  on(list, 'dragstart', event => { if (state.busy) { event.preventDefault(); return; } dragIndex = Number(event.target.closest('[data-index]')?.dataset.index); event.dataTransfer?.setData('text/plain', String(dragIndex)); });
  on(list, 'dragover', event => event.preventDefault());
  on(list, 'drop', safe(event => { event.preventDefault(); if (state.busy) return; const index = Number(event.target.closest('[data-index]')?.dataset.index); setFrames(model.reorder(state.frames, dragIndex, index)); }));
  const operationList=q('.ap-operation-list'),clearOperationDragState=()=>{operationList.querySelectorAll('.ap-operation').forEach(row=>{delete row.dataset.dragging;delete row.dataset.dropTarget;});};
  on(operationList,'dragstart',event=>{const row=event.target.closest('.ap-operation');if(!row||state.busy){event.preventDefault();return;}operationDragIndex=Number(row.dataset.index);row.dataset.dragging='true';if(event.dataTransfer){event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',String(operationDragIndex));}});
  on(operationList,'dragover',event=>{const row=event.target.closest('.ap-operation');if(!row||state.busy||operationDragIndex<0)return;event.preventDefault();if(event.dataTransfer)event.dataTransfer.dropEffect='move';operationList.querySelectorAll('.ap-operation').forEach(item=>{if(item!==row)delete item.dataset.dropTarget;});row.dataset.dropTarget='true';});
  on(operationList,'drop',safe(async event=>{event.preventDefault();const row=event.target.closest('.ap-operation'),target=Number(row?.dataset.index),from=operationDragIndex;operationDragIndex=-1;clearOperationDragState();if(state.busy||!Number.isInteger(from)||!Number.isInteger(target)||from<0||target<0||from===target)return;imageDraft.moveOperation(state.processDraft,from,target-from);await processChanged();}));
  on(operationList,'dragend',()=>{operationDragIndex=-1;clearOperationDragState();});
  on(field('useSelected'), 'change', safe(refreshContext));
  on(field('fps'), 'change', () => { pause(); state.fps = model.fps(field('fps').value); field('fps').value = state.fps; state.elapsed = state.currentIndex * 1000 / state.fps; state.clip = null; state.placed = null; state.sheetDirty = true; syncDirty(); state.revision++; updateControls(); });
  on(field('loop'), 'change', () => { state.loop = field('loop').checked; state.clip = null; state.placed = null; state.sheetDirty = true; syncDirty(); state.revision++; updateControls(); });
  on(field('seek'), 'input', () => { pause(); state.currentIndex = Number(field('seek').value); state.elapsed = state.currentIndex * 1000 / state.fps; drawAnimation(); });
  on(field('transformAction'),'change',safe(async()=>{const selectedAction=field('transformAction').value;field('transformAction').value='';if(selectedAction&&actions[selectedAction])await actions[selectedAction]();}));
  on(field('outputFormat'),'change',safe(async()=>{const jpeg=field('outputFormat').value==='jpeg';root.querySelectorAll('.ap-jpeg-field').forEach(node=>{node.hidden=!jpeg;});field('versionName').value=field('versionName').value.replace(/\.(?:png|jpe?g)$/i,jpeg?'.jpg':'.png');syncProcessOutput();state.processDirty=imageDraft.dirty(state.processDraft);syncDirty();await renderProcessDraft();}));
  on(field('versionName'),'input',()=>{syncProcessOutput();state.processDirty=imageDraft.dirty(state.processDraft);syncDirty();updateControls();});
  for(const name of ['jpegQuality','jpegMatte'])on(field(name),'change',safe(async()=>{if(field('outputFormat').value==='jpeg'){syncProcessOutput();state.processDirty=imageDraft.dirty(state.processDraft);syncDirty();await renderProcessDraft();}}));
  for(const name of ['imageNodeName','imageParentPath','imageNodeWidth','imageNodeHeight','anchorX','anchorY','spriteSliced'])on(field(name),'change',()=>{state.imagePlaced=null;updateControls();});
  const point = event => model.sourcePoint(event.clientX, event.clientY, image.getBoundingClientRect(), state.width, state.height);
  on(svg, 'pointerdown', safe(event => {
    if (!state.draw || state.busy || event.button !== 0) return;
    event.preventDefault(); event.stopPropagation(); const start = point(event), id = event.target.dataset.handle || event.target.dataset.frame;
    if (id) { state.selected = id; state.drag = { start, original: { ...selected() }, type: event.target.dataset.handle ? 'resize' : 'move' }; }
    else { if (state.frames.length >= model.MAX_FRAMES) throw new Error(`最多支持 ${model.MAX_FRAMES} 帧。`);
      let ordinal = state.frames.length + 1;
      const base = model.nameBase(source.displayName);
      while (state.frames.some(frame => frame.name === `${base}_${String(ordinal).padStart(2,'0')}`)) ordinal++;
      const name = `${base}_${String(ordinal).padStart(2,'0')}`;
      const frame = { ...model.rect({ x: start.x, y: start.y, width: 1, height: 1 }, state.width, state.height), id: `manual-${++state.sequence}`, name, order: state.frames.length };
      state.frames.push(frame); state.selected = frame.id; state.drag = { start, original: { ...frame }, type: 'create' }; }
    invalidate(); svg.setPointerCapture(event.pointerId); renderRects();
  }));
  on(svg, 'pointermove', safe(event => {
    if (!state.drag) return; const current = point(event), { start, original, type } = state.drag, frame = selected();
    const dx = current.x - start.x, dy = current.y - start.y;
    const next = type === 'move' ? { ...original, x: Math.max(0, Math.min(state.width - original.width, original.x + dx)), y: Math.max(0, Math.min(state.height - original.height, original.y + dy)) }
      : type === 'resize' ? { ...original, width: Math.max(1, original.width + dx), height: Math.max(1, original.height + dy) }
        : { x: Math.min(start.x,current.x), y: Math.min(start.y,current.y), width: Math.max(1,Math.abs(dx)), height: Math.max(1,Math.abs(dy)) };
    Object.assign(frame, model.rect(next, state.width, state.height)); renderRects();
  }));
  const endDrag = event => { if (!state.drag) return; state.drag = null; if (svg.hasPointerCapture?.(event.pointerId)) svg.releasePointerCapture(event.pointerId); renderFrames(); status(`${state.frames.length} 帧 · 尚未保存`); };
  on(svg, 'pointerup', endDrag); on(svg, 'pointercancel', endDrag);
  on(root, 'keydown', event => { if (event.key === 'Escape') { event.preventDefault(); actions.close(); }
    else if (event.key === 'Delete' && state.sheet && !['INPUT','TEXTAREA'].includes(event.composedPath()[0]?.tagName) && !state.busy) actions.delete(); });
  on(doc, 'visibilitychange', () => { if (doc.hidden) pause(); });
  on(win, 'beforeunload', destroy);
  // Creator keeps backgroundThrottling disabled: native hide may leave document.hidden=false.
  // Its bundled Electron remote supplies the actual window lifecycle; release these listeners too.
  const hostWindow = require('@electron/remote').getCurrentWindow();
  for (const event of ['hide', 'minimize']) {
    hostWindow.on(event, pause); listeners.push(() => hostWindow.removeListener(event, pause));
  }
  on(stage, 'wheel', event => { if (panzoom) { event.preventDefault(); panzoom.zoomWithWheel(event); } }, { passive: false });
  on(plane, 'panzoomchange', event => { if (state.disposed) return; q('.ap-zoom').textContent = `${Math.round(event.detail.scale * 100)}%`; renderRects(); });
  function destroy() {
    if (state.disposed) return; state.disposed = true; pause(); cancelLoad?.();
    for (const dispose of listeners.splice(0)) dispose(); observer?.disconnect(); panzoom?.destroy(); panzoom = null;
    image.onload = image.onerror = null; image.removeAttribute('src');
    if (state.blobUrl) win.URL.revokeObjectURL(state.blobUrl); state.blobUrl = '';
    if (state.previewBlobUrl) win.URL.revokeObjectURL(state.previewBlobUrl); state.previewBlobUrl = '';
    releaseCanvases(); state.drag = null; root.remove(); options.closed?.();
  }
  async function load() {
    try {
      const loaded = await options.read(); if (state.disposed) return;
      if (!loaded) {
        root.dataset.empty = 'true'; plane.hidden = true; q('.ap-stage-empty').hidden = false;
        q('.ap-title').textContent = '图片编辑'; q('[data-action=locate]').hidden = true;
        setMode('sheet');
        root.querySelectorAll('.ap-tools button, .ap-tools input, .ap-tools select, .ap-toolbar button').forEach(node => { node.disabled = !['view','process-mode','sheet','settings-mode'].includes(node.dataset.action); });
        q('.ap-zoom').textContent = '—'; status(''); return;
      }
      source = loaded;state.sourceAssetUuid=source.assetUuid||''; q('.ap-title').textContent = source.displayName || '图片'; q('[data-action=locate]').hidden = !source.assetUrl;
      const blob = source.blob || new win.Blob([source.bytes?.data ? new Uint8Array(source.bytes.data) : source.bytes], { type: source.mimeType });
      if (!['image/png','image/jpeg','image/webp'].includes(blob.type)) throw new Error('格式不支持，请选择 PNG、JPG 或 WebP。');
      state.blobUrl = win.URL.createObjectURL(blob);
      await new Promise((resolve, reject) => { cancelLoad = () => reject(new Error('预览已关闭')); image.onload = resolve; image.onerror = () => reject(new Error('图片无法读取。')); image.src = state.blobUrl; });
      cancelLoad = null; image.onload = image.onerror = null; if (state.disposed) return;
      model.dimensions(image.naturalWidth, image.naturalHeight);state.sourceWidth=image.naturalWidth;state.sourceHeight=image.naturalHeight;applyDimensions(state.sourceWidth,state.sourceHeight);
      panzoom = Panzoom(plane, { canvas: true, minScale: .001, maxScale: 32, step: .25, animate: false });
      observer = new win.ResizeObserver(() => { if (!state.disposed) fit(); }); observer.observe(stage);
      state.ready = true; root.dataset.ready = 'true';
      const base = model.nameBase(source.displayName),format=source.mimeType==='image/jpeg'?'jpeg':'png',extension=format==='jpeg'?'.jpg':'.png';
      state.processDraft=imageDraft.createDraft(source,{output:{format,name:`${base}-edited${extension}`}});field('versionName').value=state.processDraft.output.name;field('outputFormat').value=format;
      root.querySelectorAll('.ap-jpeg-field').forEach(node=>{node.hidden=format!=='jpeg';});
      field('cropWidth').value=state.sourceWidth;field('cropHeight').value=state.sourceHeight;field('resizeWidth').value=state.sourceWidth;field('resizeHeight').value=state.sourceHeight;
      field('canvasWidth').value=state.sourceWidth;field('canvasHeight').value=state.sourceHeight;field('imageOutputPath').value=`assets/art/${state.processDraft.output.name}`;
      field('outputFolder').value = `assets/${base}_frames`; field('nodeName').value = base;renderOperations();updateSettingsTarget();
      await refreshContext(); if (state.disposed) return;
      field('parentPath').value = context.canvasPaths?.[0] || ''; q('.ap-target').textContent = context.selectedNodeName || (context.selectedNodeUuid ? '已选择节点' : '未选择节点'); q('.ap-target').title = context.selectedNodeUuid || ''; q('.ap-target').hidden = !field('useSelected').checked;
      await setMode('view');fit(); status('拖动平移 · 滚轮缩放'); root.focus();
    } catch (error) { if (!state.disposed) status(error.message || '图片无法读取。', error); }
  }
  function agentSnapshot() {
    return { revision:state.revision, ready:state.ready, source:{name:source?.displayName,assetUrl:source?.assetUrl,assetUuid:source?.assetUuid},
      width:state.width,height:state.height,frames:state.frames.map(f=>({...f})),fps:state.fps,loop:state.loop,
      playing:state.playing,index:state.currentIndex,dirty:state.dirty,saved:state.saved,clip:state.clip,placed:state.placed,
      scene:context,mode:state.mode,drawMode:state.draw,
      review:state.lastReview ? {turnId:state.lastReview.changeSet?.turnId || state.lastReview.turnId || state.lastReview.taskId} : null,
      scale:panzoom?.getScale(),pan:panzoom?.getPan() };
  }
  async function agentAction(command,args={}) {
    if (!state.ready || state.disposed) throw Error('图片编辑器尚未就绪。');
    if (state.busy || state.preparing || state.drag) throw Error('图片编辑器正在操作，请稍后重试。');
    if (command==='inspect') { await refreshContext(); return agentSnapshot(); }
    if (args.revision!==state.revision) throw Error('图片草稿已改变，请重新 inspect 后使用最新 revision。');
    const o=args.options||{};
    const strictRect=f=>{const r=model.rect(f,state.width,state.height);if(['x','y','width','height'].some(k=>r[k]!==f[k]))throw Error('Frame 超出源图边界。');return {...r,...(f.name?{name:f.name}:{})};};
    const index=(v)=>{if(!Number.isInteger(v)||v<0||v>=state.frames.length)throw Error('帧索引无效。');return v;};
    if(command==='close') {
      if (state.dirty && args.discard !== true) throw Error('存在未保存草稿，关闭需明确 discard=true。');
      const result = { ...agentSnapshot(), closed:true };
      pause(); await options.requestClose?.({ discard:args.discard === true }); return result;
    } else if(command==='edit') {
      await setMode('sheet');
      if(args.action==='grid') {
        const frames=model.grid(state.width,state.height,{...o,base:source.displayName});
        for(const key of ['columns','rows','frameWidth','frameHeight','spacingX','spacingY','offsetX','offsetY']) if(o[key]!==undefined)field(key).value=o[key];
        field('gridMode').value=o.mode || 'count';setFrames(frames);
      }
      else if(args.action==='auto') { for(const k of ['threshold','minArea','gutter']) if(o[k]!==undefined)field(k).value=o[k];actions.auto(); }
      else if(args.action==='set_frames') { if(!Array.isArray(o.frames))throw Error('frames is required.');setFrames(model.frames(o.frames.map(strictRect),source.displayName).map((f,i)=>({...f,name:o.frames[i].name||f.name}))); }
      else if(args.action==='add_frame') {
        const frame = strictRect(o.frame || {});
        const next = model.frames([...state.frames,frame],source.displayName);
        setFrames(next.map((f,i)=>({...f,name:i<state.frames.length?state.frames[i].name:frame.name||f.name})));
      }
      else if(args.action==='update_frame') { const at=index(o.index),rect=strictRect(o.frame||{});setFrames(state.frames.map((f,i)=>i===at?{...f,...rect}:f)); }
      else if(args.action==='delete_frame') { const at=index(o.index);setFrames(state.frames.filter((f,i)=>i!==at).map((f,order)=>({...f,order}))); }
      else if(args.action==='reorder') setFrames(model.reorder(state.frames,o.from,o.to));
      else if(args.action==='clear') setFrames([]);
      else throw Error('Unsupported edit action.');
    } else if(command==='playback') {
      if (args.action === 'seek') index(args.index);
      if(args.fps!==undefined||args.loop!==undefined) {
        pause();state.fps=args.fps??state.fps;state.loop=args.loop??state.loop;field('fps').value=state.fps;field('loop').checked=state.loop;
        state.clip=null;state.placed=null;state.sheetDirty=true;state.dirty=true;state.revision++;state.elapsed=state.currentIndex*1000/state.fps;
      }
      if(args.action==='seek'){pause();state.currentIndex=index(args.index);state.elapsed=state.currentIndex*1000/state.fps;drawAnimation();}
      else if(['play','pause','stop'].includes(args.action))actions[args.action]();else throw Error('Unsupported playback action.');
    } else if(command==='view') {
      if(args.action==='capture') {
        if(args.target==='animation'||(!args.target&&state.frames.length)) {
          if(!state.frames.length)throw Error('请先切片。');
          drawAnimation();return {...agentSnapshot(),image:animation.toDataURL('image/png')};
        }
        const canvas=doc.createElement('canvas');canvases.add(canvas);
        try { drawFrame(canvas,{x:0,y:0,width:state.width,height:state.height});return {...agentSnapshot(),image:canvas.toDataURL('image/png')}; }
        finally { canvas.width=canvas.height=0;canvases.delete(canvas); }
      }
      if(args.action==='zoom') { if(!Number.isFinite(args.scale))throw Error('scale is required.');panzoom.zoom(args.scale,{force:true,animate:false}); }
      else if(args.action==='pan') { if(!Number.isFinite(args.x)||!Number.isFinite(args.y))throw Error('x/y are required.');panzoom.pan(args.x,args.y,{force:true,animate:false}); }
      else if(['zoom_in','zoom_out','draw_mode','pan_mode'].includes(args.action)) actions[{zoom_in:'plus',zoom_out:'minus',draw_mode:'manual',pan_mode:'pan'}[args.action]]();
      else if(['fit','reset','view','sheet','locate','review'].includes(args.action))await actions[args.action]();else throw Error('Unsupported view action.');
    } else {
      if(['place_in_scene','start_preview'].includes(command)) {
        const fresh=await options.context();
        if(state.disposed||state.busy||state.preparing||state.drag||args.revision!==state.revision)throw Error('图片草稿已改变，请重新 inspect。');
        if(!args.sceneUuid||fresh.sceneUuid!==args.sceneUuid)throw Error('当前 Scene 已改变，请重新检查。');context=fresh;
      }
      if(command==='save_frames')field('outputFolder').value=args.outputFolder;
      if(command==='create_animation')field('animationName').value=args.name;
      if(command==='place_in_scene') {
        if(!args.targetUuid&&!args.parentPath)throw Error('需要明确的 parentPath 或 targetUuid。');
        field('nodeName').value=args.nodeName||model.nameBase(source.displayName);field('parentPath').value=args.parentPath||'';
        field('useSelected').checked=!!args.targetUuid;context.selectedNodeUuid=args.targetUuid||'';field('playOnLoad').checked=args.playOnLoad===true;
      }
      const action={save_frames:'frames',create_animation:'animation',place_in_scene:'place',start_preview:'preview'}[command];
      if(!action)throw Error('Unsupported image editor command.');
      const result=await commit(action);return {...agentSnapshot(),writeResult:result.result};
    }
    updateControls(); return agentSnapshot();
  }
  const ready = load();
  return { root, state, ready, destroy, actions, agentAction, agentSnapshot, setFrames, exportFrames, fit, refreshContext, showError: error => status(error?.message || '操作失败，请重试。', error),
    snapshot: () => ({ ready: state.ready, disposed: state.disposed, frameCount: state.frames.length, playing: state.playing, raf: state.raf, listenerCount: listeners.length, canvasCount: canvases.size, blobActive: !!state.blobUrl, panzoomActive: !!panzoom, scale: panzoom?.getScale(), pan: panzoom?.getPan() }) };
}
module.exports = { createAssetPreview };
