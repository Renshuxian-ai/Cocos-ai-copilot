'use strict';

const PROMPT_COLLAPSED_LINES = 7;

const template = `
  <div class="copilot-root">
    <div id="fileDropHint" class="file-drop-hint" aria-hidden="true" hidden>松开添加</div>
    <header class="panel-header">
      <div class="session-context">
        <ui-button id="sessionHistoryButton" class="icon-button back-button" title="返回会话" aria-label="返回会话">←</ui-button>
        <button id="sessionTitleButton" class="session-title" type="button" title="新会话">新会话</button>
      </div>
      <div id="sessionStatus" class="session-status" title="Editor mode · Main.scene">
        <span class="status-prefix">状态：</span>
        <span id="modeLabel" class="mode-label">Editor</span>
      </div>
      <div class="header-actions" aria-label="Panel actions">
        <ui-button id="sessionMoreButton" class="icon-button" title="更多操作" aria-label="更多操作">⋯</ui-button>
        <ui-button id="settingsButton" class="icon-button settings-button" title="设置" aria-label="设置">
          <svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="2.1"/><path d="M6.7 1.9h2.6l.45 1.45c.35.13.68.32.98.56l1.47-.34 1.3 2.25-1.02 1.11c.03.18.04.37.04.56s-.01.38-.04.56l1.02 1.11-1.3 2.25-1.47-.34c-.3.24-.63.43-.98.56L9.3 14.1H6.7l-.45-1.45a5.1 5.1 0 0 1-.98-.56l-1.47.34-1.3-2.25 1.02-1.11A3.8 3.8 0 0 1 3.48 8c0-.19.01-.38.04-.56L2.5 6.33l1.3-2.25 1.47.34c.3-.24.63-.43.98-.56L6.7 1.9Z"/></svg>
        </ui-button>
        <ui-button id="newSessionButton" class="icon-button new-session-button" title="New session" aria-label="New session">
          <svg viewBox="0 0 16 16" aria-hidden="true">
            <path d="M3.25 2.75h6.5a1.5 1.5 0 0 1 1.5 1.5v2.1M3.25 2.75a1.5 1.5 0 0 0-1.5 1.5v7.5a1.5 1.5 0 0 0 1.5 1.5h7.5a1.5 1.5 0 0 0 1.5-1.5v-1" />
            <path d="m8.5 10.25 4.2-4.2 1.25 1.25-4.2 4.2-1.75.5.5-1.75Z" />
          </svg>
        </ui-button>
      </div>
    </header>

    <section id="sessionHistory" class="session-history" aria-label="最近会话" hidden>
      <div class="session-search-wrap">
        <input id="sessionSearchInput" class="session-search" type="search" placeholder="搜索最近聊天" aria-label="搜索最近聊天" />
      </div>
      <div class="session-history-separator" aria-hidden="true"></div>
      <div class="session-history-heading">本地聊天</div>
      <div id="sessionList" class="session-list" role="listbox" aria-label="会话列表"></div>
    </section>

    <div id="sessionMoreMenu" class="session-menu" role="menu" aria-label="会话操作" hidden>
      <button id="renameSessionButton" type="button" role="menuitem">
        <svg class="session-menu-icon" viewBox="0 0 16 16" aria-hidden="true">
          <path d="m10.5 2.5 3 3-7.75 7.75-3.5.5.5-3.5L10.5 2.5Z" />
          <path d="m9.25 3.75 3 3" />
        </svg>
        <span>重命名</span>
      </button>
      <button id="continueSessionButton" type="button" role="menuitem">
        <svg class="session-menu-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 3v6a3 3 0 0 0 3 3h7m-3-3 3 3-3 3" /></svg>
        <span>在新会话中继续</span>
      </button>
      <button id="archiveSessionButton" type="button" role="menuitem">
        <svg class="session-menu-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M2 3h12v3H2zM3 6v7h10V6M6 9h4" /></svg>
        <span>归档</span>
      </button>
      <button id="deleteSessionButton" type="button" role="menuitem">
        <svg class="session-menu-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M2.5 4h11M6 4V2h4v2M4 4l.5 10h7L12 4M6.5 7v4M9.5 7v4" /></svg>
        <span id="deleteSessionLabel">删除</span>
      </button>
    </div>

    <div id="renameSessionDialog" class="rename-dialog-backdrop" role="presentation" hidden>
      <section class="rename-dialog" role="dialog" aria-modal="true" aria-labelledby="renameSessionTitle">
        <div id="renameSessionTitle" class="rename-dialog-title">重命名聊天</div>
        <div class="rename-dialog-subtitle">保持简短且易于识别</div>
        <input id="renameSessionInput" class="rename-session-input" type="text" aria-label="聊天标题" placeholder="添加标题…" maxlength="80" />
        <div class="rename-dialog-actions">
          <button id="renameSessionCancel" class="secondary-action" type="button">取消</button>
          <button id="renameSessionSave" class="primary-action" type="button">保存</button>
        </div>
      </section>
    </div>

    <div id="sessionNotice" class="session-notice" role="status" hidden></div>
    <section id="firstRunOnboarding" class="first-run-onboarding" hidden>
      <div class="onboarding-content">
        <h2>AI Copilot</h2>
        <p>连接模型服务后即可开始</p>
        <button id="onboardingChatGpt" type="button">使用 ChatGPT 登录</button>
        <button id="onboardingOpenAiKey" type="button">使用 OpenAI API Key</button>
        <button id="onboardingDeepSeekKey" type="button">使用 DeepSeek API Key</button>
        <div id="onboardingMessage" class="onboarding-message" role="status" hidden></div>
      </div>
    </section>
    <main id="activityScroller" class="conversation-thread" aria-label="AI Copilot conversation">
      <div id="activityContent" class="thread-content">
        <div id="emptyState" class="empty-state">输入开发任务，AI Copilot 会在这里显示真实执行过程。</div>
      </div>
    </main>
    <footer class="composer">
      <section id="queueArea" class="queue-area" aria-label="排队消息" hidden>
        <div id="queuePausedStatus" class="queue-paused-status" hidden></div>
        <div id="queueItems" class="queue-items"></div>
      </section>
      <section id="approvalTray" class="approval-tray" aria-label="待批准操作" aria-live="polite" hidden></section>
      <button id="scrollToLatestButton" class="scroll-to-latest" type="button" title="滚动到最新消息" aria-label="滚动到最新消息" hidden>
        <svg class="scroll-indicator-arrow" viewBox="0 0 18 18" aria-hidden="true">
          <path d="M9 3.25v10.25" />
          <path d="m4.75 9.5 4.25 4.25 4.25-4.25" />
        </svg>
        <span class="scroll-indicator-dots" aria-hidden="true">
          <span></span>
          <span></span>
          <span></span>
        </span>
      </button>
      <div id="composerSurface" class="composer-surface">
        <div class="composer-pin-row">
          <button id="pinEntryButton" class="pin-entry-button" type="button" aria-label="钉住 Cocos 对象">
            <svg viewBox="0 0 16 16" aria-hidden="true">
              <path d="M5.1 2.5h5.8M6 2.5l.45 4.1-2.2 2.2v.95h7.5V8.8l-2.2-2.2L10 2.5M8 9.75v3.75" />
            </svg>
          </button>
          <button id="pinCount" class="pin-count-button" type="button" aria-label="查看钉子" hidden>0</button>
        </div>
        <div id="pinModeBar" class="pin-mode-bar" role="status" hidden>
          <span>钉子模式 · <strong id="pendingPinCount">0</strong></span>
          <span class="pin-mode-actions">
            <button id="cancelPinModeButton" type="button" title="取消钉子模式" aria-label="取消钉子模式">×</button>
            <button id="confirmPinModeButton" type="button" title="确认钉住" aria-label="确认钉住">✓</button>
          </span>
        </div>
        <div id="pinDropHint" class="pin-drop-hint" aria-hidden="true" hidden>松开以钉住</div>
        <div id="composerAttachments" class="attachment-list composer-attachment-list" aria-label="附件" hidden></div>
        <textarea id="composerInput" rows="2" placeholder="提出开发任务..."></textarea>
        <div class="composer-footer">
          <div class="composer-actions">
            <ui-button id="attachButton" class="composer-action attach-button" title="添加附件" aria-label="添加附件"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2.25v11.5M2.25 8h11.5"/></svg></ui-button>
            <button id="agentButton" class="agent-button" type="button" title="Agent · Codex" aria-label="Agent · Codex" aria-haspopup="menu" aria-expanded="false"><svg class="agent-icon" viewBox="0 0 16 16" aria-hidden="true"><rect x="3.25" y="4.25" width="9.5" height="7.5" rx="2"/><path d="M8 2.25v2M5.5 8h.01M10.5 8h.01M6 10h4"/></svg></button>
            <button id="modelButton" class="model-button" type="button" title="选择模型" aria-label="选择模型" aria-haspopup="menu" aria-expanded="false">选择模型</button>
            <button id="reasoningButton" class="reasoning-button" type="button" title="思考强度" aria-label="思考强度" aria-haspopup="menu" aria-expanded="false">中</button>
            <ui-button id="toolsButton" class="tools-button" title="Tools" aria-label="Tools" aria-haspopup="dialog" aria-expanded="false"><svg class="tools-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="M9.7 2.1a3.5 3.5 0 0 0-4.4 4.4l-3.1 3.1a1.7 1.7 0 0 0 2.4 2.4l3.1-3.1a3.5 3.5 0 0 0 4.4-4.4L9.8 6.8 8 5l1.7-2.9Z"/></svg></ui-button>
            <ui-button id="sendButton" class="composer-action send-button is-send-empty" title="发送" aria-label="发送">↑</ui-button>
          </div>
        </div>
      </div>
      <div class="permission-dock"><button id="permissionButton" class="permission-button" type="button" title="更改权限" aria-label="更改权限" aria-haspopup="menu" aria-expanded="false"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.6 13 3.5v4.2c0 3-1.8 5.2-5 6.7-3.2-1.5-5-3.7-5-6.7V3.5L8 1.6Z"/><path d="M8 5.1v3.8M8 11.2h.01"/></svg></button></div>
      <div id="composerToast" class="composer-toast" role="status" aria-live="polite" hidden></div>
      <div id="queueContextMenu" class="composer-context-menu queue-context-menu" role="menu" aria-label="排队消息操作" hidden>
        <button id="queueEditButton" type="button" role="menuitem">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m10.5 2.5 3 3-7.75 7.75-3.5.5.5-3.5L10.5 2.5Z"/><path d="m9.25 3.75 3 3"/></svg>
          <span>编辑消息</span>
        </button>
        <button id="queueClearButton" type="button" role="menuitem">
          <svg class="queue-toggle-icon" viewBox="0 0 20 20" aria-hidden="true"><path d="M2.66797 11V3.33301C2.66797 2.96574 2.96574 2.66797 3.33301 2.66797C3.70028 2.66797 3.99805 2.96574 3.99805 3.33301V11C3.99805 11.7109 3.99894 12.2044 4.03027 12.5879C4.06098 12.9634 4.11776 13.175 4.19824 13.333L4.26856 13.459C4.44487 13.7465 4.69781 13.9808 5 14.1348L5.12988 14.1904C5.27366 14.2419 5.46311 14.2797 5.74512 14.3027C6.12864 14.3341 6.62197 14.335 7.33301 14.335H15L15.0674 14.3418L14.1123 13.3867L14.0273 13.2822C13.8571 13.0242 13.8854 12.6735 14.1123 12.4463C14.3397 12.2189 14.6911 12.1906 14.9492 12.3613L15.0537 12.4463L17.1367 14.5293C17.3964 14.7889 17.3963 15.21 17.1367 15.4697L15.0537 17.5537C14.794 17.8134 14.372 17.8134 14.1123 17.5537C13.8526 17.294 13.8526 16.872 14.1123 16.6123L15.0664 15.6582L15 15.665H7.33301C6.64392 15.665 6.08696 15.6647 5.63672 15.6279C5.23614 15.5952 4.87531 15.5309 4.53906 15.3867L4.39649 15.3193C3.87528 15.0538 3.43887 14.6502 3.13477 14.1543L3.0127 13.9365C2.82084 13.5599 2.74153 13.1541 2.7041 12.6963C2.66732 12.2461 2.66797 11.6889 2.66797 11ZM15.665 15C15.665 15.0226 15.6594 15.0444 15.6572 15.0664L15.7256 14.999L15.6572 14.9316C15.6595 14.9541 15.665 14.9769 15.665 15ZM11.666 8.91797L11.8008 8.93164C12.1036 8.99381 12.3311 9.2618 12.3311 9.58301C12.3311 9.90422 12.1036 10.1722 11.8008 10.2344L11.666 10.248H7.5C7.13273 10.248 6.83496 9.95028 6.83496 9.58301C6.83496 9.21574 7.13273 8.91797 7.5 8.91797H11.666ZM14.166 4.33496L14.3008 4.34863C14.6036 4.41083 14.8311 4.67881 14.8311 5C14.8309 5.32109 14.6035 5.58924 14.3008 5.65137L14.166 5.66504H7.5C7.13284 5.66504 6.83514 5.36712 6.83496 5C6.83496 4.63273 7.13273 4.33496 7.5 4.33496H14.166Z"/></svg>
          <span>关闭排队</span>
        </button>
      </div>
    </footer>
    <div id="permissionMenu" class="permission-menu" role="menu" aria-label="Codex 权限模式" hidden></div>
    <div id="agentMenu" class="agent-menu compact-picker" role="menu" aria-label="Agent" hidden></div>
    <div id="modelMenu" class="model-menu" role="menu" aria-label="选择模型" hidden></div>
    <div id="reasoningMenu" class="reasoning-menu compact-picker" role="menu" aria-label="思考强度" hidden></div>
    <div id="composerPinPopover" class="pin-popover" role="dialog" aria-label="钉子" hidden></div>
    <div id="toolsPopover" class="tools-popover" role="dialog" aria-label="Tools" hidden></div>
  </div>
`;

const style = `
  :host {
    --font-body: 14px;
    --font-secondary: 12px;
    --font-caption: 11px;
    --font-code: 12px;
    --line-body: 21px;
    --line-secondary: 18px;
    --space-1: 4px;
    --space-2: 8px;
    --space-3: 12px;
    --space-4: 16px;
    --thread-padding: 16px;
    --icon-column: 16px;
    --text-primary: var(--color-normal-contrast, #d6d6d6);
    --text-secondary: var(--color-normal-contrast-weak, #a7a7a7);
    --text-muted: var(--color-normal-contrast-weakest, #747474);
    --surface: #202020;
    --surface-raised: #292929;
    --surface-approval: #393939;
    --border-subtle: rgba(128, 128, 128, 0.22);
    --success: #69b77d;
    --warning: #d4ac62;
    --danger: #d77979;
    --running: #78a9d1;
    --radius-message: 8px;
    --radius-composer: 8px;
    --radius-detail: 6px;
    display: block;
    height: 100%;
    min-width: 0;
    color: var(--text-primary);
    background: var(--surface);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: var(--font-body);
  }

  * { box-sizing: border-box; }

  button, textarea { font: inherit; }

  .conversation-thread,
  .thread-content,
  .conversation-turn,
  .turn-user-message,
  .user-message-surface,
  .user-message-text,
  .turn-assistant,
  .assistant-block,
  .assistant-presentation,
  .assistant-message,
  .assistant-message-content,
  .activity-header,
  .activity-summary,
  .activity-status,
  .activity-detail,
  .plan-list,
  .activity-list,
  .detail-heading,
  .detail-grid,
  .detail-section,
  .detail-output,
  .command-line,
  .file-name,
  .file-path,
  .file-diff,
  .state-guard-reason,
  .error-detail,
  .turn-error,
  .duration-disclosure,
  .markdown-paragraph,
  .markdown-list,
  .inline-code,
  .code-block {
    -webkit-user-select: text;
    user-select: text;
  }

  .panel-header,
  .icon-button,
  .prompt-toggle,
  .inline-toggle,
  .activity-icon,
  .activity-chevron,
  .assistant-copy-button,
  .scroll-to-latest,
  .composer-footer,
  .composer-context-menu,
  .duration-disclosure > span:last-child {
    -webkit-user-select: none;
    user-select: none;
  }

  .copilot-root {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
    line-height: var(--line-body);
  }

  .panel-header {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    height: 28px;
    min-width: 0;
    padding: 0 6px;
    border-bottom: 1px solid var(--color-normal-border, var(--border-subtle));
    background: var(--surface);
  }

  .session-context {
    display: flex;
    flex: 1 1 auto;
    align-items: center;
    min-width: 0;
    gap: var(--space-1);
    overflow: hidden;
  }

  .session-title {
    display: block;
    flex: 0 1 auto;
    min-width: 0;
    max-width: 100%;
    padding: 1px 3px;
    overflow: hidden;
    color: var(--text-secondary);
    border: 0;
    border-radius: 3px;
    outline: 0;
    background: transparent;
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
    text-align: left;
    white-space: nowrap;
    text-overflow: ellipsis;
    cursor: pointer;
  }

  .session-title:hover,
  .session-title:focus-visible {
    color: var(--text-primary);
    background: var(--surface-raised);
  }

  .session-title.is-static {
    color: var(--text-secondary);
    cursor: default;
  }

  .session-title.is-static:hover,
  .session-title.is-static:focus-visible { background: transparent; }

  .session-status {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    gap: var(--space-1);
    margin-left: var(--space-2);
    color: var(--text-secondary);
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
    white-space: nowrap;
  }

  .mode-label { color: var(--text-secondary); }
  .mcp-label { margin-left: var(--space-1); }

  .connection-dot {
    width: 5px;
    height: 5px;
    flex: 0 0 5px;
    border-radius: 50%;
    background: #777;
    opacity: 0.75;
  }

  .connection-dot.is-started { background: var(--success); opacity: 0.95; }
  .connection-dot.is-stopped { background: #986b6b; opacity: 0.9; }

  .header-actions {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    margin-left: var(--space-1);
  }

  .panel-header .icon-button {
    width: 20px;
    min-width: 20px;
    height: 20px;
    min-height: 20px;
    padding: 0;
    color: var(--text-muted);
    border-color: transparent;
    background: transparent;
    font-size: var(--font-secondary);
  }

  .panel-header .icon-button:hover {
    color: var(--text-primary);
    background: var(--surface-raised);
  }

  .panel-header .back-button { margin-left: -2px; }
  .panel-header .icon-button[hidden] { display: none; }

  .panel-header .new-session-button svg {
    width: 13px;
    height: 13px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.15;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .panel-header .settings-button svg {
    width: 13px;
    height: 13px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.05;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .first-run-onboarding {
    display: flex;
    flex: 1 1 auto;
    min-height: 0;
    align-items: center;
    justify-content: center;
    padding: 28px 22px 48px;
  }

  .first-run-onboarding[hidden] { display: none; }
  .onboarding-content { width: min(100%, 300px); text-align: center; }
  .onboarding-content h2 { margin: 0; color: var(--text-primary); font-size: 18px; line-height: 26px; font-weight: 500; }
  .onboarding-content p { margin: 4px 0 22px; color: var(--text-muted); font-size: var(--font-secondary); }
  .onboarding-content button { display: block; width: 100%; min-height: 32px; margin-top: 7px; padding: 0 11px; border: 1px solid rgba(128,128,128,.22); border-radius: 6px; color: var(--text-secondary); background: rgba(128,128,128,.075); cursor: pointer; }
  .onboarding-content button:hover { color: var(--text-primary); background: rgba(128,128,128,.14); }
  .onboarding-content button:focus-visible { outline: 1px solid rgba(120,164,202,.72); outline-offset: 2px; }
  .onboarding-message { margin-top: 12px; color: var(--warning); font-size: var(--font-caption); line-height: 17px; }
  .copilot-root.is-onboarding .conversation-thread,
  .copilot-root.is-onboarding .composer { display: none; }

  .session-history {
    position: absolute;
    z-index: 30;
    top: 32px;
    left: 6px;
    right: 6px;
    max-height: min(300px, calc(100% - 44px));
    padding: 5px 4px 4px;
    overflow: hidden;
    border: 1px solid var(--color-normal-border, var(--border-subtle));
    border-radius: 6px;
    background: var(--surface-raised);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.24);
  }

  .session-history[hidden] { display: none; }

  .session-search-wrap { padding: 2px 4px 5px; }

  .session-search,
  .all-sessions-search,
  .rename-session-input {
    display: block;
    width: 100%;
    min-width: 0;
    height: 28px;
    padding: 3px 8px;
    color: var(--text-primary);
    border: 1px solid rgba(128, 128, 128, 0.24);
    border-radius: 5px;
    outline: 0;
    background: rgba(0, 0, 0, 0.12);
    font-size: var(--font-secondary);
  }

  .session-search:focus,
  .all-sessions-search:focus,
  .rename-session-input:focus { border-color: rgba(88, 125, 158, 0.72); }

  .session-search::placeholder,
  .all-sessions-search::placeholder,
  .rename-session-input::placeholder { color: var(--text-muted); }

  .session-history-separator {
    height: 1px;
    margin: 0 6px;
    background: rgba(128, 128, 128, 0.16);
  }

  .session-history-heading {
    padding: 5px 7px 3px;
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: 16px;
    user-select: none;
  }

  .session-list {
    display: flex;
    flex-direction: column;
    max-height: min(220px, calc(100vh - 128px));
    min-height: 0;
    gap: 0;
    overflow-x: hidden;
    overflow-y: auto;
  }

  .session-list::-webkit-scrollbar { width: 5px; }
  .session-list::-webkit-scrollbar-thumb {
    border-radius: 8px;
    background: rgba(128, 128, 128, 0.22);
  }

  .session-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: center;
    width: 100%;
    min-height: 34px;
    padding: 5px 7px;
    color: var(--text-secondary);
    border: 0;
    border-radius: 4px;
    outline: 0;
    background: transparent;
    column-gap: 10px;
    text-align: left;
    cursor: pointer;
  }

  .session-row:hover,
  .session-row:focus-visible,
  .session-row-wrap:hover > .session-row {
    color: var(--text-primary);
    background: rgba(128, 128, 128, 0.1);
  }

  .session-row.is-active {
    color: var(--text-primary);
    background: rgba(128, 128, 128, 0.14);
  }

  .session-row-title {
    min-width: 0;
    overflow: hidden;
    font-size: var(--font-secondary);
    line-height: 17px;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  .session-row-time {
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: 16px;
    white-space: nowrap;
  }

  .session-row-meta {
    flex: 0 0 auto;
  }

  .session-row-wrap { position: relative; display: flex; min-width: 0; }
  .session-row-archive {
    position: absolute; top: 50%; right: 7px; transform: translateY(-50%);
    display: inline-flex; align-items: center; justify-content: center;
    width: 24px; height: 24px; padding: 3px; border: 0; border-radius: 4px;
    color: var(--text-secondary); background: transparent; cursor: pointer;
    opacity: 0; pointer-events: none;
  }
  .session-row-archive svg { width: 18px; height: 18px; fill: none; stroke: currentColor; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; }
  .session-row-archive:hover, .session-row-archive:focus-visible { color: var(--text-primary); }
  .session-row-wrap:hover .session-row-archive,
  .session-row-archive:focus-visible { opacity: 1; pointer-events: auto; }
  .session-row-wrap:hover .session-row-meta,
  .session-row-wrap:hover .session-row-updated,
  .session-row-archive:focus-visible + .session-row .session-row-meta,
  .session-row-archive:focus-visible + .session-row .session-row-updated { visibility: hidden; }

  .session-row-spinner, .composer-toast[data-kind="progress"]::before {
    width: 15px;
    height: 15px;
    box-sizing: border-box;
    border: 1.5px solid rgba(190, 190, 190, 0.28);
    border-top-color: rgba(224, 224, 224, 0.78);
    border-radius: 50%;
    animation: session-row-spin 0.9s linear infinite;
  }
  .session-row-waiting { color: var(--warning); font-size: var(--font-caption); white-space: nowrap; }
  .session-notice { padding: 6px 16px; color: var(--warning); font-size: var(--font-secondary); }
  .session-notice[hidden] { display: none; }
  .queue-resume { color: var(--text-secondary); background: transparent; border: 0; cursor: pointer; margin-left: 8px; }

  @keyframes session-row-spin {
    to { transform: rotate(360deg); }
  }

  .session-list-empty {
    padding: 18px 8px;
    color: var(--text-muted);
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
    text-align: center;
  }

  .session-menu {
    position: absolute;
    z-index: 42;
    top: 30px;
    right: 28px;
    width: max-content;
    min-width: 180px;
    padding: 4px;
    border: 1px solid var(--color-normal-border, var(--border-subtle));
    border-radius: 6px;
    background: var(--surface-raised);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.24);
  }

  .session-menu[hidden],
  .rename-dialog-backdrop[hidden] { display: none; }

  .session-menu button {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    min-height: 34px;
    padding: 5px 8px;
    color: var(--text-secondary);
    border: 0;
    border-radius: 4px;
    background: transparent;
    font-size: var(--font-secondary);
    text-align: left;
    white-space: nowrap;
    cursor: pointer;
  }

  .session-menu-icon {
    width: 16px;
    height: 16px;
    flex: 0 0 16px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.25;
    stroke-linecap: round;
    stroke-linejoin: round;
    opacity: 0.76;
  }

  .session-menu button:hover,
  .session-menu button:focus-visible {
    color: var(--text-primary);
    outline: 0;
    background: rgba(128, 128, 128, 0.12);
  }

  .rename-dialog-backdrop {
    position: absolute;
    z-index: 60;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    background: rgba(0, 0, 0, 0.34);
  }

  .rename-dialog {
    width: min(320px, 100%);
    padding: 14px;
    border: 1px solid rgba(128, 128, 128, 0.3);
    border-radius: 8px;
    background: var(--surface-raised);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.32);
  }

  .rename-dialog-title {
    color: var(--text-primary);
    font-size: var(--font-body);
    font-weight: 600;
    line-height: var(--line-body);
  }

  .rename-dialog-subtitle {
    margin: 2px 0 10px;
    color: var(--text-muted);
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
  }

  .rename-dialog-actions {
    display: flex;
    justify-content: flex-end;
    gap: 6px;
    margin-top: 12px;
  }

  .rename-dialog-actions button {
    min-height: 26px;
    padding: 3px 10px;
    border: 1px solid rgba(128, 128, 128, 0.28);
    border-radius: 5px;
    color: var(--text-secondary);
    background: transparent;
    cursor: pointer;
  }

  .rename-dialog-actions button:hover { color: var(--text-primary); }
  .rename-dialog-actions .primary-action { background: rgba(88, 125, 158, 0.42); }
  .rename-dialog-actions .primary-action:disabled { opacity: 0.45; cursor: default; }

  .conversation-thread {
    position: relative;
    flex: 1 1 auto;
    min-width: 0;
    min-height: 0;
    padding: var(--space-3) var(--thread-padding) 48px;
    overflow-x: hidden;
    overflow-y: auto;
    overscroll-behavior: contain;
  }

  .conversation-thread::-webkit-scrollbar { width: 5px; }
  .conversation-thread::-webkit-scrollbar-thumb {
    border: 1px solid transparent;
    border-radius: 8px;
    background: rgba(128, 128, 128, 0.2);
    background-clip: padding-box;
  }
  .conversation-thread::-webkit-scrollbar-thumb:hover {
    background: rgba(128, 128, 128, 0.42);
    background-clip: padding-box;
  }

  .thread-content {
    min-width: 0;
    max-width: 720px;
    margin: 0 auto;
  }

  .empty-state {
    padding: var(--space-4) 0;
    color: var(--text-muted);
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
    text-align: center;
  }

  .empty-state[hidden] { display: none; }

  .sessions-page {
    min-height: 100%;
    padding: 0 0 12px;
  }

  .chats-home .home-session-list,
  .chats-home .home-view-all {
    position: relative;
    z-index: 1;
  }

  .all-sessions-label {
    margin-bottom: 4px;
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: 16px;
    user-select: none;
  }

  .home-session-list,
  .all-sessions-list {
    display: flex;
    flex-direction: column;
    gap: 1px;
  }

  .chats-home .home-session-list { gap: 4px; }

  .chats-home .session-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 42px;
    min-height: 42px;
    box-sizing: border-box;
    padding: 0 7px;
    border-radius: 7px;
    column-gap: 10px;
  }

  .chats-home .session-row-title {
    flex: 1 1 auto;
    min-width: 0;
    color: rgba(224, 224, 224, 0.92);
    font-size: 13px;
    font-weight: 400;
    line-height: 18px;
  }

  .chats-home .session-row-time {
    color: rgba(190, 190, 190, 0.78);
    font-size: 12px;
    line-height: 16px;
  }

  .home-view-all {
    display: block;
    width: 100%;
    min-height: 28px;
    margin-top: 6px;
    padding: 4px 7px;
    color: var(--text-muted);
    border: 0;
    border-radius: 4px;
    background: transparent;
    font-size: var(--font-secondary);
    text-align: left;
    cursor: pointer;
  }

  .home-view-all:hover,
  .home-view-all:focus-visible {
    color: var(--text-secondary);
    outline: 0;
    background: rgba(128, 128, 128, 0.07);
  }

  .home-ambient {
    position: absolute;
    z-index: 0;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(150, 150, 150, 0.32);
    pointer-events: none;
    user-select: none;
  }

  .home-ambient svg {
    width: 42px;
    height: 42px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.25;
  }

  .all-sessions-search-wrap { margin-bottom: 10px; }
  .all-sessions-list { padding-bottom: 10px; }

  .copilot-root[data-session-view="all"] .composer { display: none; }

  .conversation-turn {
    min-width: 0;
  }

  .conversation-turn + .conversation-turn { margin-top: 20px; }

  .turn-user-message {
    width: fit-content;
    max-width: 72%;
    margin-left: auto;
    margin-right: 14px;
  }

  .steer-follow-up { margin-top: 10px; margin-bottom: 10px; }

  .user-message-actions {
    display: flex;
    min-height: 20px;
    margin: 3px 2px 0;
    align-items: center;
    justify-content: flex-end;
    gap: 4px;
    opacity: 0;
    pointer-events: none;
    transition: opacity 140ms ease;
  }

  .turn-user-message:hover > .user-message-actions,
  .turn-user-message:focus-within > .user-message-actions {
    opacity: 1;
    pointer-events: auto;
  }

  .user-message-time {
    color: var(--text-muted);
    font-size: var(--font-caption);
    font-weight: normal;
    line-height: 16px;
    -webkit-user-select: text;
    user-select: text;
  }

  .user-message-copy-button { opacity: 0.68; }
  .user-message-copy-button:hover,
  .user-message-copy-button:focus-visible { opacity: 1; }

  .user-message-surface {
    padding: 8px 12px;
    overflow: hidden;
    border: 0;
    border-radius: 11px;
    background: rgba(128, 128, 128, 0.055);
    box-shadow: none;
  }

  .user-message-text {
    min-width: 0;
    color: var(--text-primary);
    font-size: var(--font-body);
    line-height: var(--line-body);
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }

  .user-message-text.is-collapsed {
    display: -webkit-box;
    overflow: hidden;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: ${PROMPT_COLLAPSED_LINES};
  }

  .attachment-list {
    display: flex;
    min-width: 0;
    flex-direction: column;
    align-items: flex-start;
    gap: 6px;
  }

  .attachment-list[hidden] { display: none; }

  .attachment-chip {
    display: flex;
    width: fit-content;
    max-width: 100%;
    min-width: 0;
    height: 32px;
    align-items: center;
    overflow: hidden;
    border: 1px solid rgba(128, 128, 128, 0.18);
    border-radius: 999px;
    background: rgba(128, 128, 128, 0.14);
  }

  .attachment-open-button {
    appearance: none;
    display: flex;
    max-width: 100%;
    min-width: 0;
    flex: 1 1 auto;
    align-items: center;
    gap: 7px;
    padding: 0 11px;
    overflow: hidden;
    border: 0;
    color: var(--text-primary);
    background: transparent;
    font-size: var(--font-secondary);
    font-weight: 400;
    line-height: 30px;
    text-align: left;
    cursor: pointer;
  }

  .attachment-chip:hover { background: rgba(128, 128, 128, 0.2); }

  .attachment-document-icon {
    width: 15px;
    height: 15px;
    flex: 0 0 15px;
    fill: none;
    stroke: var(--text-secondary);
    stroke-width: 1.15;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .attachment-title {
    min-width: 0;
    flex: 1 1 auto;
    overflow: hidden;
    font-size: var(--font-secondary);
    font-weight: 400;
    line-height: 30px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .attachment-text-title {
    display: block;
    min-width: 0;
    overflow: hidden;
    color: var(--text-primary);
    line-height: 17px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .attachment-text-copy {
    display: flex;
    min-width: 0;
    flex: 1 1 auto;
    flex-direction: column;
    justify-content: center;
    overflow: hidden;
  }

  .attachment-text-source {
    display: block;
    min-width: 0;
    overflow: hidden;
    color: var(--text-muted);
    font-size: 10px;
    line-height: 14px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .attachment-chip.is-text-attachment {
    height: 44px;
    border-radius: 9px;
  }

  .attachment-chip.is-text-attachment .attachment-open-button {
    height: 42px;
    line-height: normal;
  }

  .attachment-chip.is-text-attachment .attachment-remove-button { height: 42px; }

  .attachment-file-button { cursor: default; }
  .attachment-secondary {
    flex: 0 0 auto;
    color: var(--text-muted);
    font-size: 10px;
    line-height: 30px;
    white-space: nowrap;
  }
  .attachment-chip.is-unavailable { opacity: 0.58; }
  .attachment-chip.is-pending { opacity: 0.72; }
  .attachment-chip.is-failed { border-color: rgba(205, 105, 105, 0.28); }

  .composer-attachment-list,
  .turn-attachment-list { flex-flow: row wrap; }
  .image-attachment {
    position: relative;
    width: 112px;
    height: 76px;
    overflow: hidden;
    border: 1px solid rgba(128, 128, 128, 0.18);
    border-radius: 8px;
    background: rgba(128, 128, 128, 0.1);
  }
  .image-attachment:hover,
  .image-attachment:focus-within { border-color: rgba(160, 160, 160, 0.34); background: rgba(128, 128, 128, 0.16); }
  .image-attachment img { display: block; width: 100%; height: 100%; object-fit: cover; }
  .image-attachment.is-unavailable img { display: none; }
  .image-attachment-unavailable { display: none; height: 100%; align-items: center; justify-content: center; padding: 8px; color: var(--text-muted); font-size: 10px; text-align: center; }
  .image-attachment-unavailable::before { content: '▧'; margin-right: 4px; font-size: 12px; }
  .image-attachment.is-unavailable .image-attachment-unavailable { display: flex; }
  .image-attachment-remove {
    position: absolute;
    top: 4px;
    right: 4px;
    display: inline-flex;
    width: 20px;
    height: 20px;
    align-items: center;
    justify-content: center;
    padding: 0;
    border: 1px solid rgba(255,255,255,0.16);
    border-radius: 50%;
    background: rgba(24,24,24,0.82);
    color: #e8e8e8;
    font-size: 14px;
    line-height: 18px;
    opacity: 0;
    cursor: pointer;
  }
  .image-attachment:hover .image-attachment-remove,
  .image-attachment:focus-within .image-attachment-remove,
  .image-attachment-remove:focus-visible { opacity: 1; }

  .copilot-root.is-file-drag-over { cursor: copy; }

  .queue-attachment-list { display: flex; min-width: 0; align-items: center; gap: 5px; overflow: hidden; }
  .queue-attachment-thumb { width: 24px; height: 24px; flex: 0 0 24px; overflow: hidden; border: 1px solid rgba(128,128,128,0.2); border-radius: 5px; background: rgba(128,128,128,0.12); }
  .queue-attachment-thumb img { width: 100%; height: 100%; object-fit: cover; }
  .queue-attachment-thumb.is-unavailable img { display: none; }
  .queue-attachment-thumb.is-unavailable .image-attachment-unavailable { display: flex; padding: 2px; font-size: 0; }
  .queue-attachment-thumb.is-unavailable .image-attachment-unavailable::before { content: '▧'; font-size: 12px; }
  .queue-attachment-file { display: inline-flex; min-width: 0; max-width: 120px; align-items: center; gap: 4px; color: var(--text-muted); font-size: 10px; }
  .queue-attachment-file span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  .attachment-remove-button {
    appearance: none;
    display: inline-flex;
    width: 26px;
    height: 30px;
    flex: 0 0 26px;
    align-items: center;
    justify-content: center;
    padding: 0;
    border: 0;
    color: var(--text-muted);
    background: transparent;
    font-size: 14px;
    opacity: 0.45;
    cursor: pointer;
  }

  .attachment-chip:hover .attachment-remove-button,
  .attachment-remove-button:focus-visible { opacity: 0.9; }

  .attachment-remove-button:hover {
    color: var(--text-primary);
    background: rgba(128, 128, 128, 0.08);
  }

  .turn-attachment-list { margin-top: 7px; }
  .turn-attachment-list:first-child { margin-top: 0; }

  .tools-row.tools-content-tool { display:flex; align-items:center; gap:7px; padding:4px 7px; min-height:26px; font-size:11px; }
  .tools-content-tool .tools-row-name { text-align:left; }
  .tools-content-tool:disabled { opacity:.45; cursor:default; }
  .tools-content-icon { display:flex; flex:0 0 14px; width:14px; height:14px; }
  .tools-content-icon svg { width:14px; height:14px; fill:none; stroke:currentColor; stroke-width:1.2; stroke-linecap:round; stroke-linejoin:round; }
  .assistant-artifact-list { display: flex; flex-direction: column; gap: 6px; margin-top: 9px; }
  .assistant-artifact-card {
    display: grid;
    grid-template-columns: 18px minmax(0, 1fr) 26px;
    width: min(100%, 310px);
    min-height: 42px;
    align-items: center;
    gap: 8px;
    padding: 5px 7px 5px 9px;
    border: 1px solid rgba(128, 128, 128, 0.18);
    border-radius: 9px;
    background: rgba(128, 128, 128, 0.09);
  }
  .assistant-artifact-card.is-image { position:relative; grid-template-columns:minmax(0,1fr); box-sizing:border-box; padding:7px; border-radius:5px; }
  .assistant-artifact-card.is-audio { display:block;box-sizing:border-box;width:min(100%,310px);padding:8px 9px;border-radius:7px;background:rgba(255,255,255,.035);border-color:rgba(255,255,255,.09);transition:background .14s ease,border-color .14s ease,box-shadow .14s ease; }
  .assistant-artifact-card.is-audio:hover,.assistant-artifact-card.is-audio:focus-within { background:rgba(255,255,255,.055);border-color:rgba(255,255,255,.16);box-shadow:0 1px 7px rgba(0,0,0,.14); }
  .artifact-audio-head { display:flex;align-items:center;gap:7px;min-width:0; }
  .artifact-audio-head .assistant-artifact-name { flex:1; }
  .artifact-audio-meta { margin:3px 0 5px 24px; color:var(--text-muted); font-size:10px; line-height:14px; white-space:normal; overflow-wrap:anywhere; }
  .assistant-audio-group { min-width:0; }
  .assistant-audio-group .assistant-artifact-list { margin:0; }
  .artifact-audio-versions { margin-top:4px; width:100%; max-width:100%; color:var(--text-secondary); background:var(--surface-input,#282828); border:1px solid var(--border-color,#454545); border-radius:4px; padding:5px; font:inherit; }
  .artifact-audio-controls { display:grid;grid-template-columns:25px 25px minmax(0,1fr) auto;align-items:center;gap:6px; }
  .artifact-audio-controls button { width:25px;height:25px;padding:0;border:0;border-radius:4px;background:transparent;color:var(--text-secondary);cursor:pointer;transition:color .12s ease,background .12s ease,transform .12s ease; }
  .artifact-audio-controls button svg { display:block;width:13px;height:13px;margin:auto;fill:currentColor; }
  .artifact-audio-controls button:hover:not(:disabled),.artifact-audio-controls button:focus-visible { color:#fff;background:rgba(255,255,255,.09); }
  .artifact-audio-controls button:active:not(:disabled) { transform:scale(.94); }
  .artifact-audio-controls button:focus-visible,.artifact-audio-actions button:focus-visible { outline:1px solid rgba(255,255,255,.55);outline-offset:1px; }
  .artifact-audio-controls button:disabled { opacity:.38;cursor:default; }
  .artifact-audio-controls button.is-active { color:#fff;background:rgba(255,255,255,.11); }
  .artifact-audio-controls input[type="range"] { --audio-progress:0%;appearance:none;-webkit-appearance:none;width:100%;height:16px;margin:0;background:transparent;cursor:pointer; }
  .artifact-audio-controls input[type="range"]::-webkit-slider-runnable-track { height:3px;border-radius:999px;background:linear-gradient(to right,rgba(255,255,255,.82) 0 var(--audio-progress),rgba(255,255,255,.20) var(--audio-progress) 100%);transition:background .12s ease; }
  .artifact-audio-controls input[type="range"]::-webkit-slider-thumb { appearance:none;-webkit-appearance:none;width:11px;height:11px;margin-top:-4px;border:1px solid rgba(0,0,0,.34);border-radius:50%;background:#f5f5f5;box-shadow:0 1px 3px rgba(0,0,0,.38);transition:transform .12s ease,background .12s ease,box-shadow .12s ease; }
  .artifact-audio-controls input[type="range"]:hover::-webkit-slider-runnable-track,.artifact-audio-controls input[type="range"]:focus-visible::-webkit-slider-runnable-track { background:linear-gradient(to right,#fff 0 var(--audio-progress),rgba(255,255,255,.30) var(--audio-progress) 100%); }
  .artifact-audio-controls input[type="range"]:hover::-webkit-slider-thumb,.artifact-audio-controls input[type="range"]:focus-visible::-webkit-slider-thumb { transform:scale(1.18);background:#fff;box-shadow:0 1px 5px rgba(0,0,0,.48); }
  .artifact-audio-controls input[type="range"]:focus-visible { outline:none; }
  .artifact-audio-controls input[type="range"]:disabled { opacity:.38;cursor:default; }
  .artifact-audio-time { color:var(--text-muted);font-size:10px;font-variant-numeric:tabular-nums;white-space:nowrap; }
  .artifact-audio-actions { display:flex;gap:5px;margin-top:5px; }
  .artifact-audio-actions button { flex:1;height:25px;padding:0 5px;border:1px solid rgba(255,255,255,.09);border-radius:4px;background:rgba(255,255,255,.018);color:var(--text-secondary);font-size:10px;cursor:pointer;transition:background .12s ease,border-color .12s ease,color .12s ease; }
  .artifact-audio-actions button:hover:not(:disabled),.artifact-audio-actions button:focus-visible { background:rgba(255,255,255,.075);border-color:rgba(255,255,255,.17);color:#fff; }
  .artifact-audio-actions button:disabled { opacity:.4;cursor:default; }
  .is-image .assistant-artifact-icon, .is-image .assistant-artifact-copy { display:none; }
  .is-image .artifact-thumbnail { width:100%; height:108px; object-fit:contain; cursor:pointer; background:#222; }
  .artifact-image-actions { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); display:flex; align-items:center; justify-content:center; gap:8px; max-width:calc(100% - 16px); padding:5px 8px; border-radius:5px; background:rgba(22,24,28,.18); backdrop-filter:blur(2px); opacity:0; pointer-events:none; transition:opacity .12s ease; }
  .is-image:hover .artifact-image-actions,.is-image:focus-within .artifact-image-actions { opacity:1; pointer-events:auto; }
  .artifact-image-actions .assistant-artifact-save { color:#eee; }
  .artifact-image-actions .assistant-artifact-save:hover { color:#fff; background:rgba(255,255,255,.14); }
  .artifact-image-actions .assistant-artifact-save { width:auto; min-width:26px; padding:0 3px; white-space:nowrap; font-size:11px; }
  .assistant-artifact-card.is-unavailable { opacity: 0.58; }
  .assistant-artifact-icon { width: 17px; height: 17px; fill: none; stroke: var(--text-secondary); stroke-width: 1.2; stroke-linecap: round; stroke-linejoin: round; }
  .assistant-artifact-copy { min-width: 0; }
  .assistant-artifact-name { overflow: hidden; color: var(--text-primary); font-size: var(--font-secondary); line-height: 16px; text-overflow: ellipsis; white-space: nowrap; }
  .assistant-artifact-meta { overflow: hidden; color: var(--text-muted); font-size: 10px; line-height: 14px; text-overflow: ellipsis; white-space: nowrap; }
  .assistant-artifact-save { display: inline-flex; width: 26px; height: 26px; align-items: center; justify-content: center; padding: 0; border: 0; border-radius: 6px; background: transparent; color: var(--text-secondary); cursor: pointer; }
  .assistant-artifact-save:hover { color: var(--text-primary); background: rgba(128, 128, 128, 0.12); }
  .assistant-artifact-save:disabled { color: var(--text-muted); cursor: default; opacity: 0.6; }
  .assistant-artifact-save svg { width: 15px; height: 15px; fill: none; stroke: currentColor; stroke-width: 1.35; stroke-linecap: round; stroke-linejoin: round; }

  .user-message-surface.is-attachment-only {
    padding: 0;
    overflow: visible;
    border: 0;
    background: transparent;
  }

  .user-message-surface.is-pin-only {
    padding: 5px 8px;
  }

  .user-message-surface.has-pins { overflow: visible; }

  .user-message-surface.has-text-pins {
    position: relative;
    padding-right: 25px;
  }

  .pin-indicator-wrap {
    position: relative;
    width: fit-content;
    max-width: 100%;
  }

  .turn-pin-indicator {
    margin-top: 4px;
    margin-left: auto;
  }
  .turn-pin-indicator:first-child { margin-top: 0; }

  .has-text-pins .turn-pin-indicator {
    position: absolute;
    right: 7px;
    bottom: 6px;
    margin: 0;
  }

  .turn-pin-indicator .pin-indicator-button {
    position: relative;
    min-width: 0;
    height: 11px;
    gap: 1px;
    padding: 0;
    border-color: transparent;
    border-radius: 2px;
    color: var(--text-muted);
    background: transparent;
    font-size: 8px;
    line-height: 10px;
    opacity: 0.55;
    transition: opacity 120ms ease;
  }

  .turn-pin-indicator .pin-indicator-button::before {
    position: absolute;
    inset: -6px;
    content: '';
  }

  .turn-pin-indicator .pin-indicator-button:hover,
  .turn-pin-indicator .pin-indicator-button:focus-visible {
    border-color: transparent;
    color: var(--text-secondary);
    background: rgba(128, 128, 128, 0.08);
    opacity: 0.9;
  }

  .turn-pin-indicator .pin-indicator-button svg {
    width: 8px;
    height: 8px;
  }

  .turn-pin-indicator .pin-count {
    font-size: 8px;
    line-height: 10px;
  }

  .pin-indicator-button,
  .pin-entry-button,
  .pin-count-button {
    appearance: none;
    display: inline-flex;
    min-width: 22px;
    height: 22px;
    align-items: center;
    justify-content: center;
    gap: 4px;
    padding: 0 5px;
    border: 1px solid rgba(128, 128, 128, 0.2);
    border-radius: 6px;
    color: var(--text-muted);
    background: rgba(128, 128, 128, 0.06);
    cursor: pointer;
  }

  .pin-indicator-button:hover,
  .pin-indicator-button:focus-visible,
  .pin-entry-button:hover,
  .pin-entry-button:focus-visible,
  .pin-count-button:hover,
  .pin-count-button:focus-visible {
    color: var(--text-secondary);
    outline: 0;
    border-color: rgba(128, 128, 128, 0.34);
    background: rgba(128, 128, 128, 0.12);
  }

  .pin-indicator-button svg,
  .pin-entry-button svg {
    width: 15px;
    height: 15px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.3;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .pin-count,
  .pin-count-button {
    font-size: var(--font-caption);
    line-height: 16px;
  }

  .pin-count-button {
    min-width: 20px;
    padding: 0 5px 0 2px;
    border-color: transparent;
    border-radius: 0 6px 6px 0;
    background: transparent;
  }
  .pin-count-button[hidden] { display: none; }

  .pin-popover {
    position: absolute;
    z-index: 30;
    display: flex;
    flex-direction: column;
    min-width: 0;
    overflow: hidden;
    border: 1px solid rgba(128, 128, 128, 0.32);
    border-radius: 10px;
    color: var(--text-secondary);
    background: var(--surface-raised);
    box-shadow: 0 5px 18px rgba(0, 0, 0, 0.26);
  }

  .pin-popover[hidden] { display: none; }

  .pin-popover-header {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    justify-content: space-between;
    min-height: 30px;
    padding: 5px 10px 4px;
    border-bottom: 1px solid rgba(128, 128, 128, 0.16);
    font-size: var(--font-secondary);
    line-height: 18px;
  }
  .pin-popover-title { color: var(--text-primary); }
  .pin-popover-total { color: var(--text-muted); font-size: var(--font-caption); }
  .pin-popover-list {
    min-height: 0;
    overflow-x: hidden;
    overflow-y: auto;
    scrollbar-gutter: stable;
  }
  .pin-popover-list::-webkit-scrollbar { width: 5px; }
  .pin-popover-list::-webkit-scrollbar-thumb {
    border-radius: 5px;
    background: rgba(128, 128, 128, 0.3);
  }

  .pin-popover-item {
    position: relative;
    min-width: 0;
    min-height: 46px;
    padding: 5px 9px 6px;
  }

  .pin-popover-item + .pin-popover-item { border-top: 1px solid rgba(128, 128, 128, 0.12); }
  .pin-item-main {
    display: flex;
    min-width: 0;
    align-items: center;
    gap: 6px;
    height: 18px;
  }
  .pin-kind {
    flex: 0 0 auto;
    color: var(--text-muted);
    font-size: 11px;
    line-height: 18px;
    white-space: nowrap;
  }
  .pin-label {
    min-width: 0;
    flex: 1 1 auto;
    overflow: hidden;
    color: var(--text-primary);
    font-size: var(--font-secondary);
    line-height: 18px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .pin-path {
    display: block;
    width: 100%;
    min-width: 0;
    margin-top: 1px;
    overflow: hidden;
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: 16px;
    white-space: nowrap;
  }
  .pin-remove-button {
    appearance: none;
    width: 18px;
    height: 18px;
    flex: 0 0 18px;
    padding: 0;
    border: 0;
    border-radius: 4px;
    color: var(--text-muted);
    background: transparent;
    cursor: pointer;
    opacity: 0.45;
  }
  .pin-popover-item:hover .pin-remove-button,
  .pin-remove-button:focus-visible { opacity: 0.85; }
  .pin-remove-button:hover { color: var(--text-primary); background: rgba(128, 128, 128, 0.12); }

  .prompt-toggle,
  .inline-toggle,
  .activity-header,
  .duration-disclosure {
    appearance: none;
    border: 0;
    background: transparent;
    cursor: pointer;
  }

  .prompt-toggle {
    display: inline-flex;
    width: max-content;
    max-width: 100%;
    align-items: center;
    justify-content: flex-end;
    gap: 3px;
    margin: 5px 0 0 auto;
    padding: 1px 0 0;
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: 14px;
    opacity: 0.62;
  }

  .prompt-toggle-label { display: block; line-height: 14px; }
  .prompt-toggle-icon { display: inline-flex; width: 12px; height: 12px; align-items: center; justify-content: center; flex: 0 0 12px; }
  .prompt-toggle-icon svg { display: block; width: 12px; height: 12px; fill: none; stroke: currentColor; stroke-width: 1.35; stroke-linecap: round; stroke-linejoin: round; }
  .prompt-toggle-icon.is-expanded { transform: rotate(180deg); }
  .prompt-toggle:hover,
  .prompt-toggle:focus-visible { color: var(--text-secondary); opacity: 0.82; }
  .prompt-toggle[hidden] { display: none !important; }

  .turn-assistant {
    min-width: 0;
    margin-top: var(--space-3);
  }

  .assistant-block:empty,
  .turn-error:empty { display: none; }

  .assistant-block {
    min-width: 0;
    color: var(--text-primary);
    font-size: var(--font-body);
    line-height: var(--line-body);
    overflow-wrap: anywhere;
  }

  .assistant-message { min-width: 0; }
  .assistant-message.is-progress { color: var(--text-secondary); }
  .assistant-message + .assistant-message,
  .activity-group + .assistant-message,
  .approval-card + .assistant-message { margin-top: var(--space-3); }
  .turn-final-answer:not(:empty) { margin-top: 0; }
  .turn-activity-history:not([hidden]) ~ .turn-final-answer:not(:empty) { margin-top: var(--space-3); }
  .turn-activity-history[hidden] { display: none; }
  .steer-progress-entry[hidden],
  .steer-progress-entry:empty { display: none; }
  .assistant-message-content { min-width: 0; }

  .assistant-message-actions {
    display: flex;
    min-height: 20px;
    margin-top: var(--space-2);
    align-items: center;
    justify-content: flex-start;
    gap: 8px;
    opacity: 0;
    pointer-events: none;
    transition: opacity 140ms ease;
  }

  .assistant-message.is-final:hover > .assistant-message-actions,
  .assistant-message.is-final:focus-within > .assistant-message-actions {
    opacity: 1;
    pointer-events: auto;
  }

  .assistant-message-time {
    color: var(--text-muted);
    font-size: var(--font-caption);
    font-weight: normal;
    line-height: 20px;
    -webkit-user-select: text;
    user-select: text;
  }

  .assistant-copy-button {
    appearance: none;
    display: inline-flex;
    width: 22px;
    height: 20px;
    padding: 0;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: 4px;
    color: var(--text-muted);
    background: transparent;
    cursor: pointer;
  }

  .assistant-copy-button:hover {
    color: var(--text-primary);
    background: rgba(128, 128, 128, 0.1);
  }

  .assistant-copy-button:focus-visible {
    outline: 1px solid rgba(120, 164, 202, 0.62);
    outline-offset: 1px;
  }

  .assistant-copy-button svg {
    width: 14px;
    height: 14px;
    fill: none;
    stroke: currentColor;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-width: 1.35;
  }

  .assistant-copy-feedback {
    display: none;
    font-size: var(--font-secondary);
    font-weight: 600;
    line-height: 1;
  }

  .assistant-copy-button.is-copied { color: var(--text-muted); }
  .assistant-copy-button.is-failed { color: var(--danger); }
  .assistant-copy-button.is-copied svg,
  .assistant-copy-button.is-failed svg { display: none; }
  .assistant-copy-button.is-copied .assistant-copy-feedback,
  .assistant-copy-button.is-failed .assistant-copy-feedback { display: inline; }

  .markdown-paragraph { margin: 0; }
  .markdown-paragraph + .markdown-paragraph,
  .markdown-list + .markdown-paragraph,
  .markdown-paragraph + .markdown-list,
  .code-block + .markdown-paragraph { margin-top: var(--space-2); }

  .markdown-list {
    margin: 0;
    padding-left: 22px;
  }

  .markdown-list li { padding-left: 1px; }

  .inline-code {
    padding: 1px 3px;
    border-radius: 3px;
    background: rgba(128, 128, 128, 0.14);
    font-family: Consolas, "SFMono-Regular", "Courier New", monospace;
    font-size: var(--font-code);
  }

  .inline-strong {
    color: var(--text-primary);
    font-weight: 650;
  }

  .inline-reference {
    color: var(--text-secondary);
    font-weight: 500;
  }

  .code-block,
  .detail-output {
    max-width: 100%;
    margin: var(--space-2) 0 0;
    padding: var(--space-2);
    overflow: auto;
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-detail);
    background: rgba(0, 0, 0, 0.14);
    color: var(--text-secondary);
    font-family: Consolas, "SFMono-Regular", "Courier New", monospace;
    font-size: var(--font-code);
    line-height: 18px;
    white-space: pre;
  }

  .live-state {
    display: flex;
    align-items: center;
    min-width: 0;
    margin-top: var(--space-2);
    color: var(--text-muted);
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
  }

  .live-state[hidden] { display: none; }

  .runtime-status {
    display: grid;
    grid-template-columns: 16px minmax(0, 1fr);
    align-items: center;
    gap: 4px;
    margin: 6px 0;
    color: var(--text-muted);
    font-size: 12px;
    line-height: 18px;
    opacity: 0.58;
  }

  .runtime-status.is-running { opacity: 0.82; }
  .runtime-status-label { overflow: visible; overflow-wrap: anywhere; text-overflow: clip; white-space: normal; }
  .runtime-status svg {
    display: block;
    width: 16px;
    height: 16px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.3;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .live-state-label {
    background: linear-gradient(90deg, var(--text-muted) 20%, var(--text-secondary) 50%, var(--text-muted) 80%);
    background-size: 200% 100%;
    color: transparent;
    background-clip: text;
    -webkit-background-clip: text;
    animation: live-shimmer 1.8s linear infinite;
  }

  .live-dots { margin-left: 2px; letter-spacing: 1px; }

  @keyframes live-shimmer {
    from { background-position: 200% 0; }
    to { background-position: -200% 0; }
  }

  @media (prefers-reduced-motion: reduce) {
    .live-state-label { animation: none; color: var(--text-muted); background: none; }
  }

  .activity-disclosure {
    min-width: 0;
  }

  .activity-group {
    margin-top: var(--space-1);
    color: var(--text-muted);
  }

  .activity-group > .activity-header-row .activity-header {
    grid-template-columns: var(--icon-column) minmax(0, 1fr) auto 12px;
    padding: 1px 0;
    color: var(--text-muted);
    font-size: var(--font-secondary);
    opacity: 0.58;
    transition: color 120ms ease, opacity 120ms ease;
  }

  .activity-group > .activity-header-row .activity-header:hover,
  .activity-group > .activity-header-row .activity-header:focus-visible {
    color: var(--text-secondary);
    opacity: 1;
  }

  .activity-group > .activity-header-row .activity-icon,
  .activity-group > .activity-header-row .activity-chevron {
    color: var(--text-muted);
    transition: color 120ms ease, opacity 120ms ease;
  }

  .activity-group > .activity-header-row .activity-icon { opacity: 0.72; }
  .activity-group > .activity-header-row .activity-chevron { opacity: 0; }

  .activity-group > .activity-header-row .activity-header:hover .activity-icon,
  .activity-group > .activity-header-row .activity-header:hover .activity-chevron {
    color: var(--text-secondary);
    opacity: 1;
  }

  .activity-group > .activity-header-row .activity-summary {
    overflow: visible;
    overflow-wrap: anywhere;
    text-overflow: clip;
    white-space: normal;
  }

  .activity-group > .activity-header-row .activity-status {
    overflow: hidden;
    max-width: 54px;
    text-overflow: ellipsis;
  }

  .activity-group.is-running > .activity-header-row .activity-status::before {
    display: inline-block;
    width: 5px;
    height: 5px;
    margin-right: var(--space-1);
    border-radius: 50%;
    background: currentColor;
    content: "";
    animation: activity-pulse 1.2s ease-in-out infinite;
  }

  .activity-group > .activity-detail {
    max-width: 100%;
    margin: var(--space-1) 0 var(--space-2);
    padding: 0;
    overflow: hidden;
    border: 0;
    border-radius: 0;
    background: transparent;
  }

  .activity-group > .activity-detail > .activity-disclosure + .activity-disclosure {
    margin-top: 2px;
  }

  .activity-group > .activity-detail > .activity-disclosure > .activity-header-row .activity-header {
    grid-template-columns: 14px minmax(0, 1fr) auto 12px;
    gap: var(--space-1);
    min-height: 16px;
    padding: 0;
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: 16px;
    opacity: 0.56;
    transition: color 120ms ease, opacity 120ms ease;
  }

  .activity-group > .activity-detail > .activity-disclosure > .activity-header-row .activity-header:hover,
  .activity-group > .activity-detail > .activity-disclosure > .activity-header-row .activity-header:focus-visible {
    color: var(--text-secondary);
    opacity: 1;
  }

  .activity-group > .activity-detail > .activity-disclosure > .activity-header-row .activity-summary {
    overflow: visible;
    overflow-wrap: anywhere;
    text-overflow: clip;
    white-space: normal;
  }

  .activity-group > .activity-detail > .activity-disclosure > .activity-header-row .activity-icon {
    width: 14px;
    height: 16px;
    color: var(--text-muted);
    opacity: 0.78;
  }

  .activity-group > .activity-detail > .activity-disclosure > .activity-header-row .activity-icon svg {
    width: 12px;
    height: 12px;
  }

  .activity-group > .activity-detail > .activity-disclosure > .activity-header-row .activity-header:hover .activity-icon {
    color: var(--text-secondary);
    opacity: 1;
  }

  @keyframes activity-pulse {
    0%, 100% { opacity: 0.35; transform: scale(0.8); }
    50% { opacity: 0.9; transform: scale(1); }
  }

  @media (prefers-reduced-motion: reduce) {
    .activity-group.is-running > .activity-header-row .activity-status::before { animation: none; }
  }

  .activity-disclosure + .activity-disclosure { margin-top: var(--space-1); }

  .activity-header-row {
    display: flex;
    align-items: flex-start;
    min-width: 0;
  }

  .activity-header {
    appearance: none;
    display: grid;
    flex: 1 1 auto;
    width: 100%;
    grid-template-columns: var(--icon-column) minmax(0, 1fr) auto 12px;
    gap: var(--space-1);
    min-width: 0;
    padding: 1px 0;
    border: 0;
    color: var(--text-secondary);
    background: transparent;
    cursor: pointer;
    font-family: inherit;
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
    text-align: left;
  }

  .activity-header.no-icon {
    grid-template-columns: minmax(0, 1fr) auto 12px;
  }

  .activity-header:hover { color: var(--text-primary); }
  .activity-header.no-detail { cursor: default; }
  .activity-header.no-detail:hover { color: var(--text-secondary); }

  .activity-icon {
    display: inline-flex;
    width: var(--icon-column);
    height: var(--line-secondary);
    align-items: center;
    justify-content: center;
    text-align: center;
    font-weight: 600;
  }

  .activity-icon svg {
    width: 14px;
    height: 14px;
    fill: none;
    stroke: currentColor;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-width: 1.25;
  }

  .activity-summary {
    min-width: 0;
    overflow-wrap: anywhere;
  }

  .activity-status {
    color: var(--text-muted);
    font-size: var(--font-caption);
    white-space: nowrap;
    transition: color 120ms ease;
  }

  .activity-group > .activity-header-row .activity-header:hover .activity-status {
    color: var(--text-secondary);
  }

  .activity-chevron {
    display: inline-flex;
    width: 12px;
    height: var(--line-secondary);
    align-items: center;
    justify-content: center;
    color: var(--text-muted);
    text-align: center;
    opacity: 0;
    transition: color 120ms ease, opacity 120ms ease;
  }

  .activity-header:hover .activity-chevron,
  .activity-header:focus-visible .activity-chevron {
    color: var(--text-secondary);
    opacity: 1;
  }

  .activity-header.no-detail .activity-chevron { display: none; }

  .activity-chevron svg,
  .turn-meta-chevron svg {
    width: 12px;
    height: 12px;
    fill: none;
    stroke: currentColor;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-width: 1.25;
  }

  .activity-detail {
    min-width: 0;
    margin: var(--space-1) 0 var(--space-2) calc(var(--icon-column) + var(--space-1));
    padding: var(--space-2);
    border: 1px solid var(--border-subtle);
    border-radius: var(--radius-detail);
    background: rgba(0, 0, 0, 0.06);
  }

  .activity-detail[hidden] { display: none; }

  .activity-disclosure.is-running > .activity-header-row .activity-summary { color: var(--text-primary); }
  .activity-disclosure.is-failed > .activity-header-row .activity-summary { color: var(--danger); }
  .activity-disclosure.is-warning > .activity-header-row .activity-summary { color: var(--warning); }

  .status-success { color: var(--success); }
  .status-running { color: var(--running); }
  .status-failed { color: var(--danger); }
  .status-warning, .status-manual { color: var(--warning); }
  .status-pending { color: var(--text-muted); }

  .status-waiting { color: var(--warning); }
  .status-approved { color: var(--success); }
  .status-denied, .status-cancelled { color: var(--text-muted); }

  .approval-activity { margin: 3px 0 5px calc(var(--icon-column) + var(--space-1)); color: var(--text-secondary); font-size: var(--font-secondary); line-height: 18px; }
  .approval-activity-note { display: block; margin-left: 14px; color: var(--text-muted); }

  .plan-list,
  .activity-list {
    margin: 0;
    padding-left: 20px;
    color: var(--text-secondary);
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
  }

  .activity-list { padding-left: 0; list-style: none; }

  .inline-toggle {
    margin-top: var(--space-1);
    padding: 0;
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: var(--line-secondary);
  }

  .inline-toggle:hover { color: var(--text-secondary); }

  .detail-heading {
    margin-bottom: var(--space-2);
    color: var(--text-secondary);
    font-size: var(--font-secondary);
    font-weight: 600;
  }

  .detail-grid {
    display: grid;
    grid-template-columns: 54px minmax(0, 1fr);
    gap: var(--space-1) var(--space-2);
    margin: 0;
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
  }

  .detail-grid dt { color: var(--text-muted); }
  .detail-grid dd { min-width: 0; margin: 0; overflow-wrap: anywhere; }

  .detail-grid code,
  .command-line,
  .file-diff {
    font-family: Consolas, "SFMono-Regular", "Courier New", monospace;
    font-size: var(--font-code);
  }

  .detail-section { margin-top: var(--space-2); }
  .detail-section-label {
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: var(--line-secondary);
  }

  .detail-output { max-height: 180px; white-space: pre-wrap; overflow-wrap: anywhere; }

  .command-line {
    display: -webkit-box;
    margin-top: var(--space-1);
    overflow: hidden;
    color: var(--text-primary);
    line-height: 18px;
    overflow-wrap: anywhere;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .command-line.is-expanded { display: block; }

  .file-list { min-width: 0; }
  .file-row-main {
    display: flex;
    min-width: 0;
    align-items: baseline;
    gap: var(--space-1);
  }
  .file-name { color: var(--text-primary); overflow-wrap: anywhere; }
  .file-path { color: var(--text-muted); font-size: var(--font-caption); overflow-wrap: anywhere; }
  .diff-add { color: var(--success); }
  .diff-remove { color: var(--danger); }
  .file-diff { max-height: 220px; }

  .state-guard-reason,
  .error-detail {
    color: var(--text-secondary);
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }

  .turn-error {
    margin-top: var(--space-2);
    color: var(--danger);
    font-size: var(--font-secondary);
    line-height: var(--line-secondary);
    white-space: pre-wrap;
  }
  .turn-error details { margin-top:4px; color:var(--text-muted); font-size:var(--font-caption); }
  .turn-error summary { width:fit-content; cursor:pointer; list-style:none; }
  .turn-error summary::-webkit-details-marker { display:none; }
  .turn-error summary:hover { color:var(--text-secondary); }
  .turn-error pre { max-height:150px; margin:6px 0 0; padding:8px; overflow:auto; border-radius:6px; color:var(--text-secondary); background:rgba(0,0,0,.14); font:inherit; white-space:pre-wrap; overflow-wrap:anywhere; }

  .turn-change-card {
    --change-details-bg: rgba(255,255,255,0.025);
    --change-shell-bg: rgba(0,0,0,0.18);
    --change-row-hover-bg: rgba(0,0,0,0.14);
    margin-top: 12px;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 11px;
    background: rgba(255,255,255,0.045);
    color: var(--text-secondary);
  }
  .turn-change-card[hidden] { display: none; }
  .change-card-head { display: flex; align-items: center; min-width: 0; min-height: 46px; padding: 7px 9px; gap: 7px; background: var(--change-shell-bg); }
  .change-card-toggle { display: flex; flex: 1 1 auto; min-width: 0; align-items: center; gap: 8px; padding: 0; border: 0; background: transparent; color: inherit; text-align: left; font: inherit; cursor: pointer; }
  .change-card-icon { display: inline-flex; flex: 0 0 40px; width: 40px; height: 40px; align-items: center; justify-content: center; border-radius: 9px; background: rgba(0,0,0,0.24); color: var(--text-secondary); }
  .change-card-icon svg { width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 1.7; stroke-linecap: round; stroke-linejoin: round; }
  .change-card-copy { min-width: 0; flex: 1 1 auto; }
  .change-card-title { display: block; overflow: hidden; color: var(--text-primary); text-overflow: ellipsis; white-space: nowrap; }
  .change-card-stats { display: block; margin-top: 1px; font-size: var(--font-caption); line-height: 15px; }
  .change-card-stats .diff-add { margin-right: 4px; }
  .change-card-chevron { display: inline-flex; flex: 0 0 12px; width: 12px; color: var(--text-muted); }
  .change-card-chevron svg { width: 12px; height: 12px; fill: none; stroke: currentColor; stroke-width: 1.4; }
  .change-card-undo { flex: 0 0 auto; min-height: 29px; padding: 4px 10px; border: 1px solid rgba(255,255,255,0.07); border-radius: 15px; background: rgba(255,255,255,0.025); color: var(--text-secondary); font: inherit; cursor: pointer; }
  .change-card-undo:hover:not(:disabled) { background: rgba(255,255,255,0.07); color: var(--text-primary); }
  .change-card-undo:disabled { opacity: .45; cursor: default; }
  .change-card-body { padding: 0; border-top: 1px solid rgba(255,255,255,0.055); }
  .change-details-surface { background: var(--change-details-bg); }
  .change-card-details { padding: 0 10px 9px; }
  .change-card-body[hidden] { display: none; }
  .change-card-group { margin-top: 8px; }
  .change-card-group-title { color: var(--text-muted); font-size: var(--font-caption); }
  .change-card-row { display: flex; min-width: 0; align-items: baseline; gap: 6px; padding: 3px 0; color: var(--text-secondary); font-size: var(--font-secondary); }
  .change-card-row.has-status { display: grid; grid-template-columns: minmax(0, 1fr) 72px; align-items: start; column-gap: 0; }
  button.change-card-row.is-clickable { width: 100%; border: 0; border-radius: 5px; background: transparent; text-align: left; font-family: inherit; cursor: pointer; }
  button.change-card-row.is-clickable:hover { color: var(--text-primary); background: var(--change-row-hover-bg); }
  button.change-card-row.is-clickable.has-status:hover { background: linear-gradient(to right, var(--change-row-hover-bg) 0 calc(100% - 72px), transparent calc(100% - 72px)); }
  button.change-card-row.is-clickable:focus-visible { outline: 1px solid rgba(255,255,255,0.16); outline-offset: -1px; }
  .change-card-row-copy { min-width: 0; max-width: 100%; overflow: hidden; flex: 1 1 auto; }
  .change-card-row-label { min-width: 0; flex: 1 1 auto; overflow: hidden; line-height: 18px; text-overflow: ellipsis; white-space: nowrap; }
  .change-card-row-copy .change-card-row-label { display: block; }
  .change-card-row-detail { display: block; min-width: 0; max-width: 100%; margin-top: 1px; overflow: hidden; color: var(--text-muted); font-size: var(--font-caption); text-overflow: ellipsis; white-space: nowrap; }
  .change-card-row-detail .diff-add,.change-card-row-state .diff-add { margin-right: 4px; }
  .change-card-row-state { flex: 0 0 auto; color: var(--text-muted); font-size: var(--font-caption); line-height: 18px; }
  .change-card-row.has-status > .change-card-row-state { align-self: stretch; min-width: 0; padding: 0 0 0 10px; border-left: 1px solid rgba(255,255,255,0.07); white-space: nowrap; }
  .change-card-more { padding: 3px 0; color: var(--text-muted); font-size: var(--font-caption); }
  .change-card-footer { display: flex; justify-content: flex-end; min-height: 32px; align-items: center; padding: 4px 10px; border-top: 1px solid rgba(255,255,255,0.045); background: var(--change-shell-bg); }
  .change-card-view { padding: 2px 0; border: 0; background: transparent; color: var(--text-secondary); font: inherit; font-size: var(--font-secondary); cursor: pointer; }
  .change-card-view:hover { color: var(--text-primary); }

  .duration-disclosure {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    min-height: 24px;
    margin: 0 0 10px;
    padding: 0 1px 6px;
    border-bottom: 1px solid rgba(128, 128, 128, 0.14);
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: var(--line-secondary);
    font-weight: 400;
    text-align: left;
    border-radius: 0;
    opacity: 0.58;
    transition: color 120ms ease, opacity 120ms ease;
  }

  .duration-disclosure:not(.is-static):hover,
  .duration-disclosure:not(.is-static):focus-visible {
    color: var(--text-secondary);
    background: transparent;
    opacity: 1;
  }
  .turn-meta-chevron {
    display: inline-flex;
    flex: 0 0 12px;
    width: 12px;
    height: var(--line-secondary);
    align-items: center;
    justify-content: center;
    color: var(--text-muted);
    text-align: center;
    opacity: 0;
    transition: color 120ms ease, opacity 120ms ease;
  }
  .duration-disclosure:not(.is-static):hover .turn-meta-chevron,
  .duration-disclosure:not(.is-static):focus-visible .turn-meta-chevron {
    color: var(--text-secondary);
    opacity: 1;
  }
  .duration-disclosure[hidden] { display: none; }
  .duration-disclosure.is-static { cursor: default; }
  .duration-disclosure.is-static:hover { color: var(--text-muted); }
  .duration-disclosure.is-running,
  .duration-disclosure.is-stopping { color: var(--text-secondary); opacity: 0.78; }
  .duration-disclosure.is-failed { color: rgba(215, 121, 121, 0.78); opacity: 0.78; }

  .composer {
    position: relative;
    flex: 0 0 auto;
    min-width: 0;
    padding: var(--space-2) var(--thread-padding) 42px;
    background: var(--surface);
  }

  .approval-tray {
    position: relative;
    z-index: 3;
    container-type: inline-size;
    min-width: 0;
    width: 100%;
    max-height: min(440px, 58vh);
    overflow-y: auto;
    margin: 0 0 8px;
    padding: 16px;
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 16px;
    background: var(--surface-approval);
    color: var(--text-secondary);
    font-size: var(--font-body);
    line-height: var(--line-body);
  }
  .approval-tray[hidden] { display: none; }
  .approval-tray-heading { display: flex; align-items: center; gap: 8px; min-width: 0; }
  .approval-tray-source-icon { display: inline-flex; flex: 0 0 16px; width: 16px; height: 16px; align-items: center; justify-content: center; }
  .approval-tray-source-icon svg { width: 16px; height: 16px; fill: none; stroke: currentColor; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; }
  .approval-tray-title { flex: 1 1 auto; min-width: 0; color: var(--text-secondary); font-size: var(--font-body); font-weight: 400; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .approval-tray-count { flex: 0 0 auto; color: var(--text-muted); font-size: var(--font-caption); }
  .approval-tray-question { margin-top: 16px; color: var(--text-primary); overflow-wrap: anywhere; white-space: pre-wrap; }
  .approval-tray-question strong { color: var(--text-primary); font-weight: 600; }
  .approval-tray-code { max-height: 92px; overflow: auto; margin: 14px 0 0; padding: 10px 12px; border-radius: 9px; background: var(--surface); color: var(--text-secondary); font-family: Consolas, monospace; font-size: var(--font-secondary); white-space: pre-wrap; overflow-wrap: anywhere; }
  .approval-tray-file { display: flex; align-items: center; gap: 9px; min-width: 0; margin-top: 14px; padding: 8px 10px; border-radius: 8px; background: var(--surface); }
  .approval-tray-file-name { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .approval-tray-file-stats { flex: 0 0 auto; margin-left: auto; font-size: var(--font-secondary); color: var(--text-muted); }
  .approval-tray-details { margin-top: 12px; font-size: var(--font-secondary); }
  .approval-tray-details summary { width: fit-content; color: var(--text-muted); cursor: pointer; list-style: none; }
  .approval-tray-details summary::-webkit-details-marker { display: none; }
  .approval-tray-details summary::after { content: ' ›'; }
  .approval-tray-details[open] summary::after { content: ' ⌄'; }
  .approval-tray-details summary:hover { color: var(--text-secondary); }
  .approval-tray-details pre { max-height: 125px; overflow: auto; margin: 6px 0 0; padding: 8px; border-radius: 6px; background: var(--surface); white-space: pre-wrap; overflow-wrap: anywhere; font-size: var(--font-caption); }
  .approval-tray-actions { position: relative; display: flex; flex-direction: column; gap: 10px; margin-top: 16px; min-width: 0; }
  .approval-tray-actions button { min-height: 34px; min-width: 0; width: 100%; padding: 5px 10px; border: 1px solid rgba(255,255,255,0.07); border-radius: 20px; background: transparent; color: var(--text-primary); font: inherit; cursor: pointer; }
  .approval-tray-actions button:hover:not(:disabled) { background: rgba(255,255,255,0.06); }
  .approval-tray-actions button:disabled { opacity: 0.5; cursor: default; }
  .approval-tray-allow-row { position: relative; width: 100%; min-width: 0; }
  .approval-tray-actions .approval-tray-allow { background: #d4d4d4; border-color: #d4d4d4; color: #292929; }
  .approval-tray-actions .approval-tray-allow:hover:not(:disabled),
  .approval-tray-actions .approval-tray-more:hover:not(:disabled) { background: #e5e5e5; border-color: #e5e5e5; color: #202020; }
  .approval-tray-allow-row .approval-tray-allow { width: 100%; border-radius: 20px; }
  .approval-tray-actions .approval-tray-more { position: absolute; top: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; min-height: 0; width: 28px; padding: 0; border: 0; border-left: 1px solid #aaa; border-radius: 0 20px 20px 0; background: #d4d4d4; color: #292929; }
  .approval-tray-more svg { display: block; width: 12px; height: 12px; fill: none; stroke: currentColor; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; }
  .approval-tray-menu { position: absolute; z-index: 6; right: 0; bottom: 42px; display: flex; flex-direction: column; gap: 2px; width: min(250px, 100%); padding: 4px; border: 1px solid var(--border-subtle); border-radius: 10px; background: var(--surface-raised); box-shadow: 0 8px 24px rgba(0,0,0,0.34); }
  .approval-tray-menu[hidden] { display: none; }
  .approval-tray-actions .approval-tray-menu button { min-height: 34px; border: 0; border-radius: 6px; text-align: center; color: var(--text-secondary); }
  .approval-tray-actions .approval-tray-menu button:hover:not(:disabled) { color: var(--text-primary); }
  .approval-tray-scope-option { position: relative; display: flex; align-items: center; justify-content: center; gap: 8px; }
  .approval-tray-scope-info { position: absolute; right: 10px; top: 50%; display: inline-flex; width: 16px; height: 16px; align-items: center; justify-content: center; color: var(--text-secondary); transform: translateY(-50%); }
  .approval-tray-scope-info svg { width: 16px; height: 16px; fill: none; stroke: currentColor; stroke-width: 1.35; stroke-linecap: round; stroke-linejoin: round; }
  .approval-tray-scope-tooltip { position: absolute; z-index: 7; right: calc(100% + 8px); top: 50%; display: none; width: 145px; padding: 8px 10px; border: 1px solid var(--border-subtle); border-radius: 9px; background: var(--surface-raised); color: var(--text-secondary); font-size: var(--font-secondary); line-height: 18px; text-align: center; transform: translateY(-50%); box-shadow: 0 8px 24px rgba(0,0,0,0.32); white-space: normal; overflow-wrap: anywhere; pointer-events: none; }
  .approval-tray-scope-info:hover + .approval-tray-scope-tooltip,
  .approval-tray-scope-info:focus + .approval-tray-scope-tooltip { display: block; }
  @container (max-width: 420px) {
    .approval-tray-scope-tooltip { right: 0; top: auto; bottom: calc(100% + 6px); width: min(220px, calc(100% - 8px)); transform: none; }
  }
  .approval-tray-error { margin-top: 6px; color: var(--danger); }
  .approval-tray-warning { margin-top: 6px; color: var(--text-muted); }

  .composer::before {
    position: absolute;
    z-index: 1;
    right: 0;
    bottom: 100%;
    left: 0;
    height: 60px;
    pointer-events: none;
    background: linear-gradient(to bottom, transparent, var(--surface));
    content: '';
  }

  .scroll-to-latest {
    appearance: none;
    display: flex !important;
    position: absolute;
    z-index: 2;
    top: -36px;
    left: 50%;
    width: 34px;
    height: 34px;
    padding: 0;
    align-items: center;
    justify-content: center;
    transform: translateX(-50%) translateY(0);
    border: 1px solid rgba(128, 128, 128, 0.32);
    border-radius: 50%;
    color: var(--text-primary);
    background: var(--surface-raised, rgba(45, 45, 45, 0.96));
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
    cursor: pointer;
    opacity: 0.9;
    transition:
      opacity 140ms ease,
      transform 140ms ease,
      visibility 0s linear 0s,
      background-color 140ms ease,
      border-color 140ms ease;
  }

  .scroll-to-latest:hover {
    color: var(--text-primary);
    border-color: rgba(160, 160, 160, 0.48);
    background: rgba(58, 58, 58, 0.98);
    opacity: 1;
  }

  .scroll-to-latest:focus-visible {
    outline: 1px solid rgba(120, 164, 202, 0.72);
    outline-offset: 2px;
  }

  .scroll-to-latest:active {
    transform: translateX(-50%) scale(0.96);
  }

  .scroll-indicator-arrow {
    width: 18px;
    height: 18px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.9;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .scroll-indicator-dots {
    display: none;
    height: 8px;
    align-items: center;
    justify-content: center;
    gap: 3px;
  }

  .scroll-indicator-dots > span {
    display: block;
    width: 3px;
    height: 3px;
    border-radius: 50%;
    background: currentColor;
    opacity: 0.48;
    animation: scroll-indicator-dot 1.05s ease-in-out infinite;
  }

  .scroll-indicator-dots > span:nth-child(2) { animation-delay: 120ms; }
  .scroll-indicator-dots > span:nth-child(3) { animation-delay: 240ms; }

  .scroll-to-latest.is-running .scroll-indicator-arrow { display: none; }
  .scroll-to-latest.is-running .scroll-indicator-dots { display: flex; }

  @keyframes scroll-indicator-dot {
    0%, 60%, 100% {
      opacity: 0.42;
      transform: translateY(0);
    }
    30% {
      opacity: 0.9;
      transform: translateY(-1.5px);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .scroll-indicator-dots > span {
      animation: none;
      opacity: 0.68;
      transform: none;
    }
  }

  .scroll-to-latest[hidden] {
    visibility: hidden;
    pointer-events: none;
    opacity: 0;
    transform: translateX(-50%) translateY(4px);
    transition-delay: 0s, 0s, 140ms, 0s, 0s;
  }

  .composer-surface {
    position: relative;
    min-width: 0;
    padding: var(--space-1) var(--space-2) var(--space-2);
    border: 1px solid rgba(128, 128, 128, 0.3);
    border-radius: var(--radius-composer);
    background: var(--surface-raised);
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.16);
  }

  .composer-surface::after {
    position: absolute;
    z-index: 3;
    inset: -1px;
    border-radius: inherit;
    box-shadow: 0 0 16px 3px rgba(239, 242, 245, 0.2), 0 0 30px 6px rgba(239, 242, 245, 0.08);
    content: '';
    opacity: 0;
    pointer-events: none;
    transition: opacity 240ms ease-out;
  }

  .composer-surface.is-pin-dragover {
    border-color: transparent;
  }

  .composer-surface.is-pin-dragover::after {
    animation: pin-drop-glow-breathe 1.5s ease-in-out infinite;
  }

  @keyframes pin-drop-glow-breathe {
    0%, 100% { opacity: 0.5; }
    50% { opacity: 0.92; }
  }

  @keyframes pin-drop-text-breathe {
    0%, 100% { opacity: 0.64; }
    50% { opacity: 0.92; }
  }

  @media (prefers-reduced-motion: reduce) {
    .composer-surface.is-pin-dragover::after { animation: none; opacity: 0.76; }
    .pin-drop-hint:not([hidden]) { animation: none; opacity: 0.82; }
  }

  .composer-surface.is-pin-mode textarea { opacity: 0.58; }

  .composer-pin-row {
    position: relative;
    display: flex;
    width: fit-content;
    min-height: 22px;
    margin: 0 0 4px;
    align-items: center;
  }

  .pin-entry-button { padding: 0 4px; border-color: transparent; background: transparent; }
  .pin-entry-button.has-pins { border-radius: 6px 0 0 6px; border-color: rgba(128, 128, 128, 0.2); border-right: 0; background: rgba(128, 128, 128, 0.07); }
  .pin-entry-button.has-pins + .pin-count-button {
    border: 1px solid rgba(128, 128, 128, 0.2);
    border-left: 0;
    background: rgba(128, 128, 128, 0.07);
  }
  .pin-entry-button.is-active { color: var(--running); background: rgba(120, 169, 209, 0.1); }
  .pin-entry-button:disabled { cursor: default; opacity: 0.45; }

  .pin-mode-bar {
    display: flex;
    min-height: 28px;
    margin: 0 0 5px;
    padding: 3px 4px 3px 7px;
    align-items: center;
    justify-content: space-between;
    border: 1px solid rgba(120, 164, 202, 0.26);
    border-radius: 6px;
    color: var(--text-secondary);
    background: rgba(120, 164, 202, 0.08);
    font-size: var(--font-secondary);
  }
  .pin-mode-bar[hidden] { display: none; }
  .pin-mode-actions { display: inline-flex; gap: 3px; }
  .pin-mode-actions button {
    appearance: none;
    width: 22px;
    height: 22px;
    padding: 0;
    border: 0;
    border-radius: 4px;
    color: var(--text-secondary);
    background: transparent;
    cursor: pointer;
  }
  .pin-mode-actions button:hover { color: var(--text-primary); background: rgba(128, 128, 128, 0.13); }

  .pin-drop-hint {
    position: absolute;
    z-index: 4;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(239, 242, 245, 0.82);
    font-size: 12px;
    letter-spacing: 0.04em;
    text-shadow: 0 0 10px rgba(239, 242, 245, 0.32);
    background: transparent;
    pointer-events: none;
    animation: pin-drop-text-breathe 1.5s ease-in-out infinite;
  }
  .pin-drop-hint[hidden] { display: none; }

  .file-drop-hint {
    position: absolute;
    z-index: 70;
    inset: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    color: rgba(255, 255, 255, 0.82);
    background: rgba(255, 255, 255, 0.045);
    box-shadow: inset 0 0 18px rgba(255, 255, 255, 0.025), 0 0 12px rgba(255, 255, 255, 0.045);
    font-size: 12px;
    letter-spacing: 0.04em;
    text-shadow: 0 0 10px rgba(255, 255, 255, 0.18);
    pointer-events: none;
    animation: file-drop-soft-breathe 1.45s ease-in-out infinite;
  }
  .file-drop-hint[hidden] { display: none; }

  @keyframes file-drop-soft-breathe {
    0%, 100% {
      background: rgba(255, 255, 255, 0.035);
      opacity: 0.78;
    }
    50% {
      background: rgba(255, 255, 255, 0.065);
      opacity: 1;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .file-drop-hint:not([hidden]) { animation: none; opacity: 0.9; }
  }

  .queue-pin-indicator .pin-indicator-button { height: 20px; padding: 0 4px; }
  .queue-pin-indicator .pin-indicator-button svg { width: 13px; height: 13px; }

  .composer-attachment-list {
    max-height: 96px;
    margin: 1px 0 6px;
    padding-right: 2px;
    overflow-y: auto;
  }

  .composer-attachment-list::-webkit-scrollbar { width: 4px; }
  .composer-attachment-list::-webkit-scrollbar-thumb {
    border-radius: 4px;
    background: rgba(128, 128, 128, 0.24);
  }

  .composer-toast {
    position: absolute;
    z-index: 6;
    right: var(--thread-padding);
    bottom: 8px;
    width: max-content;
    max-width: calc(100% - (var(--thread-padding) * 2));
    padding: 4px 8px;
    overflow: hidden;
    border: 1px solid rgba(128, 128, 128, 0.28);
    border-radius: 6px;
    color: var(--text-secondary);
    background: rgba(45, 45, 45, 0.97);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    font-size: var(--font-secondary);
    line-height: 18px;
    text-overflow: ellipsis;
    white-space: nowrap;
    pointer-events: none;
  }

  .composer-toast[hidden] { display: none; }
  .composer-toast[data-kind="progress"]::before { content: ""; display: inline-block; width: 13px; height: 13px; margin-right: 6px; vertical-align: -2px; }
  .composer-toast[data-kind="success"]::before { content: "✓"; margin-right: 6px; }
  .composer-toast[data-kind="error"]::before { content: "×"; margin-right: 6px; }

  .queue-area {
    min-width: 0;
    margin-bottom: 6px;
    border: 1px solid rgba(128, 128, 128, 0.18);
    border-radius: 11px;
    background: rgba(128, 128, 128, 0.065);
    overflow: hidden;
  }

  .queue-area[hidden],
  .queue-paused-status[hidden] { display: none; }

  .queue-paused-status {
    margin: 0;
    padding: 5px 9px 0;
    color: var(--text-muted);
    font-size: var(--font-caption);
    line-height: 16px;
  }

  .queue-area.is-waiting {
    border: 0;
    border-radius: 0;
    background: transparent;
    overflow: visible;
  }

  .queue-area.is-waiting .queue-paused-status {
    display: flex;
    min-width: 0;
    padding: 1px 2px 3px;
    align-items: center;
    gap: 5px;
    overflow: hidden;
    white-space: nowrap;
  }

  .waiting-status-icon {
    display: inline-flex;
    flex: 0 0 14px;
    width: 14px;
    height: 14px;
    align-items: center;
    justify-content: center;
    color: var(--text-muted);
  }

  .waiting-status-icon svg {
    width: 14px;
    height: 14px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.3;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .waiting-status-text {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .queue-items {
    min-width: 0;
    max-height: min(30vh, 220px);
    overflow-x: hidden;
    overflow-y: auto;
  }

  .queue-item {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    min-width: 0;
    min-height: 34px;
    padding: 4px 7px 4px 9px;
    border: 0;
    background: transparent;
  }

  .queue-item + .queue-item { border-top: 1px solid rgba(128, 128, 128, 0.12); }
  .queue-item.is-dragging { opacity: 0.55; }

  .queue-area.is-waiting .queue-item {
    min-height: 30px;
    padding: 2px;
    gap: 6px;
  }

  .queue-area.is-waiting .queue-item + .queue-item {
    border-top-color: rgba(128, 128, 128, 0.08);
  }

  .queue-drag-handle {
    position: absolute;
    z-index: 1;
    top: 50%;
    left: 6px;
    display: inline-flex;
    width: 20px;
    height: 24px;
    padding: 0;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: 4px;
    color: var(--text-muted);
    background: transparent;
    cursor: grab;
    opacity: 0;
    pointer-events: none;
    transform: translateY(-50%);
  }
  .queue-drag-handle:active { cursor: grabbing; }
  .queue-drag-handle svg { width: 13px; height: 13px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; }
  .queue-item.is-reorderable:hover .queue-drag-handle,
  .queue-item.is-reorderable:focus-within .queue-drag-handle { opacity: 1; pointer-events: auto; }
  .queue-item.is-reorderable:hover .queue-preview > .queue-toggle-icon,
  .queue-item.is-reorderable:focus-within .queue-preview > .queue-toggle-icon { opacity: 0; }

  .queue-preview {
    display: inline-flex;
    flex: 1 1 auto;
    min-width: 0;
    align-items: center;
    gap: 7px;
    color: var(--text-secondary);
    font-size: var(--font-secondary);
    line-height: 20px;
    user-select: none;
  }

  .queue-preview svg { flex: 0 0 14px; width: 14px; height: 14px; color: var(--text-muted); fill: none; stroke: currentColor; stroke-width: 1.35; stroke-linecap: round; stroke-linejoin: round; }
  .queue-preview svg.queue-toggle-icon { fill: currentColor; stroke: none; }
  .queue-preview-text { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  .queue-item-actions {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    gap: 2px;
    user-select: none;
  }

  .queue-item-action {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 22px;
    height: 22px;
    padding: 0;
    border: 0;
    border-radius: 4px;
    color: var(--text-muted);
    background: transparent;
    font-size: var(--font-secondary);
    cursor: pointer;
  }

  .queue-item-action:disabled { opacity: 0.45; cursor: default; }

  .queue-item-action:hover:not(:disabled) {
    color: var(--text-secondary);
    background: rgba(128, 128, 128, 0.12);
  }

  .queue-item-action svg {
    width: 13px;
    height: 13px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.35;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .queue-steer-action {
    width: auto;
    min-width: 0;
    gap: 5px;
    padding: 0 5px;
    white-space: nowrap;
  }

  .queue-steer-action.is-pending { cursor: progress; }

  .queue-waiting-action {
    width: auto;
    height: 22px;
    padding: 0 3px;
    font-size: var(--font-caption);
    white-space: nowrap;
  }

  .composer-context-menu.queue-context-menu {
    min-width: 120px;
    padding: 4px;
    border-color: rgba(255, 255, 255, 0.05);
    border-radius: 12px;
    background: #303030;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.34);
  }
  .composer-context-menu.queue-context-menu button {
    justify-content: flex-start;
    min-height: 30px;
    gap: 7px;
    padding: 4px 8px;
    border-radius: 8px;
    color: var(--text-secondary);
    font-size: var(--font-secondary);
    line-height: 18px;
    cursor: pointer;
  }
  .composer-context-menu.queue-context-menu button svg {
    flex: 0 0 16px;
    width: 16px;
    height: 16px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.35;
    stroke-linecap: round;
    stroke-linejoin: round;
  }
  .composer-context-menu.queue-context-menu button svg.queue-toggle-icon {
    fill: currentColor;
    stroke: none;
  }

  @media (max-width: 360px) {
    .queue-item { gap: 4px; padding-left: 7px; padding-right: 5px; }
    .queue-item-actions { gap: 0; }
    .queue-steer-action { padding: 0 3px; }
    .queue-area.is-waiting .queue-item { padding-left: 2px; padding-right: 0; }
    .queue-area.is-waiting .queue-preview { gap: 4px; }
    .queue-waiting-action { padding: 0 2px; }
  }

  .queue-steer-label {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .queue-item.is-steering .queue-preview {
    color: var(--text-muted);
  }

  .composer-surface textarea {
    display: block;
    width: 100%;
    min-width: 0;
    min-height: 42px;
    max-height: 126px;
    margin: 0;
    padding: 0 2px;
    resize: none;
    overflow-y: auto;
    border: 0;
    outline: 0;
    color: var(--text-primary);
    background: transparent;
    font-family: inherit;
    font-size: var(--font-body);
    line-height: var(--line-body);
  }

  .composer-surface textarea::placeholder { color: var(--text-muted); opacity: 0.66; }
  .composer-surface.is-pin-dragover textarea::placeholder { opacity: 0; }

  .composer-context-menu {
    position: fixed;
    z-index: 1000;
    min-width: 166px;
    padding: 4px;
    border: 1px solid rgba(128, 128, 128, 0.34);
    border-radius: 5px;
    background: var(--surface-raised);
    box-shadow: 0 5px 16px rgba(0, 0, 0, 0.34);
  }

  .composer-context-menu[hidden] { display: none; }

  .composer-context-menu button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    min-height: 25px;
    padding: 3px 8px;
    border: 0;
    border-radius: 3px;
    color: var(--text-primary);
    background: transparent;
    cursor: default;
    font: inherit;
    font-size: var(--font-secondary);
    text-align: left;
  }

  .composer-context-menu button:hover,
  .composer-context-menu button:focus-visible {
    outline: 0;
    background: rgba(128, 128, 128, 0.16);
  }

  .composer-context-menu button:disabled {
    color: var(--text-muted);
    opacity: 0.5;
  }

  .composer-context-menu kbd {
    margin-left: 20px;
    color: var(--text-muted);
    font-family: inherit;
    font-size: var(--font-caption);
    font-weight: 400;
  }

  .composer-footer {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    min-width: 0;
    height: 24px;
    margin-top: var(--space-1);
  }

  .composer-actions {
    display: flex;
    flex: 1 1 auto;
    min-width: 0;
    align-items: center;
    justify-content: space-between;
    gap: 0;
  }

  .permission-dock { position: absolute; z-index: 2; left: calc(var(--thread-padding) + 6px); bottom: 20px; display: flex; height: 17px; align-items: center; }
  .permission-button { display: inline-flex; flex: 0 0 18px; width: 18px; height: 17px; align-items: center; justify-content: center; padding: 0; border: 0; border-radius: 4px; background: transparent; color: #c8a900; opacity: .72; cursor: pointer; }
  .permission-button:hover { background: rgba(128,128,128,.07); color: #d5b61d; opacity: 1; }
  .permission-button svg { display: block; width: 13px; height: 13px; fill: none; stroke: currentColor; stroke-width: 1.35; stroke-linecap: round; stroke-linejoin: round; }
  .permission-menu { position: absolute; z-index: 32; width: min(292px, calc(100% - 16px)); max-height: min(250px, 48vh); overflow-y: auto; padding: 6px; border: 1px solid rgba(255,255,255,0.07); border-radius: 12px; background: var(--surface-raised); box-shadow: 0 8px 24px rgba(0,0,0,0.28); }
  .permission-menu[hidden] { display: none; }
  .permission-menu-option { display: grid; grid-template-columns: 18px minmax(0, 1fr) 16px; width: 100%; min-height: 44px; align-items: start; column-gap: 8px; padding: 4px 7px; border: 0; border-radius: 7px; background: transparent; color: var(--text-secondary); font: inherit; text-align: left; cursor: pointer; }
  .permission-menu-option:hover, .permission-menu-option:focus-visible { background: rgba(255,255,255,0.045); outline: none; }
  .permission-menu-option[aria-checked="true"] { background: transparent; }
  .permission-menu-option[aria-checked="true"]:hover,
  .permission-menu-option[aria-checked="true"]:focus-visible { background: rgba(255,255,255,0.045); }
  .permission-menu-icon { display: inline-flex; width: 18px; height: 18px; align-items: center; justify-content: center; margin-top: 1px; color: var(--text-muted); }
  .permission-menu-icon svg { display: block; width: 16px; height: 16px; fill: none; stroke: currentColor; stroke-width: 1.3; stroke-linecap: round; stroke-linejoin: round; }
  .permission-menu-copy { min-width: 0; }
  .permission-menu-title { display: block; color: var(--text-secondary); font-size: 12px; line-height: 17px; }
  .permission-menu-description { display: block; color: var(--text-muted); font-size: 10.5px; line-height: 14px; overflow-wrap: anywhere; }
  .permission-menu-check { align-self: center; color: transparent; font-size: 15px; line-height: 16px; text-align: center; }
  .permission-menu-option[aria-checked="true"] .permission-menu-icon,
  .permission-menu-option[aria-checked="true"] .permission-menu-title,
  .permission-menu-option[aria-checked="true"] .permission-menu-description,
  .permission-menu-option[aria-checked="true"] .permission-menu-check { color: #d9b900; }
  .permission-menu-status { padding: 9px; color: var(--text-muted); font-size: var(--font-secondary); }

  .model-menu { position:absolute; z-index:33; width:min(238px,calc(100% - 16px)); max-height:min(286px,56vh); overflow:hidden; padding:4px; border:1px solid rgba(255,255,255,.07); border-radius:9px; background:var(--surface-raised); box-shadow:0 7px 20px rgba(0,0,0,.28); }
  .model-menu[hidden] { display: none; }
  .model-menu-heading { padding:2px 6px 3px; color:var(--text-muted); font-size:10.5px; line-height:15px; }
  .provider-tabs { display:flex; gap:2px; padding:0 1px 3px; }
  .provider-tab { min-width:0; height:22px; padding:0 7px; border:0; border-radius:5px; color:var(--text-muted); background:transparent; font-size:11.5px; cursor:pointer; }
  .provider-tab:hover,.provider-tab:focus-visible { color:var(--text-secondary); background:rgba(255,255,255,.04); outline:0; }
  .provider-tab.is-active { color:var(--text-primary); background:rgba(128,128,128,.16); }
  .model-menu-list { max-height:min(200px,43vh); overflow-y:auto; overflow-x:hidden; }
  .model-menu-option { display:grid; grid-template-columns:minmax(0,1fr) 15px; width:100%; height:25px; min-height:25px; align-items:center; column-gap:5px; padding:0 6px; border:0; border-radius:5px; color:var(--text-secondary); background:transparent; font-size:12px; text-align:left; cursor:pointer; }
  .model-menu-option:hover,.model-menu-option:focus-visible { color:var(--text-primary); background:rgba(255,255,255,.045); outline:0; }
  .model-menu-option-title { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .model-menu-check { color:transparent; text-align:center; }
  .model-menu-option[aria-checked="true"] .model-menu-check { color:#ddd; }
  .model-menu-option.is-selecting { background:rgba(255,255,255,.09); transition:background-color 150ms ease; }
  .model-menu-separator { height:1px; margin:4px 4px; background:rgba(128,128,128,.18); }
  .model-menu-manage { width:100%; min-height:26px; padding:2px 6px; border:0; border-radius:6px; color:var(--text-muted); background:transparent; font-size:12px; text-align:left; cursor:pointer; }
  .model-menu-manage:hover { color:var(--text-secondary); background:rgba(255,255,255,.04); }
  .compact-picker { position:absolute; z-index:34; width:min(152px,calc(100% - 16px)); max-height:min(200px,46vh); overflow-y:auto; padding:4px; border:1px solid rgba(255,255,255,.07); border-radius:9px; background:var(--surface-raised); box-shadow:0 7px 20px rgba(0,0,0,.28); }
  .compact-picker[hidden] { display:none; }
  .compact-picker-heading { padding:2px 6px 3px; color:var(--text-muted); font-size:10.5px; line-height:15px; }
  .compact-picker .model-menu-option { font-size:12px; }

  .composer-footer .composer-action {
    flex: 0 0 22px;
    width: 22px;
    min-width: 22px;
    max-width: 22px;
    height: 22px;
    min-height: 22px;
    padding: 0;
    border-color: transparent;
    background: transparent;
  }

  .composer-surface.is-pin-mode .attach-button,
  .composer-surface.is-pin-mode .agent-button,
  .composer-surface.is-pin-mode .model-button,
  .composer-surface.is-pin-mode .reasoning-button,
  .composer-surface.is-pin-mode .tools-button,
  .composer-surface.is-pin-mode .send-button { opacity: 0.38; }
  .copilot-root.is-pin-mode .permission-button { opacity: 0.38; }

  .copilot-root.is-pin-mode .queue-area,
  .copilot-root.is-pin-mode .session-history,
  .copilot-root.is-pin-mode .sessions-page {
    pointer-events: none;
    opacity: 0.58;
  }

  .attach-button { color: var(--text-secondary); }
  .attach-button svg { display: block; width: 16px; height: 16px; margin: auto; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; }
  .attach-button:hover { color: var(--text-primary); background: var(--surface); }

  .tools-button {
    flex: 0 0 22px;
    width: 22px;
    min-width: 22px;
    max-width: 22px;
    height: 22px;
    min-height: 22px;
    padding: 0 2px;
    transform: translateX(-6px);
    color: var(--text-muted);
    border-color: transparent;
    background: transparent;
    font-size: var(--font-secondary);
    font-weight: 400;
  }

  .tools-button:hover { color: var(--text-secondary); background: transparent; }

  .tools-button .tools-icon {
    display: inline-block;
    width: 14px;
    height: 14px;
    margin-right: 0;
    vertical-align: -2px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.25;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .agent-button { display:inline-flex; flex:0 0 22px; width:22px; height:24px; align-items:center; justify-content:center; padding:0; border:0; border-radius:5px; color:var(--text-muted); background:transparent; cursor:pointer; }
  .agent-button:hover { color:var(--text-primary); background:rgba(128,128,128,.08); }
  .agent-button .agent-icon { display:block; width:13px; height:13px; fill:none; stroke:currentColor; stroke-width:1.25; stroke-linecap:round; stroke-linejoin:round; }

  .model-button {
    flex: 0 1 clamp(74px, 34%, 130px);
    width: clamp(74px, 34%, 130px);
    min-width: 74px;
    max-width: 130px;
    height: 24px;
    padding: 0 4px;
    overflow: hidden;
    border: 0;
    border-radius: 5px;
    color: var(--text-secondary);
    background: transparent;
    font-size: 12px;
    line-height: 20px;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
  }
  .model-button:hover { color: var(--text-primary); background: rgba(128,128,128,.08); }
  .model-button.is-unavailable { color: var(--text-muted); }
  .reasoning-button { flex:0 0 auto; min-width:38px; max-width:58px; height:24px; padding:0 4px; overflow:hidden; border:0; border-radius:5px; color:var(--text-secondary); background:transparent; font-size:12px; line-height:20px; text-overflow:ellipsis; white-space:nowrap; cursor:pointer; }
  .reasoning-button:hover { color:var(--text-primary); background:rgba(128,128,128,.08); }
  .model-button.is-updating,.reasoning-button.is-updating { opacity:.58; transition:opacity 140ms ease; }
  @media (prefers-reduced-motion: reduce) { .model-menu-option.is-selecting,.model-button.is-updating,.reasoning-button.is-updating { transition:none; } }

  .tools-popover {
    position: absolute;
    z-index: 31;
    display: flex;
    flex-direction: column;
    min-width: 0;
    overflow: hidden;
    border: 1px solid rgba(128, 128, 128, 0.3);
    border-radius: 6px;
    color: var(--text-secondary);
    background: var(--surface-raised);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
    font-size: var(--font-secondary);
  }
  .tools-popover[hidden] { display: none; }
  .tools-popover-header {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    gap: 5px;
    min-height: 31px;
    padding: 5px 10px;
    border-bottom: 1px solid rgba(128, 128, 128, 0.16);
    color: var(--text-primary);
  }
  .tools-popover-title { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .tools-popover-back, .tools-popover-refresh {
    flex: 0 0 auto;
    padding: 0 4px;
    border: 0;
    color: var(--text-muted);
    background: transparent;
    cursor: pointer;
  }
  .tools-popover-back:hover, .tools-popover-refresh:hover { color: var(--text-primary); }
  .tools-popover-refresh { margin-left: auto; }
  .tools-popover-refresh:disabled { cursor: default; opacity: 0.7; }
  .tools-refresh-icon { display: inline-block; width: 14px; text-align: center; }
  .tools-refresh-icon.is-spinning { animation: tools-refresh-spin 850ms linear infinite; }
  @keyframes tools-refresh-spin { to { transform: rotate(360deg); } }
  @media (prefers-reduced-motion: reduce) {
    .tools-refresh-icon.is-spinning { animation: none; }
  }
  .tools-popover-body {
    min-height: 0;
    overflow-x: hidden;
    overflow-y: auto;
    scrollbar-gutter: auto;
    padding: 2px;
  }
  .tools-popover-body::-webkit-scrollbar { width: 5px; }
  .tools-popover-body::-webkit-scrollbar-thumb { border-radius: 5px; background: rgba(128, 128, 128, 0.3); }
  .tools-section-label, .tools-detail-count, .tools-path-hint, .tools-empty {
    padding: 5px 11px 3px;
    color: var(--text-muted);
    font-size: var(--font-caption);
  }
  .tools-section-label:not(:first-child) { margin-top: 7px; }
  .tools-row {
    display: flex;
    width: 100%;
    min-width: 0;
    align-items: center;
    gap: 8px;
    padding: 6px 11px;
    border: 0;
    color: var(--text-secondary);
    background: transparent;
    text-align: left;
    cursor: pointer;
  }
  .tools-row:hover { color: var(--text-primary); background: rgba(128, 128, 128, 0.09); }
  .tools-row-name { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .tools-row-meta { flex: 0 0 auto; color: var(--text-muted); font-size: var(--font-caption); }
  .tools-status-dot { flex: 0 0 auto; width: 6px; height: 6px; border-radius: 50%; background: #858585; }
  .tools-status-dot[data-status="connected"] { background: #77a587; }
  .tools-status-dot[data-status="disconnected"] { background: #a87979; }
  .tools-detail-item { min-width: 0; padding: 6px 11px; }
  .tools-detail-item + .tools-detail-item { border-top: 1px solid rgba(128, 128, 128, 0.1); }
  .tools-detail-name, .tools-detail-description { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .tools-detail-name { color: var(--text-primary); }
  .tools-detail-description { color: var(--text-muted); font-size: var(--font-caption); }
  .tools-source-id, .tools-source-kind, .tools-source-name, .tools-source-path, .tools-source-unknown {
    box-sizing: border-box;
    max-width: 100%;
    min-width: 0;
    padding: 0 11px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .tools-source-id { padding-top: 9px; color: var(--text-muted); font-size: var(--font-caption); }
  .tools-source-kind { padding-top: 12px; color: var(--text-muted); font-size: var(--font-caption); }
  .tools-source-name { padding-top: 3px; color: var(--text-primary); }
  .tools-source-path { margin: 9px 0 10px; color: var(--text-secondary); font-size: var(--font-caption); -webkit-user-select: text; user-select: text; cursor: text; }
  .tools-source-unknown { padding-top: 4px; padding-bottom: 12px; color: var(--text-secondary); }
  .tools-path-hint { padding-top: 9px; overflow-wrap: anywhere; }
  .tools-search { box-sizing: border-box; width: calc(100% - 22px); margin: 5px 11px; padding: 4px 6px; border: 1px solid rgba(128,128,128,.23); border-radius: 5px; color: var(--text-primary); background: rgba(0,0,0,.12); outline: none; }

  .send-button {
    border-radius: 50%;
    font-size: 17px;
    font-weight: 700;
    line-height: 1;
    border-color: rgba(156, 156, 156, 0.28) !important;
    background: rgba(128, 128, 128, 0.18) !important;
    transition: color 120ms ease, background-color 120ms ease, border-color 120ms ease;
  }

  .send-button.is-send-empty {
    color: #3c3c3c;
    border-color: rgba(178, 178, 178, 0.52) !important;
    background: rgba(154, 154, 154, 0.86) !important;
  }

  .send-button.is-send-empty:hover {
    color: #343434;
    border-color: rgba(190, 190, 190, 0.62) !important;
    background: rgba(168, 168, 168, 0.9) !important;
  }

  .send-button.is-send-active {
    color: #383838;
    border-color: rgba(220, 220, 220, 0.88) !important;
    background: rgba(220, 220, 220, 0.94) !important;
  }

  .send-button.is-send-active:hover {
    color: #303030;
    border-color: rgba(224, 224, 224, 0.8) !important;
    background: rgba(224, 224, 224, 0.93) !important;
  }

  .send-button.is-send-active:active {
    background: rgba(202, 202, 202, 0.9) !important;
  }

  .send-button.is-stop {
    color: var(--danger);
    font-size: 11px;
    font-weight: 600;
    border-color: var(--color-normal-border, var(--border-subtle)) !important;
    background: var(--surface) !important;
  }

  .send-button.is-stop:hover {
    border-color: rgba(215, 121, 121, 0.42) !important;
    background: rgba(215, 121, 121, 0.08) !important;
  }
  .send-button.is-stop:not([disabled]) {
    animation: stop-task-pulse 1.05s ease-in-out infinite;
    will-change: color, border-color, box-shadow;
  }
  .send-button[disabled] { cursor: default; opacity: 0.45; }

  @keyframes stop-task-pulse {
    0%, 100% {
      color: var(--danger);
      border-color: var(--color-normal-border, var(--border-subtle));
      box-shadow: none;
    }
    50% {
      color: #ff9292;
      border-color: rgba(222, 104, 104, 0.52);
      box-shadow: 0 0 0 2px rgba(222, 104, 104, 0.1);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .send-button.is-stop:not([disabled]),
    .session-row-spinner, .composer-toast[data-kind="progress"]::before { animation: none; }
  }

  @media (max-width: 340px) {
    :host { --thread-padding: 12px; }
    .status-prefix { display: none; }
    .turn-user-message { margin-right: 12px; }
    .session-status { margin-left: var(--space-1); }
    .model-button { max-width: 104px; }
  }
`;

module.exports = { template, style, PROMPT_COLLAPSED_LINES };
