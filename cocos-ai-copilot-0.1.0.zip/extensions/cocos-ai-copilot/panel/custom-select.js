'use strict';

function enhanceSelectFields(root) {
  const doc = root.ownerDocument, win = doc.defaultView, cleanups = [], records = [];
  const listen = (target, type, handler) => {
    target.addEventListener(type, handler);
    cleanups.push(() => target.removeEventListener(type, handler));
  };
  const closeAll = except => {
    for (const record of records) if (record !== except) {
      record.menu.hidden = true;
      record.trigger.setAttribute('aria-expanded', 'false');
    }
  };
  for (const select of root.querySelectorAll('select')) {
    if (select.dataset.enhancedSelect === 'true') continue;
    select.dataset.enhancedSelect = 'true';
    select.classList.add('tool-native-select');
    select.hidden = true;
    const wrapper = doc.createElement('div'); wrapper.className = 'tool-select';
    select.parentNode.insertBefore(wrapper, select); wrapper.append(select);
    const trigger = doc.createElement('button'); trigger.type = 'button'; trigger.className = 'tool-select-trigger'; trigger.setAttribute('aria-haspopup', 'listbox'); trigger.setAttribute('aria-expanded', 'false');
    const value = doc.createElement('span'); value.className = 'tool-select-value';
    const arrow = doc.createElement('span'); arrow.className = 'tool-select-arrow'; arrow.textContent = '⌄'; arrow.setAttribute('aria-hidden', 'true');
    trigger.append(value, arrow);
    const menu = doc.createElement('div'); menu.className = 'tool-select-menu'; menu.setAttribute('role', 'listbox'); menu.hidden = true;
    const record = {select, wrapper, trigger, value, menu, options:[]};
    const sync = () => {
      const selected = [...select.options].find(option => option.value === select.value) || select.options[0];
      value.textContent = selected?.textContent || '';
      trigger.disabled = select.disabled;
      trigger.title = select.title || '';
      for (const item of record.options) item.setAttribute('aria-selected', String(item.dataset.value === select.value));
    };
    record.sync = sync;
    for (const option of select.options) {
      const item = doc.createElement('button'); item.type = 'button'; item.className = 'tool-select-option'; item.dataset.value = option.value; item.textContent = option.textContent; item.setAttribute('role', 'option'); item.disabled = option.disabled;
      record.options.push(item); menu.append(item);
      listen(item, 'click', event => {
        event.preventDefault(); event.stopPropagation();
        select.value = option.value;
        select.dispatchEvent(new win.Event('change', {bubbles:true}));
        menu.hidden = true; trigger.setAttribute('aria-expanded', 'false');
        win.queueMicrotask(sync);
      });
    }
    wrapper.append(trigger, menu); records.push(record); sync();
    listen(trigger, 'click', event => {
      event.preventDefault(); event.stopPropagation();
      const opening = menu.hidden; closeAll(record); menu.hidden = !opening; trigger.setAttribute('aria-expanded', String(opening));
      if (opening) menu.querySelector('[aria-selected="true"]')?.focus();
    });
    listen(select, 'change', () => win.queueMicrotask(sync));
    listen(trigger, 'keydown', event => { if (event.key === 'Escape') { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); trigger.focus(); } });
    listen(menu, 'keydown', event => { if (event.key === 'Escape') { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); trigger.focus(); } });
  }
  listen(doc, 'click', () => closeAll());
  listen(win, 'blur', () => closeAll());
  return {
    sync(){ for (const record of records) record.sync(); },
    destroy(){ cleanups.splice(0).forEach(cleanup => cleanup()); },
  };
}

module.exports = {enhanceSelectFields};
