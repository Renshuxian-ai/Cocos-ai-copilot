'use strict';

const { createReviewPresentation } = require('../lib/review-presentation');

const EXTENSION_NAME = 'cocos-ai-copilot';
const CHANGES_EVENT_CHANNEL = `${EXTENSION_NAME}:changes-changed`;

const template = `
  <main class="changes-root">
    <header class="changes-header">
      <div>
        <div id="changesTitle" class="changes-title">本轮更改</div>
        <div id="changesStats" class="changes-stats"></div>
      </div>
      <nav id="filters" class="changes-filters" aria-label="更改类型">
        <button type="button" data-filter="all" class="is-active">全部</button>
        <button type="button" data-filter="scene">场景</button>
        <button type="button" data-filter="file">文件</button>
        <button type="button" data-filter="asset">资源</button>
      </nav>
    </header>
    <section id="changesBody" class="changes-body"></section>
    <div id="changesEmpty" class="changes-empty">从聊天中的“查看更改”打开某一轮修改</div>
  </main>
`;

const style = `
  :host { display:block; width:100%; height:100%; color:var(--color-normal-contrast,#d6d6d6); background:var(--color-normal-fill,#202020); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
  * { box-sizing:border-box; }
  button { font:inherit; }
  .changes-root { position:relative; display:flex; width:100%; height:100%; min-width:0; min-height:0; overflow:hidden; flex-direction:column; }
  .changes-header { display:flex; flex:0 0 auto; min-width:0; min-height:56px; align-items:center; justify-content:space-between; gap:8px 18px; padding:10px 18px; border-bottom:1px solid rgba(128,128,128,.2); }
  .changes-header > div { min-width:0; }
  .changes-title { color:var(--color-normal-contrast,#ddd); font-size:13px; line-height:18px; }
  .changes-stats { margin-top:1px; color:var(--color-normal-contrast-weakest,#777); font-size:11px; line-height:15px; }
  .diff-add { color:#73b786; } .diff-remove { color:#d06955; }
  .changes-filters { display:flex; flex:0 1 auto; min-width:0; gap:3px; padding:3px; overflow-x:auto; border-radius:9px; background:rgba(255,255,255,.025); }
  .changes-filters button { min-width:44px; padding:4px 9px; border:0; border-radius:7px; background:transparent; color:var(--color-normal-contrast-weakest,#777); cursor:pointer; }
  .changes-filters button:hover { color:var(--color-normal-contrast,#ddd); }
  .changes-filters button.is-active { background:rgba(255,255,255,.075); color:var(--color-normal-contrast,#ddd); }
  .changes-body { flex:1 1 auto; min-width:0; min-height:0; overflow-x:hidden; overflow-y:auto; padding:14px 22px 34px; }
  .changes-body:empty { display:none; }
  .changes-empty { position:absolute; inset:56px 0 0; display:flex; align-items:center; justify-content:center; padding:28px; color:var(--color-normal-contrast-weakest,#777); font-size:12px; }
  .changes-empty[hidden] { display:none; }
  .change-section + .change-section { margin-top:20px; }
  .change-section-title { margin-bottom:7px; color:var(--color-normal-contrast-weakest,#777); font-size:11px; text-transform:uppercase; letter-spacing:.04em; }
  .change-entry { min-width:0; border-top:1px solid rgba(128,128,128,.14); }
  .change-entry:last-child { border-bottom:1px solid rgba(128,128,128,.14); }
  .change-summary { display:flex; min-width:0; min-height:43px; align-items:center; gap:10px; padding:8px 4px; border:0; list-style:none; cursor:pointer; }
  .change-summary.is-navigation-target,.semantic-entry.is-navigation-target { background:transparent; outline:none; box-shadow:none; animation:navigation-target-glow 1.6s ease-out both; }
  .change-summary.is-navigation-target:focus,.semantic-entry.is-navigation-target:focus { outline:none; }
  @keyframes navigation-target-glow {
    0% { background:rgba(255,255,255,.035); box-shadow:0 0 8px rgba(255,255,255,.07); }
    38% { background:rgba(255,255,255,.025); box-shadow:0 0 14px rgba(255,255,255,.10); }
    100% { background:transparent; box-shadow:0 0 0 rgba(255,255,255,0); }
  }
  @media (prefers-reduced-motion: reduce) {
    .change-summary.is-navigation-target,.semantic-entry.is-navigation-target { animation-duration:.01ms; }
  }
  .change-summary::-webkit-details-marker { display:none; }
  .entry-label { flex:1 1 auto; min-width:0; overflow:hidden; color:var(--color-normal-contrast,#ddd); font-size:13px; text-overflow:ellipsis; white-space:nowrap; }
  .entry-count { flex:0 0 auto; color:var(--color-normal-contrast-weakest,#777); font-size:11px; white-space:nowrap; }
  .entry-stats { flex:0 0 auto; font-size:12px; }
  .entry-state { flex:0 0 auto; color:var(--color-normal-contrast-weakest,#777); font-size:11px; white-space:nowrap; }
  .entry-chevron { flex:0 0 auto; width:14px; color:var(--color-normal-contrast-weakest,#777); font-size:15px; transform:rotate(0); }
  details[open] > .change-summary .entry-chevron { transform:rotate(90deg); }
  .entry-detail { min-width:0; max-width:100%; margin:0 0 12px; overflow-x:auto; overflow-y:hidden; border-radius:7px; background:rgba(0,0,0,.15); }
  .diff-line { display:grid; grid-template-columns:34px 34px minmax(max-content,1fr); width:max-content; min-width:100%; font:12px/19px Consolas,"Cascadia Mono",monospace; white-space:pre; }
  .diff-line-number { padding:0 7px 0 3px; color:var(--color-normal-contrast-weakest,#666); text-align:right; user-select:none; }
  .diff-line-code { min-width:0; padding-right:14px; }
  .diff-marker { display:inline-block; width:16px; color:var(--color-normal-contrast-weakest,#777); user-select:none; }
  .diff-line.is-add { color:#84c695; background:rgba(70,140,88,.12); }
  .diff-line.is-remove { color:#df7b68; background:rgba(160,65,50,.12); }
  .scene-group-detail { min-width:0; padding:0 4px 8px 18px; }
  .semantic-entry { display:grid; grid-template-columns:minmax(0,1fr) auto; min-width:0; align-items:start; gap:12px; padding:7px 0; border-top:1px solid rgba(128,128,128,.1); }
  .semantic-entry:first-child { border-top:0; }
  .semantic-main { flex:1 1 auto; min-width:0; }
  .semantic-value { display:flex; min-width:0; gap:9px; color:var(--color-normal-contrast-weakest,#999); font:11px/17px Consolas,"Cascadia Mono",monospace; }
  .semantic-value.is-add { color:#84c695; }
  .semantic-value.is-remove { color:#df7b68; }
  .semantic-property { min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .semantic-transition { flex:0 0 auto; white-space:nowrap; }
  .component-group > summary,.technical-details > summary,.more-groups > summary { padding:7px 0; color:var(--color-normal-contrast,#bbb); font-size:12px; cursor:pointer; }
  .more-groups > summary { display:flex; align-items:center; justify-content:center; min-height:30px; list-style:none; border-radius:3px; }
  .more-groups[open] { position:relative; padding-bottom:30px; }
  .more-groups[open] > summary { position:absolute; bottom:0; left:0; right:0; height:30px; }
  .more-groups > summary::-webkit-details-marker { display:none; }
  .more-groups > summary::after { content:''; width:6px; height:6px; border-right:1px solid currentColor; border-bottom:1px solid currentColor; transform:translateY(-2px) rotate(45deg); }
  .more-groups[open] > summary::after { transform:translateY(2px) rotate(225deg); }
  .more-groups > summary:hover { background:rgba(255,255,255,.045); color:var(--color-normal-contrast,#ddd); }
  .more-groups > summary:focus-visible { outline:1px solid var(--color-focus-border,#7095bb); outline-offset:-1px; }
  .component-group { padding-left:10px; }
  .component-heading { display:block; padding:7px 0; color:var(--color-normal-contrast,#bbb); font-size:12px; }
  .technical-details { margin:8px 0; color:var(--color-normal-contrast-weakest,#999); font-size:11px; }
  .technical-json { max-height:420px; overflow:auto; white-space:pre-wrap; overflow-wrap:anywhere; font:11px/17px Consolas,monospace; }
  .snapshot-note,.scene-name,.evidence-note { padding:6px 0; color:var(--color-normal-contrast-weakest,#888); font-size:11px; }
  .semantic-transition { flex:1 1 auto; white-space:normal; overflow-wrap:anywhere; }
  .semantic-state { flex:0 0 auto; padding-top:1px; color:var(--color-normal-contrast-weakest,#777); font-size:11px; white-space:nowrap; }
  .undo-outcome { margin:7px 0 0; padding:7px 9px; border-radius:6px; background:rgba(255,255,255,.035); color:var(--color-normal-contrast-weakest,#999); font-size:11px; line-height:17px; }
  .locate { flex:0 0 auto; padding:3px 7px; border:0; background:transparent; color:var(--color-normal-contrast-weakest,#888); cursor:pointer; }
  .locate:hover { color:var(--color-normal-contrast,#ddd); }
  .changes-body::-webkit-scrollbar,.entry-detail::-webkit-scrollbar,.changes-filters::-webkit-scrollbar { width:7px; height:7px; }
  .changes-body::-webkit-scrollbar-thumb,.entry-detail::-webkit-scrollbar-thumb,.changes-filters::-webkit-scrollbar-thumb { border-radius:7px; background:rgba(128,128,128,.28); }
  @media (max-width:420px) {
    .changes-header { align-items:flex-start; flex-direction:column; }
    .changes-filters { width:100%; }
    .changes-filters button { flex:1 1 0; min-width:0; }
    .changes-body { padding-right:14px; padding-left:14px; }
    .scene-group-detail { padding-left:10px; }
  }
`;

module.exports = Editor.Panel.define({
  template,
  style,
  $: {
    body: '#changesBody',
    empty: '#changesEmpty',
    filters: '#filters',
    stats: '#changesStats',
    title: '#changesTitle',
  },
  methods: {
    clear(node) { while (node?.firstChild) node.removeChild(node.firstChild); },
    element(tag, className = '', text = '') {
      const node = (this.$.body.ownerDocument || document).createElement(tag);
      if (className) node.className = className;
      if (text !== '') node.textContent = text;
      return node;
    },
    renderUndoOutcome(view) {
      if (!view?.undoDetails?.length) return null;
      const block = this.element('div', 'undo-outcome');
      view.undoDetails.forEach((detail) => block.appendChild(this.element('div', '', detail)));
      return block;
    },
    groupOpen(group) {
      return this._expandedGroups?.has(group.key)
        ? this._expandedGroups.get(group.key) : group.defaultExpanded;
    },
    trackGroup(details, group) {
      details.open = Boolean(this.groupOpen(group));
      details.addEventListener('toggle', () => this._expandedGroups?.set(group.key, Boolean(details.open)));
    },
    appendStats(summary, item) {
      if (!item.textDiff) return;
      const stats = this.element('span', 'entry-stats');
      stats.appendChild(this.element('span', 'diff-add', `+${item.additions}`));
      stats.appendChild(this.element('span', 'diff-remove', ` -${item.deletions}`));
      summary.appendChild(stats);
    },
    registerNavigationAnchor(map, key, node, details, groupKey = '', ancestors = []) {
      const anchorId = String(key || '');
      if (!anchorId) return;
      node.dataset.anchorId = anchorId;
      map.set(anchorId, { node, details, ancestors, groupKey: String(groupKey || '') });
    },
    applyNavigationTarget(target = this._navigationTarget) {
      if (this._activeNavigationNode) {
        this._activeNavigationNode.classList.remove('is-navigation-target');
        this._activeNavigationNode.removeAttribute?.('aria-current');
      }
      this._activeNavigationNode = null;
      if (!target) return 'viewer';
      const leaf = this._changeAnchors?.get(String(target.anchorId || ''));
      const group = this._groupAnchors?.get(String(target.groupAnchorId || ''));
      const match = leaf || group;
      if (!match) return 'viewer';
      for (const ancestor of match.ancestors || []) ancestor.open = true;
      if (match.details) {
        match.details.open = true;
        if (match.groupKey) this._expandedGroups?.set(match.groupKey, true);
      }
      match.node.classList.add('is-navigation-target');
      match.node.setAttribute?.('aria-current', 'true');
      if (String(match.node.tagName || '').toLowerCase() !== 'summary') {
        match.node.setAttribute?.('tabindex', '-1');
      }
      match.node.scrollIntoView?.({ block: 'center', inline: 'nearest' });
      match.node.focus?.({ preventScroll: true });
      this._activeNavigationNode = match.node;
      return leaf ? 'change' : 'group';
    },
    activateNavigationFilter(target) {
      const domain = String(target?.domain || '');
      if (!domain || this._filter === 'all' || this._filter === domain) return;
      this._filter = domain;
      Array.from(this.$.filters.querySelectorAll('[data-filter]')).forEach((item) => (
        item.classList.toggle('is-active', item.dataset.filter === domain)
      ));
    },
    appendLocate(summary, group) {
      if (!group.canLocate) return;
      const locate = this.element('button', 'locate', '定位');
      locate.type = 'button';
      locate.addEventListener('click', (event) => {
        event.preventDefault?.();
        event.stopPropagation?.();
        const item = group.items.find((view) => view.targetAvailable && view.kind !== 'node-delete')?.item || {};
        Editor.Message.request(EXTENSION_NAME, 'locate-change-target', {
          nodeUuid: item.nodeUuid || '', path: item.path || '',
        }).catch(() => {});
      });
      summary.appendChild(locate);
    },
    technicalDetails(group) {
      const details = this.element('details', 'technical-details');
      details.appendChild(this.element('summary', '', `技术详情 · ${group.changeCount} 项原始事实`));
      const raw = this.element('pre', 'technical-json');
      details.appendChild(raw);
      details.addEventListener('toggle', () => {
        if (details.open && !raw.textContent) raw.textContent = JSON.stringify({
          canonicalItems: group.items.map(view => view.item), coverage: this._changeSet?.coverage,
          sceneContext: this._changeSet?.sceneContext,
        }, null, 2);
      });
      return details;
    },
    appendProgressiveGroups(parent, groups, render, ancestors = []) {
      const maximum = this._model?.maxVisibleGroups || 8;
      groups.slice(0, maximum).forEach(group => parent.appendChild(render(group, ancestors)));
      if (groups.length <= maximum) return;
      const more = this.element('details', 'more-groups');
      const remaining = groups.length - maximum;
      const toggle = this.element('summary');
      toggle.setAttribute('aria-label', `展开剩余 ${remaining} 项`);
      more.appendChild(toggle);
      more.addEventListener('toggle', () => {
        toggle.setAttribute('aria-label', `${more.open ? '收起' : '展开剩余'} ${remaining} 项`);
      });
      groups.slice(maximum).forEach(group => more.appendChild(render(group, [...ancestors, more])));
      parent.appendChild(more);
    },
    renderFileDomain(domain) {
      if (!domain.changeCount) return;
      const section = this.element('section', 'change-section');
      section.appendChild(this.element('div', 'change-section-title', `${domain.label} · ${domain.changeCount}`));
      this.appendProgressiveGroups(section, domain.groups, (group, ancestors) => {
        const item = group.items[0];
        const details = this.element('details', 'change-entry');
        this.trackGroup(details, group);
        const summary = this.element('summary', 'change-summary');
        this.registerNavigationAnchor(this._groupAnchors, group.anchorId, summary, details, group.key, ancestors);
        this.registerNavigationAnchor(this._changeAnchors, item.anchorId, summary, details, group.key, ancestors);
        const label = this.element('span', 'entry-label', group.label);
        label.title = group.fullLabel;
        summary.appendChild(label);
        this.appendStats(summary, item);
        const state = item.status || item.fileKind;
        if (state) summary.appendChild(this.element('span', 'entry-state', state));
        this.appendLocate(summary, group);
        summary.appendChild(this.element('span', 'entry-chevron', '›'));
        details.appendChild(summary);
        if (group.relatedScene) {
          details.open = this._expandedGroups.has(group.key) ? this._expandedGroups.get(group.key) : false;
        }
        const detail = this.element('div', 'entry-detail');
        if (group.relatedScene) detail.appendChild(this.element('div', 'evidence-note', group.evidenceLabel));
        if (item.status === '仅查看' && item.item.reason) detail.appendChild(this.element('div', 'evidence-note', item.item.reason));
        if (domain.id === 'asset') {
          detail.appendChild(this.element('div', 'evidence-note',
            `${item.fileKind}${item.item.assetType ? ` · ${item.item.assetType}` : ''} · ${item.path}`));
          const imageReview = item.item.imageReview;
          if (imageReview) {
            const byteLength = Number(imageReview.byteLength || 0);
            const size = byteLength < 1024 ? `${byteLength} B`
              : byteLength < 1024 * 1024 ? `${(byteLength / 1024).toFixed(1)} KiB`
                : `${(byteLength / 1024 / 1024).toFixed(1)} MiB`;
            detail.appendChild(this.element('div', 'semantic-value',
              `图片新版本 · ${String(imageReview.format || '').toUpperCase()} · ${imageReview.width} × ${imageReview.height} · ${size}`));
            detail.appendChild(this.element('div', 'semantic-value',
              `处理：${imageReview.operations?.length ? imageReview.operations.join(' → ') : '无像素操作'} · ${imageReview.hasTransparentPixels ? '含透明像素' : '不含透明像素'}`));
          }
        }
        if (item.binary || !item.diffLines.length) {
          const message = item.binary ? (item.item.imageReview ? '二进制图片 · 像素内容见上方摘要' : '二进制资源 · 仅显示摘要')
            : item.diffUnavailableReason === 'too-large' ? '文件较大，仅显示变更摘要'
              : '没有可显示的文本 diff';
          const line = this.element('div', 'semantic-value', message);
          line.style.padding = '9px 12px';
          detail.appendChild(line);
        } else {
          item.diffLines.forEach((line) => {
            const row = this.element('div', `diff-line${line.kind ? ` is-${line.kind}` : ''}`);
            row.appendChild(this.element('span', 'diff-line-number', line.oldLine == null ? '' : String(line.oldLine)));
            row.appendChild(this.element('span', 'diff-line-number', line.newLine == null ? '' : String(line.newLine)));
            const code = this.element('span', 'diff-line-code');
            code.appendChild(this.element('span', 'diff-marker', line.marker));
            code.appendChild(this.element('span', '', line.text));
            row.appendChild(code);
            detail.appendChild(row);
          });
        }
        const undoOutcome = this.renderUndoOutcome(item);
        if (undoOutcome) detail.appendChild(undoOutcome);
        details.appendChild(detail);
        if (item.diffTruncated) details.appendChild(this.element('div', 'evidence-note', 'Diff 预览已折叠剩余行；查看 Raw Diff 可访问完整内容'));
        const rawDiff = this.element('details', 'technical-details');
        rawDiff.appendChild(this.element('summary', '', '查看 Raw Diff'));
        const raw = this.element('pre', 'technical-json');
        rawDiff.appendChild(raw);
        rawDiff.addEventListener('toggle', () => { if (rawDiff.open) raw.textContent = item.rawDiff || '无可用 Raw Diff'; });
        details.appendChild(rawDiff);
        details.appendChild(this.technicalDetails(group));
        return details;
      });
      this.$.body.appendChild(section);
    },
    renderSceneGroup(group, ancestors = []) {
        const details = this.element('details', 'change-entry scene-object-group');
        this.trackGroup(details, group);
        const summary = this.element('summary', 'change-summary');
        this.registerNavigationAnchor(this._groupAnchors, group.anchorId, summary, details, group.key, ancestors);
        const label = this.element('span', 'entry-label', group.label);
        label.title = group.fullLabel;
        label.textContent = group.displayLabel || group.label;
        summary.appendChild(label);
        summary.appendChild(this.element('span', 'entry-count', `${group.changeCount} 项改动`));
        this.appendLocate(summary, group);
        summary.appendChild(this.element('span', 'entry-chevron', '›'));
        details.appendChild(summary);
        const groupDetail = this.element('div', 'scene-group-detail');
        if (group.items.some(item => item.semantic.snapshotNote)) groupDetail.appendChild(this.element('div', 'snapshot-note', '创建后快照 · 完整属性见技术详情'));
        const renderedOutcomes = new Set();
        for (const item of group.items) {
          const key = JSON.stringify(item.undoDetails || []);
          if (!item.undoDetails?.length || renderedOutcomes.has(key)) continue;
          renderedOutcomes.add(key);
          const outcome = this.renderUndoOutcome(item);
          if (outcome) groupDetail.appendChild(outcome);
        }
        for (const component of group.components || []) {
          const expandable = component.rows.length > 0 || component.items.some(item => item.undoDetails?.length);
          const componentDetails = this.element(expandable ? 'details' : 'div', 'component-group');
          if (expandable) this.trackGroup(componentDetails, { key: `${group.key}/${component.key}`, defaultExpanded: component.defaultExpanded === true });
          const componentSummary = this.element(expandable ? 'summary' : 'span', expandable ? '' : 'component-heading', component.label);
          componentDetails.appendChild(componentSummary);
          if (!component.rows.length) for (const item of component.items) {
            if (item.status) componentSummary.appendChild(this.element('span', 'semantic-state', ` · ${item.status}`));
          }
          for (const { view: item, line } of component.rows) {
          const row = this.element('div', 'semantic-entry');
          if (group.type !== 'pattern') this.registerNavigationAnchor(this._changeAnchors, item.anchorId, row, componentDetails,
            `${group.key}/${component.key}`, [...ancestors, details]);
          const main = this.element('div', 'semantic-main');
            const value = this.element('div', `semantic-value${line.tone ? ` is-${line.tone}` : ''}`);
            if (line.text) value.textContent = line.text;
            else {
              value.appendChild(this.element('span', 'semantic-property', line.label));
              value.appendChild(this.element('span', 'semantic-transition', `${line.before} → ${line.after}`));
            }
            main.appendChild(value);
          row.appendChild(main);
          const status = group.type === 'pattern' ? group.compact.status : item.status;
          if (status) row.appendChild(this.element('span', 'semantic-state', status));
          componentDetails.appendChild(row);
          }
          groupDetail.appendChild(componentDetails);
        }
        // Structural items without a property row still retain their canonical navigation target.
        if (group.type !== 'pattern') for (const item of group.items) if (!this._changeAnchors.has(item.anchorId)) {
          this.registerNavigationAnchor(this._changeAnchors, item.anchorId, summary, details, group.key, ancestors);
        }
        if (group.type === 'pattern') {
          const members = this.element('details', 'pattern-members');
          members.appendChild(this.element('summary', '', `查看 ${group.members.length} 个对象`));
          this.appendProgressiveGroups(members, group.members, (member, parents) => this.renderSceneGroup(member, parents), [...ancestors, details, members]);
          groupDetail.appendChild(members);
        }
        groupDetail.appendChild(this.technicalDetails(group));
        details.appendChild(groupDetail);
        return details;
    },
    renderSceneDomain(domain) {
      if (!domain.changeCount) return;
      const section = this.element('section', 'change-section');
      section.appendChild(this.element('div', 'change-section-title', `${domain.label} · ${domain.changeCount}`));
      for (const scene of domain.scenes) {
        section.appendChild(this.element('div', 'scene-name', scene.label));
        this.appendProgressiveGroups(section, scene.groups, (group, ancestors) => this.renderSceneGroup(group, ancestors));
      }
      this.$.body.appendChild(section);
    },
    render() {
      this.clear(this.$.body);
      this._changeAnchors = new Map();
      this._groupAnchors = new Map();
      this._activeNavigationNode = null;
      const set = this._changeSet;
      const filter = this._filter || 'all';
      const model = set ? createReviewPresentation(set) : null;
      this._model = model;
      this.$.title.textContent = model ? `本轮 · ${model.totalChanges} 项改动` : '未选择更改';
      this.$.stats.textContent = '';
      if (model?.hasTextDiff) {
        this.$.stats.appendChild(this.element('span', 'diff-add', `+${model.textAdditions}`));
        this.$.stats.appendChild(this.element('span', 'diff-remove', ` -${model.textDeletions}`));
      }
      if (model?.undoSummary) this.$.stats.appendChild(this.element('span', '', ` · ${model.undoSummary}`));
      if (model?.persistence) this.$.stats.appendChild(this.element('span', '', ` · ${model.persistence}`));
      for (const warning of model?.warnings || []) this.$.stats.appendChild(this.element('span', '', ` · ${warning}`));
      const domainPriority = filter === 'all' ? { scene: 0, asset: 1, file: 2 } : {};
      const domains = model?.domains.filter((domain) => (
        domain.changeCount && (filter === 'all' || filter === domain.id)
      )).sort((left, right) => (domainPriority[left.id] ?? 0) - (domainPriority[right.id] ?? 0)) || [];
      domains.forEach((domain) => {
        if (domain.id === 'scene') this.renderSceneDomain(domain);
        else this.renderFileDomain(domain);
      });
      this.$.empty.textContent = !set ? '从聊天中的“查看更改”打开某一轮修改'
        : model?.warnings.length ? '本轮核对不完整，请查看上方说明'
        : filter === 'all' ? '本轮没有可显示的更改'
          : `本轮没有${({ scene: '场景', file: '文件', asset: '资源' })[filter]}更改`;
      this.$.empty.hidden = domains.length > 0;
      this.applyNavigationTarget();
    },
    async load(payload = {}) {
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'get-turn-changes', payload);
        const nextBinding = result?.active || null;
        const nextKey = nextBinding ? `${nextBinding.sessionId || ''}:${nextBinding.turnId || ''}` : '';
        if (nextKey !== this._bindingKey) this._expandedGroups.clear();
        this._changeSet = result?.changeSet || null;
        this._binding = nextBinding;
        this._bindingKey = nextKey;
        this._navigationTarget = nextBinding?.navigationTarget || payload.navigationTarget || null;
        this.activateNavigationFilter(this._navigationTarget);
      } catch (_) { this._changeSet = null; }
      this.render();
    },
    clearSelection() {
      this._binding = null;
      this._bindingKey = '';
      this._changeSet = null;
      this._navigationTarget = null;
      this._activeNavigationNode = null;
      this._changeAnchors?.clear();
      this._groupAnchors?.clear();
      this._expandedGroups.clear();
      this.render();
    },
  },
  ready() {
    this._filter = 'all';
    this._binding = null;
    this._bindingKey = '';
    this._changeSet = null;
    this._navigationTarget = null;
    this._activeNavigationNode = null;
    this._changeAnchors = new Map();
    this._groupAnchors = new Map();
    this._expandedGroups = new Map();
    this._filterHandler = (event) => {
      const button = event.target?.closest?.('[data-filter]');
      if (!button) return;
      this._filter = button.dataset.filter;
      Array.from(this.$.filters.querySelectorAll('[data-filter]')).forEach((item) => item.classList.toggle('is-active', item === button));
      this.render();
    };
    this.$.filters.addEventListener('click', this._filterHandler);
    this._changesHandler = (payload = {}) => {
      if (payload.type === 'selection-cleared') { this.clearSelection(); return; }
      if (payload.type === 'selection-changed') { this.load(payload); return; }
      if (payload.type === 'change-set-updated'
        && this._binding?.sessionId === payload.sessionId
        && this._binding?.turnId === String(payload.turnId || payload.taskId || '')) this.load(this._binding);
    };
    Editor.Message.addBroadcastListener?.(CHANGES_EVENT_CHANNEL, this._changesHandler);
    this.load();
  },
  close() {
    this.$.filters?.removeEventListener('click', this._filterHandler);
    Editor.Message.removeBroadcastListener?.(CHANGES_EVENT_CHANNEL, this._changesHandler);
    this._filterHandler = null;
    this._changesHandler = null;
    this._binding = null;
    this._bindingKey = '';
    this._changeSet = null;
    this._navigationTarget = null;
    this._activeNavigationNode = null;
    this._changeAnchors?.clear();
    this._groupAnchors?.clear();
    this._changeAnchors = null;
    this._groupAnchors = null;
    this._expandedGroups?.clear();
    this._expandedGroups = null;
  },
});
