'use strict';

const { semanticActivity, classifyActivity, activityForDisplay } = require('../lib/semantic-activity');
const { redactDisplayValue } = require('../lib/detail-registry');

// Activity UI and user responses use the owning panel state; no second lifecycle.
module.exports = function createActivityMethods(EXTENSION_NAME) {
  return {
    activityExpanded(turn, key, fallback) {
      return turn.ui.expanded.has(key) ? turn.ui.expanded.get(key) : Boolean(fallback);
    },

    setActivityExpanded(turn, key, expanded) {
      turn.ui.expanded.set(key, Boolean(expanded));
    },

    renderActivityDisclosure(parent, turn, options) {
      const ownerDocument = parent.ownerDocument || document;
      const presentation = this.statusPresentation(options.status);
      const hasDetail = typeof options.renderDetail === 'function';
      const forcedOpen = options.status === 'failed';
      let expanded = hasDetail && (forcedOpen || this.activityExpanded(turn, options.key, options.defaultExpanded));
      let detail = null;
      let detailRendered = false;
      const section = this.createElement(ownerDocument, 'section', `activity-disclosure is-${options.status || 'pending'}`);
      if (options.warning) section.classList.add('is-warning');
      const headerRow = this.createElement(ownerDocument, 'div', 'activity-header-row');
      const header = this.createElement(
        ownerDocument,
        'button',
        `activity-header${hasDetail ? '' : ' no-detail'}${options.hideIcon ? ' no-icon' : ''}`
      );
      header.type = 'button';
      header.setAttribute('aria-disabled', String(!hasDetail));
      header.setAttribute('aria-expanded', String(expanded));
      if (!options.hideIcon) {
        const icon = this.createElement(ownerDocument, 'span', `activity-icon ${presentation.className}`);
        if (options.iconSvg) icon.innerHTML = options.iconSvg;
        else icon.textContent = options.icon || presentation.symbol;
        icon.setAttribute('aria-hidden', 'true');
        header.appendChild(icon);
      }
      header.appendChild(this.createElement(ownerDocument, 'span', 'activity-summary', options.summary));
      header.appendChild(this.createElement(ownerDocument, 'span', 'activity-status', options.statusLabel || ''));
      const chevron = this.createElement(ownerDocument, 'span', 'activity-chevron');
      if (hasDetail) chevron.innerHTML = this.disclosureChevronSvg(expanded);
      header.appendChild(chevron);
      if (hasDetail && !forcedOpen) {
        header.addEventListener('click', () => {
          if (this.hasTextSelectionWithin(header)) return;
          expanded = !expanded;
          this.setActivityExpanded(turn, options.key, expanded);
          if (typeof options.onToggle === 'function') options.onToggle(expanded);
          header.setAttribute('aria-expanded', String(expanded));
          chevron.innerHTML = this.disclosureChevronSvg(expanded);
          if (!detail) return;
          if (expanded && !detailRendered) {
            options.renderDetail(detail);
            detailRendered = true;
          }
          detail.hidden = !expanded;
        });
      }
      headerRow.appendChild(header);
      section.appendChild(headerRow);
      if (hasDetail) {
        detail = this.createElement(ownerDocument, 'div', 'activity-detail');
        detail.hidden = !expanded;
        if (expanded) {
          options.renderDetail(detail);
          detailRendered = true;
        }
        section.appendChild(detail);
      }
      parent.appendChild(section);
      return section;
    },

    renderPlan(turn, parent) {
      const plan = turn.plan;
      if (!plan) return;
      const steps = Array.isArray(plan.steps) ? plan.steps : [];
      if (!steps.length && plan.status === 'running') return;
      const longPlan = steps.length > 5;
      if (turn.ui.planExpanded == null) {
        turn.ui.planExpanded = !longPlan;
        turn.ui.expanded.set('plan', turn.ui.planExpanded);
      }
      if (turn.executionStarted && longPlan && !turn.ui.planUserToggled) {
        turn.ui.planExpanded = false;
        turn.ui.expanded.set('plan', false);
      }
      const title = steps.length ? `计划 · ${steps.length} 步` : '计划';
      this.renderActivityDisclosure(parent, turn, {
        key: 'plan',
        summary: title,
        status: plan.status === 'failed' ? 'failed' : plan.status === 'running' ? 'running' : 'success',
        statusLabel: plan.status === 'running' ? '正在制定' : '',
        defaultExpanded: turn.ui.planExpanded,
        onToggle: (expanded) => {
          turn.ui.planExpanded = expanded;
          turn.ui.planUserToggled = true;
          turn.ui.expanded.set('plan', expanded);
        },
        renderDetail: (detail) => {
          const ownerDocument = detail.ownerDocument || document;
          const list = this.createElement(ownerDocument, 'ol', 'plan-list');
          steps.forEach((step) => list.appendChild(this.createElement(ownerDocument, 'li', '', step.title || '')));
          detail.appendChild(list);
        },
      });
    },

    detailField(list, label, value, code = false) {
      if (value === '' || value === null || value === undefined) return;
      const ownerDocument = list.ownerDocument || document;
      list.appendChild(this.createElement(ownerDocument, 'dt', '', label));
      const item = this.createElement(ownerDocument, 'dd');
      item.appendChild(this.createElement(ownerDocument, code ? 'code' : 'span', '', value));
      list.appendChild(item);
    },

    appendOutputSection(parent, label, value, className = '') {
      if (!value) return null;
      const ownerDocument = parent.ownerDocument || document;
      const section = this.createElement(ownerDocument, 'div', 'detail-section');
      section.appendChild(this.createElement(ownerDocument, 'div', 'detail-section-label', label));
      section.appendChild(this.createElement(ownerDocument, 'pre', `detail-output ${className}`.trim(), value));
      parent.appendChild(section);
      return section;
    },

    renderToolDetail(detail, turn, activity) {
      const ownerDocument = detail.ownerDocument || document;
      detail.appendChild(this.createElement(ownerDocument, 'div', 'detail-heading', 'Cocos MCP'));
      const grid = this.createElement(ownerDocument, 'dl', 'detail-grid');
      this.detailField(grid, '操作', activity.title || '调用 Cocos 工具');
      this.detailField(grid, 'Tool', activity.toolName || 'Unknown', true);
      this.detailField(grid, 'Server', activity.server, true);
      this.detailField(grid, '状态', this.statusPresentation(activity.status).label);
      this.detailField(grid, 'Raw status', activity.rawStatus || activity.status, true);
      this.detailField(grid, 'Target', activity.targetIdentity || activity.target, true);
      const semantic = classifyActivity(activity);
      this.detailField(grid, 'Context', semantic.context, true);
      this.detailField(grid, 'Semantic', `${semantic.action} / ${semantic.target} / ${semantic.lifecycle}`, true);
      this.detailField(grid, 'Classification evidence', semantic.evidence.join(', '), true);
      this.detailField(grid, 'Plan step', activity.activityPlanStep);
      this.appendOutputSection(detail, 'Effects metadata', activity.activityEvidence ? JSON.stringify(activity.activityEvidence, null, 2) : '');
      this.appendOutputSection(detail, 'Target / reference', activity.resolvedTarget ? JSON.stringify(activity.resolvedTarget, null, 2) : '');
      this.detailField(grid, 'Attempt ID', activity.attemptId, true);
      this.detailField(grid, 'Call ID', activity.callId, true);
      this.detailField(grid, 'Decision Trace', activity.traceId, true);
      if (activity.retryResolved) {
        this.detailField(grid, 'Retry', `已由 ${activity.resolvedByCallId || activity.resolvedByAttemptId || '后续调用'} 完成`, true);
      }
      detail.appendChild(grid);
      this.appendOutputSection(detail, '参数', activity.arguments);
      this.appendOutputSection(detail, activity.error ? 'Error' : 'Result', activity.error || activity.result);
      if (activity.outputOmitted) this.appendOutputSection(detail, '运行输出', '详细运行输出未保留');
      if (activity.rawResult && activity.rawResult !== activity.result) {
        const rawKey = `raw:${activity.id}`;
        const expanded = this.activityExpanded(turn, rawKey, false);
        const toggle = this.createElement(ownerDocument, 'button', 'inline-toggle', expanded ? '隐藏原始 Tool Output' : 'Show raw tool output');
        toggle.type = 'button';
        toggle.addEventListener('click', () => {
          turn.ui.expanded.set(rawKey, !expanded);
          this.renderTurn(turn);
        });
        detail.appendChild(toggle);
        if (expanded) this.appendOutputSection(detail, 'Raw output', activity.rawResult);
      }
    },

    renderToolActivity(parent, turn, activity, scope = '') {
      activity = activityForDisplay(activity, turn.status);
      const hasDetail = Boolean(activity.toolName || activity.arguments || activity.result || activity.rawResult || activity.error);
      const statusLabel = activity.status === 'running'
        ? 'Running'
        : activity.status === 'failed'
          ? 'Failed'
          : activity.status === 'blocked'
            ? (activity.retryResolved ? 'Blocked · 后续成功' : 'Blocked')
            : '';
      this.renderActivityDisclosure(parent, turn, {
        key: `${scope}tool:${activity.id}`,
        summary: this.activityLogSummary(activity),
        status: activity.retryResolved || activity.attemptFailed ? 'pending' : activity.status,
        statusLabel: activity.retryResolved ? '后续重试成功' : activity.attemptFailed ? '中间尝试' : statusLabel,
        defaultExpanded: activity.status === 'running'
          || (activity.status === 'failed' && !activity.attemptFailed && !activity.retryResolved)
          || (activity.status === 'blocked' && !activity.retryResolved),
        iconSvg: this.activitySummaryIconSvg(this.activityLogIconName(activity)),
        renderDetail: hasDetail ? (detail) => this.renderToolDetail(detail, turn, activity) : null,
      });
    },

    approvalDecisionLabel(decision) {
      if (typeof decision !== 'string') {
        if (typeof decision?.label === 'string' && decision.label.trim()) return decision.label.trim();
        if (decision?.permissionAction === 'deny') return '拒绝';
        if (decision?.permissionAction === 'grantForTurn') return '允许一次';
        if (decision?.acceptWithExecpolicyAmendment) return '允许类似命令';
        if (decision?.applyNetworkPolicyAmendment) {
          const action = decision.applyNetworkPolicyAmendment.network_policy_amendment?.action;
          if (action === 'deny') return '拒绝并记住此网络规则';
          if (action === 'allow') return '允许并记住此网络规则';
        }
        return JSON.stringify(decision);
      }
      return {
        decline: '拒绝', cancel: '取消并停止', accept: '允许一次',
        acceptForSession: '本次会话允许',
      }[decision] || decision;
    },

    approvalCommandForDisplay(command) {
      const raw = String(command || '').trim();
      const marker = /\s-(?:command|c)\s+/iu.exec(raw);
      if (!marker) return raw;
      const launcher = raw.slice(0, marker.index);
      if (!/(?:powershell|pwsh)(?:\.exe)?["']?\s*$/iu.test(launcher)) return raw;
      let inner = raw.slice(marker.index + marker[0].length).trim();
      if (inner.length > 1 && ((inner[0] === "'" && inner.at(-1) === "'")
        || (inner[0] === '"' && inner.at(-1) === '"'))) inner = inner.slice(1, -1);
      return inner.replace(/^&\s+/u, '').trim() || raw;
    },

    approvalCommandNetworkContext(params) {
      const command = this.approvalCommandForDisplay(params?.command);
      const explicitHost = String(params?.networkApprovalContext?.host || '').trim();
      const urlHost = /https?:\/\/([^\s/'"`]+)/iu.exec(command)?.[1] || '';
      return {
        command,
        host: explicitHost || urlHost,
        isHead: /(?:^|\s)(?:curl(?:\.exe)?)\b[\s\S]*(?:--head|-I)(?:\s|$)/iu.test(command),
      };
    },

    renderApprovalQuestion(parent, ownerDocument, question, commandContext) {
      const row = this.createElement(ownerDocument, 'div', 'approval-tray-question');
      if (commandContext?.host && commandContext.isHead) {
        row.appendChild(this.createElement(ownerDocument, 'span', '', '是否允许向 '));
        row.appendChild(this.createElement(ownerDocument, 'strong', '', commandContext.host));
        row.appendChild(this.createElement(ownerDocument, 'span', '', ' 发送这一次只读 '));
        row.appendChild(this.createElement(ownerDocument, 'strong', '', 'HEAD'));
        row.appendChild(this.createElement(ownerDocument, 'span', '', ' 请求？'));
      } else row.textContent = this.approvalSafeDetail(question);
      parent.appendChild(row);
      return row;
    },

    pendingApprovalsForSession(session) {
      return (session?.messages || [])
        .filter((turn) => turn.status === 'running')
        .flatMap((turn) => (turn.activities || [])
          .filter((activity) => activity.type === 'approval' && activity.approvalState === 'pending')
          .map((activity) => ({ turn, activity })))
        .sort((left, right) => left.activity.presentationOrder - right.activity.presentationOrder);
    },

    async submitNativeApprovalDecision(turn, activity, decision) {
      if (!activity || activity.submitting || activity.approvalState !== 'pending') return false;
      activity.submitting = true;
      this.renderApprovalTray();
      try {
        const result = await Editor.Message.request(EXTENSION_NAME, 'resolve-native-approval', {
          requestId: activity.requestId,
          sessionId: turn.sessionId,
          taskId: turn.taskId,
          threadId: activity.threadId,
          turnId: activity.turnId,
          decision,
        });
        if (!result || result.accepted !== true) {
          activity.submitting = false;
          activity.submitError = result && result.reason ? String(result.reason) : '审批已失效';
          this.renderApprovalTray();
          return false;
        }
        return true;
      } catch (error) {
        activity.submitting = false;
        activity.submitError = error.message;
        this.renderApprovalTray();
        return false;
      }
    },

    mcpElicitationTarget(params) {
      const displays = Array.isArray(params._meta?.tool_params_display)
        ? params._meta.tool_params_display : [];
      const candidates = displays.concat(Object.entries(params._meta?.tool_params || {})
        .map(([name, value]) => ({ name, value })));
      const isOpaque = (name, value) => /uuid|(?:^|_)id$/iu.test(name)
        || /^[0-9a-f]{8}-[0-9a-f-]{27,}$/iu.test(value)
        || (/^[A-Za-z0-9+/]{20,24}={0,2}$/u.test(value)
          && /[A-Z]/u.test(value) && /[a-z]/u.test(value) && /\d/u.test(value));
      for (const name of ['name', 'path', 'target', 'node', 'asset']) {
        const entry = candidates.find((item) => String(item?.name || '').toLowerCase() === name
          && typeof item.value === 'string' && item.value.trim());
        const value = String(entry?.value || '').trim();
        if (value && !isOpaque(name, value)) return value;
      }
      return '';
    },

    mcpElicitationTitle(params) {
      const toolName = String(params._meta?.tool_name
        || /tool\s+["“]([^"”]+)["”]/iu.exec(String(params.message || ''))?.[1] || '').trim();
      const target = this.mcpElicitationTarget(params);
      if (toolName === 'delete_node') return target
        ? `要允许 Codex 删除 ${target} 吗？` : '要允许 Codex 删除节点吗？';
      if (toolName === 'delete_asset') return target
        ? `要允许 Codex 删除 ${target} 吗？` : '要允许 Codex 删除资源吗？';
      return target ? `要允许 Codex 对 ${target} 执行此操作吗？` : '要允许 Codex 执行此操作吗？';
    },

    approvalSafeDetail(value, depth = 0) {
      return redactDisplayValue(value, depth);
    },

    renderApprovalTray() {
      const tray = this.$?.approvalTray;
      if (!tray) return;
      const pending = this._sessionView === 'conversation'
        ? this.pendingApprovalsForSession(this.activeSession()) : [];
      this.clearElement(tray);
      tray.hidden = pending.length === 0;
      if (!pending.length) return;
      const { turn, activity } = pending[0];
      const params = activity.params || {};
      const ownerDocument = tray.ownerDocument || document;
      const heading = this.createElement(ownerDocument, 'div', 'approval-tray-heading');
      const isCommand = activity.method === 'item/commandExecution/requestApproval';
      const isFile = activity.method === 'item/fileChange/requestApproval';
      const isPermission = activity.method === 'item/permissions/requestApproval';
      const isMcpElicitation = activity.method === 'mcpServer/elicitation/request';
      const isMcpApproval = isMcpElicitation && activity.requestKind === 'approval';
      const isInput = activity.requestKind === 'input';
      const requestKey = `${turn.taskId || ''}:${activity.requestId ?? ''}`;
      if (this._approvalTrayRequestKey !== requestKey) {
        this._approvalTrayRequestKey = requestKey;
        tray.scrollTop = 0;
      }
      tray.setAttribute('aria-label', isInput ? '待输入请求' : '待批准操作');
      const network = params.networkApprovalContext;
      const server = (this._environmentSnapshot?.mcpServers || [])
        .find((item) => item.id === params.serverName);
      const serverDisplayName = String(server?.displayName || params._meta?.connector_name
        || server?.name || params.serverName || 'MCP 工具');
      const source = isCommand ? '终端' : isFile ? '文件' : isPermission ? '权限'
        : isInput ? '需要你的输入'
          : server?.sourceType === 'project-extension' && /\bCocos MCP\b/iu.test(serverDisplayName)
            ? 'Cocos MCP' : serverDisplayName;
      const iconName = isCommand ? 'terminal' : isFile ? 'edit' : isPermission ? 'shield'
        : isInput ? 'input' : 'tool';
      const icon = this.createElement(ownerDocument, 'span', 'approval-tray-source-icon');
      icon.innerHTML = this.activitySummaryIconSvg(iconName);
      heading.appendChild(icon);
      heading.appendChild(this.createElement(ownerDocument, 'span', 'approval-tray-title', source));
      if (pending.length > 1) heading.appendChild(this.createElement(ownerDocument, 'span', 'approval-tray-count', `1 / ${pending.length}`));
      tray.appendChild(heading);
      const fileActivity = isFile ? turn.activities.find((item) => item.type === 'file_change' && item.id === params.itemId) : null;
      const file = fileActivity?.files?.[0];
      const fileName = this.fileDisplayParts(file?.path || params.grantRoot || '').name;
      const commandContext = isCommand ? this.approvalCommandNetworkContext(params) : null;
      const question = isMcpApproval ? this.mcpElicitationTitle(params)
        : isMcpElicitation ? String(params.message || '请提供输入。')
          : isCommand ? String(params.reason || (network?.host
            ? `要允许 Codex 访问 ${network.host} 吗？` : '要允许 Codex 运行此命令吗？'))
            : isFile ? `要允许 Codex 修改 ${fileName || '文件'} 吗？`
              : isPermission ? String(params.reason || '要允许 Codex 使用额外权限吗？')
                : String(params.questions?.[0]?.question || 'Codex 请求你的回答。');
      this.renderApprovalQuestion(tray, ownerDocument, question, commandContext);
      if (isCommand && params.command) tray.appendChild(this.createElement(ownerDocument,
        'pre', 'approval-tray-code', this.approvalSafeDetail(commandContext.command)));
      if (isFile && file) {
        const fileRow = this.createElement(ownerDocument, 'div', 'approval-tray-file');
        fileRow.appendChild(this.createElement(ownerDocument, 'span', 'approval-tray-file-name', fileName));
        if (Number.isInteger(file.additions) && Number.isInteger(file.deletions)) fileRow.appendChild(
          this.createElement(ownerDocument, 'span', 'approval-tray-file-stats',
            `+${file.additions} -${file.deletions}`));
        tray.appendChild(fileRow);
        if (file.diff) tray.appendChild(this.createElement(ownerDocument, 'pre', 'approval-tray-code',
          this.approvalSafeDetail(file.diff)));
      }
      const details = this.createElement(ownerDocument, 'details', 'approval-tray-details');
      details.appendChild(this.createElement(ownerDocument, 'summary', '', '查看详情'));
      const detailText = isCommand
        ? { method: activity.method, requestId: activity.requestId, command: params.command, cwd: params.cwd, reason: params.reason, commandActions: params.commandActions,
          networkApprovalContext: network, additionalPermissions: params.additionalPermissions }
        : isFile ? { method: activity.method, requestId: activity.requestId, grantRoot: params.grantRoot, reason: params.reason, files: fileActivity?.files }
          : isPermission ? { method: activity.method, requestId: activity.requestId, cwd: params.cwd, permissions: params.permissions, reason: params.reason }
            : isMcpElicitation ? { method: activity.method, requestId: activity.requestId, serverName: params.serverName,
              tool: params._meta?.tool_name, target: this.mcpElicitationTarget(params),
              parameters: params._meta?.tool_params, mode: params.mode,
              message: params.message, requestedSchema: params.requestedSchema,
              _meta: params._meta, url: params.url, elicitationId: params.elicitationId }
              : { method: activity.method, requestId: activity.requestId, questions: params.questions };
      details.appendChild(this.createElement(ownerDocument, 'pre', '', JSON.stringify(
        this.approvalSafeDetail(detailText), null, 2)));
      if (!isCommand) tray.appendChild(details);
      if (activity.unsupportedReason) tray.appendChild(this.createElement(ownerDocument,
        'div', 'approval-tray-warning', activity.unsupportedReason));
      const actions = this.createElement(ownerDocument, 'div', 'approval-tray-actions');
      const available = activity.availableDecisions || [];
      const isNegative = (decision) => decision === 'decline' || decision === 'cancel'
        || decision?.action === 'decline' || decision?.action === 'cancel'
        || decision?.permissionAction === 'deny'
        || decision?.applyNetworkPolicyAmendment?.network_policy_amendment?.action === 'deny';
      const isOnce = (decision) => decision === 'accept' || decision?.permissionAction === 'grantForTurn'
        || (decision?.action === 'accept' && !decision._meta?.persist);
      const isPersist = (decision) => decision === 'acceptForSession'
        || (decision?.action === 'accept' && ['session', 'always'].includes(decision._meta?.persist))
        || Boolean(decision?.acceptWithExecpolicyAmendment)
        || decision?.applyNetworkPolicyAmendment?.network_policy_amendment?.action === 'allow';
      const makeButton = (decision, className = '') => {
        const button = this.createElement(ownerDocument, 'button', className, this.approvalDecisionLabel(decision));
        button.type = 'button';
        button.disabled = Boolean(activity.submitting);
        button.addEventListener('click', () => this.submitNativeApprovalDecision(turn, activity, decision));
        return button;
      };
      if (isInput) available.forEach((decision) => actions.appendChild(makeButton(decision)));
      else {
        const negative = available.find(isNegative);
        const once = available.find(isOnce);
        const persist = available.filter(isPersist);
        if (negative) actions.appendChild(makeButton(negative, 'approval-tray-deny'));
        if (once && persist.length) {
          const row = this.createElement(ownerDocument, 'div', 'approval-tray-allow-row');
          row.appendChild(makeButton(once, 'approval-tray-allow'));
          const more = this.createElement(ownerDocument, 'button', 'approval-tray-more');
          more.innerHTML = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="m2.5 4.5 3.5 3 3.5-3" /></svg>';
          more.type = 'button';
          more.disabled = Boolean(activity.submitting);
          more.setAttribute('aria-label', '选择授权范围');
          more.setAttribute('aria-expanded', 'false');
          more.setAttribute('aria-controls', 'approvalScopeMenu');
          row.appendChild(more);
          actions.appendChild(row);
          const menu = this.createElement(ownerDocument, 'div', 'approval-tray-menu');
          menu.id = 'approvalScopeMenu';
          menu.hidden = true;
          [once, ...persist, ...available.filter((decision) => decision !== negative && decision !== once
            && !persist.includes(decision))].forEach((decision) => {
            const option = makeButton(decision, 'approval-tray-scope-option');
            if (decision?.acceptWithExecpolicyAmendment) {
              const label = option.textContent;
              option.textContent = '';
              option.appendChild(this.createElement(ownerDocument, 'span', '', label));
              const info = this.createElement(ownerDocument, 'span', 'approval-tray-scope-info');
              info.tabIndex = 0;
              info.setAttribute('role', 'note');
              info.setAttribute('aria-label', '查看允许范围');
              info.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.2"/><path d="M8 7.1v3.6M8 4.8h.01"/></svg>';
              info.addEventListener('click', (event) => {
                event.preventDefault();
                event.stopPropagation();
              });
              option.appendChild(info);
              option.appendChild(this.createElement(ownerDocument, 'span', 'approval-tray-scope-tooltip',
                `允许在此对话中使用以 ${commandContext.command} 开头的命令`));
            }
            menu.appendChild(option);
          });
          more.addEventListener('click', () => {
            menu.hidden = !menu.hidden;
            more.setAttribute('aria-expanded', String(!menu.hidden));
          });
          actions.appendChild(menu);
        } else {
          if (once) actions.appendChild(makeButton(once, 'approval-tray-allow'));
          available.filter((decision) => decision !== negative && decision !== once)
            .forEach((decision) => actions.appendChild(makeButton(decision)));
        }
      }
      tray.appendChild(actions);
      if (activity.submitError) tray.appendChild(this.createElement(ownerDocument, 'div', 'approval-tray-error', activity.submitError));
    },

    renderApprovalActivity(parent, turn, activity) {
      const ownerDocument = parent.ownerDocument || document;
      const state = activity.approvalState;
      const isInput = activity.requestKind === 'input';
      const label = state === 'pending' ? (isInput ? '● 需要你的输入' : '● 已请求权限')
        : state === 'approved' ? '✓ 已获得用户批准'
          : state === 'submitted' ? '✓ 已提供输入'
            : state === 'denied' ? (isInput ? '— 未提供输入' : '— 用户拒绝了操作')
              : state === 'cancelled' ? '— 已取消请求' : '— 审批已结束';
      const row = this.createElement(ownerDocument, 'div', 'approval-activity', label);
      if (state === 'pending') row.appendChild(this.createElement(ownerDocument, 'span', 'approval-activity-note',
        activity.unsupportedReason || '正在等待你的回答'));
      parent.appendChild(row);
    },

    renderCommandDetail(detail, activity) {
      const ownerDocument = detail.ownerDocument || document;
      detail.appendChild(this.createElement(ownerDocument, 'div', 'detail-heading', 'Shell'));
      if (activity.command) {
        const command = this.createElement(ownerDocument, 'div', 'command-line', `$ ${activity.command}`);
        command.title = activity.command;
        command.addEventListener('click', () => {
          if (this.hasTextSelectionWithin(command)) return;
          command.classList.toggle('is-expanded');
        });
        detail.appendChild(command);
      }
      this.appendOutputSection(detail, 'Output', activity.outputOmitted ? '详细运行输出未保留'
        : activity.output || (activity.status === 'success' ? 'No output' : ''));
      if (activity.error) this.appendOutputSection(detail, 'Error', activity.error);
      const grid = this.createElement(ownerDocument, 'dl', 'detail-grid detail-section');
      this.detailField(grid, '状态', this.statusPresentation(activity.status).label);
      this.detailField(grid, 'Raw status', activity.rawStatus || activity.status, true);
      if (activity.exitCode !== null && activity.exitCode !== undefined) {
        this.detailField(grid, 'Exit code', activity.exitCode, true);
      }
      detail.appendChild(grid);
    },

    renderCommandActivity(parent, turn, activity, scope = '') {
      activity = activityForDisplay(activity, turn.status);
      const summary = this.activityLogSummary(activity);

      this.renderActivityDisclosure(parent, turn, {
        key: `${scope}command:${activity.id}`,
        summary,
        status: activity.attemptFailed ? 'pending' : activity.status,
        statusLabel: activity.attemptFailed ? '中间尝试' : activity.status === 'running' ? 'Running' : activity.status === 'failed' ? 'Failed' : '',
        defaultExpanded: activity.status === 'running' || activity.status === 'failed' && !activity.attemptFailed,
        iconSvg: this.activitySummaryIconSvg('terminal'),
        renderDetail: (detail) => this.renderCommandDetail(detail, activity),
      });
    },

    fileDisplayParts(filePath) {
      const normalized = String(filePath || '').replace(/\\/g, '/');
      const index = normalized.lastIndexOf('/');
      return index === -1
        ? { name: normalized, directory: '' }
        : { name: normalized.slice(index + 1), directory: normalized.slice(0, index) };
    },

    renderFileDetail(detail, file) {
      const ownerDocument = detail.ownerDocument || document;
      const parts = this.fileDisplayParts(file.path);
      detail.appendChild(this.createElement(ownerDocument, 'div', 'detail-heading', parts.name));
      const grid = this.createElement(ownerDocument, 'dl', 'detail-grid');
      this.detailField(grid, '路径', file.originalPath || file.path, true);
      this.detailField(grid, '类型', file.kind || 'update');
      this.detailField(grid, 'Raw status', file.rawStatus || file.status, true);
      detail.appendChild(grid);
      if (file.diff) this.appendOutputSection(detail, 'Diff', file.diff, 'file-diff');
      if (file.outputOmitted) this.appendOutputSection(detail, '运行输出', '详细运行输出未保留');
      if (file.error) this.appendOutputSection(detail, 'Error', file.error);
    },

    renderFileRow(parent, turn, file, index, scope = '') {
      const parts = this.fileDisplayParts(file.path);
      const statsAvailable = Number.isInteger(file.additions) && Number.isInteger(file.deletions);
      const semantic = semanticActivity({ type: 'file_change', status: file.status, files: [file] });
      const summary = semantic.copy + ' · ' + parts.name
        + (statsAvailable ? '  +' + file.additions + ' -' + file.deletions : '');

      this.renderActivityDisclosure(parent, turn, {
        key: `${scope}file:${file.path}:${index}`,
        summary,
        status: file.status,
        statusLabel: '',
        defaultExpanded: file.status === 'failed',
        iconSvg: this.activitySummaryIconSvg('edit'),
        renderDetail: (detail) => this.renderFileDetail(detail, file),
      });
    },

    renderCocosChangeActivity(parent, turn, activity, scope = '') {
      const summary = this.activityLogSummary(activity);

      this.renderActivityDisclosure(parent, turn, {
        key: `${scope}cocos-change:${activity.id}`,
        summary,
        status: activity.status || 'success',
        iconSvg: this.activitySummaryIconSvg('tool'),
        renderDetail: (detail) => this.appendOutputSection(detail, 'Raw change', JSON.stringify(activity, null, 2)),
      });
    },

    flattenFileChanges(events) {
      const files = new Map();
      events.forEach((event) => {
        (event.files || []).forEach((file) => files.set(file.path, {
          ...files.get(file.path),
          ...file,
          status: event.status,
          rawStatus: event.rawStatus || event.status,
          error: event.error || file.error || '',
        }));
      });
      return Array.from(files.values()).filter((file) => file.path);
    },

    renderStateGuard(parent, turn, activity, scope = '') {
      const resolved = Boolean(activity.retryResolved);
      this.renderActivityDisclosure(parent, turn, {
        key: `${scope}state-guard:${activity.id}`,
        summary: resolved ? `${activity.action || '操作'} · 后续重试成功` : (activity.title || '已阻止操作'),
        status: resolved ? 'success' : 'warning',
        statusLabel: resolved ? 'Retry completed' : (activity.guardType || 'State Guard'),
        warning: !resolved,
        persistent: true,
        defaultExpanded: false,
        renderDetail: (detail) => {
          const ownerDocument = detail.ownerDocument || document;
          if (activity.action) detail.appendChild(this.createElement(ownerDocument, 'div', 'detail-heading', activity.action));
          const reason = activity.reason || activity.error || '操作被状态守卫阻止。';
          detail.appendChild(this.createElement(
            ownerDocument,
            'div',
            'state-guard-reason',
            resolved ? `${reason} 后续重试已成功完成。` : reason
          ));
          const fields = [
            ['Tool', activity.toolName],
            ['Decision', activity.decision],
            ['Decision Trace', activity.traceId],
            ['Request ID', activity.requestId],
            ['Resolved by', activity.resolvedByCallId || activity.resolvedByAttemptId],
          ];
          fields.forEach(([label, value]) => {
            if (!value) return;
            detail.appendChild(this.createElement(ownerDocument, 'div', 'tool-meta', `${label}: ${value}`));
          });
        },
      });
    },

    activitySummaryBehavior(activity) {
      if (activity.type === 'state_guard') return { key: 'guard', label: '检查了执行状态', priority: 55, icon: 'tool' };
      if (activity.type === 'approval') return { key: 'approval', label: activity.approvalState === 'pending'
        ? (activity.requestKind === 'input' ? '需要你的输入' : '已请求权限')
        : (activity.requestKind === 'input' ? '提供了输入' : '确认了操作'), priority: 50, icon: 'tool' };
      const semantic = semanticActivity(activity);
      const priority = activity.type === 'file_change' ? 10 : semantic.action === 'read' ? 20
        : semantic.target === 'preview' ? 45 : activity.type === 'command' ? 60 : 30;
      return { key: [semantic.action, semantic.target, semantic.context, semantic.lifecycle].join(':'),
        label: semantic.copy, priority, icon: this.activityLogIconName(activity) };
    },

    activityLogSummary(activity) {
      if (activity.retryResolved) return '本次尝试未成功，后续重试成功';
      if (activity.attemptFailed) return semanticActivity(activity).copy.replace(/失败$/u, '') + ' · 本次尝试未成功';
      return semanticActivity(activity).copy;
    },

    activityLogIconName(activity) {
      const toolName = String(activity.toolName || '').trim().toLowerCase();
      if (activity.type === 'command') return 'terminal';
      if (activity.type === 'file_change') return 'edit';
      if (['run_preview', 'run_project_preview', 'start_preview', 'stop_preview'].includes(toolName)) return 'preview';
      if (toolName === 'get_editor_state') return 'editor';
      if (['get_scene', 'get_scene_info', 'list_scenes'].includes(toolName)) return 'scene';
      if (['get_hierarchy', 'get_nodes', 'get_node'].includes(toolName)) return 'hierarchy';
      if (['get_components', 'get_component', 'inspect_component'].includes(toolName)) return 'component';
      if (['get_selection', 'inspect_node'].includes(toolName)) return 'selection';
      if (toolName === 'create_node') return 'node';
      if (['save_scene', 'save_current_scene'].includes(toolName)) return 'save';
      if (/^(?:read_|get_|list_|search_|inspect_)/.test(toolName)) return 'read';
      if (/^(?:create_|update_|set_|add_|attach_|remove_|delete_|move_|rename_|bind_|save_)/.test(toolName)) {
        return 'edit';
      }
      const semantic = classifyActivity(activity);
      if (semantic.action === 'input') return 'input';
      if (semantic.target === 'preview') return 'preview';
      if (semantic.target === 'component') return 'component';
      if (semantic.action === 'read') return 'read';
      return 'tool';
    },

    activitySummaryEntries(group) {
      const entries = new Map();
      const activities = group.activities || [];
      const tools = new Set(activities.filter((item) => item.type === 'tool').map((item) => item.id));
      const add = (activity) => {
        if (activity.retryResolved) return; // Detailed attempt history remains intact.
        if (activity.attemptFailed) {
          entries.set('attempt', { key: 'attempt', label: '包含中间尝试', priority: 70, firstSeen: entries.size });
          return;
        }
        const item = this.activitySummaryBehavior(activity);
        // Equal copy can collapse scene/node reads, but distinct lifecycle states stay visible.
        if (!entries.has(item.label)) entries.set(item.label, { ...item, firstSeen: entries.size });
      };
      activities.filter((item) => !(item.type === 'cocos_change' && tools.has(String(item.id).replace(/^cocos-change:/, '')))).forEach(add);
      (group.validations || []).filter((item) => !tools.has(String(item.id).replace(/^validation:/, '')))
        .forEach((item) => add({ ...item, type: 'validation' }));
      const values = Array.from(entries.values());
      return values.filter((item) => !item.key.startsWith('read:project:editor:') || !values.some((other) =>
        /^read:(?:scene|node):editor:/.test(other.key) && other.key.split(':').pop() === item.key.split(':').pop()))
        .sort((a, b) => a.priority - b.priority || a.firstSeen - b.firstSeen);
    },

    activityGroupSummary(group) {
      return this.activitySummaryEntries(group).map((item) => item.label).join(' ');
    },

    activityGroupOperationCount(group) {
      const activities = group.activities || [];
      const tools = activities.filter((item) => item.type === 'tool');
      const toolIds = new Set(tools.map((item) => String(item.id || '')));
      const knownTypes = new Set(['tool', 'command', 'file_change', 'cocos_change', 'state_guard', 'approval']);
      const fileRows = this.flattenFileChanges(activities.filter((item) => this.hasRealFileChange(item))).length;
      const fileErrors = activities.filter((item) => item.type === 'file_change' && !this.hasRealFileChange(item)).length;
      const commands = activities.filter((item) => item.type === 'command').length;
      const cocosChanges = activities.filter((item) => {
        if (item.type !== 'cocos_change') return false;
        const id = String(item.id || '');
        return !id.startsWith('cocos-change:') || !toolIds.has(id.slice('cocos-change:'.length));
      }).length;
      const guards = activities.filter((item) => item.type === 'state_guard').length;
      const approvals = activities.filter((item) => item.type === 'approval').length;
      const unknown = activities.filter((item) => !knownTypes.has(item.type)).length;
      const toolValidationIds = new Set(tools.map((item) => `validation:${item.id}`));
      const validations = (group.validations || []).filter((item) => !toolValidationIds.has(item.id)).length;
      return fileRows + fileErrors + tools.length + commands + cocosChanges + guards + approvals + unknown + validations;
    },

    activityGroupCollapsedSummary(group) {
      const count = this.activityGroupOperationCount(group);
      if (!count) return '';
      if (this.activityGroupHasFailure(group)) return `${count} 项操作中有失败`;
      if (this.pendingApprovalActivities(group).length) return `等待处理 ${count} 项操作`;
      if (this.activityGroupIsRunning(group)) return `正在执行 ${count} 项操作`;
      if ((group.activities || []).some(item => item.attemptFailed && !item.retryResolved)) return `${count} 项操作 · 含中间尝试`;
      return `已完成 ${count} 项操作`;
    },

    activityGroupIconName(group) {
      const activities = group.activities || [];
      if (activities.some((item) => item.type === 'file_change')) return 'edit';
      if (activities.some((item) => ['scene', 'node', 'component', 'preview', 'asset'].includes(classifyActivity(item).target))) return 'tool';
      return this.activitySummaryEntries(group)[0]?.icon || 'tool';
    },

    activitySummaryIconSvg(iconName) {
      const icons = {
        reconnecting: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1.5 5.5a10 10 0 0 1 13 0M4 8a6.2 6.2 0 0 1 8 0M6.5 10.5a2.3 2.3 0 0 1 3 0"></path><circle cx="8" cy="13" r=".5"></circle></svg>',
        'context-compaction': '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 2H3v12h2M11 2h2v12h-2M5.5 6h5M5.5 10h5M7 4l1 1 1-1M7 12l1-1 1 1"></path></svg>',
        edit: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m10.5 2.5 3 3-7.75 7.75-3.5.5.5-3.5L10.5 2.5Z"></path><path d="m9.25 3.75 3 3"></path></svg>',
        terminal: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2.25" y="2.75" width="11.5" height="10.5" rx="1.5"></rect><path d="m4.25 6 2 1.75-2 1.75M7.75 10h3.25"></path></svg>',
        read: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2.5 3.25c2.2-.55 3.85-.15 5.5 1.1v8.15c-1.65-1.25-3.3-1.65-5.5-1.1V3.25Z"></path><path d="M13.5 3.25c-2.2-.55-3.85-.15-5.5 1.1v8.15c1.65-1.25 3.3-1.65 5.5-1.1V3.25Z"></path></svg>',
        scene: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2.5" y="2.5" width="11" height="11" rx="1.5"></rect><path d="m4.5 10 2.25-2.25 1.75 1.5 1.5-1.5 1.5 2.25M10.75 5.25h.01"></path></svg>',
        editor: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2.5 4.25h4M9.5 4.25h4M2.5 8h7M12.5 8h1M2.5 11.75h2M7.5 11.75h6"></path><circle cx="8" cy="4.25" r="1.25"></circle><circle cx="11" cy="8" r="1.25"></circle><circle cx="6" cy="11.75" r="1.25"></circle></svg>',
        hierarchy: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="4" cy="3.5" r="1.25"></circle><circle cx="4" cy="12.5" r="1.25"></circle><circle cx="12" cy="8" r="1.25"></circle><path d="M4 4.75v6.5M5.25 8H10.75"></path></svg>',
        component: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2.5" y="2.5" width="4.5" height="4.5" rx=".75"></rect><rect x="9" y="2.5" width="4.5" height="4.5" rx=".75"></rect><rect x="2.5" y="9" width="4.5" height="4.5" rx=".75"></rect><rect x="9" y="9" width="4.5" height="4.5" rx=".75"></rect></svg>',
        selection: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="m3 2.5 8 5-3.5 1.25L6 12.5 3 2.5Z"></path><path d="m8 9 2.5 3"></path></svg>',
        node: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="5" cy="4" r="1.5"></circle><circle cx="5" cy="12" r="1.5"></circle><path d="M5 5.5v5M9.5 8h4M11.5 6v4"></path></svg>',
        save: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2.5 2.5h9l2 2v9h-11v-11Z"></path><path d="M5 2.5v4h6v-4M5 13.5v-4h6v4"></path></svg>',
        preview: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="5.5"></circle><path d="m6.75 5.5 4 2.5-4 2.5v-5Z"></path></svg>',
        shield: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.75 13 3.5v4.2c0 3-1.7 5.1-5 6.55-3.3-1.45-5-3.55-5-6.55V3.5L8 1.75Z"></path><path d="M8 5.25v3.5M8 11h.01"></path></svg>',
        input: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2.5" y="3" width="11" height="10" rx="2"></rect><path d="M5 6.25h6M5 9.5h3.5"></path></svg>',
        tool: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M9.7 2.1a3.5 3.5 0 0 0-4.4 4.4l-3.1 3.1a1.7 1.7 0 0 0 2.4 2.4l3.1-3.1a3.5 3.5 0 0 0 4.4-4.4L9.8 6.8 8 5l1.7-2.9Z"></path></svg>',
      };
      return icons[iconName] || icons.tool;
    },

    activityGroupIsRunning(group) {
      return (group.activities || []).some((item) => (
        ['running', 'pending'].includes(item.status)
        && !(item.type === 'approval' && item.approvalState === 'pending')
      )) || (group.validations || []).some((item) => item.status === 'running');
    },

    activityGroupHasFailure(group) {
      const tools = new Set((group.activities || []).filter(item => item.type === 'tool').map(item => String(item.id)));
      return (group.activities || []).filter(item => !(item.type === 'cocos_change'
        && tools.has(String(item.id).replace(/^cocos-change:/u, '')))).some((item) => (
        (item.status === 'failed' && !item.retryResolved && !item.attemptFailed)
        || (item.status === 'blocked' && !item.retryResolved)
      )) || (group.validations || []).some((item) => item.status === 'failed'
        && !tools.has(String(item.id).replace(/^validation:/u, '')));
    },

    activityGroupPresentation(turn, group, failedGroupKey = '') {
      const pendingRequests = this.pendingApprovalActivities(group);
      if (turn.status === 'running' && pendingRequests.length) {
        return { status: 'running', statusLabel: pendingRequests[0].requestKind === 'input'
          ? '等待输入' : '等待批准', defaultExpanded: true };
      }
      if (turn.status === 'running' && this.activityGroupIsRunning(group)) {
        return { status: 'running', statusLabel: '进行中', defaultExpanded: false };
      }
      if (turn.status === 'failed' && group.key === failedGroupKey) {
        return { status: 'failed', statusLabel: '失败', defaultExpanded: true };
      }
      return { status: 'pending', statusLabel: '', defaultExpanded: false };
    },

    pendingApprovalActivities(group) {
      return (group.activities || []).filter((activity) => (
        activity.type === 'approval' && activity.approvalState === 'pending'
      ));
    },

    renderGenericActivity(parent, turn, activity, scope = '') {
      const hasDetail = Boolean(activity.type || activity.title || activity.error || activity.result || activity.arguments || activity.rawResult);
      this.renderActivityDisclosure(parent, turn, {
        key: `${scope}activity:${activity.id}`,
        summary: this.activityLogSummary(activity),
        status: activity.status || 'pending',
        statusLabel: activity.status === 'failed' ? 'Failed' : '',
        defaultExpanded: activity.status === 'failed',
        renderDetail: hasDetail ? (detail) => {
          this.appendOutputSection(detail, 'Raw activity', `${activity.type || 'unknown'} / ${activity.status || 'unknown'} / ${activity.title || ''}`);
          this.appendOutputSection(detail, 'Error', activity.error);
          this.appendOutputSection(detail, 'Result', activity.result);
          this.appendOutputSection(detail, 'Arguments', activity.arguments);
          this.appendOutputSection(detail, 'Raw output', activity.rawResult);
        } : null,
      });
    },

    renderActivityGroupDetails(parent, turn, group, scope) {
      const activities = group.activities || [];
      const tools = activities.filter((item) => item.type === 'tool');
      const commands = activities.filter((item) => item.type === 'command');
      const files = activities.filter((item) => this.hasRealFileChange(item));
      const fileErrors = activities.filter((item) => item.type === 'file_change' && !this.hasRealFileChange(item));
      const cocosChanges = activities.filter((item) => item.type === 'cocos_change');
      const guards = activities.filter((item) => item.type === 'state_guard');
      const approvals = activities.filter((item) => item.type === 'approval');
      const knownTypes = new Set(['tool', 'command', 'file_change', 'cocos_change', 'state_guard', 'approval']);
      const mirroredChanges = new Map(cocosChanges
        .filter((item) => String(item.id || '').startsWith('cocos-change:'))
        .map((item) => [String(item.id).slice('cocos-change:'.length), item]));
      const toolIds = new Set(tools.map((item) => String(item.id || '')));
      const toolValidationIds = new Set(tools.map((item) => `validation:${item.id}`));

      this.flattenFileChanges(files).forEach((file, index) => (
        this.renderFileRow(parent, turn, file, index, scope)
      ));
      fileErrors.forEach((activity) => this.renderGenericActivity(parent, turn, activity, scope));
      tools.forEach((activity) => {
        const change = mirroredChanges.get(String(activity.id || ''));
        if (!change) {
          this.renderToolActivity(parent, turn, activity, scope);
          return;
        }
        const action = String(change.action || activity.title || '调用 Cocos 工具').trim();
        const target = String(change.target || '').trim();
        this.renderToolActivity(parent, turn, {
          ...activity,
          title: target && !action.includes(target) ? `${action} ${target}` : action,
        }, scope);
      });
      commands.forEach((activity) => this.renderCommandActivity(parent, turn, activity, scope));
      cocosChanges
        .filter((item) => {
          const id = String(item.id || '');
          return !id.startsWith('cocos-change:') || !toolIds.has(id.slice('cocos-change:'.length));
        })
        .forEach((activity) => this.renderCocosChangeActivity(parent, turn, activity, scope));
      guards.forEach((activity) => this.renderStateGuard(parent, turn, activity, scope));
      approvals.forEach((activity) => this.renderApprovalActivity(parent, turn, activity));
      (group.validations || []).filter((item) => !toolValidationIds.has(item.id)).forEach((item) => {
        this.renderActivityDisclosure(parent, turn, {
          key: `${scope}validation:${item.id}`,
          renderDetail: (detail) => this.appendOutputSection(detail, 'Raw validation', JSON.stringify(item, null, 2)),
          summary: this.activityLogSummary({ ...item, type: 'validation' }) + (item.status === 'manual' ? ' · 需要人工确认' : ''),
          status: item.status,
          statusLabel: item.status === 'running' ? 'Running' : '',
          iconSvg: this.activitySummaryIconSvg('tool'),
        });
      });
      activities.filter((item) => !knownTypes.has(item.type)).forEach((activity) => (
        this.renderGenericActivity(parent, turn, activity, scope)
      ));
    },

    renderActivityGroup(parent, turn, group, failedGroupKey = '') {
      group = { ...group,
        activities: (group.activities || []).map((item) => activityForDisplay(item, turn.status)),
        validations: (group.validations || []).map((item) => activityForDisplay(item, turn.status)),
      };
      const summary = this.activityGroupCollapsedSummary(group);
      if (!summary) return null;
      const scope = `presentation:${group.key}:`;
      const presentation = this.activityGroupPresentation(turn, group, failedGroupKey);
      const iconName = this.activityGroupIconName(group);
      const section = this.renderActivityDisclosure(parent, turn, {
        key: `${scope}summary`,
        summary,
        status: presentation.status,
        statusLabel: presentation.statusLabel,
        defaultExpanded: presentation.defaultExpanded,
        iconSvg: this.activitySummaryIconSvg(iconName),
        renderDetail: (detail) => this.renderActivityGroupDetails(detail, turn, group, scope),
      });
      section.classList.add('activity-group');
      return section;
    },

    renderRuntimeStatus(container, activity) {
      const ownerDocument = container.ownerDocument || document;
      const row = this.createElement(ownerDocument, 'div',
        `runtime-status${activity.status === 'running' ? ' is-running' : ''}`);
      row.setAttribute('role', 'status');
      const icon = this.createElement(ownerDocument, 'span');
      icon.innerHTML = this.activitySummaryIconSvg(activity.kind);
      row.appendChild(icon);
      row.appendChild(this.createElement(ownerDocument, 'span', 'runtime-status-label', activity.title));
      container.appendChild(row);
    },
  };
};
