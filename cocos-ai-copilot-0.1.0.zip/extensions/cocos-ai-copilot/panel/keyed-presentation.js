'use strict';

// Compare presentation data without serializing large raw tool-output strings.
function snapshot(value) {
  if (Array.isArray(value)) return value.map(snapshot);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, snapshot(item)]));
  }
  return value;
}

function equal(left, right) {
  if (left === right) return true;
  if (!left || !right || typeof left !== 'object' || typeof right !== 'object') return false;
  const keys = Object.keys(left);
  return keys.length === Object.keys(right).length
    && keys.every((key) => Object.hasOwn(right, key) && equal(left[key], right[key]));
}

// Each key owns a range of sibling nodes. Unchanged ranges remain connected:
// images, audio playback, focus and open disclosures survive unrelated events.
function reconcile(parent, descriptors, previous = new Map()) {
  const next = new Map();
  const desired = [];
  for (const item of descriptors) {
    let block = previous.get(item.key);
    if (!block || !equal(block.value, item.value)) {
      const stage = parent.ownerDocument.createElement('div');
      item.render(stage);
      block = { value: snapshot(item.value), nodes: Array.from(stage.children) };
    }
    next.set(item.key, block);
    desired.push(...block.nodes);
  }
  const keep = new Set(desired);
  for (const child of Array.from(parent.children)) if (!keep.has(child)) parent.removeChild(child);
  desired.forEach((node, index) => {
    if (parent.children[index] !== node) parent.insertBefore(node, parent.children[index] || null);
  });
  return next;
}

module.exports = { reconcile };
