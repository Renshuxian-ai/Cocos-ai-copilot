'use strict';

module.paths.push(Editor.App.path + '/node_modules');

const cc = require('cc');
const { director, Node, Component, Asset, Vec3, Quat, js } = cc;
const runtimeSceneMethods = require('./lib/cocos-runtime/scene-methods').methods;

const MAX_NODES = 5000;
const MAX_COMPONENTS_PER_NODE = 40;
const MAX_PROPERTIES_PER_COMPONENT = 120;
const MAX_SNAPSHOT_CHARS = 4 * 1024 * 1024;
const sceneDocuments = new WeakMap();
let nextDocument = 0;
const documentSession = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
let serializedProofs = new Map();

function captureSerializedProofs(scene) {
  serializedProofs = new Map();
  try {
    const serialized = globalThis.cce?.Utils?.serialize?.(scene);
    const records = typeof serialized === 'string' ? JSON.parse(serialized) : serialized;
    if (!Array.isArray(records)) return;
    const normalize = (value, depth = 0) => {
      if (depth > 20) throw new Error('Serialized proof exceeded depth limit.');
      if (!value || typeof value !== 'object') return value;
      if (Array.isArray(value)) return value.map(item => normalize(item, depth + 1));
      if (Number.isInteger(value.__id__)) {
        const target = records[value.__id__];
        if (!target) throw new Error('Invalid serialized reference.');
        return target._id ? { reference: target._id } : normalize(target, depth + 1);
      }
      return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, normalize(item, depth + 1)]));
    };
    for (const record of records) if (record?._id) serializedProofs.set(String(record._id), stableJson(normalize(record)));
  } catch (_) { serializedProofs.clear(); }
}

function getScene() {
  const scene = director.getScene();
  if (!scene) throw new Error('No active scene is loaded.');
  return scene;
}

function nodePath(node, activeScene = null) {
  const names = [];
  const scene = activeScene || getScene();
  let current = node;
  while (current && current !== scene) {
    names.unshift(current.name);
    current = current.parent;
  }
  return [scene.name, ...names].filter(Boolean).join('/');
}

function walk(node, visitor) {
  if (visitor(node) === false) return false;
  for (const child of node.children || []) if (walk(child, visitor) === false) return false;
  return true;
}

function findNode(uuid, activeScene = null) {
  const identity = String(uuid || '');
  if (!identity) return null;
  let match = null;
  walk(activeScene || getScene(), (node) => { if (!match && String(node.uuid || '') === identity) match = node; });
  return match;
}

function typeName(value) {
  return String(js?.getClassName?.(value) || value?.constructor?.name || 'Component');
}

function numericObject(value) {
  // Use one representation for each Creator value type; Color.xyzw are normalized aliases.
  const keys = ['r', 'g', 'b', 'a'].every(key => Number.isFinite(value?.[key])) ? ['r', 'g', 'b', 'a']
    : ['width', 'height'].every(key => Number.isFinite(value?.[key]))
      ? ((cc.Rect && value instanceof cc.Rect) || value?.constructor?.name === 'Rect' ? ['x', 'y', 'width', 'height'] : ['width', 'height'])
      : ['x', 'y', 'z', 'w'];
  const output = {};
  keys.forEach((key) => { if (Number.isFinite(value?.[key])) output[key] = Number(value[key]); });
  const prototype = value && Object.getPrototypeOf(value);
  if (value && (prototype === Object.prototype || prototype === null)
    && Object.keys(value).some(key => !keys.includes(key))) return null;
  return Object.keys(output).length ? output : null;
}

function serializableValue(value, depth = 0) {
  if (value == null || ['string', 'boolean'].includes(typeof value)) return { supported: true, value };
  if (typeof value === 'number') return { supported: Number.isFinite(value), value };
  if (depth > 5) return { supported: false, state: 'truncated' };
  if (Asset && value instanceof Asset) return { supported: true, value: { __assetUuid: String(value.uuid || value._uuid || ''), name: String(value.name || '') } };
  if (typeof value !== 'object' || value instanceof Node
    || value instanceof Component) return { supported: false, state: 'unsupported' };
  const numeric = numericObject(value);
  if (numeric && Object.keys(numeric).length >= 2) return { supported: true, value: numeric };
  if (Array.isArray(value)) {
    if (value.length > 60) return { supported: false, state: 'truncated' };
    const items = value.map((item) => serializableValue(item, depth + 1));
    return items.every((item) => item.supported)
      ? { supported: true, value: items.map((item) => item.value) }
      : { supported: false, state: items.find(item => !item.supported)?.state || 'unsupported' };
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) return { supported: false };
  const entries = Object.entries(value);
  if (entries.length > 40) return { supported: false, state: 'truncated' };
  const output = {};
  for (const [key, item] of entries) {
    if (key.startsWith('_')) return { supported: false };
    const normalized = serializableValue(item, depth + 1);
    if (!normalized.supported) return normalized;
    output[key] = normalized.value;
  }
  return { supported: true, value: output };
}

function componentProperties(component) {
  const declared = Array.isArray(component?.constructor?.__props__)
    ? component.constructor.__props__.filter((key) => typeof key === 'string' && !key.startsWith('_') && key !== 'node')
    : [];
  const properties = {};
  const reversibleProperties = [];
  const propertyStates = {};
  let completeness = Array.isArray(component?.constructor?.__props__) ? 'complete' : 'unknown';
  for (const key of declared.slice(MAX_PROPERTIES_PER_COMPONENT)) propertyStates[key] = 'omitted';
  if (declared.length > MAX_PROPERTIES_PER_COMPONENT) completeness = 'truncated';
  for (const key of declared.slice(0, MAX_PROPERTIES_PER_COMPONENT)) {
    let normalized;
    try { normalized = serializableValue(component[key]); } catch (_) { normalized = { supported: false, state: 'unavailable' }; }
    if (!normalized.supported) {
      propertyStates[key] = normalized.state || 'unsupported';
      if (completeness === 'complete' || ['truncated', 'omitted', 'unavailable'].includes(propertyStates[key])) completeness = propertyStates[key];
      continue;
    }
    propertyStates[key] = normalized.value === undefined ? 'undefined' : normalized.value === null ? 'null' : 'complete';
    properties[key] = normalized.value;
    reversibleProperties.push(key);
  }
  if (typeof component.enabled === 'boolean') { reversibleProperties.push('enabled'); propertyStates.enabled = 'complete'; }
  return { properties, reversibleProperties, propertyStates, completeness };
}

function snapshotComponent(component, index) {
  const type = typeName(component);
  const uuid = String(component?.uuid || component?._id || '');
  const values = componentProperties(component);
  return {
    id: uuid || `${type}:${index}`,
    uuid,
    type,
    index,
    enabled: typeof component.enabled === 'boolean' ? component.enabled : undefined,
    ...values,
    propertyCoverage: values.completeness,
    serializedProof: serializedProofs.get(uuid),
    // Native serialization retains reference identities and private serializable fields that
    // the readable property projection cannot represent. Never use projection equality alone.
    completeness: !serializedProofs.has(uuid) ? 'unknown'
      : ['truncated', 'omitted', 'unavailable'].includes(values.completeness) ? values.completeness : 'complete',
  };
}

function snapshotNode(node, activeScene = null) {
  const components = (node.components || []).slice(0, MAX_COMPONENTS_PER_NODE)
    .map((component, index) => snapshotComponent(component, index));
  return {
    uuid: String(node.uuid || ''),
    name: String(node.name || ''),
    path: nodePath(node, activeScene),
    parentUuid: String(node.parent?.uuid || ''),
    siblingIndex: typeof node.getSiblingIndex === 'function' ? node.getSiblingIndex() : 0,
    active: Boolean(node.active),
    position: numericObject(node.position),
    rotation: numericObject(node.rotation),
    scale: numericObject(node.scale),
    layer: node.layer,
    mobility: node.mobility,
    components,
    serializedProof: serializedProofs.get(String(node.uuid || '')),
    completeness: !serializedProofs.has(String(node.uuid || '')) ? 'unknown'
      : (node.components || []).length > MAX_COMPONENTS_PER_NODE ? 'truncated'
      : components.find(component => component.completeness !== 'complete')?.completeness || 'complete',
  };
}

function snapshotSubtree(node) {
  if (!node || !String(node.uuid || '')) return null;
  const nodes = [];
  let valid = true;
  walk(node, (current) => {
    if (!String(current?.uuid || '')) { valid = false; return false; }
    nodes.push(snapshotNode(current));
    return undefined;
  });
  return valid ? nodes : null;
}

function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`;
  if (!value || typeof value !== 'object') return JSON.stringify(value);
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(',')}}`;
}

function equal(left, right) {
  return stableJson(left) === stableJson(right);
}

function createdSubtreeProof(value) {
  if (!Array.isArray(value)) return value;
  // A created subtree owns its nodes and properties, not its position among
  // siblings. Creator's transient editor helpers can also change the raw
  // Scene-root sibling index during save/reload without changing user data.
  return value.map((node) => {
    if (!node || typeof node !== 'object') return node;
    const { siblingIndex: _volatileSiblingIndex, ...stable } = node;
    return stable;
  });
}

function equalCreatedSubtree(left, right) {
  return equal(createdSubtreeProof(left), createdSubtreeProof(right));
}

function componentByIdentity(node, change) {
  const components = node?.components || [];
  const uuid = String(change.componentUuid || '');
  if (uuid) {
    const matches = components.filter((component) => String(component?.uuid || component?._id || '') === uuid);
    return matches.length === 1 ? matches[0] : null;
  }
  const id = String(change.componentId || '');
  if (!id) return null;
  const separator = id.lastIndexOf(':');
  const expectedType = separator > 0 ? id.slice(0, separator) : '';
  if (!expectedType || components.filter((component) => typeName(component) === expectedType).length !== 1) return null;
  const matches = components.filter((component, index) => {
    const candidateType = typeName(component);
    return `${candidateType}:${index}` === id;
  });
  return matches.length === 1 ? matches[0] : null;
}

function readNodeProperty(node, property) {
  if (property === 'name') return node.name;
  if (property === 'parentUuid') return String(node.parent?.uuid || '');
  if (property === 'parentState') return {
    parentUuid: String(node.parent?.uuid || ''), siblingIndex: node.getSiblingIndex(),
  };
  if (property === 'siblingIndex') return node.getSiblingIndex();
  if (property === 'active') return Boolean(node.active);
  if (property === 'position') return numericObject(node.position);
  if (property === 'rotation') return numericObject(node.rotation);
  if (property === 'scale') return numericObject(node.scale);
  return undefined;
}

function restoreNodeProperty(node, change) {
  const value = change.before;
  if (change.property === 'name') node.name = String(value);
  else if (change.property === 'parentState') {
    const parent = findNode(value?.parentUuid);
    if (!parent) throw new Error('Original parent no longer exists.');
    node.parent = parent;
    node.setSiblingIndex(Number(value.siblingIndex));
  }
  else if (change.property === 'parentUuid') {
    const parent = findNode(value);
    if (!parent) throw new Error('Original parent no longer exists.');
    node.parent = parent;
  } else if (change.property === 'siblingIndex') node.setSiblingIndex(Number(value));
  else if (change.property === 'active') node.active = Boolean(value);
  else if (change.property === 'position') node.setPosition(new Vec3(value.x, value.y, value.z));
  else if (change.property === 'rotation') node.setRotation(new Quat(value.x, value.y, value.z, value.w));
  else if (change.property === 'scale') node.setScale(new Vec3(value.x, value.y, value.z));
  else throw new Error('Unsupported Node property.');
}

async function restoreComponentProperty(component, property, value) {
  if (property === 'enabled') {
    component.enabled = Boolean(value);
    return;
  }
  if (!Array.isArray(component?.constructor?.__props__) || !component.constructor.__props__.includes(property)) {
    throw new Error('Component property is no longer declared serializable.');
  }
  if (value?.__assetUuid) {
    component[property] = await new Promise((resolve, reject) => cc.assetManager.loadAny({ uuid:value.__assetUuid }, (error, asset) => error ? reject(error) : resolve(asset)));
    return;
  }
  const current = component[property];
  if (current && typeof current.set === 'function' && value && typeof value === 'object' && !Array.isArray(value)) {
    const shape = numericObject(current);
    const keys = Object.keys(shape || {});
    if (keys.length >= 2 && keys.every(key => Number.isFinite(value[key]))) {
      // Assign through the component setter as well: UITransform and renderers track changes there.
      const restored = typeof current.clone === 'function' ? current.clone() : new current.constructor();
      restored.set(...keys.map(key => value[key]));
      component[property] = restored;
      return;
    }
    throw new Error('Unsupported structured value restore contract.');
  }
  component[property] = value == null || typeof value !== 'object'
    ? value : JSON.parse(JSON.stringify(value));
}

const copilotSceneMethods = {
  async configureAudioSource(options = {}) {
    const scene=getScene();
    if(String(options.sceneUuid||'')!==String(scene.uuid||''))throw new Error('Scene changed before AudioSource configuration.');
    const normalize=value=>String(value||'').replace(/^\/+|\/+$/g,'');
    let node=options.targetUuid?findNode(options.targetUuid,scene):null,created=false;
    if(options.targetUuid&&!node)throw new Error('AudioSource target no longer exists.');
    if(!node){
      const expected=normalize(options.parentPath),matches=[];
      if(!expected)matches.push(scene);
      else walk(scene,current=>{const full=normalize(nodePath(current,scene)),relative=full.startsWith(scene.name+'/')?full.slice(scene.name.length+1):full;if(full===expected||relative===expected)matches.push(current);});
      if(matches.length!==1)throw new Error('AudioSource parent path is missing or not unique.');
      const nodeName=String(options.nodeName||'GameAudio'),existing=matches[0].children.filter(child=>child.name===nodeName);
      if(existing.length>1)throw new Error('AudioSource node name is not unique under the selected parent.');
      if(existing.length===1)node=existing[0];
      else{node=new Node(nodeName);matches[0].addChild(node);node.layer=matches[0].layer;created=true;}
    }
    let source=node.getComponent(cc.AudioSource),componentCreated=false;
    if(!source){source=node.addComponent(cc.AudioSource);componentCreated=true;}
    const clip=await new Promise((resolve,reject)=>cc.assetManager.loadAny({uuid:String(options.clipUuid||'')},(error,asset)=>error?reject(error):resolve(asset)));
    if(!(clip instanceof cc.AudioClip))throw new Error('Asset is not a Cocos AudioClip.');
    source.clip=clip;source.volume=Math.max(0,Math.min(1,Number(options.volume)));source.loop=Boolean(options.loop);source.playOnAwake=Boolean(options.playOnAwake);
    if(options.play===true)source.play();
    const state={sceneUuid:String(scene.uuid||''),nodeUuid:String(node.uuid||''),path:nodePath(node,scene),created,componentCreated,clipUuid:String(source.clip?.uuid||''),volume:source.volume,loop:source.loop,playOnAwake:source.playOnAwake,playing:Boolean(source.playing),state:source.state};
    return {...state,verified:state.clipUuid===String(options.clipUuid)&&Math.abs(state.volume-Number(options.volume))<1e-6&&state.loop===Boolean(options.loop)&&state.playOnAwake===Boolean(options.playOnAwake)};
  },
  async audioSourceState(options = {}) {
    const scene=getScene(),node=findNode(options.nodeUuid,scene),source=node?.getComponent(cc.AudioSource);
    if(!node||!source)return {verified:false,reason:'audio-source-missing',sceneUuid:String(scene.uuid||''),nodeUuid:String(options.nodeUuid||'')};
    const state={sceneUuid:String(scene.uuid||''),nodeUuid:String(node.uuid||''),path:nodePath(node,scene),clipUuid:String(source.clip?.uuid||''),clipName:String(source.clip?.name||''),volume:source.volume,loop:source.loop,playOnAwake:source.playOnAwake,playing:Boolean(source.playing),state:source.state,duration:source.duration,currentTime:source.currentTime};
    return {...state,verified:!options.clipUuid||state.clipUuid===String(options.clipUuid)};
  },
  async assetPreviewNodeState(options = {}) {
    const node = findNode(options.nodeUuid);
    const sprite = node?.getComponent(cc.Sprite), animation = node?.getComponent(cc.Animation);
    return { verified: Boolean(sprite?.spriteFrame && animation?.clips?.some(clip => clip?.uuid === options.clipUuid)),
      nodeUuid: node?.uuid || '', layer: node?.layer, spriteFrameUuid: sprite?.spriteFrame?.uuid || '',
      clipUuids: animation?.clips?.map(clip => clip?.uuid) || [], playOnLoad: animation?.playOnLoad };
  },
  async imageSpriteState(options = {}) {
    const scene=director.getScene(),node=findNode(options.nodeUuid,scene),sprite=node?.getComponent(cc.Sprite),transform=node?.getComponent(cc.UITransform);
    if(!node||!sprite||!transform)return {verified:false,reason:'sprite-missing',sceneUuid:String(scene?.uuid||''),nodeUuid:String(options.nodeUuid||'')};
    const state={sceneUuid:String(scene.uuid||''),nodeUuid:String(node.uuid||''),path:nodePath(node,scene),spriteFrameUuid:String(sprite.spriteFrame?.uuid||''),
      spriteType:sprite.type,sliced:sprite.type===cc.Sprite.Type.SLICED,width:transform.width,height:transform.height,anchorX:transform.anchorX,anchorY:transform.anchorY,trim:sprite.trim,sizeMode:sprite.sizeMode};
    return {...state,verified:Boolean(state.spriteFrameUuid)&&state.spriteFrameUuid===String(options.spriteFrameUuid||state.spriteFrameUuid)&&(options.sliced===undefined||state.sliced===Boolean(options.sliced))};
  },
  async assetPreviewClip(options = {}) {
    return require('./lib/asset-preview/clip-adapter').clipAdapter(cc, globalThis.cce, options);
  },
  async hasChangeTarget(options = {}) {
    const scene = director.getScene();
    return scene ? Boolean(findNode(options.nodeUuid, scene)) : false;
  },

  async captureChangeSnapshot() {
    const scene = director.getScene();
    if (!scene) return {
      available: false,
      reason: 'no-active-scene',
      capturedAt: Date.now(),
    };
    const nodes = [];
    captureSerializedProofs(scene);
    let approximateChars = 0;
    let truncated = false;
    walk(scene, (node) => {
      if (node === scene) return undefined;
      let branch = node;
      while (branch.parent && branch.parent !== scene) branch = branch.parent;
      if (['editor scene foreground', 'editor scene background'].includes(String(branch.name).toLowerCase())) return undefined;
      if (nodes.length >= MAX_NODES) { truncated = true; return false; }
      const snapshot = snapshotNode(node, scene);
      approximateChars += JSON.stringify(snapshot).length;
      if (approximateChars > MAX_SNAPSHOT_CHARS) { truncated = true; return false; }
      nodes.push(snapshot);
      return undefined;
    });
    if (!sceneDocuments.has(scene)) sceneDocuments.set(scene, `${documentSession}:${++nextDocument}`);
    return {
      available: true,
      scene: { uuid: String(scene.uuid || ''), name: String(scene.name || ''), documentId: sceneDocuments.get(scene) },
      nodes,
      truncated,
      completeness: truncated ? 'truncated' : nodes.find(node => node.completeness !== 'complete')?.completeness || 'complete',
      capturedAt: Date.now(),
    };
  },

  async applyInverseChanges(options = {}) {
    const changes = Array.isArray(options.changes) ? options.changes : [];
    const outcome = (change, status, reasonCode, extra = {}) => ({
      id: change.id,
      status,
      reasonCode,
      targetKind: String(change.kind || '').startsWith('component-') ? 'component' : 'node',
      targetLabel: change.nodePath || change.label || change.componentType || '',
      ...extra,
    });
    const failure = (status, reasonCode, message, extra = {}) => Object.assign(new Error(message), {
      undoStatus: status,
      reasonCode,
      ...extra,
    });
    let scene;
    try { scene = getScene(); } catch (error) {
      return { results: changes.map((change) => outcome(change, 'unavailable', 'scene-unavailable', {
        message: error.message,
      })) };
    }
    if (String(options.sceneUuid || '') !== String(scene.uuid || '')) {
      return { results: changes.map((change) => outcome(change, 'conflict', 'scene-mismatch')) };
    }
    const results = [];
    for (const change of changes) {
      try {
        captureSerializedProofs(scene);
        let reasonCode = '';
        let expectedAfter = change.after;
        let currentValue;
        let restoredValue = change.before;
        if (change.kind === 'node-create') {
          const node = findNode(change.nodeUuid, scene);
          if (!Array.isArray(change.afterSubtree) || !change.afterSubtree.length
            || change.afterSubtree.some(item => item.completeness !== 'complete')) {
            throw failure('unavailable', 'created-subtree-proof-missing', 'Created subtree proof is missing.');
          }
          const currentSubtree = snapshotSubtree(node);
          if (!node || !currentSubtree || !equalCreatedSubtree(currentSubtree, change.afterSubtree)) {
            throw failure('conflict', 'created-subtree-changed', 'Created subtree changed after the Turn.', {
              currentValue: node ? 'changed' : 'missing',
            });
          }
          node.removeFromParent();
          node.destroy();
          if (findNode(change.nodeUuid, scene)) throw failure('conflict', 'undo-readback-mismatch', 'Created node still exists.');
          reasonCode = 'node-create-reverted';
          expectedAfter = undefined;
          restoredValue = null;
        } else if (String(change.kind).startsWith('node-')) {
          const node = findNode(change.nodeUuid, scene);
          currentValue = node ? readNodeProperty(node, change.property) : undefined;
          if (!node || !equal(currentValue, change.after)) {
            throw failure('conflict', change.kind === 'node-rename'
              ? 'rename-current-value-changed' : 'current-value-changed',
            'Node current value differs from the recorded after value.', {
              expectedAfter: change.after,
              currentValue,
            });
          }
          restoreNodeProperty(node, change);
          currentValue = readNodeProperty(node, change.property);
          if (!equal(currentValue, change.before)) throw failure('conflict', 'undo-readback-mismatch', 'Node restore readback differs.', { currentValue });
          reasonCode = change.kind === 'node-rename' ? 'node-rename-reverted' : 'node-property-reverted';
        } else if (change.kind === 'component-add') {
          if (change.after?.completeness !== 'complete') throw failure('unavailable', 'component-proof-incomplete', 'Component snapshot is incomplete.');
          const node = findNode(change.nodeUuid, scene);
          const component = componentByIdentity(node, change);
          const index = node?.components?.indexOf(component) ?? -1;
          const current = node && component ? snapshotComponent(component, index) : undefined;
          if (!node || !component || !equal(current, change.after)) {
            throw failure('conflict', 'component-changed-or-missing', 'Component changed or is missing.');
          }
          node.removeComponent(component);
          if (typeof component.destroy === 'function') component.destroy();
          if (componentByIdentity(node, change)) throw failure('conflict', 'undo-readback-mismatch', 'Component still exists.');
          reasonCode = 'component-add-reverted';
          expectedAfter = undefined;
          restoredValue = null;
        } else if (change.kind === 'component-property') {
          const node = findNode(change.nodeUuid, scene);
          const component = componentByIdentity(node, change);
          if (!node || !component) throw failure('conflict', 'component-changed-or-missing', 'Component is missing.');
          const current = change.property === 'enabled'
            ? Boolean(component.enabled) : serializableValue(component[change.property]);
          currentValue = change.property === 'enabled' ? current : current.supported ? current.value : undefined;
          if (!equal(currentValue, change.after)) {
            throw failure('conflict', 'current-value-changed', 'Component current value differs from the recorded after value.', {
              expectedAfter: change.after,
              currentValue,
            });
          }
          await restoreComponentProperty(component, change.property, change.before);
          currentValue = change.property === 'enabled' ? Boolean(component.enabled)
            : serializableValue(component[change.property]).value;
          if (!equal(currentValue, change.before)) throw failure('conflict', 'undo-readback-mismatch', 'Component restore readback differs.', { currentValue });
          reasonCode = 'component-property-reverted';
        } else {
          results.push(outcome(change, 'irreversible', 'unsafe-undo-unavailable', {
            message: change.reason || 'This change cannot be restored automatically.',
          }));
          continue;
        }
        results.push(outcome(change, 'restored', reasonCode, {
          verified: true,
          ...(expectedAfter !== undefined ? { expectedAfter } : {}),
          ...(currentValue !== undefined ? { currentValue } : {}),
          restoredValue,
        }));
      } catch (error) {
        results.push(outcome(change, error.undoStatus || 'conflict', error.reasonCode || 'scene-undo-failed', {
          message: error.message,
          ...(Object.prototype.hasOwnProperty.call(error, 'expectedAfter') ? { expectedAfter: error.expectedAfter } : {}),
          ...(Object.prototype.hasOwnProperty.call(error, 'currentValue') ? { currentValue: error.currentValue } : {}),
        }));
      }
    }
    return { results };
  },
};

const sceneMethodCollisions = Object.keys(copilotSceneMethods)
  .filter((name) => Object.prototype.hasOwnProperty.call(runtimeSceneMethods, name));
if (sceneMethodCollisions.length) {
  throw new Error(`Cocos Runtime scene method collision: ${sceneMethodCollisions.join(', ')}`);
}

exports.methods = { ...runtimeSceneMethods, ...copilotSceneMethods };
